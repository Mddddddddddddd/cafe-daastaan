# تغییر ۱۳۳ — واترمارک قابل کنترل، بزرگنمایی عکس، مدیریت باشگاه مشتریان، دسته‌بندی واقعی

## ۱) واترمارک (حذف + گزینه‌ی ادمین)
- پیش‌فرض: **خاموش** (تا ادمین روشنش نکند)
- تنظیم در: پنل ادمین ← «مدیریت صفحه اصلی» ← چک‌باکس «واترمارک روی عکس محصولات» → ذخیره صفحه اصلی
- بک‌اند: `homeSections.watermark` (بدون تغییر schema)
- endpoint جدید سبک: `GET /menu/home` (فقط تنظیمات صفحه اصلی)
- فرانت: `components/WatermarkPreference.tsx` → کلاس `wm-off` روی `<html>` → CSS: `html.wm-off .productImageWatermark:after{display:none}`

## ۲) بزرگنمایی عکس محصول (lightbox)
- `backgroundSize` از `cover` به **`contain`** → کل عکس دیده می‌شه (بدون برش)
- پس‌زمینه‌ی lightbox تیره شد تا حاشیه‌ها تمیز باشه

## ۳) مدیریت باشگاه مشتریان (تب جدید در صفحه ادمین)
- endpointهای جدید (guard: ADMIN):
  - `GET /loyalty/admin/members?q=` — لیست اعضا + ۳ تراکنش آخر
  - `PATCH /loyalty/admin/members/:id` — `{ delta, tier }` (اعطا/کسر امتیاز + تغییر تیر؛ با ثبت در LoyaltyHistory)
  - `GET /loyalty/admin/reward-codes` — کدهای جایزه صادرشده
  - `POST /loyalty/admin/reward-codes/:id/disable` — غیرفعال‌سازی کد (voucher + discountCode)
- فرانت: Section «مدیریت باشگاه مشتریان» — جستجوی عضو، اعطا/کسر امتیاز، تغییر تیر (۴ تیر)، لیست کدها + غیرفعال‌سازی
- فایل جدید: `backend/src/modules/loyalty/loyalty-admin.controller.ts`
- LoyaltyModule: import AuthModule + ثبت controller جدید

## ۴) دسته‌بندی منو (فیکس باگ)
- **مشکل:** دسته‌بندی‌ها در `RemoteMenu.tsx` **hardcoded** بودند → دسته‌های ساخته‌شده در «مدیریت دسته‌بندی» نمایش نمی‌داد
- **فیکس:** endpoint جدید `GET /menu/categories` (دسته‌های فعال از دیتابیس، مرتب بر اساس displayOrder) + فرانت حالا از دیتابیس می‌خواند (فالبک: لیست قدیمی فقط اگر endpoint در دسترس نباشد)

## تست‌ها (لوکال)
- build بک‌اند ✅ · build فرانت ✅
- `GET /menu/categories` ✅ · `GET /menu/home` ✅ · بدون تداخل route با `:id` ✅
- guard loyalty admin: بدون توکن 401 ✅

## Deploy (هر دو بک‌اند و فرانت تغییر کردند)
```bash
cd /var/www
unzip -o /مسیر/فایل/cafe-dastan-final-customer-scoped-complete.zip
cd /var/www/cafe-dastan/backend
npm install
npm run build
pm2 restart cafe-dastan-backend
cd /var/www/cafe-dastan/frontend
rm -rf .next
npm install
npm run build
pm2 delete cafe-dastan-frontend 2>/dev/null
pm2 start node_modules/next/dist/bin/next --name cafe-dastan-frontend -- start -p 3000
pm2 save
```
- schema تغییر نکرده → prisma:push لازم نیست
- ⚠️ استارت فرانت حتماً با `node_modules/next/dist/bin/next` (نه `.bin/next` — باگ shim)
