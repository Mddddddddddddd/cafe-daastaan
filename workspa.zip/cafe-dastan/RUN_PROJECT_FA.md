# راهنمای اجرای پروژه کافه داستان

## ساختار پروژه
- `frontend/` فرانت‌اند Next.js-style
- `backend/` بک‌اند NestJS-style
- `prototype/` نسخه نمایشی HTML اولیه
- `app/` مستندات و طرح سیستم

## پیش‌نیازها
- Node.js 18+
- npm
- PostgreSQL (برای مرحله دیتابیس)

---

## 1) اجرای بک‌اند
```bash
cd cafe-dastan/backend
cp .env.example .env
npm install
npx prisma generate
npm run start:dev
```

بک‌اند روی این آدرس بالا می‌آید:
- `http://localhost:4000`

### اگر دیتابیس PostgreSQL آماده داری
```bash
npx prisma db push
npx ts-node prisma/seed.ts
```

> در فایل `.env` مقدار `DATABASE_URL` را با دیتابیس خودت تنظیم کن.

---

## 2) اجرای فرانت‌اند
در ترمینال جدید:
```bash
cd cafe-dastan/frontend
cp .env.local.example .env.local
npm install
npm run dev
```

فرانت‌اند روی این آدرس بالا می‌آید:
- `http://localhost:3000`

> در فایل `.env.local` آدرس API این است:
```env
NEXT_PUBLIC_API_BASE_URL="http://localhost:4000"
```

---

## 3) مسیرهای مهم فرانت‌اند
- `/` صفحه اصلی منو
- `/product/p1` جزئیات محصول
- `/cart` سبد خرید
- `/checkout` نهایی‌سازی سفارش
- `/tracking/1042` رهگیری سفارش
- `/story` داستان من
- `/notifications` اعلان‌ها
- `/auth/login` ورود مشتری
- `/admin/login` ورود ادمین
- `/bar/login` ورود بار
- `/kitchen/login` ورود آشپزخانه
- `/waiter/login` ورود گارسون

---

## 4) endpointهای مهم بک‌اند
- `POST /auth/request-otp`
- `POST /auth/verify-otp`
- `POST /auth/staff-login`
- `GET /menu`
- `GET /menu/:id`
- `POST /orders`
- `GET /orders/:id`
- `PATCH /orders/:id/status`
- `GET /notifications`
- `POST /notifications/broadcast`
- `GET /staff/bar/orders`
- `PATCH /staff/bar/orders/:id/advance`
- `GET /staff/kitchen/orders`
- `PATCH /staff/kitchen/orders/:id/advance`
- `GET /staff/waiter/tables`
- `PATCH /staff/waiter/tables/:id/resolve`

---

## 5) لاگین نمونه
### مشتری
- هر شماره‌ای وارد شود، OTP نمونه برمی‌گردد
- کد نمونه: `123456`

### کارکنان
برای نقش‌ها می‌توانی از این نام‌های کاربری نمونه استفاده کنی:
- `admin`
- `bar`
- `kitchen`
- `waiter`

رمز عبور فعلاً نمایشی است.

---

## 6) وضعیت فعلی پروژه
### آماده و ساخته‌شده
- منوی دیجیتال موبایل‌فرست
- جستجو و فیلتر
- جزئیات محصول
- سبد خرید
- Checkout
- رهگیری سفارش
- اعلان‌ها
- داستان من
- پنل ادمین
- پنل بار
- پنل آشپزخانه
- پنل گارسون
- بک‌اند اولیه
- Prisma schema
- seed data
- اتصال فرانت و بک‌اند

### هنوز برای production نهایی نشده
- JWT واقعی production-grade
- RBAC کامل production-grade
- OTP پیامکی واقعی
- Realtime با WebSocket
- اتصال POS و Printer
- مدیریت موجودی واقعی کامل
- چندزبانه کامل
- نوتیفیکیشن Push واقعی

---

## 7) فایل‌های اصلی برای شروع
### فرانت
- `frontend/app/page.tsx`
- `frontend/app/checkout/page.tsx`
- `frontend/app/product/[id]/page.tsx`
- `frontend/lib/api.ts`

### بک‌اند
- `backend/src/app.module.ts`
- `backend/src/modules/auth/auth.controller.ts`
- `backend/src/modules/menu/menu.controller.ts`
- `backend/src/modules/orders/orders.controller.ts`
- `backend/src/modules/staff/staff.controller.ts`
- `backend/prisma/schema.prisma`

---

## 8) اگر فقط بخواهی سریع اجرا کنی
### بک‌اند
```bash
cd cafe-dastan/backend
cp .env.example .env
npm install
npx prisma generate
npm run start:dev
```

### فرانت‌اند
```bash
cd cafe-dastan/frontend
cp .env.local.example .env.local
npm install
npm run dev
```

تمام.
