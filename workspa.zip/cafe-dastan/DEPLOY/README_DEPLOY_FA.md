# راهنمای Deploy — سرور VPS

- بک‌اند: `/var/www/cafe-dastan/backend` → PM2: `cafe-dastan-backend` (port 4000)
- فرانت: `/var/www/cafe-dastan/frontend` → PM2: `cafe-dastan-frontend` (port 3000)
- دامنه: `cafedaastaan.ir` / ساب‌دامین API: `api.cafedaastaan.ir` (هرگز `cafedastan.ir`)
- `.env` بک‌اند: `/var/www/cafe-dastan/backend/.env` (نسخه دقیق پراکشن توی پروژه محلی هم هست)
- `.env.local` فرانت: `NEXT_PUBLIC_API_BASE_URL=https://api.cafedaastaan.ir`
- لیمیت‌های حجمی رسانه (اختیاری، پیش‌فرض video=500 / image=50):
  `MEDIA_MAX_VIDEO_MB` و `MEDIA_MAX_IMAGE_MB` در `.env` بک‌اند

## فایکس 413 (محدودیت Nginx) — شامل ویدیوهای حجیم استوری
هر دو کانفیگ Nginx فاقد `client_max_body_size` بودند (پیش‌فرض 1MB).
- API: **550m** (ویدیو 500MB + overhead multipart)
- دامنه اصلی: **30m**
نسخه‌های کامل اصلاح‌شده: همین پوشه (`nginx-api-cafedaastaan.conf` → باید برود به `api.cafedaastaan.ir` و `nginx-cafedaastaan.conf` → به `cafedaastaan.ir`)

اعمال سریع بدون ویرایش دستی:

```bash
# ⚠️ نام فایل‌های فعال با پسوند .ir است (api.cafedaastaan.ir / cafedaastaan.ir) — فایل‌های api-cafedaastaan و cafedaastaan غیرفعال‌اند!
sudo sed -i '/server_name api.cafedaastaan.ir;/a\    client_max_body_size 550m;' /etc/nginx/sites-available/api.cafedaastaan.ir
sudo sed -i '/server_name cafedaastaan.ir www.cafedaastaan.ir;/a\    client_max_body_size 30m;' /etc/nginx/sites-available/cafedaastaan.ir
sudo nginx -t && sudo systemctl reload nginx
grep -n client_max_body_size /etc/nginx/sites-available/*
```

## ترتیب deploy بعد از تغییر کد
**بک‌اند (اول):**
```bash
cd /var/www/cafe-dastan/backend
npm install
npm run prisma:generate
npm run prisma:push   # فقط اگر schema تغییر کرده
npm run build
pm2 restart cafe-dastan-backend
```
**فرانت (بعد):**
```bash
cd /var/www/cafe-dastan/frontend
rm -rf .next
npm install
npm run build
pm2 delete cafe-dastan-frontend 2>/dev/null
pm2 start node_modules/next/dist/bin/next --name cafe-dastan-frontend -- start -p 3000
pm2 save
```
> ⚠️ اگر فرانت قبلاً در PM2 بود حتماً اول `pm2 delete` بزن (دوتایی شدن فرانت = bug شبکه)
> ⚠️ حتماً `node_modules/next/dist/bin/next` را استارت کن، نه `node_modules/.bin/next` — روی این سرور `.bin/next` اسکریپت shell است و PM2 (Node) نمی‌تواند آن را اجرا کند (SyntaxError).
