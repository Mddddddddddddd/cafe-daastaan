# تغییر ۱۳۷ — تشخیص دقیق Push، تب آیتم‌های باز، گام‌های رهگیری پویا و کوتاه، بکاپ قابل‌دانلود، رفع نصب PWA پنل‌ها

## ۱) دکمه‌ی نوتیفیکیشن — تشخیص دقیق مشکل (به‌جای «پشتیبانی نمی‌کند» کورکورانه)
`components/StaffPushBell.tsx` بازنویسی شد؛ حالا هر مشکل پیام **خاص خودش** را دارد:
| وضعیت | پیام |
|-------|------|
| ورود از غیر-https | «⚠️ برای نوتیفیکیشن باید با آدرس https وارد شوید» |
| مرورگر قدیمی/ناسازگار | «🔕 مرورگر این گوشی نوتیفیکیشن وب را پشتیبانی نمی‌کند (کروم به‌روز را امتحان کن)» |
| **سرور بدون VAPID** | «⚠️ نوتیفیکیشن سمت سرور فعال نیست — با مدیریت سایت تماس بگیر» |
| مسدودشده در مرورگر | «🔕 از آیکون قفل در نوار آدرس، اعلان‌ها را Allow کن» |
| خطای ثبت | «⚠️ فعال‌سازی ناموفق بود — دوباره تلاش کن» (با دکمه‌ی ری‌تروی) |

⚠️ **نکته‌ی مهم:** در نسخه‌ی قبلی اگر کلیدهای VAPID در `.env` سرور نباشد، همان پیام «پشتیبانی نمی‌کند» را نشان می‌داد (درها!) — الان این دو از هم جدا شدند. اول مطمئن شو ۳ خط VAPID در `/var/www/cafe-dastan/backend/.env` هست:
```
grep VAPID /var/www/cafe-dastan/backend/.env
```
اگر چیزی نشان نداد، این خط:
```
echo -e "VAPID_PUBLIC_KEY=BAoyvfU_5-6NIaSLzXPEkz_UwakXKLJ1yrJVs_ILDMCSSeibT1naP3m_uowPLo7csrKxHLW4wRInw7Vb0hWFf2M\nVAPID_PRIVATE_KEY=eiN_1yG0UeRe0F2TOPuMusyHSvwg1GT7zRUOs7YQu_E\nVAPID_CONTACT=mailto:admin@cafedaastaan.ir" >> /var/www/cafe-dastan/backend/.env
```
و بعد `pm2 restart cafe-dastan-backend`.

## ۲) تب «آیتم‌های همین سفارش» از همان ابتدا باز
`<details>` صفحه‌ی رهگیری با `open` → آیتم‌ها بلافاصله دیده می‌شوند؛ کاربر می‌تواند با لمس summary آن را ببندد.

## ۳) گام‌های رهگیری — کوتاه، پویا و بدون مراحل اضافی
**قبل:** ۶ گام ثابت (درحال بررسی / درحال آماده‌سازی در بار / درحال آماده‌سازی در آشپزخانه / آماده سرو / در مسیر میز / تحویل شد) + ۲ گام پرداخت جدا.
**حالا:**
- برچسب‌های کوتاه: **ثبت شد · آماده‌سازی بار · آماده‌سازی آشپزخانه · آماده سرو · تحویل شد**
- **پویا:** اگر سفارش فقط آشپزخانه باشد، گام «آماده‌سازی بار» اصلاً نمی‌آید (و برعکس)
- «در مسیر میز» **حذف** شد (ON_THE_WAY به گام «آماده سرو» می‌رسد)
- بخش ۲ گامی «پرداخت نشده/پرداخت شده» از تایم‌لاین حذف شد (برچسب پرداخت در همان ردیف بالا باقی است)
- برای این کار backend در `mapOrder` فیلد `station` را به هر آیتم اضافه می‌کند
- متن وضعیت زیر عنوان هم بر اساس وضعیت واقعی سفارش می‌آید

## ۴) دانلود بکاپ — دو باگ واقعی رفع شد
**باگ ۱ (سرور):** قبل از ارسال، ZIP کامل در فایل temp ساخته می‌شد و اگر وسط استریم خطا می‌افتاد، مرورگر فایل ناقص/خالی می‌گرفت. حالا:
- `backup.service.ts`: `buildProductsZip` / `buildFullZip` → ساخت کامل روی دیسک (`os.tmpdir()`)
- `backup.controller.ts`: ارسال فایل کامل با `Content-Length` صحیح + پاک‌سازی temp بعد از ارسال + هر خطا **قبل** از ارسال هدرها به‌صورت JSON بازمی‌گردد
**باگ ۲ (مرورگر موبایل):** در `admin/page.tsx` بعد از `a.click()` بلافاصله `URL.revokeObjectURL` زده می‌شد — در مرورگرهای موبایل این کار دانلود را **نصفه‌کاره/بدون** باقی می‌گذاشت. حالا revoke با ۶۰ ثانیه تأخیر.
**علاوه‌بر این:** پیام خطای واقعی سرور در صفحه نمایش داده می‌شود (نه «ناموفق بود» کور) + هشدار «بکاپ کامل ممکن است ۱-۲ دقیقه طول بکشد» + بررسی فایل خالی.
⚠️ اگر بکاپ **کامل** (db.json + کل uploads) خیلی بزرگ باشد و در پروکسی سرور قطع شود، در `/etc/nginx/sites-available/api.cafedaastaan.ir` این دو خط را اضافه کن و `sudo nginx -t && sudo systemctl reload nginx`:
```
proxy_read_timeout 900s;
proxy_send_timeout 900s;
```

## ۵) نصب PWA پنل‌ها — فنی + روش صحیح نصب
**فنی:** manifestهای پنل‌ها به‌جای `.webmanifest` با پسوند `.json` سرو می‌شوند (همان فرمتی که اپ اصلی با `manifest.json` روی گوشی‌ها درست نصب می‌شود):
- `public/manifest-kitchen.json`، `manifest-bar.json`، `manifest-waiter.json`، `manifest-admin.json`
- `app/{kitchen,bar,waiter,admin}/layout.tsx` → `metadata.manifest` هر صفحه فقط manifest خودش را لینک می‌کند (تست‌شده: هر صفحه دقیقاً یک link دارد)

**روش صحیح نصب (مهم‌ترین بخش!):**
1. داخل **اپ نصب‌شده‌ی اصلی کافه داستان** نمی‌شود اپ جدید نصب کرد — باید از **مرورگر کروم** (نه اپ) استفاده کنی
2. در کروم، مستقیم آدرس پنل را باز کن: `https://cafedaastaan.ir/kitchen` (یا bar / waiter / admin)
3. وارد شو و صبر کن صفحه کامل لود شود
4. روی **آیکون نصب در نوار آدرس** بزن (بالای صفحه، آیکون مانیتور/فلش به سمت پایین) — در تنظیمات ⋮ هم «نصب برنامه / Install app» هست
5. اگر «کافه داستان» اصلی پیشنهاد شد، یعنی هنوز داخل اپ قدیمی هستی؛ برگرد به کروم و از مرحله ۲ شروع کن
6. بعد از نصب، آیکون رنگی با حرف نقش (K/B/W/A) در صفحه‌ی اصلی گوشی می‌آید و مستقیم همان پنل باز می‌شود

## deploy (بعد از آپلود و extract ZIP)
```
cd /var/www/cafe-dastan/backend && npm run build
```
```
cd /var/www/cafe-dastan/frontend && npm run build
```
```
pm2 restart cafe-dastan-backend cafe-dastan-frontend
```
بدون تغییر schema، بدون dependency جدید، بدون env جدید.

## فایل‌های دست‌کاری‌شده
**backend:**
- `src/prisma/db-mapper.ts` (station در آیتم‌های سفارش)
- `src/modules/backup/backup.service.ts` (بکاپ به temp file)
- `src/modules/backup/backup.controller.ts` (ارسال فایل کامل)

**frontend:**
- `components/StaffPushBell.tsx` (تشخیص دقیق وضعیت‌ها)
- `app/tracking/[id]/page.tsx` (گام‌های پویا + details باز)
- `app/admin/page.tsx` (دانلود با revoke دیرهنگام + خطای واقعی)
- `public/manifest-{kitchen,bar,waiter,admin}.json` (**جدید** — جایگزین .webmanifest)
- `app/{kitchen,bar,waiter,admin}/layout.tsx` (آپدیت آدرس manifest)
