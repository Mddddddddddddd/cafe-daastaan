# تغییر ۱۳۴ — ایستگاه‌ها (ناموجود/پنهان)، بکاپ، نظرسنجی کامل‌تر، پاپ‌آپ نظرسنجی، شخصی‌سازی در پنل سریع، فیلتر باشگاه

## ۱) صفحه محصولات ایستگاه (بار / آشپزخانه) — مورد اول
- صفحه‌های جدید: `/bar/products` و `/kitchen/products`
- هر عضو فقط محصولات ایستگاه خودش را می‌بیند (backend guard: BAR/KITCHEN/ADMIN)
- دو حالت برای آیتم موجود‌نیست:
  - **🚫 ناموجود**: در منو دیده می‌شود ولی دکمه سفارش غیرفعال است (فیلد جدید `Product.outOfStock`)
  - **🙈 مخفی از منو**: اصلاً در منو نیست (`active=false`)
- در پنل سفارش بار/آشپزخانه دکمه‌ی «آیتمی موجود نیست؟» به این صفحه می‌رود
- مشتری: روی کارت محصول برچسب «🚫 ناموجود» + دکمه‌ها غیرفعال؛ در صفحه‌ی محصول دکمه‌ی «افزودن به سبد» غیرفعال با پیام
- endpointهای جدید: `GET /staff/bar/products`، `GET /staff/kitchen/products`، `PATCH /staff/{bar|kitchen}/products/:id` (فقط active/outOfStock)
- ⚠️ **تغییر schema**: فیلد `outOfStock` به Product اضافه شد → `prisma:push` لازم است

## ۲) بکاپ و بازیابی — مورد دوم
- Section جدید «بکاپ و بازیابی (Backup)» در صفحه ادمین:
  - **📦 بکاپ محصولات (ZIP)**: products.json + فایل عکس‌های محصولات → `GET /admin/backup/products`
  - **🗄️ بکاپ کامل سایت (ZIP)**: db.json (همه‌ی جدول‌ها) + کل پوشه‌ی uploads → `GET /admin/backup/full`
  - **بازیابی محصولات**: آپلود products.json → `POST /admin/backup/restore-products` (آپ‌sert بر اساس id، دسته‌ها همگام می‌شوند، محصولات حذف‌شده دوباره فعال می‌شوند)
- dependency جدید: `archiver`

## ۳) مدیریت نظرسنجی ادمین کامل‌تر — مورد سوم
- `RemoteFeedbackReport` بازنویسی شد:
  - جستجو (شناسه سفارش / نام مشتری)
  - فیلتر: همه | ⚠️ امتیاز پایین (≤۲) | با توضیح
  - آمار آیتم‌ها: میانگین امتیاز هر محصول (پریدهای پایین‌امتیاز قرمز می‌شوند)
  - **خروجی CSV** همه‌ی نظرسنجی‌ها
  - **حذف** هر نظرسنجی → endpoint جدید `DELETE /feedback/:id` (فقط ADMIN)

## ۴) پاپ‌آپ نظرسنجی برای کاربر — مورد چهارم
- صفحه tracking: بعد از **ثبت سفارش** (اولین بازدید) و بعد از **تحویل** (DELIVERED) یک‌بار در هر نشست پاپ‌آپ نمایش داده می‌شود
- متن: «ثبت نظرسنجی کاملاً اختیاری است. اگر نظرسنجی را کامل پر کنی، **۳۵ امتیاز باشگاه مشتریان** برایت ثبت می‌شود.»
- اگر نظرسنجی قبلاً ثبت شده باشد پاپ‌آپ نمی‌آید
- دکمه‌ی «ثبت نظرسنجی سفارش» هم همیشه در کارت وضعیت باقی مانده است

## ۵) شخصی‌سازی محصول در پنل مدیریت سریع — مورد پنجم
- `CustomizationEditor` به کامپوننت مشترک `components/CustomizationEditor.tsx` منتقل شد
- پنل «مدیریت سریع محصولات» (`/admin/products-manager`):
  - فرم **افزودن فوری**: بخش شخصی‌سازی اضافه شد
  - **مودال ویرایش**: بخش شخصی‌سازی اضافه شد
- صفحه ادمین اصلی از همان کامپوننت مشترک استفاده می‌کند (تغییر ظاهری ندارد)

## ۶) باشگاه مشتریان فقط اعضا — مورد ششم
- `GET /loyalty/admin/members` حالا فقط اعضایی را نشان می‌دهد که **مشتری ثبت‌نام‌کرده (با تلفن)** دارند
- مهمان‌هایی که فقط وارد سایت شده‌اند دیگر در لیست ادمین دیده نمی‌شوند

## تست‌ها (لوکال)
- build بک‌اند ✅ · build فرانت ✅ (۳۰ صفحه)
- `GET /staff/bar/products`: بدون توکن 401 ✅ / با توکن admin لیست ✅
- `PATCH /staff/bar/products/:id`، `GET /admin/backup/*`، `DELETE /feedback/:id` — guardها و پیام‌ها ✅

## Deploy (⚠️ schema تغییر کرده + هر دو بک‌اند و فرانت)
```bash
cd /var/www
unzip -o /مسیر/فایل/cafe-dastan-final-customer-scoped-complete.zip
cd /var/www/cafe-dastan/backend
npm install
npx prisma generate
npx prisma db push
npm run build
pm2 restart cafe-dastan-backend
```
```bash
cd /var/www/cafe-dastan/frontend
rm -rf .next
npm install
npm run build
pm2 delete cafe-dastan-frontend 2>/dev/null
pm2 start node_modules/next/dist/bin/next --name cafe-dastan-frontend -- start -p 3000
pm2 save
```
- ⚠️ استارت فرانت حتماً با `node_modules/next/dist/bin/next`
- ورود ادمین: `admin` / `NNSVcafe`
