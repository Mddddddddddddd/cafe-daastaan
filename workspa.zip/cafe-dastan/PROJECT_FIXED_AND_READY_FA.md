# پروژه اصلاح شد و آماده دانلود است

## کارهایی که انجام شد
- ناسازگاری `category` قدیمی با `categories` جدید در backend و frontend اصلاح شد
- فایل `backend/src/modules/orders/orders.service.ts` اصلاح شد
- فایل `frontend/components/RemoteProductDetail.tsx` اصلاح شد
- آخرین اصلاحات UX/Admin/Home/Story در پروژه موجود است

## کاری که تو باید انجام بدهی
1. کل پوشه `cafe-dastan` را دانلود کن
2. روی پروژه لوکال خودت overwrite کن
3. اگر فونت IRANSans را داری، این فایل‌ها را داخل این مسیر بگذار:
   - `frontend/public/fonts/IRANSans-Regular.woff2`
   - `frontend/public/fonts/IRANSans-Medium.woff2`
4. backend را اجرا کن:
```bash
cd cafe-dastan/backend
npm install
npm run start:dev
```
5. frontend را اجرا کن:
```bash
cd cafe-dastan/frontend
npm install
npm run dev
```
6. اگر frontend نسخه قدیمی نشان داد:
```bash
cd cafe-dastan/frontend
rmdir /s /q .next
npm run dev
```

## بعد از این مرحله
اگر تست کردی و flow اوکی شد، مرحله بعدی: اتصال stateهای in-memory به دیتابیس واقعی Prisma/PostgreSQL
