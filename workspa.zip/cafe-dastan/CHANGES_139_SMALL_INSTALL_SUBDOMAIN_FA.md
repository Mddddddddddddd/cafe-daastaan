# تغییر ۱۳۹ — دکمه‌ی نصب کوچک + زیردامنه‌ی جدا برای هر پنل (حل قطعی نصب اپ اصلی)

## چرا تا حالا اپ اصلی نصب می‌شد؟ (ریشه‌ی مشکل)
وقتی **اپ اصلی** روی گوشی نصب باشد، کروم برای همان دامنه (`cafedaastaan.ir`) دیگر اپ دیگری پیشنهاد نمی‌دهد — هم از نوار آدرس، هم از رویداد نصب. راه قطعی: **هر پنل روی origin جدا (زیردامنه)** باشد تا کروم آن را اپ کاملاً جدید و مستقل بشناسد.

## ۱) زیردامنه برای هر پنل (فایل جدید: `deploy/nginx-staff-pwa.conf`)
| پنل | آدرس جدید |
|-----|-----------|
| آشپزخانه | `https://kitchen.cafedaastaan.ir` (خودش را به `/kitchen` می‌رساند) |
| بار | `https://bar.cafedaastaan.ir` → `/bar` |
| گارسون | `https://waiter.cafedaastaan.ir` → `/waiter` |
| مدیریت | `https://admin.cafedaastaan.ir` → `/admin` |

هرکدام روی origin جدا، با manifest و لوگوی خودش → **نصب جدا، قطعاً**.
API، لاگین و push بدون تغییر کار می‌کنند (CORS سرور همه originها را قبول می‌کند).

### نصب زیردامنه‌ها روی سرور (به این ترتیب، هر خط جدا):
1. **در پنل دامنه** (جایی که DNS را مدیریت می‌کنی): یک رکورد **A** با نام `*` (وایلدکارد) بساز که به **IP سرور** اشاره کند (همان IP که `cafedaastaan.ir` را می‌رساند). صبر کن ۵-۱۰ دقیقه.
2. کپی فایل nginx:
```
sudo cp /var/www/cafe-dastan/deploy/nginx-staff-pwa.conf /etc/nginx/sites-available/staff.cafedaastaan.ir
```
3. فعال کردن:
```
sudo ln -sf /etc/nginx/sites-available/staff.cafedaastaan.ir /etc/nginx/sites-enabled/
```
4. تست و ری‌لود:
```
sudo nginx -t && sudo systemctl reload nginx
```
5. گواهی SSL:
```
sudo certbot --nginx -d kitchen.cafedaastaan.ir -d bar.cafedaastaan.ir -d waiter.cafedaastaan.ir -d admin.cafedaastaan.ir
```
(پاسخ‌های Yes/موافقت را بده. در پایان آدرس‌ها https می‌شوند.)

## ۲) دکمه‌ی نصب — کوچک و تمیز
- کارت بزرگ حذف شد؛ حالا یک **چیب کوچک** بالای صفحه کنار زنگ نوتیفیکیشن: «📲 نصب آشپزخانه» (در هر پنل با اسم خودش)
- بعد از نصب موفق **برای همیشه مخفی می‌شود** (نشان در localStorage + رویداد appinstalled + تشخیص حالت standalone)
- محافظت اضافی: قبل از نصب، آدرس manifest صفحه چک می‌شود؛ اگر HTML قدیمی بود، یک‌بار صفحه را تازه می‌کند
- اگر کروم هنوز رویداد نصب را ثبت نکرده باشد، با اولین ضربه صفحه یک‌بار تازه می‌شود و ضربه‌ی دوم نصب می‌کند

## deploy (بعد از آپلود و extract ZIP)
```
cd /var/www/cafe-dastan/frontend && npm run build
```
```
pm2 restart cafe-dastan-frontend
```
(بک‌اند دست نخورده است.) بعدش ۵ مرحله‌ی زیردامنه‌ها در بالا.

## روش نصب نهایی روی گوشی (بعد از همه‌ی مراحل)
1. در **کروم** برو `https://kitchen.cafedaastaan.ir`
2. وارد شو
3. بالا سمت راست روی «📲 نصب آشپزخانه» بزن → پنل آشپزخانه **جداگانه** (با آیکون نارنجی K) نصب می‌شود
4. دکمه دیگر نمایش داده نمی‌شود

## فایل‌های دست‌کاری‌شده
- `frontend/components/InstallPwaButton.tsx` (دکمه‌ی کوچک + مخفی‌شدن بعد از نصب + محافظت manifest)
- `frontend/app/{kitchen,bar,waiter,admin}/page.tsx` (چیدمان دکمه)
- `cafe-dastan/deploy/nginx-staff-pwa.conf` (**جدید**)
