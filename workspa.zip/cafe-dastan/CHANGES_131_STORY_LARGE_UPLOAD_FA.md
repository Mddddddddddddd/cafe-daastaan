# تغییر ۱۳۱ — استوری ادمین با حجم خیلی بزرگ (تا 500MB ویدیو)

## مشکل
استوری ادمین محدودیت حجمی داشت:
1. `file-storage.ts` سقف سخت: ویدیو ۴۰MB / عکس ۲۵MB
2. لیمیت JSON بک‌اند 30mb (برای base64)
3. Nginx بدون `client_max_body_size` (پیش‌فرض 1MB)
4. ارسال به‌صورت base64 → ۳۳٪ تورم حجمی + بار سنگین روی RAM

## راه‌حل (معماری جدید آپلود)
- **endpoint جدید بک‌اند:** `POST /stories/admin/media` با **multipart/form-data** (فیلد `file`)
  - `multer` با `diskStorage` → فایل **مستقیم روی disk** می‌نشیند (RAM 2GB سرور درگیر نمی‌شود)
  - پاسخ: `{ success, url, mediaType, sizeBytes }`
- **لیمیت‌های قابل تنظیم از env:**
  - `MEDIA_MAX_VIDEO_MB` (پیش‌فرض **500**)
  - `MEDIA_MAX_IMAGE_MB` (پیش‌فرض **50**)
- **فرانت (پنل ادمین):** انتخاب‌گر جدید `StoryMediaPicker`
  - فایل را به‌صورت `File` نگه می‌دارد (نه base64) + پیش‌نمایش ویدیو/عکس
  - آپلود با **XHR + نمایش درصد پیشرفت** روی استاتوس
  - عکس قبل از آپلود در مرورگر فشرده می‌شود (همان 1600px / q0.82)
  - **فالبک خودکار:** اگر بک‌اند قدیمی باشد (404/405) و فایل زیر 20MB → روش base64 قدیمی
- بک‌اند: `json` limit 30mb → 100mb (فقط برای مسیر base64)
- وابستگی جدید: `multer@1.4.5-lts.1` + `@types/multer`

## endpoint
`POST /stories/admin/media` — guard: `AUTH + Roles.ADMIN`، فیلد: `file`
پس از آپلود، انتشار استوری با همان endpoint قبلی: `POST /stories/admin` و `image: <url>`

## تست‌های انجام‌شده (لوکال)
- آپلود 5MB mp4 → ذخیره در `uploads/stories/` + tmp تمیز
- فایل بیشتر از لیمیت (env 1MB) → 413
- فایل زیر لیمیت → موفق
- نوع نامعتبر (txt) → رد با پیام
- بدون توکن → 401
- فلوی کامل: آپلود → `POST /stories/admin` → استوری ساخته شد
- build بک‌اند ✅ · build فرانت ✅

## ⚠️ Deploy — حتماً اعمال کن
1. **Nginx API: `client_max_body_size 550m;`** (نه 30m — برای ویدیو 500MB)
   دستور آماده: `DEPLOY/README_DEPLOY_FA.md`
2. ترتیب deploy: اول بک‌اند (npm install → build → pm2 restart)، بعد فرانت
3. دایرکتوری `uploads/stories/` روی سرور حافظه کافی داشته باشد (ویدیو 500MB ≈ 500MB disk)
