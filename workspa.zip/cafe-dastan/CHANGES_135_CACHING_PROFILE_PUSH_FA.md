# تغییر ۱۳۵ — کش هوشمند، پروفایل کامل، پیشنهاد همراه، آیکون PWA، سبد خالی، صدای سفارش جدید + نوتیفیکیشن Push

## ۱) مدیریت کش — تغییرات ادمین بلافاصله دیده شود (بدون پاک کردن کش مرورگر)
**مشکل قبل:** مرورگر/CDN ممکن بود پاسخ API یا صفحه را cache کند و تغییرات ادمین (منو، قیمت، استوری) دیر یا اصلاً دیده نمی‌شد.

حالا سه لایه‌ی کش به‌صورت اصولی تنظیم شده است:

| لایه | رفتار | چرا |
|------|--------|-----|
| **API (بک‌اند)** | `Cache-Control: no-store, no-cache, must-revalidate` روی **همه** responseها | داده‌ی زنده (منو/قیمت/استوری) هرگز کش نشود |
| **صفحات HTML (Next)** | `no-store, no-cache, must-revalidate` | صفحه‌ی ارسالی هر بار تازه ساخته شود |
| **فایل‌های static (`/_next/static/*`)** | `public, max-age=31536000, immutable` (یک سال) | این فایل‌ها hash نام دارند؛ هر بیلد جدید = نام جدید، پس کش بلندمدت امن و سریع است |

- `backend/src/main.ts`: middleware گلوبال که روی **تمام** responseهای API هدر no-cache می‌زند
- `frontend/next.config.js`: `headers()` با دو قانون (HTML = no-store؛ static = immutable). ⚠️ نکته‌ی فنی: در Next 14 قانون **بعدی** در آرایه اولویت دارد، بنابراین قانون static **آخر** آرایه است (و حتماً بعد از تغییر config باید `npm run build` frontend دوباره زده شود، چون config در `routes-manifest.json` build می‌رود)
- `lib/api.ts` از قبل `cache:'no-store'` داشت؛ حالا لایه‌های دیگر هم کامل شد

## ۲) پس‌زمینه‌ی Lightbox سفید
- `frontend/app/layout.tsx`: رنگ پس‌زمینه‌ی `.imageLightboxPhoto` از `#102225` (تیره) به `#ffffff` (سفید) تغییر کرد — عکس‌های محصولات با حاشیه‌ی روشن نمایش داده می‌شوند

## ۳) «پیشنهاد همراه» واقعی در صفحه‌ی محصول
**قبل:** یک متن ثابت «چیزکیک» و جملەی جعلی «توضیحات این محصول از بک‌اند دریافت شده است.»
**حالا** (`frontend/components/RemoteProductDetail.tsx`):
- «پیشنهاد همراه» به‌صورت **پویا** از منو انتخاب می‌شود:
  - نقشه‌ی دسته‌بندی‌ها (مثلاً نوشیدنی ← دسر/صبحانه، دسر ← کافه/نوشیدنی، صبحانه ← نوشیدنی، غذا ← نوشیدنی)
  - فقط محصولات **فعال** و **موجود** و **متفاوت از خودِ محصول**؛ اگر هیچ‌کدام نبود، featured یا هر محصول فعال دیگر
  - اگر هیچ پیشنهادی نبود، کلاً مخفی می‌شود
- پیشنهاد به‌صورت **لینک** به صفحه‌ی آن محصول (`/product/{id}`) است
- متن توضیحات: فقط اگر محصول واقعاً `desc` داشت نمایش داده می‌شود (جملەی جعلی حذف شد)

## ۴) آیکون PWA برای اندروید (از کادر بیرون نمی‌زد)
**مشکل قبل:** آیکون با پس‌زمینه‌ی شفاف و لوگوی چسبیده به لبه‌ها → لاندر اندروید برش maskable می‌زد و لوگو از کادر بیرون می‌زد.
**حالا** (`frontend/public/images/icon-192.png` و `icon-512.png`):
- پس‌زمینه‌ی **کدر سفید** + لوگو به‌اندازه‌ی **۶۶٪** در مرکز (داخل safe-zone ۸۰٪ maskable)
- manifest بدون تغییر (purpose: `any maskable` از قبل درست بود)
- ⚠️ روی گوشی اندروید باید PWA را **حذف و دوباره نصب** کنی تا آیکون جدید ظاهر شود

## ۵) صفحه‌ی پروفایل کامل (عین صفحه‌ی پروفایل کاربری)
`frontend/app/profile/page.tsx` بازنویسی شد:
- **حساب کاربری:** نام نمایشی + نام کاربری (قابل ویرایش، ذخیره با `PATCH /me`) + نمایش شماره‌ی ثبت‌نام
- **دنج داستانی:** نوشیدنی/غذای محبوب و ساعت معمول — خودکار از تاریخچه‌ی سفارش‌ها (از پاسخ `/me`)
- **باشگاه مشتریان:** سطح فعلی، امتیاز، نوار پیشرفت و فاصله تا جایزه‌ی بعدی (از `GET /loyalty`)
- **سوابق سفارش:** ۲۰ سفارش اخیر با تاریخ فارسی، وضعیت، آیتم‌ها و لینک رهگیری (endpoint جدید `GET /orders/mine` — فقط برای مشتریِ خود، guard شده)
- **خروج از حساب**

## ۶) سبد خالی — ادامه تا پرداخت مسدود
- **سبد خرید:** اگر سبد خالی باشد دکمه‌ی «ادامه تا پرداخت» اصلاً نمایش داده **نمی‌شود**؛ به‌جایش دکمه‌ی «افزودن محصول از منو» + پیام «سبد خالی است»
- **صفحه‌ی checkout:** اگر با URL مستقیم وارد شد و سبد خالی بود، فرم اصلاً نمی‌آید؛ یک پیام دوستانه «سبد خریدت خالی است» + دکمه‌ی «مشاهده منو» نمایش داده می‌شود
- guard قبلیِ submit هم باقی است (دو لایه‌ی محافظ)

## ۷) سفارش جدید برای پرسنل: صدا + نوتیفیکیشن گوشی
### الف) صدای چیم (شبیه صدای پیام iOS)
- کامپوننت جدید `frontend/components/useNewOrderChime.ts` — با WebAudio سه‌نت ملایم (بدون فایل صوتی)
- اتصال به سه پنل: **آشپزخانه** (RemoteKitchenOrders)، **بار** (RemoteBarOrders)، **گارسون** (RemoteWaiterTables)
- فقط وقتی **سفارش جدید** به صف اضافه شود صدا می‌زند (لیست را با قبل مقایسه می‌کند؛ بار اول که صفحه باز می‌شود صدا نمی‌زند)
- ⚠️ مرورگر اجازه می‌دهد پس از اولین تعامل کاربر (تپ روی صفحه) صدا پخش کند؛ یعنی گارسون/بار باید یک‌بار صفحه را باز و تپ کند تا صدا فعال بماند (محدودیت استاندارد مرورگرهاست)

### ب) Web Push (نوتیفیکیشن واقعی گوشی — حتی وقتی اپ باز نیست)
- **بک‌اند:**
  - model جدید `PushSubscription` در schema (⚠️ `npx prisma db push` لازم است)
  - dependency جدید: `web-push` (در بیلد `npm install` می‌شود)
  - `PushService` (`backend/src/modules/notifications/push.service.ts`): اگر VAPID keys نباشد **ساکت** no-op می‌کند (سایت نمی‌افتد)
  - endpointهای جدید (فقط پرسنل/ادمین):
    - `GET /notifications/push/vapid-public-key`
    - `POST /notifications/push/subscribe`
    - `DELETE /notifications/push/subscribe?endpoint=...`
  - در `createOrder`: بعد از ثبت سفارش، push به `bar` (اگر آیتم بار داشت)، `kitchen` (اگر آیتم آشپزخانه داشت) و `waiter` (همه‌ی سفارش‌ها) — fire-and-forget، هرگز ثبت سفارش را مختل نمی‌کند
- **فرانت‌اند:**
  - `frontend/public/sw.js` — service worker: روی push نوتیفیکیشن نشان می‌دهد؛ با کلیک، پنل مربوطه باز می‌شود
  - کامپوننت `StaffPushBell.tsx` روی سه صفحه‌ی `/kitchen`، `/bar`، `/waiter`: دکمه‌ی «🔔 فعال‌سازی نوتیفیکیشن سفارش» (مرورگر permission می‌گیرد → subscribe → ثبت در بک‌اند) و «🔔 نوتیفیکیشن فعال است (برای قطع بزن)»

## تغییرات schema (Prisma)
- model جدید: **PushSubscription** (`id, endpoint@unique, p256dh, auth, staffRole, userAgent, createdAt`)
- → روی سرور: `cd /var/www/cafe-dastan/backend && npx prisma db push`

## متغیرهای محیطی جدید (backend/.env)
برای فعال شدن Push، این سه خط را به `/var/www/cafe-dastan/backend/.env` اضافه کن:
```
VAPID_PUBLIC_KEY=BAoyvfU_5-6NIaSLzXPEkz_UwakXKLJ1yrJVs_ILDMCSSeibT1naP3m_uowPLo7csrKxHLW4wRInw7Vb0hWFf2M
VAPID_PRIVATE_KEY=eiN_1yG0UeRe0F2TOPuMusyHSvwg1GT7zRUOs7YQu_E
VAPID_CONTACT=mailto:admin@cafedaastaan.ir
```
(اگر اضافه نکنی، بقیه‌ی سایت عادی کار می‌کند و فقط Push خاموش می‌ماند)

## dependency جدید
- `backend`: `web-push`

## deploy (بعد از git pull)
1. `cd /var/www/cafe-dastan/backend && npm install` (web-push نصب شود)
2. `cd /var/www/cafe-dastan/backend && npx prisma db push`
3. `cd /var/www/cafe-dastan/backend && npm run build`
4. سه خط VAPID به `.env` (بالا)
5. `cd /var/www/cafe-dastan/frontend && npm run build`
6. `pm2 restart cafe-dastan-backend cafe-dastan-frontend`
7. روی گوشی اندروید: PWA را حذف و دوباره «Add to Home screen» کن تا آیکون جدید بیاید
8. روی گوشی پرسنل: وارد پنل آشپزخانه/بار/گارسون شو و «🔔 فعال‌سازی نوتیفیکیشن سفارش» را بزن

## فایل‌های دست‌کاری‌شده
**backend:**
- `src/main.ts` (no-cache middleware)
- `src/modules/orders/orders.controller.ts` (+ `GET /orders/mine`)
- `src/modules/orders/orders.service.ts` (+ `getMyOrders` + ارسال push در `createOrder`)
- `src/modules/orders/orders.module.ts` (import NotificationsModule)
- `src/modules/notifications/push.service.ts` (**جدید**)
- `src/modules/notifications/notifications.controller.ts` (+ 3 endpoint push)
- `src/modules/notifications/notifications.module.ts` (ثبت PushService)
- `prisma/schema.prisma` (+ PushSubscription)
- `package.json` (+ web-push)
- `.env.example` (+ VAPID)

**frontend:**
- `next.config.js` (headers کش)
- `app/layout.tsx` (lightbox سفید)
- `components/RemoteProductDetail.tsx` (پیشنهاد همراه + توضیحات)
- `public/images/icon-192.png`، `public/images/icon-512.png` (آیکون‌های maskable)
- `app/profile/page.tsx` (بازنویسی کامل)
- `app/cart/page.tsx` (CTA خالی)
- `app/checkout/page.tsx` (guard سبد خالی)
- `components/useNewOrderChime.ts` (**جدید**)
- `components/StaffPushBell.tsx` (**جدید**)
- `public/sw.js` (**جدید**)
- `components/RemoteKitchenOrders.tsx`، `RemoteBarOrders.tsx`، `RemoteWaiterTables.tsx` (اتصال چیم)
- `app/kitchen/page.tsx`، `app/bar/page.tsx`، `app/waiter/page.tsx` (نمایش StaffPushBell)
