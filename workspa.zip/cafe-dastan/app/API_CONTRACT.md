# Initial API Contract

## Auth
### POST /api/auth/request-otp
Request:
```json
{ "phone": "+98912xxxxxxx" }
```
Response:
```json
{ "success": true, "message": "OTP sent" }
```

### POST /api/auth/verify-otp
```json
{ "phone": "+98912xxxxxxx", "code": "123456" }
```
Response:
```json
{ "accessToken": "jwt", "refreshToken": "jwt", "user": { "id": "u1", "role": "customer" } }
```

### POST /api/auth/staff-login
```json
{ "username": "admin", "password": "***" }
```

## Menu
### GET /api/menu?branchId=b1&category=coffee&time=night
Returns products sorted by smart rules.

### GET /api/products/:id
Returns full story/product details.

## Orders
### POST /api/orders
```json
{
  "branchId": "b1",
  "orderType": "dine_in",
  "tableId": "t-frough",
  "items": [
    {
      "productId": "p1",
      "qty": 1,
      "customizations": {
        "milk": "almond",
        "size": "large",
        "syrup": "vanilla"
      }
    }
  ],
  "paymentMethod": "pay_at_table"
}
```

### GET /api/orders/:id
Returns order details and timeline.

### PATCH /api/orders/:id/status
For staff role updates.

## Notifications
### POST /api/admin/notifications/broadcast
### GET /api/notifications/me

## Story Engine
### GET /api/story/me
### GET /api/story/recommendations
