# قدم‌های بعدی اجرای واقعی

## مرحله فعلی
پایه محصول، مسیرها، دیتامدل، قرارداد API و داده نمونه آماده شده است.

## مرحله بعدی
- ساخت فایل‌های واقعی Next.js
- ساخت ساختار اولیه NestJS
- تعریف Prisma schema
- اتصال صفحات به داده نمونه
- ساخت فرم‌های لاگین واقعی‌تر
- تعریف state management سبد خرید
- تعریف eventهای realtime

## اولویت اجرایی
1. Home + Product + Cart
2. Auth customer/staff
3. Orders + Tracking
4. Bar + Kitchen dashboards
5. Admin dashboard
