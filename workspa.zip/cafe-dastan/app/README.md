# Cafe Dastan App Scaffold

This is the initial implementation scaffold for the Cafe Dastan web application.

## Target stack
- Frontend: Next.js + TypeScript + Tailwind
- Backend: NestJS + Prisma + PostgreSQL
- Realtime: Socket.IO
- Auth: OTP + JWT + RBAC

## Included in this scaffold
- Product structure
- UI flow pages
- Sample data model definitions
- API contract draft
- Frontend route map
- Backend module map

Next implementation steps:
1. Initialize monorepo apps
2. Implement auth flows
3. Implement menu + product APIs
4. Implement order creation and realtime tracking
5. Implement role-based dashboards
