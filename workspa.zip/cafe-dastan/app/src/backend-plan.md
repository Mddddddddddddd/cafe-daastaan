# Backend Implementation Plan

## Core modules to build first
- AuthModule
- MenuModule
- ProductsModule
- OrdersModule
- RealtimeGateway
- StaffAuthModule

## Then
- StoryModule
- NotificationModule
- InventoryModule
- ReportsModule
- TablesModule
- BranchesModule

## Technical order
1. Prisma schema
2. Seed data
3. OTP request/verify endpoints
4. Staff login
5. Menu query endpoint
6. Order create endpoint
7. Realtime status stream
8. Staff status actions
