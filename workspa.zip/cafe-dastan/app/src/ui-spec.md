# UI Spec

## Home
- Sticky top bar
- Search input
- Horizontal categories
- Product list cards
- Floating cart bar

## Product Detail
- Large image
- Story description
- Flavor meta
- Option groups
- Add to cart CTA

## Cart
- Editable quantities
- Suggested pairings
- Order type selector
- Checkout CTA

## Tracking
- Realtime vertical status timeline
- ETA hint
- Story message

## Story Page
- Persona capsule
- Favorite items
- Visit memory
- Story chapter count

## Staff Dashboards
- Minimal operational cards
- Large touch targets
- Fast status buttons
