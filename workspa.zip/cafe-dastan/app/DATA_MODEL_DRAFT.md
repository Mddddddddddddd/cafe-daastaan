# Data Model Draft

## User
- id
- phone
- name
- role
- preferred_language
- story_persona
- favorite_drink_id
- favorite_food_id
- total_story_chapters
- created_at

## Employee
- id
- username
- password_hash
- role (admin, cashier, waiter, bar, kitchen)
- branch_id
- is_active

## Branch
- id
- name
- address
- phone
- is_active

## Table
- id
- branch_id
- name
- qr_code
- status

## Category
- id
- name_fa
- name_en
- type
- display_order

## Product
- id
- category_id
- type (drink, food, dessert, breakfast)
- name_fa
- description
- story_text
- price
- special_price
- prep_time_minutes
- calories
- caffeine_level
- sweetness_level
- bitterness_level
- allergens_json
- ingredients_json
- stock_status
- music_hint
- pairing_json
- active

## ProductOptionGroup
- id
- product_id
- name
- selection_type

## ProductOption
- id
- group_id
- name
- extra_price

## Order
- id
- customer_id
- branch_id
- table_id
- order_type
- status
- payment_status
- payment_method
- total_amount
- story_note
- created_at

## OrderItem
- id
- order_id
- product_id
- station (bar, kitchen)
- qty
- unit_price
- customizations_json
- status

## InventoryItem
- id
- name
- unit
- stock_qty
- low_stock_threshold

## Notification
- id
- title
- body
- audience_type
- created_by
- created_at
