# Frontend Route Map

## Customer App
- `/` Home / Digital Menu
- `/product/[id]` Product detail
- `/cart` Cart
- `/checkout` Checkout
- `/tracking/[orderId]` Order tracking
- `/story` Story profile
- `/auth/login` OTP login

## Staff / Admin
- `/admin/login`
- `/admin`
- `/admin/products`
- `/admin/orders`
- `/admin/inventory`
- `/admin/reports`
- `/bar/login`
- `/bar`
- `/kitchen/login`
- `/kitchen`
- `/waiter/login`
- `/waiter`

## Shared UX modules
- search
- categories slider
- menu list
- product customization drawer
- story cards
- smart suggestions
- realtime order timeline
