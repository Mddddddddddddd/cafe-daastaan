# فاز دیتابیس واقعی - مرحله ۱

این مرحله شروع انتقال پروژه از stateهای in-memory به Prisma/PostgreSQL است، با این اصل مهم که پروژه اگر PostgreSQL آماده نبود نشکند و همچنان با fallback قبلی بالا بیاید.

## کارهای انجام‌شده

### ۱. بازطراحی Prisma Schema برای مدل واقعی پروژه

فایل زیر به مدل‌های جدید و نزدیک به ساختار فعلی محصول تغییر کرد:

```txt
backend/prisma/schema.prisma
```

مدل‌های اصلی اضافه/اصلاح شدند:

- `Customer`
- `StaffUser`
- `CafeTable`
- `Category`
- `Product`
- `ProductCategory`
- `Order`
- `OrderItem`
- `OrderStatusLog`
- `DiscountCode`
- `LoyaltyMember`
- `LoyaltyHistory`
- `Voucher`
- `Notification`
- `HomeSettings`
- `Story`
- `StoryComment`
- `Feedback`

Enums اصلی:

- `StaffRole`
- `OrderType`
- `OrderStatus`
- `PaymentStatus`
- `StationType`
- `StationStatus`
- `DiscountType`
- `DiscountSource`

### ۲. طراحی درست سفارش و آیتم سفارش

برای اینکه سفارش‌های ترکیبی درست کار کنند، ساختار به این شکل طراحی شد:

- `Order` برای کل سفارش
- `OrderItem` برای هر آیتم سفارش
- `OrderItem.station` مشخص می‌کند آیتم مربوط به بار است یا آشپزخانه
- `OrderItem.stationStatus` وضعیت همان آیتم را نگه می‌دارد

این یعنی اگر یک سفارش شامل نوشیدنی و دسر باشد، نوشیدنی در پنل بار و دسر در پنل آشپزخانه مدیریت می‌شود.

### ۳. Snapshot قیمت و نام محصول داخل سفارش

داخل `OrderItem` این موارد ذخیره می‌شود:

- `productNameSnapshot`
- `unitPrice`
- `qty`
- `selectedOptions`

پس اگر ادمین بعداً قیمت یا نام محصول را تغییر دهد، سفارش‌های قبلی خراب نمی‌شوند.

### ۴. محصول و دسته‌بندی واقعی شدند

محصول و دسته‌بندی به شکل relational طراحی شدند:

- `Product`
- `Category`
- `ProductCategory`

هر محصول می‌تواند چند دسته‌بندی داشته باشد.

برای انعطاف در تغییرات آینده، `Product.customizations` فعلاً JSON نگه داشته شده است.

### ۵. تنظیمات صفحه اصلی در دیتابیس

تنظیمات صفحه اصلی در مدل زیر ذخیره می‌شود:

```txt
HomeSettings.data Json
```

چون ممکن است ساختار صفحه اصلی هنوز تغییر کند، این قسمت فعلاً منعطف نگه داشته شد.

### ۶. کدهای تخفیف دیتابیسی شدند

مدل `DiscountCode` اضافه شد و بخش validate تخفیف و مدیریت ادمین می‌تواند از دیتابیس استفاده کند.

### ۷. اعلان‌ها دیتابیسی شدند

مدل `Notification` اضافه شد.

صفحه اعلان‌ها و حذف تکی/حذف همه، وقتی دیتابیس فعال باشد از PostgreSQL استفاده می‌کند.

### ۸. پنل بار و آشپزخانه به OrderItem وصل شدند

وقتی دیتابیس فعال باشد:

- پنل بار از `OrderItem`هایی می‌خواند که `station = BAR` دارند.
- پنل آشپزخانه از `OrderItem`هایی می‌خواند که `station = KITCHEN` دارند.
- تغییر وضعیت در بار/آشپزخانه روی `stationStatus` ذخیره می‌شود.

### ۹. پنل waiter به Order وصل شد

وقتی دیتابیس فعال باشد:

- waiter سفارش‌های فعال را از جدول `Order` می‌خواند.
- عملیات «در مسیر میز» و «تحویل شد» روی وضعیت واقعی سفارش ذخیره می‌شود.

### ۱۰. حسابداری دیتابیسی شد

وقتی دیتابیس فعال باشد، گزارش حسابداری از جدول‌های زیر ساخته می‌شود:

- `Order`
- `OrderItem`

و شامل موارد زیر است:

- فروش کل
- تخفیف کل
- هزینه تخمینی
- سود تخمینی
- تعداد سفارش
- لیست سفارش‌ها

### ۱۱. Seed دیتابیس آماده شد

فایل زیر بازنویسی شد:

```txt
backend/prisma/seed.ts
```

Seed شامل:

- دسته‌بندی‌های اولیه
- محصولات اولیه
- میز فروغ
- اکانت‌های staff mock
- تنظیمات صفحه اصلی
- کد تخفیف `DASTAN20`
- مشتری مهمان
- عضو باشگاه مشتریان
- اعلان‌های اولیه
- سفارش نمونه `1042`

### ۱۲. Mapperهای مشترک اضافه شدند

فایل جدید:

```txt
backend/src/prisma/db-mapper.ts
```

برای تبدیل مدل‌های Prisma به شکل قبلی API ساخته شد تا فرانت‌اند نشکند.

### ۱۳. PrismaService امن شد

اگر PostgreSQL یا `DATABASE_URL` آماده نباشد، بک‌اند crash نمی‌کند و به in-memory fallback می‌کند.

این یعنی تا وقتی دیتابیس را راه‌اندازی نکردی، پروژه مثل قبل اجرا می‌شود.

### ۱۴. اسکریپت‌های Prisma اضافه شد

داخل `backend/package.json` اضافه شد:

```json
"prisma:generate": "prisma generate",
"prisma:migrate": "prisma migrate dev",
"prisma:push": "prisma db push",
"prisma:seed": "ts-node prisma/seed.ts"
```

## روش راه‌اندازی دیتابیس روی سیستم تو

۱. PostgreSQL را نصب/اجرا کن.

۲. دیتابیس بساز:

```sql
CREATE DATABASE cafe_dastan;
```

۳. در فایل زیر:

```txt
backend/.env
```

این مقدار را بگذار:

```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/cafe_dastan"
```

رمز و user را مطابق PostgreSQL خودت تغییر بده.

۴. در پوشه backend اجرا کن:

```bash
npm install
npm run prisma:generate
npm run prisma:push
npm run prisma:seed
npm run start:dev
```

## وضعیت فعلی

در این مرحله هسته دیتابیس وصل شده ولی هنوز چند بخش کامل دیتابیسی نشده‌اند:

- Story service
- Feedback service
- Loyalty redeem کامل با دیتابیس
- Auth واقعی
- File upload واقعی

این‌ها در مرحله‌های بعدی انجام می‌شوند.

## Build

Backend build با موفقیت انجام شد.
