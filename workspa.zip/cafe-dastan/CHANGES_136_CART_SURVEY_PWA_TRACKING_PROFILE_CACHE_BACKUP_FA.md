# تغییر ۱۳۶ — سبد خالی بعد از سفارش، نظرسنجی شیک، PWA جدا برای پنل‌ها، رهگیری کاربردی، پروفایل کامل، دکمه پاک‌سازی کش، رفع باگ بکاپ

## ۱) خالی شدن سبد خرید بعد از ثبت سفارش
**مشکل:** بعد از ثبت سفارش، با بازگشت به صفحه‌ی اصلی همان آیتم‌ها هنوز در سبد بود.
**حالا:** در `app/checkout/page.tsx` بعد از ثبت موفق سفارش:
- `clearCart()` (خالی‌کردن context) + حذف کلید `cafe_dastan_cart_items` از localStorage
- سپس هدایت به صفحه‌ی رهگیری
→ با هر سفارش ثبت‌شده، سبد به‌طور کامل خالی می‌شود.

## ۲) بازطراحی کامل صفحه‌ی نظرسنجی
`components/RemoteFeedbackForm.tsx` از نو ساخته شد (API و endpointها عیناً):
- هدر گرادیانی با آیکون ستاره + **نوار پیشرفت زنده** (با هر امتیاز درصد بالا می‌رود)
- **ستاره‌های بزرگ ایموجینی** (😖 😕 😐 😊 🤩) به‌جای ستاره‌های کوچیک — با انیمیشن scale
- هر بخش (کارکنان / کیفیت کلی / هر آیتم) یک کارت مجزا با آیکون، چک ✅ وقتی امتیاز داده شد
- بعد از ثبت: صفحه‌ی موفقیت جشنی 🎉 + نشان امتیاز باشگاه + دکمه‌های بازگشت/باشگاه
- دکمه‌ی ثبت گرادیانی که تا انتخاب دو امتیاز اجباری غیرفعال‌به‌نظر می‌رسد

## ۳) PWA جداگانه و قابل نصب برای ۴ پنل
هر پنل حالا اپ مجزایی با لوگوی متمایز دارد:

| پنل | نام اپ | آیکون | رنگ تم |
|-----|--------|-------|--------|
| آشپزخانه `/kitchen` | کافه داستان \| آشپزخانه | حلقه‌ی نارنجی + نشان **K** | #D9480F |
| بار `/bar` | کافه داستان \| بار | حلقه‌ی سبز + نشان **B** | #0CA678 |
| گارسون `/waiter` | کافه داستان \| گارسون | حلقه‌ی بنفش + نشان **W** | #7048E8 |
| مدیریت `/admin` | کافه داستان \| مدیریت | حلقه‌ی آبی + نشان **A** | #1971C2 |

- فایل‌های جدید: `public/manifest-kitchen.webmanifest`، `manifest-bar`، `manifest-waiter`، `manifest-admin` + آیکون‌های `icon-{role}-192/512.png` (maskable-safe)
- `app/{role}/layout.tsx` برای هر چهار پنل: با `metadata.manifest`، هر صفحه فقط manifest خودش را لینک می‌کند (ریشه = اپ مشتری با `manifest.json` بدون تغییر)
- ⚠️ نکته: Next 14 manifestهای زیرشاخه را خودش route نمی‌سازد؛ به همین دلیل فایل‌ها static در `public/` گذاشته شدند
- نصب: داخل هر پنل «Add to Home Screen» / «نصب» → اپ جدا با آیکون خود

## ۴) صفحه‌ی رهگیری سفارش — کاربردی‌تر
`app/tracking/[id]/page.tsx` بازنویسی شد:
- **اگر سفارش فعال/معتبری نباشد** (id غلط/قدیمی یا سفارش موجود نباشد): دیگه صفحه‌ی رهگیری «الکی» با وضعیت پیش‌فرض نشان داده **نمی‌شود**؛ به‌جایش:
  - کارت «🔥 N سفارش فعال داری» با لینک رهگیری زنده‌ی هرکدام
  - کارت «فعلاً سفارش فعالی نداری» + دکمه‌ی «مشاهده منو و سفارش جدید»
  - **سوابق کامل**: آخرین ۲۰ سفارش با تاریخ، وضعیت، آیتم‌ها و **مبلغ** — سفارش فعال → لینک رهگیری زنده؛ تحویل‌شده → لینک نظرسنجی
- اگر سفارش فعال پیدا شد → همان تایم‌لاین رهگیری قبلی (بدون تغییر) + پایینش سوابق
- پاپ‌آپ نظرسنجی همون رفتار قبلی

## ۵) پروفایل کاربری کامل و بینظیر
- **schema (⚠️ prisma db push لازم است):** دو فیلد جدید در `Customer`: `birthday`، `address`
- `GET /me` و `PATCH /me` این دو فیلد را می‌دهند/ذخیره می‌کنند (با اعتبارسنجی قبلی نام کاربری)
- `app/profile/page.tsx` دوباره بازنویسی شد:
  - **هدر گرادیانی**: آواتار اول‌حرفی، نام، @username، نشان شخصیت داستانی (مثلاً «دنج قهوه‌ی عصر»)
  - **آمار سه‌گانه**: تعداد سفارش / مجموع خرید (تومان) / تعداد استوری
  - **اطلاعات شخصی**: حالت نمایش (کارت‌های آیکن‌دار 👤📱🎂📍) + حالت ویرایش — نام و نام خانوادگی، نام کاربری، **تاریخ تولد** (تقویم با نمایش فارسی)، **آدرس** (چند خط)، موبایل (فقط نمایش)
  - دنج داستانی + پیشنهاد بعدی، باشگاه مشتریان، سوابق سفارش، خروج — همگی باقی‌ماندند

## ۶) دکمه‌ی «🧹 پاک‌سازی کش و اعمال آپدیت‌ها» در صفحه‌ی ادمین
- **backend:** endpoint جدید `POST /admin/cache/clear` (فقط ADMIN) → گزارش وضعیت DB + سیاست cache
- **frontend (دکمه در هدر پنل ادمین):**
  1. پاک‌کردن کش‌های محلی مرورگر (`cafe_dastan_admin_tables`، شمارنده‌ی اعلان‌ها، پرچم‌های نظرسنجی/رهگیری در sessionStorage) — **توکن‌های ورود و سبد خرید دست نمی‌خورد**
  2. به‌روزرسانی service worker (برای فعال‌شدن نسخه‌ی جدید)
  3. تماس با endpoint سرور
  4. رفرش سخت صفحه با پارامتر cache-buster
- نکته‌ی شفاف: سرور از قبل «همیشه تازه» پاسخ می‌دهد (هدر no-store روی API و HTML؛ staticها با هش نام immutable)؛ این دکمه بیشتر برای مرورگر/PWA خودِ ادمین کش‌های کهنه را پاک می‌کند

## ۷) رفع باگ «دانلود بکاپ کار نمی‌کند» ✅
**ریشه‌ی باگ:** `import archiver from 'archiver'` — چون در `tsconfig.json` فقط `allowSyntheticDefaultImports` فعال بود (نه `esModuleInterop`)، کد کامپایل‌شده `archiver.default('zip')` را صدا می‌زد که `undefined` است → هر درخواست بکاپ با TypeError با خطا می‌افتاد و چیزی دانلود نمی‌شد. (دقیقاً همان الگویی که پیش‌تر با `web-push` دیدیم.)
**فیکس:** در `backend/src/modules/backup/backup.service.ts` → `import * as archiver from 'archiver';`
→ حالا هر دو بکاپ (محصولات و کامل) ZIP را استریم می‌کنند و دانلود می‌شوند.

## تغییرات schema (Prisma)
- `Customer.birthday String?` و `Customer.address String?`
- → روی سرور: `cd /var/www/cafe-dastan/backend && npx prisma db push`

## dependency / env جدید
- **ندارد** (archiver و web-push از قبل نصب هستند؛ متغیر محیطی جدیدی لازم نیست)

## deploy (بعد از آپلود و extract ZIP)
1. `cd /var/www/cafe-dastan/backend && npx prisma db push`
2. `cd /var/www/cafe-dastan/backend && npm run build`
3. `cd /var/www/cafe-dastan/frontend && npm run build`
4. `pm2 restart cafe-dastan-backend cafe-dastan-frontend`
5. (اختیاری) برای اپ‌های جدا: داخل هر پنل از منوی مرورگر «Add to Home Screen» / «نصب برنامه»

## فایل‌های دست‌کاری‌شده
**backend:**
- `src/modules/backup/backup.service.ts` (فیکس import archiver) ⭐
- `prisma/schema.prisma` (+ birthday/address)
- `src/modules/auth/auth.service.ts` (/me با فیلد جدیدها)
- `src/modules/admin/admin.cache.controller.ts` (**جدید**)
- `src/modules/admin/admin.module.ts` (ثبت controller جدید)

**frontend:**
- `app/checkout/page.tsx` (clearCart بعد از سفارش)
- `components/RemoteFeedbackForm.tsx` (بازطراحی کامل)
- `app/tracking/[id]/page.tsx` (سوابق به‌جای رهگیری الکی)
- `app/profile/page.tsx` (بازطراحی کامل + تولد/آدرس)
- `app/admin/page.tsx` (دکمه‌ی پاک‌سازی کش)
- `app/layout.tsx` (حذف link manifest تکراری)
- `app/kitchen/layout.tsx`، `app/bar/layout.tsx`، `app/waiter/layout.tsx`، `app/admin/layout.tsx` (**جدید** — manifest هر نقش)
- `public/manifest-kitchen.webmanifest`، `manifest-bar`، `manifest-waiter`، `manifest-admin` (**جدید**)
- `public/images/icon-{kitchen,bar,waiter,admin}-{192,512}.png` (**جدید** — ۸ آیکون)
- `app/globals.css` (انیمیشن cdSpin)
