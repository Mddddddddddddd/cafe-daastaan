# فاز دیتابیس واقعی - مرحله ۴: Auth و امنیت اولیه

در این مرحله سیستم ورود و امنیت اولیه پروژه از حالت mock ساده خارج شد و آماده محافظت واقعی‌تر APIها شد، بدون اینکه جریان توسعه و تست فعلی قفل شود.

## ۱. JWT امضاشده اضافه شد

فایل تغییرکرده:

```txt
backend/src/modules/auth/jwt.service.ts
```

قبلاً توکن فقط Base64 ساده بود و امنیت واقعی نداشت.

الان توکن به شکل JWT ساده با امضای HMAC-SHA256 ساخته می‌شود:

- دارای header
- دارای payload
- دارای signature
- دارای `iat`
- دارای `exp`

توکن با `JWT_SECRET` امضا می‌شود.

## ۲. hash رمز کارکنان اضافه شد

فایل جدید:

```txt
backend/src/modules/auth/password.service.ts
```

رمز کارکنان با `scrypt` و salt هش می‌شود.

توابع اضافه‌شده:

- `hashPassword`
- `verifyPassword`

## ۳. staff login واقعی‌تر شد

فایل تغییرکرده:

```txt
backend/src/modules/auth/auth.service.ts
```

وقتی دیتابیس فعال باشد:

- کارمند از جدول `StaffUser` خوانده می‌شود.
- فعال بودن کارمند بررسی می‌شود.
- رمز با hash بررسی می‌شود.
- نقش واقعی کارمند در توکن قرار می‌گیرد.

کاربرهای پیش‌فرض:

```txt
admin / admin123
bar / bar123
kitchen / kitchen123
waiter / waiter123
```

اگر دیتابیس آماده نباشد، fallback امن‌تر نسبت به قبل وجود دارد و فقط همین username/passwordهای مشخص را قبول می‌کند.

## ۴. OTP واقعی‌تر شد

مدل `OtpCode` به Prisma schema اضافه شد.

وقتی دیتابیس فعال باشد:

- کد OTP در جدول `OtpCode` ذخیره می‌شود.
- زمان انقضا دارد.
- در verify بررسی می‌شود.
- اگر OTP_PROVIDER حالت mock باشد، کد `123456` برای توسعه فعال می‌ماند.

## ۵. seed کارکنان اصلاح شد

فایل تغییرکرده:

```txt
backend/prisma/seed.ts
```

رمزهای پیش‌فرض staff حالا hash شده ذخیره می‌شوند.

بعد از اجرای seed:

```bash
npm run prisma:seed
```

اکانت‌های زیر آماده‌اند:

```txt
admin / admin123
bar / bar123
kitchen / kitchen123
waiter / waiter123
```

## ۶. Guard و Role Guard واقعی‌تر شدند

فایل‌های تغییرکرده:

```txt
backend/src/modules/auth/auth.guard.ts
backend/src/modules/auth/roles.guard.ts
backend/src/modules/auth/roles.ts
```

قابلیت‌های اضافه‌شده:

- خواندن Authorization Bearer token
- verify کردن JWT
- قرار دادن user روی request
- بررسی نقش‌ها با decorator
- decorator جدید `RequireRoles`

## ۷. محافظت اولیه APIهای حساس

روی این کنترلرها guard قرار گرفت:

```txt
backend/src/modules/admin/admin.controller.ts
backend/src/modules/staff/staff.controller.ts
```

مسیرهای ادمین فقط برای admin آماده شده‌اند.

مسیرهای staff نقش مناسب دارند:

- bar برای پنل بار
- kitchen برای پنل آشپزخانه
- waiter برای پنل waiter
- admin هم دسترسی کامل دارد

## ۸. حالت توسعه برای نشکستن پروژه

برای اینکه پروژه در زمان تست و توسعه قفل نشود، متغیر زیر اضافه شد:

```env
AUTH_ENFORCE=false
```

وقتی `AUTH_ENFORCE=false` باشد، اگر Authorization header وجود نداشته باشد، بک‌اند dev bypass می‌کند.

برای حالت جدی‌تر و تست امنیت:

```env
AUTH_ENFORCE=true
```

در این حالت بدون token معتبر، APIهای حساس خطای Unauthorized می‌دهند.

## ۹. فرانت‌اند توکن را ذخیره و ارسال می‌کند

فایل تغییرکرده:

```txt
frontend/lib/api.ts
```

توکن در localStorage ذخیره می‌شود:

```txt
cafe_dastan_access_token
cafe_dastan_refresh_token
cafe_dastan_user
```

تمام درخواست‌های API، اگر token وجود داشته باشد، header زیر را می‌فرستند:

```txt
Authorization: Bearer TOKEN
```

## ۱۰. صفحات لاگین اصلاح شدند

صفحات زیر توکن را بعد از ورود موفق ذخیره می‌کنند:

```txt
frontend/app/admin/login/page.tsx
frontend/app/bar/login/page.tsx
frontend/app/kitchen/login/page.tsx
frontend/app/waiter/login/page.tsx
frontend/app/auth/login/page.tsx
```

همچنین input رمز کارکنان به `type=password` تغییر کرد.

## ۱۱. فایل env نمونه به‌روزرسانی شد

فایل:

```txt
backend/.env.example
```

مقدار جدید:

```env
AUTH_ENFORCE=false
```

## Build

Backend build و Frontend build هر دو با موفقیت انجام شدند.
