# راه‌اندازی کامل دیتابیس کافه داستان روی ویندوز

این نسخه بک‌اند را از stateهای موقت به Prisma/PostgreSQL منتقل کرده و در نبود دیتابیس، برای تست سریع fallback حافظه‌ای دارد. برای اجرای دیتابیس واقعی مراحل زیر را دقیق انجام بده.

## 1) جایگذاری پروژه

بهتر است پروژه قبلی را کامل کنار بگذاری یا حداقل این پوشه‌ها را پاک کنی تا فایل‌های stale باعث خطای Nest/Prisma نشوند:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
rmdir /s /q dist
rmdir /s /q node_modules\.prisma
```

اگر هنوز خطای عجیب داشتی، یک بار کامل‌تر:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
rmdir /s /q node_modules
rmdir /s /q dist
del package-lock.json
```

## 2) ساخت فایل env بک‌اند

داخل `backend` یک فایل `.env` بساز:

```env
PORT=4000
DATABASE_URL="postgresql://postgres:password@localhost:5432/cafe_dastan"
JWT_SECRET="change-me-local-dev"
JWT_REFRESH_SECRET="change-me-too-local-dev"
OTP_PROVIDER=mock
AUTH_ENFORCE=false
APP_NAME="Cafe Dastan API"
```

- `password` را با رمز PostgreSQL خودت عوض کن.
- اگر هنوز فقط می‌خواهی بدون PostgreSQL تست کنی، DATABASE_URL لازم نیست؛ ولی برای دیتابیس واقعی باید درست باشد.

## 3) ساخت دیتابیس PostgreSQL

در pgAdmin یا psql یک دیتابیس بساز با نام:

```txt
cafe_dastan
```

اگر psql داری:

```cmd
psql -U postgres -c "CREATE DATABASE cafe_dastan;"
```

## 4) نصب، Prisma generate، push، seed

راه سریع: داخل پوشه `backend` فایل زیر را اجرا کن:

```cmd
RESET_AND_SETUP_DB_WINDOWS.cmd
```

یا دستی:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
npm install
npm run prisma:generate
npm run prisma:push
npm run prisma:seed
npm run build
npm run start:dev
```

## 5) اکانت‌های پیش‌فرض پنل‌ها

بعد از seed:

```txt
admin / admin123
bar / bar123
kitchen / kitchen123
waiter / waiter123
```

## 6) اگر خطای RolesGuardMock گرفتی

این خطا یعنی فایل build قدیمی یا پروژه قبلی هنوز قاطی پروژه جدید مانده:

```txt
Nest can't resolve dependencies of the RolesGuardMock (Reflector, ?)
```

راه‌حل:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
rmdir /s /q dist
rmdir /s /q node_modules\.prisma
npm run prisma:generate
npm run build
npm run start:dev
```

در این نسخه `RolesGuardMock` اصلاً constructor ندارد، پس این خطا نباید با پروژه تمیز تکرار شود.

## 7) اگر خطای otpCode گرفتی

```txt
Property 'otpCode' does not exist on type 'PrismaService'
```

یعنی Prisma Client قدیمی است:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
npm run prisma:generate
npm run prisma:push
npm run start:dev
```

## 8) راه‌اندازی فرانت‌اند

در `frontend/.env.local` بگذار:

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:4000
```

بعد:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\frontend
npm install
npm run dev
```

برای تست با موبایل روی یک Wi-Fi:

```env
NEXT_PUBLIC_API_BASE_URL=http://IP-WINDOWS:4000
```

و فرانت را با host باز اجرا کن:

```cmd
npm run dev -- -H 0.0.0.0
```
