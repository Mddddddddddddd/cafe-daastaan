# Design System — Cafe Dastan

## Brand core
- Brand name: کافه داستان
- Core metaphor: every visit is a chapter
- Tone: warm, literary, intimate, polished, cinematic

## Visual direction
Mix of:
- Apple clarity
- Airbnb warmth
- Notion calm structure
- Spotify personalization
- Pinterest discovery
- Luxury hotel elegance
- Storytelling immersion

## Primary color
- Main Green: `#00693E`

## Supporting palette
- Deep Forest: `#0B1F17`
- Paper Ivory: `#F6F0E6`
- Warm Gold: `#B38B59`
- Ink Brown: `#4B3425`
- Mist Gray: `#D9D5CF`
- Accent Rose Dust: `#B37A6B`

## Modes
### Dark mode
- Background: near-black green/brown
- Cards: translucent deep panels with blur
- Text: warm ivory

### Light mode
- Background: paper ivory
- Cards: frosted cream
- Text: dark brown/green

## Typography
### Persian
- Suggested: Peyda / IRANSansX / Yekan Bakh / Dana (depending on license)
- Headings: bolder, premium spacing
- Body: readable with generous line-height

### English
- Serif pairing suggestion: Playfair Display / Cormorant Garamond / Libre Baskerville

## UI principles
- Mobile-first
- Soft depth
- Gentle neumorphism only where useful
- Glass morphism for overlays and feature cards
- High readability over decorative complexity

## Motion
- Slow, soft, confident
- No abrupt movement
- Page reveal with fade + slight upward float
- Card hover with depth + glow
- Ripple on tap
- Parallax on hero storytelling sections
- Smooth status transition in realtime order tracker

## Component library
- Story Hero
- Mood Selector Wheel
- Product Story Card
- Flavor Map Radar
- Story Badge / Character Capsule
- Realtime Order Timeline
- Table Card
- Bar Queue Card
- Kitchen Ticket Card
- Admin Metric Tile
- Story Toast Notification

## UX writing samples
- Welcome: «امشب دوست داری چه داستانی را مزه کنی؟»
- Memory prompt: «دفعه قبل داستانت را با یک لاته و چیزکیک شروع کردی؛ دوست داری این بار فصل جدیدی را امتحان کنی؟»
- Completion: «امشب بخشی از داستان کافه شدی. تا فصل بعد، فنجانت همیشه گرم.»

## Accessibility
- WCAG contrast targets
- Large touch targets
- Motion reduce support
- Semantic navigation
- Arabic/English RTL/LTR support
