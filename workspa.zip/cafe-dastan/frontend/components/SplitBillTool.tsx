"use client";

import { useMemo, useState } from 'react';
import { useCart } from '@/context/CartContext';

type Person = { id: string; name: string };

export default function SplitBillTool() {
  const { items } = useCart();
  const [open, setOpen] = useState(false);
  const [people, setPeople] = useState<Person[]>([
    { id: 'me', name: 'من' },
    { id: 'friend1', name: 'دوست ۱' },
  ]);
  const [assignments, setAssignments] = useState<Record<string, string>>({});

  const unitItems = useMemo(() => {
    return items.flatMap((item, itemIndex) =>
      Array.from({ length: item.qty }, (_, qtyIndex) => ({
        key: `${item.id}-${item.option}-${itemIndex}-${qtyIndex}`,
        name: item.name,
        option: item.option,
        price: item.price,
      })),
    );
  }, [items]);

  const totals = useMemo(() => {
    const map: Record<string, number> = {};
    for (const person of people) map[person.id] = 0;
    for (const item of unitItems) {
      const owner = assignments[item.key] || people[0]?.id;
      map[owner] = (map[owner] || 0) + item.price;
    }
    return map;
  }, [assignments, people, unitItems]);

  const addPerson = () => {
    const next = people.length + 1;
    setPeople((prev) => [...prev, { id: `friend${next}`, name: `دوست ${next - 1}` }]);
  };

  if (!items.length) return null;

  return (
    <section id="split-bill" className="contentPad" style={{ paddingTop: 0 }}>
      <div className="card banner splitBillCard">
        <div className="row">
          <div>
            <strong>دنگی‌دونگی</strong>
            <p>آیتم‌ها را بین خودت و دوست‌هایت تقسیم کن تا سهم هر نفر مشخص شود.</p>
          </div>
          <button className="btn secondary" onClick={() => setOpen((prev) => !prev)}>{open ? 'بستن' : 'تقسیم سفارش'}</button>
        </div>

        {open ? (
          <div className="splitBillBody">
            <div className="splitPeopleRow">
              {people.map((person) => (
                <input
                  key={person.id}
                  className="input splitPersonInput"
                  value={person.name}
                  onChange={(event) => setPeople((prev) => prev.map((item) => item.id === person.id ? { ...item, name: event.target.value } : item))}
                />
              ))}
              <button className="btn secondary" onClick={addPerson}>+ نفر</button>
            </div>

            <div className="splitItemList">
              {unitItems.map((item) => (
                <div key={item.key} className="splitItemRow">
                  <div>
                    <strong>{item.name}</strong>
                    <span>{item.option} · {item.price.toLocaleString('fa-IR')} تومان</span>
                  </div>
                  <select className="input splitSelect" value={assignments[item.key] || people[0]?.id} onChange={(event) => setAssignments((prev) => ({ ...prev, [item.key]: event.target.value }))}>
                    {people.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}
                  </select>
                </div>
              ))}
            </div>

            <div className="splitTotalsGrid">
              {people.map((person) => (
                <div key={person.id} className="splitTotalBox">
                  <span>{person.name}</span>
                  <strong>{Number(totals[person.id] || 0).toLocaleString('fa-IR')} تومان</strong>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </section>
  );
}
