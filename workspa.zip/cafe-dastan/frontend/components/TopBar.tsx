"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { apiGet } from '@/lib/api';
import ProfileEntryLink from './ProfileEntryLink';

const fallbackHome: any = {
  showHero: false,
  heroTitle: 'امشب دوست داری چه داستانی را مزه کنی؟',
  heroSubtitle: 'تجربه‌ای تصویری‌تر، شخصی‌سازی‌شده‌تر و نزدیک‌تر به منوهای مدرن موبایلی.',
  promoCode: 'DASTAN20',
  heroImage: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200&auto=format&fit=crop',
};

export default function TopBar() {
  const [home, setHome] = useState<any>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [tableContext, setTableContext] = useState<{ tableName?: string }>({});

  useEffect(() => {
    const loadTable = () => {
      if (typeof window !== 'undefined') {
        try {
          const raw = localStorage.getItem('cafe_dastan_table_context');
          if (raw) setTableContext(JSON.parse(raw));
        } catch {}
      }
    };
    loadTable();
    window.addEventListener('storage', loadTable);
    apiGet('/menu').then((res) => setHome({ ...fallbackHome, ...(res.homeSections || {}) })).catch(() => setHome(fallbackHome));
    const loadNotifications = () => apiGet('/notifications').then((res) => {
      const raw = res.data || [];
      const customerRaw = typeof window !== 'undefined' ? localStorage.getItem('cafe_dastan_customer_user') : null;
      const customer = customerRaw ? JSON.parse(customerRaw) : null;
      const filtered = customer?.id ? raw.filter((item: any) => !item?.customerId || item.customerId === customer.id) : [];
      const count = filtered.length;
      const seen = Number(localStorage.getItem('seenNotificationsCount') || '0');
      setNotificationCount(Math.max(0, count - seen));
    }).catch(() => null);
    loadNotifications();
    const interval = setInterval(loadNotifications, 30 * 1000);
    return () => clearInterval(interval);
  }, []);

  // برای جلوگیری از چشمک‌زدن بنر هنگام لود، بنر فقط وقتی نمایش داده می‌شود که بک‌اند/ادمین صراحتاً showHero=true بدهد.
  const showHero = home?.showHero === true;
  const heroImage = home?.heroImage || fallbackHome.heroImage;

  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="row">
          <div className="brandLockup">
            <img src="/images/cafedastan_logo_transparent.png" alt="لوگوی کافه داستان" className="brandLogo" />
            <div>
              <div className="brand">کافه داستان</div>
              <div className="sub">{tableContext.tableName || 'سالن اصلی کافه'} · منوی دیجیتال</div>
            </div>
          </div>
          <div className="topActions">
            <ProfileEntryLink />
            <Link href="/notifications" className="iconBtn" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              🔔
              {notificationCount > 0 ? <span className="notifBadge">{notificationCount.toLocaleString('fa-IR')}</span> : null}
            </Link>
          </div>
        </div>
        {showHero ? (
          <div className="card banner" style={{ marginTop: '10px', borderRadius: '16px', overflow: 'hidden', padding: 0 }}>
            <div style={{ position: 'relative', minHeight: '150px', background: `linear-gradient(135deg, rgba(18,56,60,.90), rgba(121,180,183,.60)), url(${heroImage}) center/cover` }}>
              <div style={{ position: 'absolute', inset: 0, padding: '16px', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <strong style={{ fontSize: '18px', display: 'block', lineHeight: 1.8 }}>{home?.heroTitle || fallbackHome.heroTitle}</strong>
                  <div style={{ fontSize: '11px', opacity: .92, lineHeight: 1.9 }}>{home?.heroSubtitle || fallbackHome.heroSubtitle}</div>
                </div>
                <div className="row" style={{ justifyContent: 'flex-start' }}>
                  {home?.promoCode ? <span className="chip active">کد تخفیف: {home.promoCode}</span> : null}
                  <span className="chip" style={{ background: 'rgba(255,255,255,.16)', color: '#fff', borderColor: 'rgba(255,255,255,.25)' }}>پیشنهاد امروز</span>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </header>
  );
}
