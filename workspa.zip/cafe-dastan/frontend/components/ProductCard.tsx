"use client";

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useCart } from '@/context/CartContext';
import { resolveImageUrl } from '@/lib/api';

export default function ProductCard({ product }: { product: any }) {
  const router = useRouter();
  const { addItem, decreaseItem, items } = useCart();
  const [imageOpen, setImageOpen] = useState(false);
  const item = items.find((i) => i.id === product.id);
  const qty = item?.qty || 0;
  const image = resolveImageUrl(product.image || '');

  const goToProduct = () => router.push(`/product/${product.id}`);
  const openImage = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    if (image) setImageOpen(true);
  };
  const closeImage = () => setImageOpen(false);

  return (
    <>
      <article
        className="card product brandPattern productClickable"
        onClick={goToProduct}
        role="link"
        tabIndex={0}
        onKeyDown={(event) => {
          if (event.key === 'Enter') goToProduct();
        }}
        aria-label={`مشاهده صفحه محصول ${product.name}`}
      >
        <button
          type="button"
          className="thumb productImageWatermark productThumbButton"
          style={image ? { backgroundImage: `url(${image})`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}
          onClick={openImage}
          aria-label={`بزرگ‌نمایی عکس ${product.name}`}
        >
          {product.outOfStock ? <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(16,34,37,.55)', zIndex: 3, color: '#fff', fontWeight: 800, fontSize: '13px' }}>🚫 ناموجود</span> : null}
          <span className="imageZoomHint">مشاهده عکس</span>
        </button>
        <div className="productInfo">
          <h3>{product.name}</h3>
          <div className="meta">
            {(product.categories || []).slice(0,2).map((cat: string) => <span key={cat} className="mini">{cat}</span>)}
            {product.discounted ? <span className="mini">تخفیف‌دار</span> : null}
          </div>
          <p className="desc">{product.desc}</p>

          <div className="productBottom">
            <div className="productPriceBlock">
              {product.oldPrice ? <div className="oldPrice">{product.oldPrice.toLocaleString('fa-IR')} تومان</div> : null}
              <div className="price">{product.price.toLocaleString('fa-IR')} تومان</div>
            </div>
          </div>

          <div className="productActions productActionsLower" onClick={(event) => event.stopPropagation()}>
            {product.outOfStock ? (
              <button className="btn" disabled style={{ opacity: .65, cursor: 'not-allowed' }}>ناموجود</button>
            ) : qty === 0 ? (
              <button className="btn" onClick={() => addItem(product.id, 'انتخاب پیش‌فرض', 0, product)}>انتخاب</button>
            ) : (
              <div className="qtyControl">
                <button className="btn secondary" onClick={() => decreaseItem(product.id, item?.option)}>-</button>
                <strong>{qty}</strong>
                <button className="btn" onClick={() => addItem(product.id, item?.option, 0, product)}>+</button>
              </div>
            )}
            <Link href={`/product/${product.id}`} className="btn secondary">جزئیات</Link>
          </div>
        </div>
      </article>

      {imageOpen ? (
        <div className="imageLightbox" onClick={closeImage} role="dialog" aria-modal="true" aria-label={`عکس ${product.name}`}>
          <button className="imageLightboxClose" type="button" onClick={closeImage} aria-label="بستن عکس">×</button>
          <div className="imageLightboxPanel" onClick={(event) => event.stopPropagation()}>
            <div
              className="imageLightboxPhoto productImageWatermark"
              style={{ backgroundImage: `url(${image})`, backgroundSize: 'contain', backgroundPosition: 'center' }}
            />
            <div className="imageLightboxCaption">
              <strong>{product.name}</strong>
              <span>{product.price.toLocaleString('fa-IR')} تومان</span>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
