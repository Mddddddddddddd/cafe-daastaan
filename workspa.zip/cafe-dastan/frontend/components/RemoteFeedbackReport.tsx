"use client";

import { useCallback, useEffect, useMemo, useState } from 'react';
import { apiDelete, apiGet } from '@/lib/api';

function avg(values: number[]) {
  const clean = values.filter(Boolean);
  if (!clean.length) return 0;
  return clean.reduce((sum, v) => sum + v, 0) / clean.length;
}

const fa = (n: number) => n.toLocaleString('fa-IR');

export default function RemoteFeedbackReport() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'low' | 'comments'>('all');
  const [status, setStatus] = useState('');
  const [busyId, setBusyId] = useState('');

  const load = useCallback(() => {
    apiGet('/feedback').then((res) => setItems(res?.data || [])).catch(() => {});
  }, []);

  useEffect(() => { load(); }, [load]);

  const summary = useMemo(() => ({
    count: items.length,
    staff: avg(items.map((i) => Number(i.staffRating || 0))),
    order: avg(items.map((i) => Number(i.orderRating || 0))),
  }), [items]);

  // میانگین امتیاز هر آیتم محصول در همه‌ی نظرسنجی‌ها
  const itemStats = useMemo(() => {
    const map = new Map<string, { name: string; ratings: number[]; count: number }>();
    for (const fb of items) {
      for (const item of fb.itemRatings || []) {
        if (!item.rating) continue;
        const key = item.name || item.productId;
        const entry = map.get(key) || { name: item.name || item.productId, ratings: [], count: 0 };
        entry.ratings.push(Number(item.rating));
        entry.count++;
        map.set(key, entry);
      }
    }
    return [...map.values()]
      .map((e) => ({ name: e.name, avg: avg(e.ratings), count: e.count }))
      .sort((a, b) => a.avg - b.avg);
  }, [items]);

  const filtered = useMemo(() => {
    const q = search.trim();
    return items.filter((fb) => {
      if (filter === 'low' && Number(fb.orderRating || 0) > 2) return false;
      if (filter === 'comments' && !fb.staffComment && !fb.orderComment) return false;
      if (q && !String(fb.orderId || '').includes(q) && !String(fb.customerName || '').includes(q)) return false;
      return true;
    });
  }, [items, search, filter]);

  const remove = async (id: string) => {
    if (typeof window !== 'undefined' && !window.confirm('این نظرسنجی حذف شود؟')) return;
    setBusyId(id);
    const res = await apiDelete(`/feedback/${id}`);
    if (res?.success) {
      setItems((prev) => prev.filter((f) => f.id !== id));
      setStatus('✅ نظرسنجی حذف شد.');
    } else {
      setStatus('❌ ' + (res?.message || 'حذف ناموفق بود.'));
    }
    setBusyId('');
  };

  const exportCsv = () => {
    const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const header = ['order_id', 'date', 'customer', 'staff_rating', 'staff_comment', 'order_rating', 'order_comment', 'item', 'item_rating', 'item_comment'];
    const rows: string[] = [header.join(',')];
    for (const fb of items) {
      const base = [fb.orderId, new Date(fb.createdAt).toLocaleDateString('en-GB'), fb.customerName, fb.staffRating || '', fb.staffComment || '', fb.orderRating || '', fb.orderComment || ''];
      const itemRows = (fb.itemRatings || []).filter((i: any) => i.rating || i.comment);
      if (!itemRows.length) rows.push([...base, '', '', ''].map(esc).join(','));
      else for (const it of itemRows) rows.push([...base, it.name || '', it.rating || '', it.comment || ''].map(esc).join(','));
    }
    const csv = '\ufeff' + rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cafe-dastan-feedback-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="card banner brandPattern">
      <div className="row" style={{ alignItems: 'center' }}>
        <div style={{ flex: 1 }}>
          <strong>نظرسنجی مشتریان</strong>
          <p>امتیازهای ثبت‌شده برای کارکنان، سفارش‌ها و آیتم‌های سفارش — با فیلتر، آمار آیتم‌ها، خروجی CSV و حذف.</p>
        </div>
        <button className="btn secondary" onClick={exportCsv} disabled={!items.length}>خروجی CSV</button>
      </div>
      <div className="accountingGrid">
        <div className="accountingItem"><strong>{fa(summary.count)}</strong><p>تعداد نظر</p></div>
        <div className="accountingItem"><strong>{summary.staff ? summary.staff.toFixed(1) : '۰'}</strong><p>میانگین کارکنان</p></div>
        <div className="accountingItem"><strong>{summary.order ? summary.order.toFixed(1) : '۰'}</strong><p>میانگین سفارش</p></div>
      </div>

      {itemStats.length ? (
        <div className="card" style={{ background: '#fff', padding: '10px', marginTop: '10px' }}>
          <strong style={{ fontSize: '13px' }}>آمار آیتم‌ها (از کمترین امتیاز)</strong>
          <div className="row" style={{ flexWrap: 'wrap', gap: '6px', marginTop: '8px' }}>
            {itemStats.slice(0, 8).map((s) => (
              <span key={s.name} className="chip" style={{ background: s.avg < 3 ? '#fdecec' : undefined, borderColor: s.avg < 3 ? '#e5a5a5' : undefined }}>
                {s.name}: {s.avg.toFixed(1)} ({fa(s.count)} نظر)
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="row" style={{ marginTop: '10px', flexWrap: 'wrap' }}>
        <input className="input" style={{ maxWidth: '220px' }} placeholder="جستجو: شناسه سفارش یا نام" value={search} onChange={(e) => setSearch(e.target.value)} />
        <button className={`chip ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>همه</button>
        <button className={`chip ${filter === 'low' ? 'active' : ''}`} onClick={() => setFilter('low')}>⚠️ امتیاز پایین (≤۲)</button>
        <button className={`chip ${filter === 'comments' ? 'active' : ''}`} onClick={() => setFilter('comments')}>با توضیح</button>
      </div>
      {status ? <div className="sub" style={{ marginTop: '6px' }}>{status}</div> : null}

      <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
        {filtered.map((fb) => (
          <div key={fb.id} className="card" style={{ padding: '10px', background: '#fff', border: Number(fb.orderRating || 0) <= 2 ? '1px solid #e5a5a5' : undefined }}>
            <div className="row" style={{ alignItems: 'center' }}>
              <div style={{ flex: 1 }}>
                <strong>سفارش #{fb.orderId}</strong>
                <span className="sub"> · {new Date(fb.createdAt).toLocaleDateString('fa-IR')}</span>
              </div>
              <button className="btn secondary" style={{ fontSize: '12px' }} disabled={busyId === fb.id} onClick={() => remove(fb.id)}>حذف</button>
            </div>
            <div className="sub">کارکنان: {fb.staffRating}/۵ · سفارش: {fb.orderRating}/۵ · {fb.customerName}</div>
            {fb.staffComment ? <p>کارکنان: {fb.staffComment}</p> : null}
            {fb.orderComment ? <p>سفارش: {fb.orderComment}</p> : null}
            {(fb.itemRatings || []).filter((i: any) => i.rating || i.comment).map((item: any) => (
              <div key={item.productId + (item.name || '')} className="sub">{item.name}: {item.rating || 0}/۵ {item.comment ? `· ${item.comment}` : ''}</div>
            ))}
          </div>
        ))}
        {!filtered.length ? <p>{items.length ? 'موردی با این فیلتر پیدا نشد.' : 'هنوز نظری ثبت نشده است.'}</p> : null}
      </div>
    </div>
  );
}
