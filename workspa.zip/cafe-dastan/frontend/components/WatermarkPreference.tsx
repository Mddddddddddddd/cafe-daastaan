"use client";

import { useEffect } from 'react';
import { API_BASE_URL } from '@/lib/api';

// می‌خواند واترمارک محصولات از تنظیمات صفحه‌ی اصلی (homeSections.watermark) روشن است یا نه
// و کلاس wm-off را روی <html> می‌زند تا CSS لایه‌ی واترمارک را پنهان کند.
// پیش‌فرض: خاموش (تا ادمین آن را روشن نکند).
export default function WatermarkPreference() {
  useEffect(() => {
    let cancelled = false;
    fetch(`${API_BASE_URL}/menu/home`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled || !data?.success) return;
        const enabled = data.homeSections?.watermark === true;
        document.documentElement.classList.toggle('wm-off', !enabled);
      })
      .catch(() => {
        if (!cancelled) document.documentElement.classList.add('wm-off');
      });
    return () => { cancelled = true; };
  }, []);
  return null;
}
