"use client";

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { clearStaffAuth, isStaffAuthenticated } from '@/lib/api';

const roleLoginMap: Record<string, string> = {
  admin: '/admin/login',
  bar: '/bar/login',
  kitchen: '/kitchen/login',
  waiter: '/waiter/login',
};

export default function ProtectedPage({ role, title, children }: { role: 'admin' | 'bar' | 'kitchen' | 'waiter'; title: string; children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    // پنل‌های پرسنل نباید با polling یا تغییر صفحه بی‌دلیل logout شوند.
    // تا وقتی کاربر خودش خروج نزده، flag ورود staff معتبر است.
    const ok = isStaffAuthenticated(role);
    if (ok) {
      setAllowed(true);
      return;
    }

    setAllowed(false);
    router.replace(roleLoginMap[role]);
  }, [role, router, pathname]);

  const logout = () => {
    clearStaffAuth(role);
    router.replace(roleLoginMap[role]);
  };

  if (!allowed) {
    return (
      <main className="page">
        <section className="contentPad">
          <div className="card banner">درحال بررسی دسترسی...</div>
        </section>
      </main>
    );
  }

  return (
    <main className="page">
      <div className="row contentPad">
        <button className="link" onClick={logout}>خروج</button>
        <strong>{title}</strong>
      </div>
      {children}
    </main>
  );
}
