"use client";

import { useEffect, useMemo, useState } from 'react';
import ProductCard from '@/components/ProductCard';
import CafeStories from '@/components/CafeStories';
import MoodAndUsualActions from '@/components/MoodAndUsualActions';
import { apiGet, resolveImageUrl } from '@/lib/api';

// فقط فالبک است؛ دسته‌بندی‌های اصلی از دیتابیس (مدیریت دسته‌بندی ادمین) خوانده می‌شوند.
const fallbackCategories = ['همه', 'نوشیدنی گرم', 'نوشیدنی سرد', 'قهوه تخصصی', 'دمنوش', 'صبحانه', 'دسر', 'کیک', 'غذای سبک', 'فصلی', 'ویژه کافه'];

function HomeCard({ card, tone = 'green', onClick }: { card: any; tone?: 'green' | 'gold'; onClick?: () => void }) {
  if (!card || card.visible === false) return null;
  const hasImage = !!card.image;
  const gradient = tone === 'gold'
    ? 'linear-gradient(135deg, rgba(179,139,89,.78), rgba(120,82,45,.48))'
    : 'linear-gradient(135deg, rgba(18,56,60,.88), rgba(121,180,183,.62))';
  const background = hasImage ? `${gradient}, url(${resolveImageUrl(card.image)}) center/cover` : gradient;

  return (
    <button type="button" onClick={onClick} className="card banner" style={{ flex: 1, borderRadius: '16px', overflow: 'hidden', padding: 0, border: '1px solid var(--line)', textAlign: 'right', cursor: onClick ? 'pointer' : 'default' }}>
      <div style={{ minHeight: '96px', background, color: '#fff', padding: '12px' }}>
        <strong>{card.title}</strong>
        <div style={{ fontSize: '11px', lineHeight: 1.8, marginTop: '8px' }}>{card.text}</div>
        {onClick ? <div style={{ fontSize: '10px', marginTop: '8px', opacity: .9 }}>برای مشاهده بزنید ←</div> : null}
      </div>
    </button>
  );
}

export default function RemoteMenu() {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('همه');
  const [items, setItems] = useState<any[]>([]);
  const [homeSections, setHomeSections] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [focusMode, setFocusMode] = useState<'all' | 'suggested' | 'discounted'>('all');

  const [categories, setCategories] = useState<string[]>(fallbackCategories);

  useEffect(() => {
    apiGet('/menu').then((res) => {
      setItems(res.data || []);
      setHomeSections(res.homeSections || null);
      setLoading(false);
    });
  }, []);

  // دسته‌بندی‌های فعال از دیتابیس (همان چیزی که ادمین در «مدیریت دسته‌بندی» ساخته)
  useEffect(() => {
    apiGet('/menu/categories').then((res) => {
      if (res?.success && Array.isArray(res.data) && res.data.length) {
        setCategories(['همه', ...res.data]);
      }
    }).catch(() => {});
  }, []);

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const matchCategory = activeCategory === 'همه' ? true : (item.categories || []).includes(activeCategory);
      const q = query.trim();
      const matchQuery = q ? item.name.includes(q) || (item.desc || '').includes(q) || (item.categories || []).join(' ').includes(q) : true;
      return matchCategory && matchQuery;
    });
  }, [items, query, activeCategory]);

  const promoCards = (homeSections?.promoCards || []).filter((card: any) => card?.visible !== false);
  const hasMemoryCard = !!homeSections?.memoryCard && homeSections.memoryCard.visible !== false;
  const hasMoodCard = !!homeSections?.moodCard && homeSections.moodCard.visible !== false;
  const showMemoryMood = homeSections?.showMemoryMood !== false && (hasMemoryCard || hasMoodCard);
  const suggestedItems = filtered.filter((item) => item.featured);
  const discountedItems = filtered.filter((item) => item.discounted);
  const showSuggested = homeSections?.showSuggested !== false;
  const showDiscounted = homeSections?.showDiscounted !== false;
  const regularItems = filtered.filter((item) => (!showSuggested || !item.featured) && (!showDiscounted || !item.discounted));
  const finalSuggested = suggestedItems.length ? suggestedItems : filtered;

  const jumpTo = (target: 'suggested' | 'discounted') => {
    setFocusMode(target);
    setActiveCategory('همه');
    window.setTimeout(() => window.scrollTo({ top: 0, behavior: 'smooth' }), 0);
  };

  return (
    <>
      {focusMode !== 'all' ? (
        <section className="section" style={{ paddingTop: '8px' }}>
          <div className="card banner">
            <div className="row">
              <strong>{focusMode === 'suggested' ? 'پیشنهادهای ما' : 'سفارش‌های تخفیف‌دار'}</strong>
              <button className="btn secondary" onClick={() => setFocusMode('all')}>بازگشت به منو اصلی</button>
            </div>
            <p>در این حالت فقط همین بخش نمایش داده می‌شود.</p>
          </div>
        </section>
      ) : (
        <section className="section" style={{ paddingTop: '8px' }}>
          <input className="input" placeholder="جستجو در نوشیدنی‌ها، دسرها و آیتم‌های کافه..." value={query} onChange={(e) => setQuery(e.target.value)} style={{ marginTop: 0, fontSize: '16px', touchAction: 'manipulation' }} />
        </section>
      )}

      {focusMode === 'all' ? <MoodAndUsualActions /> : null}

      {focusMode === 'all' && showMemoryMood ? (
        <section className="section" style={{ paddingTop: '4px' }}>
          <div className="row" style={{ gap: '10px' }}>
            <HomeCard card={homeSections?.memoryCard} tone="green" />
            <HomeCard card={homeSections?.moodCard} tone="gold" />
          </div>
        </section>
      ) : null}

      {focusMode === 'all' && false && promoCards.length ? (
        <section className="section" style={{ paddingTop: '4px' }}>
          <div className="titleRow"><div className="title">کارت‌های صفحه اصلی</div><div className="link">قابل مدیریت از ادمین</div></div>
          <div className="row" style={{ gap: '10px', alignItems: 'stretch' }}>
            {promoCards.slice(0, 4).map((card: any, index: number) => {
              const title = `${card.title || ''} ${card.text || ''}`;
              const target = title.includes('تخفیف') ? 'discounted' : 'suggested';
              return <HomeCard key={card.id || index} card={card} tone={index % 2 ? 'gold' : 'green'} onClick={() => jumpTo(target as any)} />;
            })}
          </div>
        </section>
      ) : null}

      {focusMode === 'all' ? <CafeStories /> : null}

      {showSuggested && focusMode === 'suggested' ? (
        <section id="suggested-section" className="section" style={{ paddingTop: '6px' }}>
          <div className="titleRow"><div className="title">پیشنهادهای ما</div><div className="link">{loading ? '...' : `${finalSuggested.length} آیتم`}</div></div>
          <div className="grid">
            {loading ? <div className="card banner">درحال دریافت منو...</div> : finalSuggested.map((item) => <ProductCard key={item.id} product={item} />)}
          </div>
        </section>
      ) : null}

      {!loading && showDiscounted && discountedItems.length && focusMode === 'discounted' ? (
        <section id="discounted-section" className="section" style={{ paddingTop: '6px' }}>
          <div className="titleRow"><div className="title">سفارش‌های تخفیف‌دار</div><div className="link">با قیمت ویژه</div></div>
          <div className="grid">
            {discountedItems.map((item) => <ProductCard key={`discount-${item.id}`} product={item} />)}
          </div>
        </section>
      ) : null}

      {!loading && focusMode === 'all' ? (
        <section className="section" style={{ paddingTop: '6px' }}>
          <div className="titleRow"><div className="title">منو</div><div className="link">{filtered.length} آیتم</div></div>
          <div className="chips" style={{ marginBottom: '10px' }}>
            {showSuggested ? <button className="chip" onClick={() => jumpTo('suggested')}>پیشنهادهای ما</button> : null}
            {showDiscounted ? <button className="chip" onClick={() => jumpTo('discounted')}>سفارش‌های تخفیف‌دار</button> : null}
          </div>
          <div className="categoryRail menuCategoryRail"><div className="chips">
            {categories.map((cat) => (
              <button key={cat} className={`chip ${activeCategory === cat ? 'active' : ''}`} onClick={() => setActiveCategory(cat)} style={{ cursor: 'pointer' }}>{cat}</button>
            ))}
          </div></div>
          <div className="grid" style={{ marginTop: '10px' }}>
            {filtered.map((item) => <ProductCard key={`menu-${item.id}`} product={item} />)}
          </div>
        </section>
      ) : null}
    </>
  );
}
