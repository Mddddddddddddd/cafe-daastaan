"use client";

import { useState } from 'react';
import { useCart } from '@/context/CartContext';

export default function AddToCartButton({ productId, product, option, extraPrice = 0 }: { productId: string; product?: any; option?: string; extraPrice?: number }) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addItem(productId, option, extraPrice, product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1600);
  };

  if (product?.outOfStock) {
    return (
      <button className="btn" disabled style={{ opacity: .65, cursor: 'not-allowed' }}>
        🚫 این آیتم فعلاً موجود نیست
      </button>
    );
  }

  return (
    <button className="btn" onClick={handleAdd} style={{ opacity: added ? 0.9 : 1, boxShadow: added ? '0 0 0 4px rgba(121,180,183,.22)' : 'none' }}>
      {added ? '✓ به سبد اضافه شد' : 'افزودن به سبد'}
    </button>
  );
}
