"use client";

import { useEffect, useRef } from 'react';

let audioCtx: AudioContext | null = null;

// صدای کوتاه و ملایم شبیه نوتیفیکیشن پیامک (سه نت زردالو-سی-솔)
function playOrderChime() {
  try {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    if (!audioCtx) audioCtx = new Ctx();
    if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    const notes = [1318.51, 1046.5, 783.99]; // E6, C6, G5
    notes.forEach((freq, i) => {
      const osc = audioCtx!.createOscillator();
      const gain = audioCtx!.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const t = audioCtx!.currentTime + i * 0.1;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.22, t + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
      osc.connect(gain);
      gain.connect(audioCtx!.destination);
      osc.start(t);
      osc.stop(t + 0.6);
    });
  } catch { /* صدا در دسترس نیست */ }
}

// وقتی شناسه‌ی سفارش جدیدی در لیست ظاهر شد، چیم بزن (یک‌بار برای هر بار ورود چند سفارش)
export default function useNewOrderChime(orderIds: string[]) {
  const prevIds = useRef<Set<string> | null>(null);
  const firstRun = useRef(true);

  useEffect(() => {
    const ids = new Set(orderIds || []);
    if (firstRun.current) {
      firstRun.current = false;
      prevIds.current = ids;
      return;
    }
    const prev = prevIds.current || new Set<string>();
    let hasNew = false;
    for (const id of ids) if (!prev.has(id)) { hasNew = true; break; }
    if (hasNew) playOrderChime();
    prevIds.current = ids;
  }, [orderIds]);
}
