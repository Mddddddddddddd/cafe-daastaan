"use client";

import { useEffect, useMemo, useRef, useState } from 'react';
import { apiDelete, apiGet, apiPost, getCustomerContext } from '@/lib/api';

const DAY_MS = 24 * 60 * 60 * 1000;
const STORY_USER_KEY = 'cafe_dastan_story_user_id';
const MAX_STORY_IMAGE_SIZE_MB = 25;
const MAX_STORY_VIDEO_SIZE_MB = 40;
const STORY_AUTO_NEXT_MS = 5000;
const STORY_MAX_DIMENSION = 1600;
const STORY_OUTPUT_QUALITY = 0.82;

function isFreshStory(story: any) {
  const expiresAt = story?.expiresAt ? new Date(story.expiresAt).getTime() : NaN;
  if (Number.isFinite(expiresAt)) return Date.now() < expiresAt;
  const t = story?.createdAt ? new Date(story.createdAt).getTime() : Date.now();
  return Number.isFinite(t) ? Date.now() - t < DAY_MS : true;
}

function getStoryUserId() {
  if (typeof window === 'undefined') return 'guest-story-user';
  let value = localStorage.getItem(STORY_USER_KEY);
  if (!value) {
    value = `story-user-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(STORY_USER_KEY, value);
  }
  return value;
}

function toMediaUrl(value?: string) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw.startsWith('data:image/') || raw.startsWith('data:video/')) return raw;
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  // /uploads به صورت نسبی برمی‌گردد تا از طریق rewrite در Next.js از همان دامنه نمایش داده شود
  // و به localhost روی گوشی مشتری برخورد نکند.
  if (raw.startsWith('/uploads/')) return raw;
  if (raw.startsWith('/images/')) return raw;
  return raw;
}

function loadImage(file: File) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('image-load-failed'));
    };
    img.src = objectUrl;
  });
}

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('read-file-failed'));
    reader.readAsDataURL(file);
  });
}

function formatRemaining(ms: number) {
  const safe = Math.max(0, Number(ms || 0));
  const totalMinutes = Math.ceil(safe / (60 * 1000));
  const days = Math.floor(totalMinutes / (24 * 60));
  const hours = Math.floor((totalMinutes % (24 * 60)) / 60);
  const minutes = totalMinutes % 60;

  if (days > 0) return `${days.toLocaleString('fa-IR')} روز`;
  if (hours > 0) return `${hours.toLocaleString('fa-IR')} ساعت`;
  return `${Math.max(1, minutes).toLocaleString('fa-IR')} دقیقه`;
}

async function compressStoryImage(file: File) {
  if (typeof window === 'undefined') {
    return { dataUrl: '', compressed: false, originalSizeMb: 0, outputSizeMb: 0 };
  }

  const originalSizeMb = file.size / (1024 * 1024);
  const image = await loadImage(file);
  const canvas = document.createElement('canvas');

  let width = image.naturalWidth || image.width;
  let height = image.naturalHeight || image.height;
  const largestSide = Math.max(width, height);

  if (largestSide > STORY_MAX_DIMENSION) {
    const ratio = STORY_MAX_DIMENSION / largestSide;
    width = Math.max(1, Math.round(width * ratio));
    height = Math.max(1, Math.round(height * ratio));
  }

  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('canvas-context-failed');

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(image, 0, 0, width, height);

  let quality = STORY_OUTPUT_QUALITY;
  let dataUrl = canvas.toDataURL('image/jpeg', quality);
  let outputSizeMb = dataUrl.length * 0.75 / (1024 * 1024);

  while (outputSizeMb > 2.2 && quality > 0.58) {
    quality -= 0.06;
    dataUrl = canvas.toDataURL('image/jpeg', quality);
    outputSizeMb = dataUrl.length * 0.75 / (1024 * 1024);
  }

  return {
    dataUrl,
    compressed: outputSizeMb < originalSizeMb || width !== (image.naturalWidth || image.width) || height !== (image.naturalHeight || image.height),
    originalSizeMb,
    outputSizeMb,
  };
}

export default function CafeStories({ upload = false }: { upload?: boolean }) {
  const [stories, setStories] = useState<any[]>([]);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [caption, setCaption] = useState('');
  const [image, setImage] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [comment, setComment] = useState('');
  const [message, setMessage] = useState('');
  const [storyUserId, setStoryUserId] = useState('guest-story-user');
  const [isPublished, setIsPublished] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressStartRef = useRef<number | null>(null);
  const remainingRef = useRef<number>(STORY_AUTO_NEXT_MS);
  const progressRafRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const touchCurrentYRef = useRef<number | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const freshStories = useMemo(() => stories.filter(isFreshStory).map((story) => ({ ...story, image: toMediaUrl(story.image) })), [stories]);
  const active = activeIndex !== null ? freshStories[activeIndex] : null;

  const clearAutoNext = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (progressRafRef.current !== null && typeof window !== 'undefined') {
      window.cancelAnimationFrame(progressRafRef.current);
      progressRafRef.current = null;
    }
  };

  const load = (viewerId = storyUserId) => apiGet(`/stories?viewerId=${encodeURIComponent(viewerId)}`).then((res) => setStories((res.data || []).filter(isFreshStory)));

  useEffect(() => {
    const customer = getCustomerContext();
    const id = customer.customerId || getStoryUserId();
    setStoryUserId(id);
  }, []);

  useEffect(() => {
    if (!storyUserId) return;
    load(storyUserId);
  }, [storyUserId]);

  useEffect(() => {
    if (activeIndex !== null && activeIndex >= freshStories.length) setActiveIndex(freshStories.length ? freshStories.length - 1 : null);
  }, [activeIndex, freshStories.length]);

  useEffect(() => {
    clearAutoNext();

    if (activeIndex === null || !freshStories.length || isPaused) return;
    if (active?.mediaType === 'video') return;

    if (!remainingRef.current || remainingRef.current <= 0 || remainingRef.current > STORY_AUTO_NEXT_MS) {
      remainingRef.current = STORY_AUTO_NEXT_MS;
    }

    const startedAt = Date.now();
    progressStartRef.current = startedAt;

    const tick = () => {
      const elapsed = Date.now() - startedAt;
      const consumed = STORY_AUTO_NEXT_MS - remainingRef.current + elapsed;
      const nextProgress = Math.max(0, Math.min(100, (consumed / STORY_AUTO_NEXT_MS) * 100));
      if (nextProgress < 100) {
        progressRafRef.current = window.requestAnimationFrame(tick);
      }
    };

    progressRafRef.current = window.requestAnimationFrame(tick);

    timerRef.current = setTimeout(() => {
      setComment('');
      remainingRef.current = STORY_AUTO_NEXT_MS;
      setActiveIndex((current) => {
        if (current === null) return null;
        if (current >= freshStories.length - 1) return null;
        return current + 1;
      });
    }, remainingRef.current);

    return () => clearAutoNext();
  }, [activeIndex, freshStories.length, isPaused, active?.mediaType]);

  useEffect(() => {
    if (activeIndex === null) {
      setIsPaused(false);
      remainingRef.current = STORY_AUTO_NEXT_MS;
      clearAutoNext();
    }
  }, [activeIndex]);

  useEffect(() => () => clearAutoNext(), []);

  const pauseStory = () => {
    if (activeIndex === null || isPaused) return;
    if (active?.mediaType === 'video' && videoRef.current) videoRef.current.pause();
    if (progressStartRef.current) {
      const elapsed = Date.now() - progressStartRef.current;
      remainingRef.current = Math.max(0, remainingRef.current - elapsed);
    }
    setIsPaused(true);
  };

  const resumeStory = () => {
    if (activeIndex === null) return;
    if (active?.mediaType === 'video' && videoRef.current) videoRef.current.play().catch(() => {});
    setIsPaused(false);
  };

  const onFile = async (file?: File) => {
    if (!file || isProcessingImage) return;

    const detectedMediaType = file.type.startsWith('video/') ? 'video' : 'image';
    const sizeMb = file.size / (1024 * 1024);

    if (detectedMediaType === 'video') {
      if (sizeMb > MAX_STORY_VIDEO_SIZE_MB) {
        setMessage(`حجم ویدیو زیاد است. لطفاً ویدیوی زیر ${MAX_STORY_VIDEO_SIZE_MB} مگابایت انتخاب کنید.`);
        return;
      }
      try {
        setIsProcessingImage(true);
        setMessage('درحال آماده‌سازی ویدیوی استوری...');
        const dataUrl = await fileToDataUrl(file);
        setMediaType('video');
        setImage(dataUrl);
        setIsPublished(false);
        setMessage('ویدیوی استوری آماده انتشار است.');
      } catch {
        setMessage('خطا در آماده‌سازی ویدیو. لطفاً دوباره تلاش کنید.');
      } finally {
        setIsProcessingImage(false);
      }
      return;
    }

    if (sizeMb > MAX_STORY_IMAGE_SIZE_MB) {
      setMessage(`حجم عکس زیاد است. لطفاً عکس زیر ${MAX_STORY_IMAGE_SIZE_MB} مگابایت انتخاب کنید.`);
      return;
    }

    try {
      setIsProcessingImage(true);
      setMessage('درحال آماده‌سازی و فشرده‌سازی عکس...');
      const result = await compressStoryImage(file);
      setMediaType('image');
      setImage(String(result.dataUrl || ''));
      setIsPublished(false);
      setMessage(
        result.compressed
          ? `عکس برای آپلود بهتر فشرده شد. حجم تقریبی از ${result.originalSizeMb.toFixed(1)} به ${result.outputSizeMb.toFixed(1)} مگابایت رسید.`
          : 'عکس آماده انتشار است.'
      );
    } catch {
      setMessage('خطا در آماده‌سازی عکس. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsProcessingImage(false);
    }
  };

  const submitStory = async () => {
    if (!image || isSubmitting || isPublished || isProcessingImage) { return; }
    setIsSubmitting(true);
    const customer = getCustomerContext();
    const res = await apiPost('/stories', { userName: customer.name || 'مهمان کافه', caption, image, mediaType, ownerId: storyUserId, customerId: customer.customerId });
    setIsSubmitting(false);
    if (res.success) {
      setMessage('استوری شما منتشر شد.');
      setIsPublished(true);
      load(storyUserId);
    } else {
      setMessage('خطا در انتشار استوری');
    }
  };

  const deleteStory = async (id: string) => {
    const ok = typeof window === 'undefined' ? true : window.confirm('این استوری حذف شود؟');
    if (!ok) return;
    const res = await apiDelete(`/stories/${id}?ownerId=${encodeURIComponent(storyUserId)}`);
    if (res?.success) {
      setStories((prev) => prev.filter((story) => story.id !== id));
      if (active?.id === id) setActiveIndex(null);
      setMessage('استوری حذف شد.');
    }
  };

  const openStoryById = (id: string) => {
    const nextIndex = freshStories.findIndex((story) => story.id === id);
    if (nextIndex === -1) return;
    setComment('');
    remainingRef.current = STORY_AUTO_NEXT_MS;
    setIsPaused(false);
    setActiveIndex(nextIndex);
  };

  const closeStory = () => setActiveIndex(null);

  const goNext = () => {
    setComment('');
    remainingRef.current = STORY_AUTO_NEXT_MS;
    setIsPaused(false);
    setActiveIndex((index) => {
      if (index === null) return null;
      if (index >= freshStories.length - 1) return null;
      return index + 1;
    });
  };

  const goPrev = () => {
    setComment('');
    remainingRef.current = STORY_AUTO_NEXT_MS;
    setIsPaused(false);
    setActiveIndex((index) => {
      if (index === null) return null;
      return Math.max(index - 1, 0);
    });
  };

  const likeStory = async (id: string) => {
    const target = stories.find((story) => story.id === id);
    if (target?.likedByMe) return;
    const res = await apiPost(`/stories/${id}/like`, { viewerId: storyUserId });
    if (res?.success && res.data) {
      setStories((prev) => prev.map((story) => story.id === id ? res.data : story));
    }
  };

  const sendComment = async () => {
    if (!active || !comment.trim()) return;
    const customer = getCustomerContext();
    const res = await apiPost(`/stories/${active.id}/comments`, { userName: customer.name || 'مهمان', text: comment, viewerId: storyUserId, customerId: customer.customerId });
    setComment('');
    if (res.success) { setStories((prev) => prev.map((story) => story.id === active.id ? res.data : story)); }
  };

  const onViewerTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
    touchStartYRef.current = event.touches[0]?.clientY ?? null;
    touchCurrentYRef.current = touchStartYRef.current;
  };

  const onViewerTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
    touchCurrentYRef.current = event.touches[0]?.clientY ?? null;
  };

  const onViewerTouchEnd = () => {
    if (touchStartYRef.current === null || touchCurrentYRef.current === null) {
      touchStartYRef.current = null;
      touchCurrentYRef.current = null;
      return;
    }
    const deltaY = touchCurrentYRef.current - touchStartYRef.current;
    if (Math.abs(deltaY) > 110) closeStory();
    touchStartYRef.current = null;
    touchCurrentYRef.current = null;
  };

  return (
    <>
      {!upload ? (
        <section className="section" style={{ paddingTop: '8px' }}>
          <div className="titleRow"><div className="title">استوری‌های کافه داستان</div><div className="link">همه استوری‌ها</div></div>
          <div className="storyRail">
            {freshStories.map((story) => (
              <button key={story.id} className={`storyBubble ${story.isHighlight ? 'storyBubbleHighlight' : ''}`} onClick={() => openStoryById(story.id)}>
                <img src={story.image} alt={story.caption || 'story'} />
                <span>{story.userName}</span>
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {upload ? (
        <section id="upload-story" className="contentPad" style={{ paddingTop: 0 }}>
          <div className="card banner logoWatermark">
            <strong>آپلود استوری از سفارش یا فضای کافه</strong>
            <p>عکس، ویدیو و کپشن را همین‌جا وارد کن؛ قبل از انتشار، پیش‌نمایش کامل نمایش داده می‌شود.</p>
            <p style={{ marginTop: '6px', color: 'var(--muted)', fontSize: '12px' }}>حداکثر حجم عکس: ۲۵ مگابایت | حداکثر حجم ویدیو: ۴۰ مگابایت</p>
            <p style={{ marginTop: '4px', color: 'var(--muted)', fontSize: '12px' }}>عکس‌های حجیم قبل از آپلود به‌صورت خودکار برای موبایل فشرده می‌شوند.</p>
            <label className="storyUploadBox storyUploadBoxPreview">
              <input type="file" accept="image/*,video/*" capture="environment" onChange={(e) => onFile(e.target.files?.[0])} />
              {image ? (
                mediaType === 'video'
                  ? <video src={image} className="storyPreviewFull" controls playsInline />
                  : <img src={image} alt="preview" className="storyPreviewFull" />
              ) : <span>{isProcessingImage ? 'درحال آماده‌سازی فایل...' : '＋ انتخاب یا گرفتن عکس / ویدیو استوری'}</span>}
            </label>
            <input className="input" placeholder="کپشن استوری را بنویس..." value={caption} onChange={(e) => setCaption(e.target.value)} />
            <button className="btn" style={{ marginTop: '10px', width: '100%', opacity: isPublished ? 0.85 : 1 }} onClick={submitStory} disabled={isPublished || isSubmitting || isProcessingImage}>
              {isProcessingImage ? 'درحال آماده‌سازی فایل...' : isSubmitting ? 'درحال انتشار...' : isPublished ? 'استوری شما منتشر شد' : 'انتشار استوری'}
            </button>
            {message ? <p style={{ color: 'var(--primary)' }}>{message}</p> : null}
          </div>
        </section>
      ) : null}

      {active ? (
        <div className="storyViewer" onClick={closeStory}>
          <div className="storyModal" onClick={(e) => e.stopPropagation()} onTouchStart={onViewerTouchStart} onTouchMove={onViewerTouchMove} onTouchEnd={onViewerTouchEnd}>
            <button className="storyClose" aria-label="بستن استوری" onClick={closeStory}>×</button>
            <div className="storyProgress">
              {freshStories.map((story, index) => {
                const isSeen = index < (activeIndex || 0);
                const isCurrent = index === (activeIndex || 0);
                return (
                  <span key={story.id} className={`${isSeen ? 'seen' : ''} ${isCurrent ? 'current' : ''}`.trim()}>
                    {isCurrent ? <i style={{ width: '100%' }} /> : null}
                  </span>
                );
              })}
            </div>
            <div className="storyMetaTop storyMetaTopRight">
              <strong className="storyTinyUser">{active.userName}</strong>
            </div>
            <div className="storyMetaTop storyMetaTopLeft">
              <span className="storyTinyTime">{formatRemaining(active.remainingMs)}</span>
            </div>
            <button
              className="storyTapZone storyTapRight"
              aria-label="استوری بعدی"
              onClick={goNext}
              onMouseDown={pauseStory}
              onMouseUp={resumeStory}
              onMouseLeave={resumeStory}
              onTouchStart={pauseStory}
              onTouchEnd={resumeStory}
            />
            <button
              className="storyTapZone storyTapLeft"
              aria-label="استوری قبلی"
              onClick={goPrev}
              disabled={(activeIndex || 0) <= 0}
              onMouseDown={pauseStory}
              onMouseUp={resumeStory}
              onMouseLeave={resumeStory}
              onTouchStart={pauseStory}
              onTouchEnd={resumeStory}
            />
            {active.mediaType === 'video' ? (
              <video
                ref={videoRef}
                src={active.image}
                style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#111' }}
                autoPlay
                playsInline
                controls={false}
                muted
                onEnded={goNext}
                onMouseDown={pauseStory}
                onMouseUp={resumeStory}
                onMouseLeave={resumeStory}
                onTouchStart={pauseStory}
                onTouchEnd={resumeStory}
              />
            ) : (
              <img
                src={active.image}
                alt="story"
                style={{ objectFit: 'contain', background: '#111' }}
                onMouseDown={pauseStory}
                onMouseUp={resumeStory}
                onMouseLeave={resumeStory}
                onTouchStart={pauseStory}
                onTouchEnd={resumeStory}
              />
            )}
            <div className="storyOverlay">
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                <div className="row" style={{ justifyContent: 'flex-start' }}>
                  {active.isAdmin ? <span className="chip">ادمین</span> : null}
                  {active.isHighlight ? <span className="chip">ویژه</span> : null}
                  {isPaused ? <span className="chip">مکث</span> : null}
                </div>
                {active.canDelete ? <button className="btn secondary" onClick={() => deleteStory(active.id)} style={{ padding: '4px 8px', fontSize: '10px' }}>حذف استوری</button> : null}
              </div>
              <p>{active.caption}</p>
              <div className="row" style={{ justifyContent: 'flex-start' }}>
                <button className="btn storyLikeBtn" onClick={() => likeStory(active.id)} style={{ opacity: active.likedByMe ? 0.75 : 1 }}>
                  ♥ {(active.likes || 0).toLocaleString('fa-IR')}
                </button>
              </div>
              <div className="storyComments">
                {(active.comments || []).slice(-3).map((c: any) => <div key={c.id}><strong>{c.userName}:</strong> {c.text}</div>)}
              </div>
              <div className="storyCommentBox">
                <input className="input" placeholder="کامنت بنویس..." value={comment} onChange={(e) => setComment(e.target.value)} />
                <button className="btn" onClick={sendComment}>ارسال</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
