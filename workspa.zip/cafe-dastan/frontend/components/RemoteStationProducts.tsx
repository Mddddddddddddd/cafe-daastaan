"use client";

import { useEffect, useState } from 'react';
import { apiGet, apiPatch, resolveImageUrl } from '@/lib/api';

// مدیریت محصولات مربوط به ایستگاه (بار / آشپزخانه): نمایش/مخفی از منو و ناموجود
export default function RemoteStationProducts({ role }: { role: 'bar' | 'kitchen' }) {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [busyId, setBusyId] = useState('');

  const load = () => {
    setLoading(true);
    apiGet(`/staff/${role}/products`).then((res) => {
      setProducts(res?.success ? (res.data || []) : []);
      if (!res?.success) setStatus(res?.message || 'خطا در دریافت محصولات.');
    }).catch(() => setStatus('خطای شبکه یا سرور.')).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [role]);

  const update = async (id: string, patch: any) => {
    setBusyId(id);
    const res = await apiPatch(`/staff/${role}/products/${id}`, patch);
    if (res?.success) {
      setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
      if (patch.outOfStock !== undefined) setStatus(patch.outOfStock ? '✅ «ناموجود» فعال شد؛ مشتری می‌بیند ولی نمی‌تواند سفارش بدهد.' : '✅ حالت «ناموجود» برداشته شد.');
      else setStatus(patch.active ? '✅ محصول در منو نمایش داده می‌شود.' : '✅ محصول از منو مخفی شد.');
    } else {
      setStatus('❌ ' + (res?.message || 'به‌روزرسانی ناموفق بود.'));
    }
    setBusyId('');
  };

  const title = role === 'bar' ? 'بار و کافه' : 'آشپزخانه';

  return (
    <section className="contentPad" style={{ marginTop: '10px' }}>
      <div className="card banner">
        <p>این محصولات مربوط به <strong>{title}</strong> هستند. اگر آیتمی موجود نیست، یکی از دو حالت را انتخاب کن:</p>
        <div style={{ display: 'grid', gap: '4px', margin: '8px 0 0 14px' }}>
          <span>🚫 <strong>ناموجود</strong>: مشتری در منو می‌بیند ولی نمی‌تواند سفارش بدهد</span>
          <span>🙈 <strong>مخفی از منو</strong>: اصلاً در منو نمایش داده نمی‌شود</span>
        </div>
        {status ? <div className="sub" style={{ marginTop: '8px' }}>{status}</div> : null}
      </div>
      {loading ? <div className="card" style={{ marginTop: '10px' }}>در حال بارگذاری...</div> : (
        <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
          {products.length === 0 ? <div className="card sub">محصولی برای این ایستگاه ثبت نشده است.</div> : products.map((p) => (
            <div key={p.id} className="card" style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px' }}>
              <div style={{ width: '52px', height: '52px', borderRadius: '12px', backgroundImage: `url(${resolveImageUrl(p.image || '')})`, backgroundSize: 'cover', backgroundPosition: 'center', flexShrink: 0, border: '1px solid var(--line)' }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <strong>{p.name}</strong>
                <div className="sub">{Number(p.price || 0).toLocaleString('fa-IR')} تومان</div>
              </div>
              <div style={{ display: 'grid', gap: '6px' }}>
                <button className={p.active === false ? 'btn' : 'btn secondary'} style={{ minWidth: '118px', fontSize: '12px' }} disabled={!!busyId} onClick={() => update(p.id, { active: p.active === false })}>
                  {p.active === false ? 'در منو نمایش بده' : '🙈 مخفی از منو'}
                </button>
                <button className={p.outOfStock ? 'btn' : 'btn secondary'} style={{ minWidth: '118px', fontSize: '12px' }} disabled={!!busyId || p.active === false} onClick={() => update(p.id, { outOfStock: !p.outOfStock })}>
                  {p.outOfStock ? '🚫 ناموجود است' : '🚫 ناموجود کن'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
