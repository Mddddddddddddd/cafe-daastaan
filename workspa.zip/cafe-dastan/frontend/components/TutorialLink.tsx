"use client";

import { usePathname } from 'next/navigation';

export default function TutorialLink({ label = 'راهنمای این بخش' }: { label?: string }) {
  const pathname = usePathname() || '/';

  const openTour = () => {
    window.dispatchEvent(new CustomEvent('cafe-dastan-open-tour', { detail: { pathname } }));
  };

  return (
    <span
      role="button"
      tabIndex={0}
      className="helpTextLink"
      onClick={openTour}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openTour();
        }
      }}
    >
      {label}
    </span>
  );
}
