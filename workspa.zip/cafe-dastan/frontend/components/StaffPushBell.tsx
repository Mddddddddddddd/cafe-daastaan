"use client";

import { useEffect, useState } from 'react';
import { API_BASE_URL, apiGet, apiPost, authHeaders } from '@/lib/api';

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

type PushState = 'idle' | 'on' | 'denied' | 'busy' | 'insecure' | 'ios' | 'unsupported' | 'notconfigured' | 'error';

const hintBox: React.CSSProperties = {
  cursor: 'default', maxWidth: '100%', textAlign: 'right', lineHeight: 1.8,
  background: '#fff8e6', border: '1px dashed #d4a72c',
};

// دکمه‌ی فعال‌سازی نوتیفیکیشن گوشی برای پرسنل — با تشخیص دقیق مشکل (اندروید + آیفون)
export default function StaffPushBell({ role }: { role: 'bar' | 'kitchen' | 'waiter' | 'admin' }) {
  const [state, setState] = useState<PushState>('idle');

  const browserSupported = () =>
    typeof window !== 'undefined' &&
    !!window.isSecureContext &&
    'serviceWorker' in navigator &&
    'PushManager' in window &&
    'Notification' in window;

  const check = () => {
    if (typeof window === 'undefined') return;
    const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
    if (!window.isSecureContext) { setState('insecure'); return; }
    if (!browserSupported()) { setState(ios ? 'ios' : 'unsupported'); return; }
    try {
      const perm: any = Notification.permission;
      const apply = (p: string) => setState(p === 'granted' ? 'on' : p === 'denied' ? 'denied' : 'idle');
      if (typeof perm?.then === 'function') perm.then(apply).catch(() => setState('idle'));
      else apply(String(perm));
    } catch {
      setState('idle');
    }
  };

  useEffect(() => { check(); }, []);

  const enable = async () => {
    setState('busy');
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') { setState('denied'); return; }
      const reg = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;
      const keyRes = await apiGet('/notifications/push/vapid-public-key');
      const publicKey = keyRes?.data?.publicKey;
      if (!publicKey) { setState('notconfigured'); return; }
      let sub = await reg.pushManager.getSubscription();
      if (!sub) {
        sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(publicKey) });
      }
      const res = await apiPost('/notifications/push/subscribe', { subscription: sub.toJSON(), staffRole: role, userAgent: navigator.userAgent });
      setState(res?.success ? 'on' : 'error');
    } catch {
      setState('denied');
    }
  };

  const disable = async () => {
    setState('busy');
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      if (sub) {
        await fetch(`${API_BASE_URL}/notifications/push/subscribe?endpoint=${encodeURIComponent(sub.endpoint)}`, { method: 'DELETE', headers: { ...authHeaders() } }).catch(() => {});
        await sub.unsubscribe();
      }
      setState('idle');
    } catch {
      setState('idle');
    }
  };

  switch (state) {
    case 'insecure':
      return (
        <span className="chip" style={hintBox}>
          ⚠️ برای نوتیفیکیشن باید با آدرس https وارد شوید (https://cafedaastaan.ir)
        </span>
      );
    case 'ios':
      return (
        <span className="chip" style={hintBox}>
          📱 روی آیفون نوتیفیکیشن فقط داخل <b>اپ نصب‌شده روی صفحه اصلی</b> کار می‌کند (iOS ۱۶.۴ به بعد).
          <br />۱) صفحه را با سافاری باز کن ← آیکون شریک‌سازی (⬆️) ← «افزودن به صفحه اصلی»
          <br />۲) اپ را از صفحه اصلی باز کن و دوباره همین دکمه را بزن
        </span>
      );
    case 'unsupported':
      return (
        <span className="chip" style={hintBox}>
          🔕 مرورگر این گوشی نوتیفیکیشن وب را پشتیبانی نمی‌کند — کروم به‌روز را نصب کن و با همان وارد شو
        </span>
      );
    case 'notconfigured':
      return (
        <span className="chip" style={hintBox}>
          ⚠️ نوتیفیکیشن سمت سرور فعال نیست — با مدیریت سایت تماس بگیر
        </span>
      );
    case 'error':
      return <button type="button" className="chip" style={{ cursor: 'pointer' }} onClick={enable}>⚠️ فعال‌سازی ناموفق بود — دوباره تلاش کن</button>;
    case 'denied':
      return (
        <span className="chip" style={hintBox}>
          🔕 نوتیفیکیشن مسدود است: آیکون قفل/تنظیمات کنار آدرس را بزن، اعلان‌ها (Notifications) را روی «Allow/اجازه» بگذار و صفحه را یک‌بار رفرش کن
        </span>
      );
    case 'busy':
      return <span className="chip" style={{ cursor: 'default' }}>⏳ در حال فعال‌سازی...</span>;
    case 'on':
      return (
        <button type="button" className="chip active" style={{ cursor: 'pointer' }} onClick={disable}>
          🔔 نوتیفیکیشن فعال است (برای قطع بزن)
        </button>
      );
    default:
      return (
        <button type="button" className="chip" style={{ cursor: 'pointer' }} onClick={enable}>
          🔔 فعال‌سازی نوتیفیکیشن
        </button>
      );
  }
}
