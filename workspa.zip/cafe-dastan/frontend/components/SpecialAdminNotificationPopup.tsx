"use client";

import { useEffect, useMemo, useState } from 'react';
import { apiGet, apiPost, isCustomerAuthenticated } from '@/lib/api';

function isActive(item: any) {
  if (!item?.expiresAt) return true;
  return new Date(item.expiresAt).getTime() > Date.now();
}

export default function SpecialAdminNotificationPopup() {
  const [mounted, setMounted] = useState(false);
  const [item, setItem] = useState<any>(null);
  const [hidden, setHidden] = useState(false);
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const storageKey = useMemo(() => item?.id ? `cafe_dastan_special_popup_answered_${item.id}` : '', [item?.id]);
  const closeKey = useMemo(() => item?.id ? `cafe_dastan_special_popup_closed_${item.id}` : '', [item?.id]);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    if (!isCustomerAuthenticated()) return;
    apiGet('/notifications').then((res) => {
      const first = (res.data || []).find((n: any) => n?.type === 'special-action' && n?.requiresAction && isActive(n));
      if (!first) return;
      const answered = localStorage.getItem(`cafe_dastan_special_popup_answered_${first.id}`) === '1';
      const closed = localStorage.getItem(`cafe_dastan_special_popup_closed_${first.id}`) === '1';
      if (answered || closed) return;
      setItem(first);
      setHidden(false);
      setMessage('');
    }).catch(() => null);
  }, [mounted]);

  const closePopup = () => {
    if (closeKey) localStorage.setItem(closeKey, '1');
    setHidden(true);
    setItem(null);
  };

  const answer = async (value: 'yes' | 'no') => {
    if (!item?.id) return;
    setSubmitting(true);
    const res = await apiPost(`/notifications/special/${item.id}/answer`, { answer: value });
    setSubmitting(false);
    if (res?.success) {
      localStorage.setItem(storageKey, '1');
      setMessage(res?.message || 'پاسخ شما ثبت شد.');
      setTimeout(() => {
        setHidden(true);
        setItem(null);
      }, 900);
      return;
    }
    setMessage(res?.message || 'ثبت پاسخ انجام نشد.');
  };

  if (!mounted || !item || hidden) return null;

  return (
    <div className="bootOverlay tutorialOverlay" style={{ zIndex: 150 }}>
      <div className="tutorialPopupCard" style={{ textAlign: 'right', position: 'relative', width: 'min(calc(100% - 24px), 380px)', padding: '14px', gap: '8px' }}>
        <button
          type="button"
          aria-label="بستن اعلان ویژه"
          onClick={closePopup}
          style={{ position: 'absolute', top: 10, left: 10, width: 32, height: 32, borderRadius: '50%', border: 'none', background: '#FFE8E8', color: '#B42318', fontSize: 22, lineHeight: 1, cursor: 'pointer' }}
        >
          ×
        </button>
        <div className="tutorialStepBadge" style={{ fontSize: '9px', padding: '5px 10px' }}>اعلان ویژه کافه داستان</div>
        <strong style={{ fontSize: '12px', lineHeight: '1.9', paddingLeft: '28px' }}>{item.title}</strong>
        <p style={{ fontSize: '10px', lineHeight: '1.9', margin: 0 }}>{item.body}</p>
        <div className="surveyPrompt" style={{ marginTop: 0, padding: '8px' }}>
          <strong style={{ fontSize: '10.5px' }}>{item.actionQuestion || 'آیا حضور دارید؟'}</strong>
          <p style={{ fontSize: '9.5px' }}>این دعوت ویژه تا ۱۰ ساعت فعال است و پاسخ شما برای ادمین ثبت می‌شود.</p>
        </div>
        <div className="row" style={{ justifyContent: 'center', marginTop: '10px', gap: '6px' }}>
          <button className="btn secondary" style={{ fontSize: '10px', padding: '6px 8px' }} disabled={submitting} onClick={() => answer('no')}>{item.actionNoLabel || 'خیر، نیستم'}</button>
          <button className="btn" style={{ fontSize: '10px', padding: '6px 8px' }} disabled={submitting} onClick={() => answer('yes')}>{item.actionYesLabel || 'بله، هستم'}</button>
        </div>
        <div className="row" style={{ justifyContent: 'center', marginTop: '4px' }}>
          <button className="textOnlyAction" style={{ fontSize: '9.5px' }} disabled={submitting} onClick={closePopup}>بستن</button>
        </div>
        {message ? <p style={{ color: 'var(--primary-dark)' }}>{message}</p> : null}
      </div>
    </div>
  );
}
