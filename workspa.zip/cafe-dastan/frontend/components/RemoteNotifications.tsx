"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { apiDelete, apiGet, getCustomerContext, isCustomerAuthenticated } from '@/lib/api';

const surveyStatuses = new Set(['READY_TO_SERVE', 'DELIVERED']);

export default function RemoteNotifications() {
  const [items, setItems] = useState<any[]>([]);

  const load = () => {
    if (!isCustomerAuthenticated()) {
      setItems([]);
      return Promise.resolve();
    }
    return apiGet('/notifications').then((res) => {
      const customer = getCustomerContext();
      const data = (res.data || []).filter((item: any) => !item?.customerId || item.customerId === customer.customerId);
      setItems(data);
    });
  };

  const remove = async (id: string) => {
    await apiDelete(`/notifications/${id}`);
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const clearAll = async () => {
    await apiDelete('/notifications');
    setItems([]);
    localStorage.setItem('seenNotificationsCount', '0');
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 30 * 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const seen = Number(localStorage.getItem('seenNotificationsCount') || '0');
    if (items.length > seen) return;
    localStorage.setItem('seenNotificationsCount', String(items.length));
  }, [items]);

  return (
    <>
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="row" style={{ justifyContent: 'flex-start' }}>
          <button className="btn secondary" onClick={clearAll} disabled={!items.length}>حذف تمام اعلان‌ها</button>
          <span className="sub">{items.length.toLocaleString('fa-IR')} اعلان</span>
        </div>
      </section>
      {items.map((item) => {
        const canSurvey = item?.type === 'order-status' && item?.orderId && surveyStatuses.has(item.status);
        return (
          <section className="contentPad" key={item.id}>
            <div className="card banner notificationCard">
              <div className="notificationHead"><strong>{item.title}</strong><button className="notifClose" aria-label="حذف اعلان" onClick={() => remove(item.id)}>×</button></div>
              <p>{item.body}</p>
              {canSurvey ? (
                <div className="surveyPrompt">
                  <strong>نظرت امتیاز دارد</strong>
                  <p>با ثبت نظرسنجی این سفارش، هم به بهتر شدن سرویس کافه کمک می‌کنی و هم امتیاز اضافه برای باشگاه مشتریان می‌گیری.</p>
                  <Link href={`/feedback/${item.orderId}`} className="btn">ثبت نظرسنجی و گرفتن امتیاز</Link>
                </div>
              ) : null}
            </div>
          </section>
        );
      })}
    </>
  );
}
