"use client";

import { useEffect, useState } from 'react';

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
};

// دکمه‌ی کوچک نصب همین پنل به‌عنوان PWA جدا — بعد از نصب برای همیشه مخفی می‌شود
export default function InstallPwaButton({ role, label }: { role: string; label: string }) {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [hidden, setHidden] = useState(false);
  const [help, setHelp] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    try {
      setIsIOS(/iPhone|iPad|iPod/.test(navigator.userAgent));
      if (localStorage.getItem(`cafe_dastan_pwa_installed_${role}`) === '1') { setHidden(true); return; }
      const isStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        (navigator as any).standalone === true;
      if (isStandalone) { setHidden(true); return; }
    } catch { /* ignore */ }

    const onPrompt = (e: Event) => { e.preventDefault(); setDeferred(e as BeforeInstallPromptEvent); };
    const onInstalled = () => {
      try { localStorage.setItem(`cafe_dastan_pwa_installed_${role}`, '1'); } catch { /* ignore */ }
      setHidden(true);
    };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, [role]);

  if (hidden) return null;

  const markInstalled = () => {
    try { localStorage.setItem(`cafe_dastan_pwa_installed_${role}`, '1'); } catch { /* ignore */ }
    setHidden(true);
  };

  const install = () => {
    // آیفون: نصب فقط از طریق share → add to home screen انجام می‌شود
    if (isIOS) { setHelp(true); return; }

    // کروم/برکرها: اگر رویداد نصب ثبت شده، مستقیم ویندوز نصب را باز کن
    if (deferred) {
      deferred.prompt().then(async () => {
        const choice = await deferred.userChoice;
        if (choice.outcome === 'accepted') markInstalled();
      }).catch(() => setHelp(true));
      setDeferred(null);
      return;
    }

    // رویداد هنوز نیامده: یک‌بار صفحه را تازه کن؛ اگر بعد از آن هم نبود، راهنما
    try {
      const reloaded = sessionStorage.getItem(`install_reloaded_${role}`) === '1';
      if (reloaded) { setHelp(true); return; }
      sessionStorage.setItem(`install_reloaded_${role}`, '1');
    } catch { /* ignore */ }
    window.location.reload();
  };

  const steps = isIOS
    ? [
        '۱) صفحه را با سافاری (یا کروم) باز کن',
        '۲) آیکون شریک‌سازی (مربع با فلش بالا ⬆️) را بزن',
        '۳) «افزودن به صفحه اصلی» را انتخاب کن و تأیید کن',
        '۴) بعد از حالا این پنل مثل یک اپ واقعی روی صفحه اصلی هست',
      ]
    : [
        '۱) اگر بالای صفحه (نوار آدرس) آیکون نصب دیدی — مانیتور با فلش به پایین — همان را بزن',
        '۲) اگر نبود: این تب را کاملاً ببند و آدرس را دوباره باز کن',
        '۳) با باز شدن دوباره، دکمه «نصب» همین‌جا مستقیم کار می‌کند',
        '۴) فقط در کروم/جی‌سی‌پی/امج این دکمه هست؛ فایرفاکس اپ نصب نمی‌کند',
      ];

  return (
    <>
      <button type="button" className="chip" style={{ fontSize: '11.5px', padding: '7px 12px', cursor: 'pointer' }} onClick={install}>
        📲 {label}
      </button>
      {help ? (
        <div className="imageLightbox" role="dialog" aria-modal="true" onClick={() => setHelp(false)}>
          <div className="imageLightboxPanel" style={{ width: 'min(360px, 100%)' }} onClick={(e) => e.stopPropagation()}>
            <div style={{ padding: '20px 16px', background: 'linear-gradient(135deg,#fff,var(--primary-tint))' }}>
              <div style={{ fontSize: '34px', textAlign: 'center' }}>📲</div>
              <strong style={{ display: 'block', textAlign: 'center', fontSize: '15px', marginTop: '6px' }}>
                نصب «{label.replace('نصب ', '')}» به‌عنوان اپ جداگانه
              </strong>
              <div style={{ display: 'grid', gap: '8px', marginTop: '14px' }}>
                {steps.map((s) => (
                  <div key={s} style={{ fontSize: '12.5px', lineHeight: 2, padding: '8px 10px', borderRadius: '12px', background: '#f6fbfb', border: '1px solid var(--line)' }}>{s}</div>
                ))}
              </div>
              <button type="button" className="btn" style={{ width: '100%', marginTop: '14px' }} onClick={() => setHelp(false)}>باشه، متوجه شدم</button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
