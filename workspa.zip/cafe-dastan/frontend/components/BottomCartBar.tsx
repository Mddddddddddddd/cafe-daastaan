"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { useCart } from '@/context/CartContext';

export default function BottomCartBar() {
  const { items, total } = useCart();
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);
  const count = items.reduce((sum, item) => sum + item.qty, 0);
  if (!mounted) return null;
  if (count === 0) return null;
  if (pathname === '/cart' || pathname === '/checkout') return null;

  return (
    <div className="bottomBar">
      <div>
        <strong>{count} آیتم در سبد</strong>
        <small>جمع: {total.toLocaleString('fa-IR')} تومان</small>
      </div>
      <Link href="/cart" className="btn">مشاهده سبد</Link>
    </div>
  );
}
