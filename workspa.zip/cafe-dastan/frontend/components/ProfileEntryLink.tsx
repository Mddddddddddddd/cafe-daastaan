"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getStoredUser, isCustomerAuthenticated } from '@/lib/api';

export default function ProfileEntryLink() {
  const [label, setLabel] = useState('ورود');
  const [href, setHref] = useState('/auth/login');

  useEffect(() => {
    if (isCustomerAuthenticated()) {
      const user = getStoredUser();
      setHref('/profile');
      setLabel(user?.username || user?.name || 'پروفایل');
    } else {
      setHref('/auth/login');
      setLabel('ورود');
    }
  }, []);

  return (
    <Link href={href} className="profilePillLink" aria-label="پروفایل مشتری">
      <span>👤</span>
      <small>{label}</small>
    </Link>
  );
}
