"use client";

import { useEffect, useMemo, useState } from 'react';
import { apiGet, apiPatch } from '@/lib/api';
import useNewOrderChime from '@/components/useNewOrderChime';

function statusLabel(status: string) {
  const map: Record<string, string> = {
    PENDING: 'ثبت شده',
    ACCEPTED: 'تایید شده',
    BAR_PREPARING: 'درحال آماده‌سازی بار',
    KITCHEN_PREPARING: 'درحال آماده‌سازی آشپزخانه',
    READY_TO_SERVE: 'آماده تحویل',
    ON_THE_WAY: 'آماده تحویل',
    DELIVERED: 'تحویل شده',
    CANCELLED: 'لغو شده',
  };
  return map[status] || status || 'نامشخص';
}

function formatDayKey(dateValue?: string) {
  const d = dateValue ? new Date(dateValue) : new Date();
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

function groupByDay(items: any[]) {
  const groups = new Map<string, any[]>();
  for (const item of items) {
    const key = formatDayKey(item.createdAt);
    groups.set(key, [...(groups.get(key) || []), item]);
  }
  return [...groups.entries()].map(([date, rows]) => ({ date, rows }));
}

function GroupSection({ title, count, children, defaultOpen = false }: { title: string; count: number; children: React.ReactNode; defaultOpen?: boolean }) {
  return (
    <details className="adminSection" open={defaultOpen}>
      <summary className="adminSummary">{title} ({count.toLocaleString('fa-IR')})</summary>
      <div className="adminPanelBody" style={{ display: 'grid', gap: '12px' }}>{children}</div>
    </details>
  );
}

export default function RemoteWaiterTables() {
  const [tables, setTables] = useState<any[]>([]);
  const [message, setMessage] = useState('');
  useNewOrderChime(tables.map((t: any) => String(t.orderId || t.id)));

  const load = async () => {
    const res = await apiGet('/staff/waiter/tables');
    setTables(res.data || []);
  };

  const doAction = async (id: string, action: string) => {
    const res = await apiPatch(`/staff/waiter/tables/${id}/action`, { action });
    setMessage(res?.success ? (action === 'deliver' ? 'سفارش تحویل‌شده ثبت شد.' : 'وضعیت پرداخت ثبت شد.') : (res?.message || 'خطا در انجام عملیات'));
    await load();
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 2500);
    return () => clearInterval(interval);
  }, []);

  const readyOrders = useMemo(() => tables.filter((t) => ['READY_TO_SERVE', 'ON_THE_WAY'].includes(String(t.rawStatus || ''))), [tables]);
  const deliveredOrders = useMemo(() => groupByDay(tables.filter((t) => ['DELIVERED'].includes(String(t.rawStatus || '')))), [tables]);

  const renderCard = (table: any, delivered = false) => (
    <div className="card banner brandPattern" key={table.id}>
      <div className="row">
        <strong>{table.name}</strong>
        <span className="chip active">سفارش #{table.orderId}</span>
      </div>
      <p>{table.note}</p><div className="sub">مقصد سرو: {table.name} · سفارش #{table.orderId}</div>
      <div className="sub">QR میز: {table.qrCode || '-'}</div>
      {table.orderType === 'DELIVERY' ? <div className="card" style={{ padding: '8px', marginTop: '8px', background: '#fff7ed', borderColor: '#f3d6b6' }}><strong style={{ fontSize: '11px' }}>ارسال به مشتری</strong><p>{table.address || 'آدرس ثبت نشده'}</p><div className="sub">تلفن: {table.phone || '-'}</div></div> : null}
      <div className="sub">وضعیت سفارش: {statusLabel(table.rawStatus || table.status)}</div>
      <div className={`paymentBadge ${table.paymentStatus === 'PAID' ? 'paid' : table.paymentStatus === 'FAILED' ? 'unpaid' : 'pending'}`}>{table.paymentStatus === 'PAID' ? 'پرداخت شده' : table.paymentStatus === 'FAILED' ? 'پرداخت نشده' : 'وضعیت پرداخت نامشخص'}</div>
      {!delivered ? (
        <div className="chips" style={{ marginTop: '10px' }}>
          <button className={`chip ${table.paymentStatus === 'PAID' ? 'active' : ''}`} onClick={() => doAction(table.id, 'confirmPayment')} style={{ cursor: 'pointer' }}>پرداخت شده</button>
          <button className={`chip ${table.paymentStatus === 'FAILED' ? 'active' : ''}`} onClick={() => doAction(table.id, 'markUnpaid')} style={{ cursor: 'pointer' }}>پرداخت نشده</button>
          <button className="chip active" onClick={() => doAction(table.id, 'deliver')} style={{ cursor: 'pointer', opacity: table.paymentStatus === 'PENDING' ? .65 : 1 }}>تحویل شد</button>
        </div>
      ) : null}
    </div>
  );

  return (
    <section className="contentPad" style={{ display: 'grid', gap: '14px' }}>
      <div className="card banner">
        <strong>مدیریت سفارش‌های گارسون</strong>
        <p>برای رفتن سفارش به بخش تحویل‌شده، باید وضعیت پرداخت را پرداخت شده یا پرداخت نشده انتخاب کنید و بعد تحویل شد را بزنید.</p>
        {message ? <p style={{ color: message.includes('خطا') || message.includes('قبل') ? 'var(--danger)' : 'var(--primary-dark)' }}>{message}</p> : null}
      </div>

      <GroupSection title="سفارش‌های آماده تحویل" count={readyOrders.length} defaultOpen>
        {readyOrders.length ? readyOrders.map((table) => renderCard(table)) : <div className="card">فعلاً سفارشی آماده تحویل نیست.</div>}
      </GroupSection>

      <GroupSection title="سفارش‌های تحویل‌شده" count={deliveredOrders.reduce((sum, group) => sum + group.rows.length, 0)}>
        {deliveredOrders.length ? deliveredOrders.map((group) => (
          <details key={group.date} className="adminNestedDetails">
            <summary className="adminNestedSummary">
              <span>{group.date}</span>
              <small>{group.rows.length.toLocaleString('fa-IR')} سفارش</small>
            </summary>
            <div className="adminNestedDetailsBody" style={{ padding: '10px', display: 'grid', gap: '10px' }}>
              {group.rows.map((table: any) => renderCard(table, true))}
            </div>
          </details>
        )) : <div className="card">فعلاً سفارش تحویل‌شده‌ای نیست.</div>}
      </GroupSection>
    </section>
  );
}
