"use client";

import { useEffect, useMemo, useState } from 'react';
import { apiGet, requireCustomerAuth } from '@/lib/api';
import { useCart } from '@/context/CartContext';

const drinkWords = ['قهوه', 'لاته', 'اسپرسو', 'موکا', 'کاپوچینو', 'آیس', 'چای', 'دمنوش', 'نوشیدنی'];

function isDrink(item: any) {
  const text = `${item.name || ''} ${(item.categories || []).join(' ')} ${item.desc || ''}`;
  return drinkWords.some((word) => text.includes(word));
}

function scoreProduct(item: any, answers: string[]) {
  const text = `${item.name || ''} ${(item.categories || []).join(' ')} ${item.desc || ''}`;
  let score = item.featured ? 2 : 0;
  for (const answer of answers) {
    if (answer === 'sweet' && /(شیرین|کیک|دسر|لاته|موکا|کارامل|وانیل)/.test(text)) score += 4;
    if (answer === 'bitter' && /(تلخ|اسپرسو|آمریکانو|دارک|قهوه)/.test(text)) score += 4;
    if (answer === 'cold' && /(سرد|آیس|یخ|خنک)/.test(text)) score += 4;
    if (answer === 'hot' && /(گرم|هات|دمنوش|چای|قهوه|لاته|اسپرسو)/.test(text)) score += 4;
    if (answer === 'light' && /(سبک|سالاد|صبحانه|دمنوش|چای)/.test(text)) score += 3;
    if (answer === 'full' && /(غذا|ساندویچ|پاستا|صبحانه|برگر|پنینی)/.test(text)) score += 3;
  }
  return score;
}

export default function MoodAndUsualActions() {
  const { addMany } = useCart();
  const [items, setItems] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [openMood, setOpenMood] = useState(false);
  const [kind, setKind] = useState<'drink' | 'food' | ''>('');
  const [answers, setAnswers] = useState<string[]>([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    apiGet('/menu').then((res) => setItems(res.data || [])).catch(() => null);
    apiGet('/me').then((res) => setProfile(res.data || null)).catch(() => null);
    const hash = window.location.hash;
    if (hash === '#mood-action') setOpenMood(true);
    if (hash === '#usual-order-action') window.setTimeout(() => addUsual(), 350);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const candidates = useMemo(() => {
    return items.filter((item) => kind === 'drink' ? isDrink(item) : kind === 'food' ? !isDrink(item) : true);
  }, [items, kind]);

  const suggestion = useMemo(() => {
    if (!kind || answers.length < 2) return null;
    return [...candidates].sort((a, b) => scoreProduct(b, answers) - scoreProduct(a, answers))[0] || null;
  }, [answers, candidates, kind]);

  const resetMood = () => {
    setKind('');
    setAnswers([]);
    setMessage('');
  };

  const closeMood = () => {
    setOpenMood(false);
    resetMood();
  };

  const addSuggestion = () => {
    if (!suggestion) return;
    addMany(suggestion, 1, 'پیشنهاد چی دوس داری؟');
    setMessage(`${suggestion.name} به سبدت اضافه شد.`);
  };

  const addUsual = () => {
    if (!requireCustomerAuth('/')) return;
    const usual = profile?.usualOrder;
    if (!usual?.productId && !usual?.name) {
      setMessage('هنوز سفارش کافی نداری تا همیشگی‌ات را تشخیص بدهم.');
      return;
    }
    addMany({ id: usual.productId || usual.name, name: usual.name, price: usual.price }, usual.qty || 1, usual.option || 'همون همیشگی');
    setMessage('همون همیشگی به سبدت اضافه شد.');
  };

  return (
    <section id="smart-actions" className="section" style={{ paddingTop: '4px' }}>
      <div className="smartActionGrid">
        <button id="mood-action" type="button" className="smartActionCard moodCardAction" onClick={() => setOpenMood(true)}>
          <span>✨</span>
          <strong>چی دوس داری؟</strong>
          <small>چند سؤال کوتاه، یک پیشنهاد مناسب حال تو</small>
        </button>
        <button id="usual-order-action" type="button" className="smartActionCard usualCardAction" onClick={addUsual}>
          <span>☕</span>
          <strong>همون همیشگی</strong>
          <small>{profile?.usualOrder?.title || 'از ۴ سفارش آخر تشخیص داده می‌شود'}</small>
        </button>
      </div>
      {message ? <div className="smartActionMessage">{message}</div> : null}

      {openMood ? (
        <div className="bootOverlay smartPopupOverlay">
          <div className="tutorialPopupCard smartPopupCard">
            <div className="tutorialStepBadge">پیشنهاد هوشمند</div>
            {!kind ? (
              <>
                <div className="tutorialIconLarge">🍽️</div>
                <strong>الان غذا می‌خوای یا نوشیدنی؟</strong>
                <p>اول نوع پیشنهاد را انتخاب کن تا چند سؤال کوتاه بپرسم.</p>
                <div className="smartChoiceGrid">
                  <button className="btn" onClick={() => setKind('drink')}>نوشیدنی</button>
                  <button className="btn secondary" onClick={() => setKind('food')}>غذا / دسر</button>
                </div>
              </>
            ) : answers.length < 2 ? (
              <>
                <div className="tutorialIconLarge">{kind === 'drink' ? '☕' : '🍰'}</div>
                <strong>{answers.length === 0 ? 'چه طعمی بیشتر می‌خوای؟' : 'حالت الان چیه؟'}</strong>
                <p>با جواب‌ها، نزدیک‌ترین آیتم منو را پیشنهاد می‌دهم.</p>
                {answers.length === 0 ? (
                  <div className="smartChoiceGrid">
                    <button className="btn" onClick={() => setAnswers(['sweet'])}>شیرین و نرم</button>
                    <button className="btn secondary" onClick={() => setAnswers(['bitter'])}>تلخ و جدی</button>
                  </div>
                ) : (
                  <div className="smartChoiceGrid">
                    <button className="btn" onClick={() => setAnswers((prev) => [...prev, kind === 'drink' ? 'hot' : 'full'])}>{kind === 'drink' ? 'گرم' : 'سیرکننده'}</button>
                    <button className="btn secondary" onClick={() => setAnswers((prev) => [...prev, kind === 'drink' ? 'cold' : 'light'])}>{kind === 'drink' ? 'خنک' : 'سبک'}</button>
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="tutorialIconLarge">🎯</div>
                <strong>{suggestion?.name || 'پیشنهاد آماده نشد'}</strong>
                <p>{suggestion ? `${Number(suggestion.price || 0).toLocaleString('fa-IR')} تومان · ${suggestion.desc || 'به سلیقه جواب‌هایت نزدیک است.'}` : 'فعلاً منوی کافی برای پیشنهاد وجود ندارد.'}</p>
                <div className="smartChoiceGrid">
                  <button className="btn" onClick={addSuggestion} disabled={!suggestion}>افزودن به سبد</button>
                  <button className="btn secondary" onClick={resetMood}>دوباره بپرس</button>
                </div>
              </>
            )}
            <button className="textOnlyAction" style={{ marginTop: 8 }} onClick={closeMood}>بستن</button>
          </div>
        </div>
      ) : null}
    </section>
  );
}
