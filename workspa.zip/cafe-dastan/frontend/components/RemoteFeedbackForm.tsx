"use client";

import { useEffect, useState } from 'react';
import { apiGet, apiPost, getCustomerContext } from '@/lib/api';

const EMOJI_STARS = ['😖', '😕', '😐', '😊', '🤩'];
const EMOJI_LABELS = ['بسیار ضعیف', 'ضعیف', 'متوسط', 'خوب', 'عالی'];

function BigStars({ value, onChange, disabled = false }: { value: number; onChange?: (v: number) => void; disabled?: boolean }) {
  return (
    <div dir="ltr" style={{ display: 'flex', justifyContent: 'center', gap: '8px', margin: '14px 0 6px' }}>
      {[1, 2, 3, 4, 5].map((n) => {
        const active = n <= value;
        const size = n === value ? 46 : 38;
        return (
          <button
            key={n}
            type="button"
            disabled={disabled}
            onClick={() => onChange && onChange(n)}
            aria-label={`${n} ستاره`}
            style={{
              fontSize: size, lineHeight: 1, background: active ? 'var(--primary-tint, #eaf4f5)' : 'transparent',
              border: active ? '2px solid var(--primary)' : '2px solid transparent',
              borderRadius: '50%', width: '56px', height: '56px', cursor: disabled ? 'default' : 'pointer',
              transition: 'all 0.18s ease', padding: 0,
              transform: n === value ? 'scale(1.12)' : 'scale(1)',
            }}
          >
            {active ? EMOJI_STARS[n - 1] : '⭐'}
          </button>
        );
      })}
    </div>
  );
}

function SectionCard({ icon, title, hint, active, children }: { icon: string; title: string; hint?: string; active: boolean; children: React.ReactNode }) {
  return (
    <div style={{
      borderRadius: '20px', padding: '16px 14px',
      background: active ? 'linear-gradient(180deg, #ffffff, var(--primary-tint, #eaf4f5))' : '#fff',
      border: active ? '2px solid var(--primary)' : '1px solid var(--line)',
      boxShadow: active ? '0 8px 24px rgba(18,56,60,0.10)' : 'none',
      transition: 'all 0.2s ease',
    }}>
      <div className="row" style={{ alignItems: 'center', gap: '8px' }}>
        <span style={{
          width: '40px', height: '40px', borderRadius: '12px', flexShrink: 0,
          background: 'var(--primary-tint, #eaf4f5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px',
        }}>{icon}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <strong style={{ fontSize: '14px', display: 'block' }}>{title}</strong>
          {hint ? <span className="sub" style={{ fontSize: '11px' }}>{hint}</span> : null}
        </div>
        {active ? <span style={{ fontSize: '16px' }}>✅</span> : null}
      </div>
      <div style={{ marginTop: '10px' }}>{children}</div>
    </div>
  );
}

export default function RemoteFeedbackForm({ orderId }: { orderId: string }) {
  const [survey, setSurvey] = useState<any>(null);
  const [customerName, setCustomerName] = useState('');
  const [staffRating, setStaffRating] = useState(0);
  const [staffComment, setStaffComment] = useState('');
  const [orderRating, setOrderRating] = useState(0);
  const [orderComment, setOrderComment] = useState('');
  const [itemRatings, setItemRatings] = useState<Record<string, { rating: number; comment: string }>>({});
  const [message, setMessage] = useState('');
  const [done, setDone] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const customer = getCustomerContext();

  useEffect(() => {
    apiGet(`/feedback/order/${orderId}`).then((res) => {
      const data = res.data || null;
      setSurvey(data);
      setMessage(res?.success === false ? (res?.message || 'فرم نظرسنجی برای این سفارش دریافت نشد.') : '');
      const map: Record<string, { rating: number; comment: string }> = {};
      (data?.items || []).forEach((item: any) => { map[item.productId] = { rating: 0, comment: '' }; });
      setItemRatings(map);
    }).catch(() => {
      setSurvey({ items: [], alreadySubmitted: false });
      setMessage('فرم نظرسنجی برای این سفارش دریافت نشد.');
    });
  }, [orderId]);

  const updateItem = (productId: string, patch: any) => setItemRatings((prev) => ({ ...prev, [productId]: { ...(prev[productId] || { rating: 0, comment: '' }), ...patch } }));

  const doneCount = [!!staffRating, !!orderRating].filter(Boolean).length + Object.values(itemRatings).filter((v) => v.rating > 0).length;
  const totalCount = 2 + Object.keys(itemRatings).length;
  const progress = totalCount ? Math.round((doneCount / totalCount) * 100) : 0;

  const submit = async () => {
    if (!staffRating || !orderRating) { setMessage('⚠️ امتیاز کارکنان و کیفیت سفارش را انتخاب کن.'); return; }
    setSubmitting(true);
    const payload = {
      orderId,
      customerName: customerName || customer.name || 'مهمان کافه',
      staffRating,
      staffComment,
      orderRating,
      orderComment,
      itemRatings: (survey?.items || []).map((item: any) => ({
        productId: item.productId,
        name: item.name,
        rating: itemRatings[item.productId]?.rating || 0,
        comment: itemRatings[item.productId]?.comment || '',
      })),
    };
    const res = await apiPost('/feedback', payload);
    setSubmitting(false);
    if (res.success) {
      setDone(res.data || {});
      setMessage('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setMessage('❌ ' + (res?.message || 'ثبت نظر با خطا روبه‌رو شد.'));
    }
  };

  if (!survey) {
    return (
      <div style={{ borderRadius: '22px', padding: '36px 18px', textAlign: 'center', background: 'linear-gradient(135deg,#fff,var(--primary-tint))', border: '1px solid var(--line)' }}>
        <div style={{ fontSize: '38px', animation: 'cdSpin 1.2s linear infinite', display: 'inline-block' }}>⭐</div>
        <p style={{ marginTop: '10px' }}>در حال دریافت فرم نظرسنجی...</p>
      </div>
    );
  }

  // وضعیت موفقیت پس از ثبت
  if (done) {
    const loyalty = done.loyalty;
    return (
      <div style={{ borderRadius: '24px', overflow: 'hidden', border: '1px solid var(--line)' }}>
        <div style={{
          background: 'linear-gradient(135deg, var(--primary-deep), var(--primary))', color: '#fff',
          padding: '30px 18px', textAlign: 'center',
        }}>
          <div style={{ fontSize: '54px', lineHeight: 1 }}>🎉</div>
          <strong style={{ fontSize: '18px', display: 'block', marginTop: '10px' }}>ممنون از نظرت!</strong>
          <p style={{ opacity: 0.9, fontSize: '12.5px', marginTop: '8px', lineHeight: 2 }}>
            نظرت درباره‌ی سفارش <b>#{orderId}</b> با موفقیت ثبت شد.
          </p>
          {loyalty?.awarded ? (
            <div style={{
              display: 'inline-block', marginTop: '12px', padding: '10px 18px', borderRadius: '999px',
              background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)',
              fontSize: '14px', fontWeight: 800,
            }}>
              🎁 +{Number(loyalty.points || 0).toLocaleString('fa-IR')} امتیاز باشگاه
            </div>
          ) : (
            <p style={{ marginTop: '10px', fontSize: '11.5px', opacity: 0.85 }}>امتیاز نظرسنجی این سفارش قبلاً دریافت شده بود.</p>
          )}
        </div>
        <div style={{ padding: '16px 14px', display: 'grid', gap: '8px', background: '#fff' }}>
          <a href={`/tracking/${orderId}`} className="btn" style={{ textAlign: 'center' }}>بازگشت به رهگیری سفارش</a>
          <a href="/loyalty" className="btn secondary" style={{ textAlign: 'center' }}>مشاهده باشگاه مشتریان</a>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: '12px' }}>
      {/* هدر */}
      <div style={{
        borderRadius: '22px', padding: '22px 16px', color: '#fff', textAlign: 'center',
        background: 'linear-gradient(135deg, var(--primary-deep), var(--primary))',
        boxShadow: '0 10px 28px rgba(18,56,60,0.22)',
      }}>
        <div style={{ fontSize: '44px', lineHeight: 1 }}>⭐</div>
        <strong style={{ fontSize: '17px', display: 'block', marginTop: '8px' }}>نظرسنجی سفارش #{orderId}</strong>
        <p style={{ opacity: 0.92, fontSize: '12px', marginTop: '8px', lineHeight: 2 }}>
          نظرت برای ما خیلی مهم است. امتیاز بده و {`برای هر نظرسنجی کامل `}<b>۳۵ امتیاز باشگاه</b> بگیر.
        </p>
        {/* نوار پیشرفت */}
        <div style={{ marginTop: '12px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginBottom: '4px', opacity: 0.9 }}>
            <span>پیشرفت نظرسنجی</span>
            <span>{progress.toLocaleString('fa-IR')}٪</span>
          </div>
          <div style={{ height: '8px', borderRadius: '999px', background: 'rgba(255,255,255,0.25)', overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${progress}%`, background: '#ffd166', borderRadius: '999px', transition: 'width 0.3s ease' }} />
          </div>
        </div>
      </div>

      {survey.alreadySubmitted ? (
        <div style={{ borderRadius: '14px', padding: '12px', background: '#fff8e6', border: '1px solid #f5d98a', fontSize: '12px', lineHeight: 2 }}>
          💡 برای این سفارش قبلاً یک نظر ثبت شده؛ باز هم می‌تونی نظر جدید ثبت کنی.
        </div>
      ) : null}

      {/* نام */}
      <div style={{ borderRadius: '16px', padding: '12px 14px', background: '#fff', border: '1px solid var(--line)' }}>
        <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '6px' }}>نام شما <span style={{ fontWeight: 400, color: 'var(--muted, #6b7c80)' }}>(اختیاری)</span></label>
        <input className="input" style={{ marginTop: 0 }} placeholder="مثلاً: سارا" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
      </div>

      {/* کارکنان */}
      <SectionCard icon="🛎️" title="رفتار و سرعت کارکنان" hint="اجباری" active={!!staffRating}>
        <BigStars value={staffRating} onChange={setStaffRating} />
        {staffRating ? <p style={{ textAlign: 'center', fontSize: '12px', fontWeight: 700, color: 'var(--primary)' }}>{EMOJI_LABELS[staffRating - 1]}</p> : null}
        <textarea className="input" rows={2} style={{ marginTop: '10px', resize: 'vertical' }} placeholder="توضیح درباره برخورد کارکنان، سرعت سرویس یا گارسون... (اختیاری)" value={staffComment} onChange={(e) => setStaffComment(e.target.value)} />
      </SectionCard>

      {/* کل سفارش */}
      <SectionCard icon="🍽️" title="کیفیت کلی سفارش" hint="اجباری" active={!!orderRating}>
        <BigStars value={orderRating} onChange={setOrderRating} />
        {orderRating ? <p style={{ textAlign: 'center', fontSize: '12px', fontWeight: 700, color: 'var(--primary)' }}>{EMOJI_LABELS[orderRating - 1]}</p> : null}
        <textarea className="input" rows={2} style={{ marginTop: '10px', resize: 'vertical' }} placeholder="توضیح درباره کیفیت کلی سفارش... (اختیاری)" value={orderComment} onChange={(e) => setOrderComment(e.target.value)} />
      </SectionCard>

      {/* آیتم‌ها */}
      {(survey?.items || []).length ? (
        <div style={{ display: 'grid', gap: '10px' }}>
          {(survey?.items || []).map((item: any) => {
            const state = itemRatings[item.productId] || { rating: 0, comment: '' };
            return (
              <SectionCard key={item.productId} icon="📦" title={item.name || 'آیتم سفارش'} hint="امتیاز هر آیتم (اختیاری)" active={state.rating > 0}>
                <BigStars value={state.rating} onChange={(v) => updateItem(item.productId, { rating: v })} />
                {state.rating ? <p style={{ textAlign: 'center', fontSize: '12px', fontWeight: 700, color: 'var(--primary)' }}>{EMOJI_LABELS[state.rating - 1]}</p> : null}
              </SectionCard>
            );
          })}
        </div>
      ) : null}

      {message ? <p style={{ fontSize: '12.5px', textAlign: 'center', lineHeight: 2 }}>{message}</p> : null}

      {/* دکمه ثبت */}
      <button
        type="button"
        onClick={submit}
        disabled={submitting}
        style={{
          width: '100%', padding: '16px', borderRadius: '18px', border: 'none', cursor: 'pointer',
          background: staffRating && orderRating
            ? 'linear-gradient(135deg, var(--primary-deep), var(--primary))'
            : 'linear-gradient(135deg, #9fb3b6, #b8c8ca)',
          color: '#fff', fontSize: '15px', fontWeight: 800,
          boxShadow: '0 10px 24px rgba(18,56,60,0.25)', transition: 'all 0.2s ease',
          opacity: submitting ? 0.7 : 1,
        }}
      >
        {submitting ? '⏳ در حال ثبت...' : '🚀 ثبت نظرسنجی'}
      </button>
    </div>
  );
}
