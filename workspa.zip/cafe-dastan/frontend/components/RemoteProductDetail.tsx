"use client";

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import AddToCartButton from '@/components/AddToCartButton';
import { apiGet, resolveImageUrl } from '@/lib/api';

// دسته‌بندی‌هایی که با هر دسته بهتر همراهِ سفارش می‌شوند
const companionCategories: Record<string, string[]> = {
  'نوشیدنی گرم': ['دسر', 'کیک', 'صبحانه', 'غذای سبک'],
  'نوشیدنی سرد': ['دسر', 'کیک', 'صبحانه', 'غذای سبک'],
  'قهوه تخصصی': ['دسر', 'کیک'],
  'دمنوش': ['دسر', 'کیک', 'صبحانه'],
  'دسر': ['قهوه تخصصی', 'نوشیدنی گرم', 'نوشیدنی سرد'],
  'کیک': ['قهوه تخصصی', 'نوشیدنی گرم', 'نوشیدنی سرد'],
  'صبحانه': ['نوشیدنی سرد', 'دمنوش', 'قهوه تخصصی'],
  'غذای سبک': ['نوشیدنی سرد', 'دمنوش'],
};

function pickCompanion(product: any, menu: any[]) {
  const targets = (product.categories || []).flatMap((c: string) => companionCategories[c] || []);
  const candidates = (menu || []).filter((p) => p.id !== product.id && p.active !== false && !p.outOfStock);
  const inTarget = candidates.find((p) => (p.categories || []).some((c: string) => targets.includes(c)));
  if (inTarget) return inTarget;
  const featured = candidates.find((p) => p.featured);
  return featured || candidates[0] || null;
}

function fallbackOptionPrice(value: string, index: number) {
  const v = value || '';
  if (v.includes('بادام') || v.includes('جو') || v.includes('بدون لاکتوز')) return 18000;
  if (v.includes('بزرگ')) return 22000;
  if (v.includes('متوسط')) return 12000;
  if (v.includes('زیاد')) return 9000;
  if (v.includes('سیروپ') || v.includes('کارامل') || v.includes('وانیل')) return 14000;
  if (v.includes('توت') || v.includes('شکلات')) return 16000;
  return index === 0 ? 0 : index * 7000;
}

function normalizeOption(value: any, index: number) {
  if (typeof value === 'string') return { name: value, price: fallbackOptionPrice(value, index) };
  const name = value?.name || value?.label || value?.value || '';
  return { name, price: Number(value?.price || 0) };
}

export default function RemoteProductDetail({ id }: { id: string }) {
  const [product, setProduct] = useState<any | null>(null);
  const [menu, setMenu] = useState<any[]>([]);
  const [selected, setSelected] = useState<Record<string, { value: string; price: number }>>({});

  useEffect(() => {
    apiGet(`/menu/${id}`).then((res) => {
      setProduct(res.data || null);
      setSelected({});
    });
    apiGet('/menu').then((res) => setMenu(res?.data || [])).catch(() => {});
  }, [id]);

  const companion = useMemo(() => (product ? pickCompanion(product, menu) : null), [product, menu]);

  const extraPrice = useMemo(() => Object.values(selected).reduce((sum, item) => sum + Number(item.price || 0), 0), [selected]);
  const optionText = useMemo(() => {
    const entries = Object.entries(selected);
    return entries.length ? entries.map(([k, v]) => `${k}: ${v.value}`).join(' · ') : 'بدون شخصی‌سازی';
  }, [selected]);

  if (!product) return <div className="card banner">درحال دریافت اطلاعات محصول...</div>;

  const image = resolveImageUrl(product.image || '/images/menu/coffee.svg');

  return (
    <>
      <div className="largeImage productHeroImage productImageWatermark" style={{ backgroundImage: `url(${image})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
      <div className="card banner logoWatermark" style={{ marginTop: '12px' }}>
        <div className="row" style={{ alignItems: 'start' }}>
          <div>
            <h1 style={{ margin: '0', fontSize: '22px' }}>{product.name}</h1>
            <div className="sub">{(product.categories || []).join('، ')}</div>
          </div>
          <div className="price">{(product.price + extraPrice).toLocaleString('fa-IR')}</div>
        </div>
        <div className="meta">
          {(product.categories || []).map((cat: string) => <span key={cat} className="mini">{cat}</span>)}
        </div>
        {product.desc ? <p className="desc">{product.desc}</p> : null}
        <div className="infoGrid">
          <div className="infoBox">قیمت پایه: {product.price.toLocaleString('fa-IR')}</div>
          <div className="infoBox">افزوده‌ها: {extraPrice.toLocaleString('fa-IR')}</div>
          <div className="infoBox">شخصی‌سازی: {(product.customizations || []).length ? 'دارد' : 'ندارد'}</div>
          {companion ? (
            <Link href={`/product/${companion.id}`} className="infoBox" style={{ color: 'var(--primary-deep)', textDecoration: 'none' }}>
              پیشنهاد همراه: {companion.name}
            </Link>
          ) : null}
        </div>
      </div>

      {(product.customizations || []).length > 0 ? (
        <div className="card banner" style={{ marginTop: '12px' }}>
          <strong>شخصی‌سازی با قیمت</strong>
          {(product.customizations || []).map((group: any, index: number) => (
            <div key={group.id || index} style={{ marginTop: '12px' }}>
              <div className="sub">{group.name}</div>
              <div className="chips" style={{ marginTop: '8px' }}>
                {(group.values || []).map((rawValue: any, valueIndex: number) => {
                  const option = normalizeOption(rawValue, valueIndex);
                  const isActive = selected[group.name]?.value === option.name;
                  return (
                    <button key={`${option.name}-${valueIndex}`} className="chip" onClick={() => setSelected((prev) => ({ ...prev, [group.name]: { value: option.name, price: option.price } }))} style={{ border: isActive ? '2px solid var(--primary)' : '1px solid var(--line)', background: isActive ? 'rgba(121,180,183,.14)' : '#fff', color: isActive ? 'var(--primary)' : 'inherit', cursor: 'pointer' }}>
                      {option.name} {option.price ? `+${option.price.toLocaleString('fa-IR')}` : 'رایگان'}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          <div className="card selectedOptions" style={{ marginTop: '14px' }}>
            <div className="row">
              <div className="sub">انتخاب فعلی</div>
              {Object.keys(selected).length ? <button className="removeSelection" onClick={() => setSelected({})}>×</button> : null}
            </div>
            {Object.keys(selected).length ? (
              <div style={{ display: 'grid', gap: '6px', marginTop: '8px' }}>
                {Object.entries(selected).map(([k, v]) => (
                  <div key={k} className="row selectedOptionRow">
                    <strong>{k}: {v.value}</strong>
                    <span>{v.price ? `+${v.price.toLocaleString('fa-IR')} تومان` : 'رایگان'}</span>
                    <button className="removeSelection" onClick={() => setSelected((prev) => { const next = { ...prev }; delete next[k]; return next; })}>×</button>
                  </div>
                ))}
              </div>
            ) : <strong style={{ color: 'var(--primary)' }}>هنوز چیزی انتخاب نکردی.</strong>}
          </div>
          <div style={{ marginTop: '14px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <AddToCartButton productId={id} product={product} option={optionText} extraPrice={extraPrice} />
            <button className="btn secondary" onClick={() => setSelected({})}>لغو انتخاب</button>
          </div>
        </div>
      ) : (
        <div className="card banner" style={{ marginTop: '12px' }}>
          <strong>این محصول شخصی‌سازی ندارد.</strong>
          <div style={{ marginTop: '14px' }}><AddToCartButton productId={id} product={product} /></div>
        </div>
      )}
    </>
  );
}
