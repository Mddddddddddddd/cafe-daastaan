"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiGet, apiPatch } from '@/lib/api';
import useNewOrderChime from '@/components/useNewOrderChime';

const statuses = ['جدید', 'درحال آماده‌سازی', 'آماده تحویل'];

export default function RemoteKitchenOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  useNewOrderChime(orders.map((o: any) => o.id));

  const load = async () => {
    const res = await apiGet('/staff/kitchen/orders');
    setOrders(res.data || []);
  };

  const setStatus = async (id: string, status: string) => {
    setSaving((prev) => ({ ...prev, [id]: true }));
    setOrders((prev) => prev.map((order) => order.id === id ? { ...order, status } : order));
    await apiPatch(`/staff/kitchen/orders/${id}/status`, { status });
    await load();
    setSaving((prev) => ({ ...prev, [id]: false }));
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <section className="contentPad">
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="sub">آیتمی موجود نیست؟</span>
          <Link href="/kitchen/products" className="btn secondary" style={{ fontSize: '12px' }}>🚫 ناموجود / پنهان کردن آیتم</Link>
        </div>
      </section>
      {orders.map((order) => (
        <section className="contentPad" key={order.id}>
          <div className="card banner brandPattern">
            <strong>سفارش آشپزخانه #{order.orderId}</strong>
            <p>{order.tableName || order.table} · {order.tableQr || 'QR-N/A'} · {order.time} · مجموع {order.qty || 1} آیتم</p>
            <div className="card" style={{ padding: '8px', marginTop: '10px', background: '#f8fcfc' }}>
              {(order.items || [{ name: order.name, qty: 1 }]).map((item: any, index: number) => (
                <div key={`${item.productId || index}`} className="row" style={{ padding: '5px 0', borderBottom: index === (order.items || []).length - 1 ? 'none' : '1px dashed var(--line)' }}>
                  <span>{item.name}</span>
                  <strong className="price">×{item.qty || 1}</strong>
                </div>
              ))}
            </div>
            <div className="sub">وضعیت فعلی: {order.status}{saving[order.id] ? ' · درحال ثبت...' : ''}</div>
            <div className="chips" style={{ marginTop: '10px' }}>
              {statuses.map((status) => {
                const active = order.status === status;
                return (
                  <button
                    key={status}
                    className={`chip ${active ? 'active' : ''}`}
                    disabled={!!saving[order.id]}
                    onClick={() => setStatus(order.id, status)}
                    style={{ cursor: saving[order.id] ? 'wait' : 'pointer' }}
                  >
                    {status}
                  </button>
                );
              })}
            </div>
            <p style={{ color: 'var(--primary-dark)' }}>با زدن هر وضعیت، تغییر همان لحظه ثبت می‌شود.</p>
          </div>
        </section>
      ))}
    </>
  );
}
