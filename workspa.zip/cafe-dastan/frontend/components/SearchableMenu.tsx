"use client";

import { useMemo, useState } from 'react';
import { menu } from '@/data/menu';
import ProductCard from '@/components/ProductCard';

const categories = ['همه', 'نوشیدنی گرم', 'نوشیدنی سرد', 'قهوه تخصصی', 'دمنوش', 'صبحانه', 'دسر', 'کیک', 'غذای سبک', 'فصلی', 'ویژه کافه'];

export default function SearchableMenu() {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('همه');

  const filtered = useMemo(() => {
    return menu.filter((item: any) => {
      const itemCategories = item.categories || [];
      const matchCategory = activeCategory === 'همه' ? true : itemCategories.includes(activeCategory);
      const q = query.trim();
      const matchQuery = q ? item.name.includes(q) || item.desc.includes(q) || itemCategories.join(' ').includes(q) : true;
      return matchCategory && matchQuery;
    });
  }, [query, activeCategory]);

  return (
    <>
      <section className="section">
        <input
          className="input"
          placeholder="جستجو در نوشیدنی‌ها و دسرها..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ marginTop: 0, fontSize: '16px', touchAction: 'manipulation' }}
        />
      </section>

      <section className="section">
        <div className="titleRow"><div className="title">دسته‌بندی‌ها</div><div className="link">فیلتر</div></div>
        <div className="chips">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`chip ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
              style={{ border: 'none', cursor: 'pointer' }}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="titleRow"><div className="title">پیشنهادهای کافه</div><div className="link">{filtered.length} آیتم</div></div>
        <div className="grid">
          {filtered.map((item: any) => (
            <ProductCard key={item.id} product={item} />
          ))}
        </div>
      </section>
    </>
  );
}
