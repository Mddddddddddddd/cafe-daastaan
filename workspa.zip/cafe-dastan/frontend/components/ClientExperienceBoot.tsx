"use client";

import { useEffect, useMemo, useState } from 'react';
import { usePathname } from 'next/navigation';

type TutorialStep = { title: string; text: string; icon: string };
type TourMode = 'prompt' | 'tour' | null;

function detectPlatform(): 'ios' | 'android' | 'desktop' {
  if (typeof window === 'undefined') return 'desktop';
  const ua = window.navigator.userAgent || '';
  if (/iPhone|iPad|iPod/i.test(ua)) return 'ios';
  if (/Android/i.test(ua)) return 'android';
  return 'desktop';
}

const tutorialMap: Record<string, TutorialStep[]> = {
  '/': [
    { title: 'منو و سفارش', text: 'از صفحه اصلی منو را ببین، آیتم‌ها را به سبد اضافه کن و بعد برای ادامه خرید وارد سبد شو.', icon: '🛒' },
    { title: 'جستجو و دسته‌بندی', text: 'با سرچ و دسته‌بندی‌ها سریع‌تر نوشیدنی یا دسر موردنظرت را پیدا کن.', icon: '🔎' },
  ],
  '/cart': [
    { title: 'مدیریت سبد خرید', text: 'اینجا می‌توانی تعداد آیتم‌ها را کم و زیاد کنی یا یک محصول را کامل حذف کنی.', icon: '🧺' },
    { title: 'ادامه تا پرداخت', text: 'وقتی سفارشت کامل شد، روی ادامه تا پرداخت بزن تا سفارش نهایی شود.', icon: '➡️' },
  ],
  '/checkout': [
    { title: 'ثبت سفارش', text: 'در این صفحه نوع سفارش، روش پرداخت و خلاصه نهایی سفارشت را می‌بینی.', icon: '💳' },
    { title: 'تشخیص میز از QR', text: 'اگر QR میز را اسکن کرده باشی، همین‌جا اسم میز و کد QR همان میز ثبت می‌شود.', icon: '📍' },
  ],
  '/story': [
    { title: 'استوری و داستان من', text: 'اینجا می‌توانی استوری ببینی، استوری منتشر کنی و با حساب خودت لایک و کامنت بگذاری.', icon: '📸' },
    { title: 'مالکیت استوری', text: 'استوری‌های خودت به حساب خودت وصل‌اند و حذف استوری هم فقط برای مالک مجاز است.', icon: '🛡️' },
  ],
  '/loyalty': [
    { title: 'باشگاه مشتریان', text: 'امتیاز سفارش‌ها و نظرسنجی‌ها برای خودت ذخیره می‌شود.', icon: '🏆' },
    { title: 'دریافت جایزه', text: 'وقتی امتیازت کافی شد، از همین بخش جایزه و کد تخفیف بگیر.', icon: '🎁' },
  ],
  '/notifications': [
    { title: 'اعلان‌های شخصی', text: 'اینجا فقط اعلان‌های مربوط به سفارش‌ها و حساب خودت را می‌بینی.', icon: '🔔' },
    { title: 'رهگیری وضعیت', text: 'هر زمان وضعیت سفارش عوض شود، از اینجا سریع خبردار می‌شوی.', icon: '📬' },
  ],
};

function StepLine({ title, subtitle, circle }: { title: string; subtitle: string; circle: React.ReactNode }) {
  return (
    <div className="installStepLine">
      <div className="installStepText">
        <strong>{title}</strong>
        <span>{subtitle}</span>
      </div>
      <div className="installStepCircle">{circle}</div>
    </div>
  );
}

function BrandLogo() {
  return <img src="/images/cafedastan_logo_transparent.png" alt="لوگوی کافه داستان" className="installMainLogo" />;
}

function IOSInstallGuide() {
  return (
    <>
      <div className="installLogoHolder"><BrandLogo /></div>
      <p className="installHeroText">وب‌اپلیکیشن کافه داستان را به صفحه اصلی تلفن همراه خود اضافه کنید</p>
      <div className="installStepsWrap">
        <StepLine title="Share" subtitle="انتخاب این گزینه از نوار پایین" circle="⤴" />
        <StepLine title="Add to homescreen" subtitle="انتخاب این گزینه از منوی ظاهرشده" circle="＋" />
        <StepLine title="Add" subtitle="زدن این گزینه" circle={<img src="/images/cafedastan_logo_transparent.png" alt="logo" className="installMiniLogo" />} />
      </div>
    </>
  );
}

function AndroidInstallGuide() {
  return (
    <>
      <div className="installLogoHolder"><BrandLogo /></div>
      <p className="installHeroText">وب‌اپلیکیشن کافه داستان را به صفحه اصلی تلفن همراه خود اضافه کنید</p>
      <div className="installStepsWrap">
        <StepLine title="Menu" subtitle="انتخاب منوی سه‌نقطه مرورگر" circle="⋮" />
        <StepLine title="Add to Home screen" subtitle="انتخاب این گزینه از منوی بازشده" circle="＋" />
        <StepLine title="Add" subtitle="زدن این گزینه برای افزودن به صفحه اصلی" circle={<img src="/images/cafedastan_logo_transparent.png" alt="logo" className="installMiniLogo" />} />
      </div>
    </>
  );
}

function DesktopInstallGuide() {
  return (
    <>
      <div className="installLogoHolder"><BrandLogo /></div>
      <p className="installHeroText">این وب‌اپ را از منوی مرورگر نصب کنید و بعد از همان آیکن دوباره باز کنید</p>
      <div className="installStepsWrap">
        <StepLine title="Browser menu" subtitle="منوی مرورگر را باز کنید" circle="⋮" />
        <StepLine title="Install app" subtitle="گزینه نصب وب‌اپ را انتخاب کنید" circle="＋" />
        <StepLine title="Open app" subtitle="بعد از نصب از آیکن ساخته‌شده وارد شوید" circle={<img src="/images/cafedastan_logo_transparent.png" alt="logo" className="installMiniLogo" />} />
      </div>
    </>
  );
}

export default function ClientExperienceBoot() {
  const pathname = usePathname() || '/';
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(false);
  const [installDone, setInstallDone] = useState(false);
  const [tempInstallBypass, setTempInstallBypass] = useState(false);
  const [tourMode, setTourMode] = useState<TourMode>(null);
  const [tutorialIndex, setTutorialIndex] = useState(0);
  const platform = useMemo(() => detectPlatform(), []);
  const tutorialSteps = tutorialMap[pathname] || tutorialMap['/'];

  useEffect(() => {
    const standalone = typeof window !== 'undefined' && (window.matchMedia?.('(display-mode: standalone)').matches || (window.navigator as any).standalone === true);
    if (standalone && typeof window !== 'undefined') {
      localStorage.setItem('cafe_dastan_pwa_installed', '1');
    }
    const syncNetwork = () => setOffline(!navigator.onLine);
    syncNetwork();
    window.addEventListener('online', syncNetwork);
    window.addEventListener('offline', syncNetwork);

    const timer = window.setTimeout(() => {
      setLoading(false);
      const isInstalled = standalone || (typeof window !== 'undefined' && localStorage.getItem('cafe_dastan_pwa_installed') === '1');
      const bypass = typeof window !== 'undefined' && (sessionStorage.getItem('cafe_dastan_install_bypass') === '1' || localStorage.getItem('cafe_dastan_install_dismissed') === '1');
      setInstallDone(isInstalled);
      setTempInstallBypass(bypass);
      setTutorialIndex(0);
      setTourMode(null);
    }, 700);

    const openTour = () => {
      setTutorialIndex(0);
      setTourMode('tour');
    };

    window.addEventListener('cafe-dastan-open-tour', openTour as EventListener);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('online', syncNetwork);
      window.removeEventListener('offline', syncNetwork);
      window.removeEventListener('cafe-dastan-open-tour', openTour as EventListener);
    };
  }, [pathname]);

  const retry = () => {
    if (typeof window !== 'undefined') window.location.reload();
  };

  const dismissInstallTemporarily = () => {
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('cafe_dastan_install_bypass', '1');
      localStorage.setItem('cafe_dastan_install_dismissed', '1');
    }
    setTempInstallBypass(true);
    setTourMode(null);
  };

  const startTour = () => {
    localStorage.setItem(`cafe_dastan_tutorial_answered_${pathname}`, '1');
    setTutorialIndex(0);
    setTourMode('tour');
  };

  const declineTour = () => {
    localStorage.setItem(`cafe_dastan_tutorial_answered_${pathname}`, '1');
    setTourMode(null);
  };

  const closeTour = () => setTourMode(null);

  const nextTutorial = () => {
    if (tutorialIndex >= tutorialSteps.length - 1) {
      setTourMode(null);
      return;
    }
    setTutorialIndex((prev) => prev + 1);
  };

  const currentStep = tutorialSteps[tutorialIndex];
  const mustShowInstallScreen = !loading && !offline && !installDone && !tempInstallBypass;
  const canShowTour = !loading && !offline && (installDone || tempInstallBypass) && !mustShowInstallScreen;

  return (
    <>
      {(loading || offline) ? (
        <div className="bootOverlay" role="status" aria-live="polite">
          <div className="bootCard">
            <div className="bootLogoWrap">
              <img src="/images/cafedastan_logo_transparent.png" alt="لوگوی کافه داستان" className="bootLogo" />
            </div>
            <strong>{offline ? 'اتصال اینترنت برقرار نیست' : 'درحال آماده‌سازی کافه داستان...'}</strong>
            <p>{offline ? 'اینترنت را بررسی کن و دوباره تلاش بزن.' : 'چند لحظه صبر کن تا وب‌اپ آماده شود.'}</p>
            {offline ? <button className="btn" onClick={retry}>تلاش مجدد</button> : <div className="bootDots"><span /><span /><span /></div>}
          </div>
        </div>
      ) : null}

      {mustShowInstallScreen ? (
        <div className="bootOverlay installOverlay installOverlayClean">
          <div className="installFullScreenCard installLikeSampleCard">
            {platform === 'ios' ? <IOSInstallGuide /> : platform === 'android' ? <AndroidInstallGuide /> : <DesktopInstallGuide />}
            <div className="installSkipRow">
              <button type="button" className="installSkipBtn" onClick={dismissInstallTemporarily}>متوجه شدم / ورود به منو</button>
            </div>
            <div className="installBottomActions">
              <span className="installBottomHint">بعد از نصب، وب‌اپ را از صفحه اصلی باز کن</span>
            </div>
          </div>
        </div>
      ) : null}

      {false && canShowTour && tourMode === 'prompt' ? (
        <div className="bootOverlay tutorialOverlay">
          <div className="tutorialPopupCard">
            <div className="tutorialStepBadge">راهنمای سریع</div>
            <div className="tutorialIconLarge">✨</div>
            <strong>میخوای آموزش این بخش رو ببینی؟</strong>
            <p>آموزش به‌صورت Onboarding Tour مرحله‌به‌مرحله نمایش داده می‌شود.</p>
            <div className="row" style={{ justifyContent: 'center', marginTop: '12px' }}>
              <button className="btn secondary" onClick={declineTour}>نه، بعداً</button>
              <button className="btn" onClick={startTour}>بله، شروع کن</button>
            </div>
          </div>
        </div>
      ) : null}

      {canShowTour && tourMode === 'tour' && currentStep ? (
        <div className="bootOverlay tutorialOverlay">
          <div className="tutorialPopupCard onboardingTourCard">
            <div className="tutorialStepBadge">Onboarding Tour · {tutorialIndex + 1} از {tutorialSteps.length}</div>
            <div className="tutorialIconLarge">{currentStep.icon}</div>
            <strong>{currentStep.title}</strong>
            <p>{currentStep.text}</p>
            <div className="tutorialProgressBar"><span style={{ width: `${((tutorialIndex + 1) / tutorialSteps.length) * 100}%` }} /></div>
            <div className="row" style={{ justifyContent: 'space-between', marginTop: '14px' }}>
              <button className="btn secondary" onClick={closeTour}>رد کردن</button>
              <button className="btn" onClick={nextTutorial}>{tutorialIndex === tutorialSteps.length - 1 ? 'اتمام' : 'بعدی'}</button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
