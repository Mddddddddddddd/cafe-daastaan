"use client";

import { useEffect, useMemo, useState } from 'react';
import { apiGet, apiPost, getCustomerContext } from '@/lib/api';

export default function RemoteLoyaltyClub({ compact = false }: { compact?: boolean }) {
  const [data, setData] = useState<any>(null);
  const [message, setMessage] = useState('');

  const load = () => {
    const customer = getCustomerContext();
    const params = new URLSearchParams({ customerId: customer.customerId || '', phone: customer.phone || '', name: customer.name || '' });
    return apiGet(`/loyalty?${params.toString()}`).then((res) => setData(res.data || null)).catch(() => null);
  };
  useEffect(() => { load(); }, []);

  const member = data?.member;
  const tier = data?.tier;
  const rewards = data?.rewards || [];
  const progress = useMemo(() => {
    if (!member || !tier?.next) return 100;
    const prev = tier.id === 'gold' ? 1200 : tier.id === 'silver' ? 500 : 0;
    return Math.min(100, Math.round(((member.lifetimePoints - prev) / (tier.next - prev)) * 100));
  }, [member, tier]);

  const copyCode = async (code: string) => {
    try { await navigator.clipboard.writeText(code); setMessage(`کد ${code} کپی شد.`); }
    catch { setMessage(`کد برای کپی: ${code}`); }
  };

  const redeem = async (rewardId: string) => {
    const customer = getCustomerContext();
    const res = await apiPost('/loyalty/redeem', { rewardId, customerId: customer.customerId, phone: customer.phone, name: customer.name });
    if (res.success) {
      setMessage(`کد تخفیف ساخته شد و آماده کپی است: ${res.data.voucher.code}`);
      load();
    } else setMessage(res.message || 'امتیاز کافی نیست.');
  };

  if (!data) return <div className="card banner">درحال دریافت باشگاه مشتریان...</div>;

  return (
    <div className="card banner logoWatermark loyaltyCard">
      <div className="row">
        <div>
          <strong>باشگاه مشتریان کافه داستان</strong>
          <p>با هر سفارش امتیاز می‌گیری و می‌تونی امتیازها را به جایزه تبدیل کنی.</p>
        </div>
        <span className="chip active">{tier?.title}</span>
      </div>
      <div className="loyaltyHero">
        <div>
          <div className="metricNum">{member.points.toLocaleString('fa-IR')}</div>
          <div className="sub">امتیاز قابل استفاده</div>
        </div>
        <div>
          <strong>{member.lifetimePoints.toLocaleString('fa-IR')}</strong>
          <div className="sub">امتیاز کل عضویت</div>
        </div>
      </div>
      <div className="loyaltyProgress"><span style={{ width: `${progress}%` }} /></div>
      <p>{tier?.next ? `${(tier.next - member.lifetimePoints).toLocaleString('fa-IR')} امتیاز تا سطح بعدی` : 'به بالاترین سطح باشگاه رسیدی.'}</p>

      {!compact ? (
        <>
          <div className="titleRow" style={{ marginTop: '14px' }}><div className="title">جایزه‌ها</div><div className="link">تبدیل امتیاز</div></div>
          <div style={{ display: 'grid', gap: '8px' }}>
            {rewards.map((reward: any) => (
              <div key={reward.id} className="card loyaltyReward">
                <div className="row">
                  <div><strong>{reward.title}</strong><p>{reward.description}</p></div>
                  <span className="price">{reward.points.toLocaleString('fa-IR')}</span>
                </div>
                <button className="btn secondary" style={{ width: '100%', marginTop: '8px' }} disabled={member.points < reward.points} onClick={() => redeem(reward.id)}>
                  {member.points >= reward.points ? 'ساخت کد تخفیف' : 'امتیاز کافی نیست'}
                </button>
              </div>
            ))}
          </div>

          <div className="titleRow" style={{ marginTop: '14px' }}><div className="title">کدهای فعال</div></div>
          <div className="chips">
            {(member.vouchers || []).map((v: any) => <button key={v.id} className="chip active copyCodeChip" onClick={() => copyCode(v.code)}>{v.title}: {v.code}</button>)}
            {!(member.vouchers || []).length ? <span className="chip">هنوز جایزه‌ای فعال نشده</span> : null}
          </div>

          <div className="titleRow" style={{ marginTop: '14px' }}><div className="title">تاریخچه امتیاز</div></div>
          <div style={{ display: 'grid', gap: '7px' }}>
            {(member.history || []).slice(0, 8).map((h: any) => (
              <div key={h.id} className="row loyaltyHistory" style={{ alignItems: 'center' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <span>{h.title}</span>
                  {h.note ? <div style={{ fontSize: '10.5px', opacity: 0.72, marginTop: '3px', lineHeight: 1.7 }}>{h.note}</div> : null}
                </div>
                <strong className={h.points > 0 ? 'earn' : 'burn'} style={{ flexShrink: 0, marginRight: '8px' }}>{h.points > 0 ? '+' : ''}{h.points.toLocaleString('fa-IR')}</strong>
              </div>
            ))}
            {!(member.history || []).length ? <p>بعد از ثبت اولین سفارش، امتیازها اینجا دیده می‌شوند.</p> : null}
          </div>
        </>
      ) : null}
      {message ? <p style={{ color: 'var(--primary-dark)' }}>{message}</p> : null}
    </div>
  );
}
