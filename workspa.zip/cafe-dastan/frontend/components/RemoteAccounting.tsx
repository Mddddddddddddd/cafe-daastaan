"use client";

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { apiDelete, apiGet } from '@/lib/api';

function div(a: number, b: number) { return ~~(a / b); }
function jalaliToGregorian(jy: number, jm: number, jd: number) {
  jy += 1595;
  let days = -355668 + (365 * jy) + div(jy, 33) * 8 + div((jy % 33) + 3, 4) + jd + (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
  let gy = 400 * div(days, 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * div(--days, 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    gy += div(days - 1, 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 1; gm <= 12 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
  return { gy, gm, gd };
}

function toGregorianInput(jalali: string) {
  const cleaned = jalali.trim().replace(/-/g, '/');
  const [jy, jm, jd] = cleaned.split('/').map((x) => Number(x));
  if (!jy || !jm || !jd) return '';
  const { gy, gm, gd } = jalaliToGregorian(jy, jm, jd);
  return `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(2, '0')}`;
}

function formatJalali(date: Date | string | number) {
  const d = new Date(date);
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

function formatDayKey(dateValue?: string) {
  const d = dateValue ? new Date(dateValue) : new Date();
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

function todayJalali(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-latn', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d).replace(/\u200e/g, '');
}

function groupOrdersByDay(orders: any[]) {
  const groups = new Map<string, any[]>();
  for (const order of orders || []) {
    const key = formatDayKey(order.date);
    groups.set(key, [...(groups.get(key) || []), order]);
  }
  return [...groups.entries()].map(([date, rows]) => ({ date, rows }));
}

export default function RemoteAccounting({ role = 'admin', embedded = false }: { role?: 'admin' | 'waiter'; embedded?: boolean }) {
  const [report, setReport] = useState<any>(null);
  const [fromJalali, setFromJalali] = useState(todayJalali(-30));
  const [toJalali, setToJalali] = useState(todayJalali());
  const [dateMessage, setDateMessage] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  const query = useMemo(() => {
    const from = toGregorianInput(fromJalali);
    const to = toGregorianInput(toJalali);
    return from && to ? `?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}` : '';
  }, [fromJalali, toJalali]);

  const endpoint = role === 'waiter' ? '/staff/waiter/accounting/report' : '/admin/products/accounting/report';

  const load = () => apiGet(`${endpoint}${query}`).then((res) => {
    if (res?.success === false) {
      setReport({ orders: [], totalSales: 0, totalCost: 0, totalProfit: 0, totalDiscount: 0, orderCount: 0, message: res?.message || 'دسترسی یا داده معتبر نیست.' });
      return;
    }
    setReport(res.data || { orders: [], totalSales: 0, totalCost: 0, totalProfit: 0, totalDiscount: 0, orderCount: 0 });
  }).catch(() => setReport({ orders: [], totalSales: 0, totalCost: 0, totalProfit: 0, totalDiscount: 0, orderCount: 0, message: 'خطا در دریافت گزارش.' }));

  useEffect(() => {
    if (!query) {
      setDateMessage('فرمت تاریخ باید مثل ۱۴۰۳/۰۵/۱۲ باشد.');
      return;
    }
    setDateMessage('');
    load();
    const interval = setInterval(load, 60 * 1000);
    return () => clearInterval(interval);
  }, [query, role]);

  const removeOrder = async (id: string) => {
    if (role !== 'admin') return;
    const ok = typeof window === 'undefined' ? true : window.confirm(`سفارش #${id} از تاریخچه حسابداری حذف شود؟`);
    if (!ok) return;
    const res = await apiDelete(`/admin/products/accounting/report/${id}`);
    if (res?.success) {
      setStatusMessage(`سفارش #${id} حذف شد.`);
      load();
    } else {
      setStatusMessage(res?.message || 'حذف سفارش انجام نشد.');
    }
  };

  if (!report) return <div className="card banner">درحال دریافت گزارش حسابداری...</div>;

  const isAdmin = role === 'admin';
  const groupedOrders = groupOrdersByDay(report.orders || []);

  const content = (
    <div className="card banner logoWatermark">
      <strong>{isAdmin ? 'حسابداری، فروش و سود' : 'گزارش سفارش‌ها و فروش'}</strong>
      <p>بازه انتخاب‌شده: {fromJalali} تا {toJalali}</p>
      <div className="accountingFilters">
        <label>از تاریخ شمسی<input className="input" inputMode="numeric" placeholder="مثلاً ۱۴۰۳/۰۵/۱۲" value={fromJalali} onChange={(e) => setFromJalali(e.target.value)} /></label>
        <label>تا تاریخ شمسی<input className="input" inputMode="numeric" placeholder="مثلاً ۱۴۰۳/۰۵/۱۲" value={toJalali} onChange={(e) => setToJalali(e.target.value)} /></label>
      </div>
      {dateMessage ? <p style={{ color: '#b25b00' }}>{dateMessage}</p> : null}
      {statusMessage ? <p style={{ color: 'var(--primary-dark)' }}>{statusMessage}</p> : null}
      <div className="chips" style={{ marginTop: '8px' }}>
        <button className="chip" onClick={() => { const v = todayJalali(); setFromJalali(v); setToJalali(v); }}>امروز</button>
        <button className="chip" onClick={() => { const v = todayJalali(-1); setFromJalali(v); setToJalali(v); }}>دیروز</button>
        <button className="chip" onClick={() => { setFromJalali(todayJalali(-7)); setToJalali(todayJalali()); }}>۷ روز اخیر</button>
        <button className="chip" onClick={() => { setFromJalali(todayJalali(-30)); setToJalali(todayJalali()); }}>۳۰ روز اخیر</button>
      </div>

      <div className="accountingGrid">
        <div className="accountingItem"><strong>{report.totalSales?.toLocaleString('fa-IR')} تومان</strong><p>مجموع فروش</p></div>
        <div className="accountingItem"><strong>{report.orderCount?.toLocaleString('fa-IR')}</strong><p>تعداد سفارش</p></div>
        <div className="accountingItem"><strong>{(report.totalDiscount || 0).toLocaleString('fa-IR')} تومان</strong><p>تخفیف‌ها</p></div>
        {isAdmin ? <div className="accountingItem"><strong>{report.totalProfit?.toLocaleString('fa-IR')} تومان</strong><p>سود تخمینی</p></div> : null}
        {isAdmin ? <div className="accountingItem"><strong>{report.totalCost?.toLocaleString('fa-IR')} تومان</strong><p>هزینه تخمینی</p></div> : null}
      </div>

      {isAdmin ? <p>سفارش‌های هر روز داخل منوی کشویی بسته نمایش داده می‌شوند. برای حذف سفارش روی ضربدر همان آیتم بزن.</p> : null}

      <div style={{ display: 'grid', gap: '10px', marginTop: '10px' }}>
        {groupedOrders.map((group) => (
          <details key={group.date} className="adminNestedDetails">
            <summary className="adminNestedSummary">
              <span>{group.date}</span>
              <small>{group.rows.length.toLocaleString('fa-IR')} سفارش</small>
            </summary>
            <div className="adminNestedDetailsBody" style={{ padding: '10px', display: 'grid', gap: '8px' }}>
              {group.rows.map((order: any) => (
                <div key={order.id} className="card" style={{ padding: '10px', background: '#f8fcfc', position: 'relative' }}>
                  {isAdmin ? (
                    <button
                      onClick={() => removeOrder(order.id)}
                      aria-label={`حذف سفارش ${order.id}`}
                      style={{ position: 'absolute', left: '10px', top: '10px', width: '28px', height: '28px', borderRadius: '999px', border: 'none', background: '#ffe8e8', color: '#b42318', fontSize: '20px', lineHeight: 1, cursor: 'pointer' }}
                    >×</button>
                  ) : null}
                  <div className="row" style={{ paddingLeft: isAdmin ? '34px' : 0 }}>
                    <strong>سفارش #{order.id}</strong>
                    <span className="price">{Number(order.total || 0).toLocaleString('fa-IR')} تومان</span>
                  </div>
                  <div className="sub">{formatJalali(order.date)} · {new Date(order.date).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })} · {order.table || 'میز'}</div>
                  <div style={{ marginTop: '6px' }}>
                    {(order.items || []).map((item: any, index: number) => <div key={`${item.productId}-${index}`} className="sub">{item.qty}× {item.name} · {Number(item.total || 0).toLocaleString('fa-IR')} تومان</div>)}
                  </div>
                  {isAdmin ? (
                    <div className="row" style={{ marginTop: '8px' }}>
                      <span className="sub">هزینه: {Number(order.estimatedCost || 0).toLocaleString('fa-IR')}</span>
                      <span className="sub">سود: {Number(order.profit || 0).toLocaleString('fa-IR')}</span>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          </details>
        ))}
        {report.message ? <p style={{ color: '#b25b00' }}>{report.message}</p> : null}
        {!groupedOrders.length ? <p>در این بازه سفارشی ثبت نشده است.</p> : null}
      </div>
    </div>
  );

  if (embedded) return content;

  return (
    <main className="page">
      <div className="row contentPad">
        <Link href={isAdmin ? '/admin' : '/waiter'} className="link">بازگشت</Link>
        <strong>{isAdmin ? 'حسابداری ادمین' : 'حسابداری گارسون'}</strong>
      </div>
      <section className="contentPad">{content}</section>
    </main>
  );
}
