"use client";

export const emptyCustomization = () => ({ id: `c-${Date.now()}`, name: '', values: [{ id: `v-${Date.now()}`, name: '', price: 0 }] });

export function normalizeCustomizations(input: any[] = []) {
  return (input || []).map((group: any, groupIndex: number) => ({
    id: group.id || `c-${Date.now()}-${groupIndex}`,
    name: group.name || '',
    values: (group.values || []).map((value: any, valueIndex: number) => {
      if (typeof value === 'string') return { id: `v-${Date.now()}-${groupIndex}-${valueIndex}`, name: value, price: 0 };
      return { id: value.id || `v-${Date.now()}-${groupIndex}-${valueIndex}`, name: value.name || value.label || value.value || '', price: Number(value.price || 0) };
    }),
  }));
}

export default function CustomizationEditor({ value, onChange, title = 'شخصی‌سازی محصول' }: { value: any[]; onChange: (next: any[]) => void; title?: string }) {
  const groups = normalizeCustomizations(value || []);
  const updateGroup = (index: number, patch: any) => onChange(groups.map((g, i) => (i === index ? { ...g, ...patch } : g)));
  const removeGroup = (index: number) => onChange(groups.filter((_, i) => i !== index));
  const addGroup = () => onChange([...groups, emptyCustomization()]);
  const updateValue = (groupIndex: number, valueIndex: number, patch: any) => onChange(groups.map((group, gi) => gi === groupIndex ? { ...group, values: group.values.map((v: any, vi: number) => vi === valueIndex ? { ...v, ...patch, price: patch.price !== undefined ? Number(patch.price || 0) : v.price } : v) } : group));
  const addValue = (groupIndex: number) => onChange(groups.map((group, gi) => gi === groupIndex ? { ...group, values: [...group.values, { id: `v-${Date.now()}`, name: '', price: 0 }] } : group));
  const removeValue = (groupIndex: number, valueIndex: number) => onChange(groups.map((group, gi) => gi === groupIndex ? { ...group, values: group.values.filter((_: any, vi: number) => vi !== valueIndex) } : group));

  return (
    <details className="adminNestedDetails" style={{ marginTop: '10px' }}>
      <summary className="adminNestedSummary">
        <span>{title}</span>
        <small>{groups.length ? `${groups.length.toLocaleString('fa-IR')} گروه` : 'بسته'}</small>
      </summary>
      <div className="adminSubCard adminNestedDetailsBody">
        <div className="row"><strong className="adminSubTitle">{title}</strong><button className="btn" onClick={addGroup}>افزودن گروه</button></div>
        {groups.map((group, groupIndex) => (
          <div key={group.id || groupIndex} className="card banner" style={{ marginTop: '10px', background: '#fff' }}>
            <div className="row"><strong>گروه {groupIndex + 1}</strong><button className="btn secondary" onClick={() => removeGroup(groupIndex)}>حذف گروه</button></div>
            <input className="input" placeholder="عنوان گروه" value={group.name || ''} onChange={(e) => updateGroup(groupIndex, { name: e.target.value })} />
            <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
              {(group.values || []).map((item: any, valueIndex) => (
                <div key={item.id || valueIndex} className="card" style={{ padding: '8px', background: '#f8fcfc' }}>
                  <div className="adminOptionGrid">
                    <input className="input" placeholder="نام گزینه" value={item.name || ''} onChange={(e) => updateValue(groupIndex, valueIndex, { name: e.target.value })} />
                    <input className="input" inputMode="numeric" placeholder="قیمت افزوده" value={item.price ?? 0} onChange={(e) => updateValue(groupIndex, valueIndex, { price: e.target.value })} />
                  </div>
                  <button className="btn secondary" style={{ marginTop: '8px', width: '100%' }} onClick={() => removeValue(groupIndex, valueIndex)}>حذف این گزینه</button>
                </div>
              ))}
            </div>
            <button className="btn secondary" style={{ marginTop: '10px', width: '100%' }} onClick={() => addValue(groupIndex)}>افزودن گزینه</button>
          </div>
        ))}
      </div>
    </details>
  );
}
