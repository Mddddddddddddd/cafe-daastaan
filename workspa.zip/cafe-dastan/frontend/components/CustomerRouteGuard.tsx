"use client";

import { useEffect } from 'react';
import { isCustomerAuthenticated, requireCustomerAuth } from '@/lib/api';

export default function CustomerRouteGuard({ nextPath }: { nextPath: string }) {
  useEffect(() => {
    // کمی تأخیر می‌دهیم تا بعد از login/redirect، localStorage کامل sync شود.
    const timer = window.setTimeout(() => {
      if (!isCustomerAuthenticated()) requireCustomerAuth(nextPath);
    }, 120);
    return () => window.clearTimeout(timer);
  }, [nextPath]);

  return null;
}
