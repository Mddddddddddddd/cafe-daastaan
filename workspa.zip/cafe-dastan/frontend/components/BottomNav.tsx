import Link from 'next/link';

export default function BottomNav({ active }: { active: string }) {
  return (
    <nav className="bottomNav">
      <Link href="/" className={active === 'home' ? 'active' : ''}>خانه</Link>
      <Link href="/cart" className={active === 'cart' ? 'active' : ''}>سبد</Link>
      <Link href="/story" className={active === 'story' ? 'active' : ''}>داستان</Link>
      <Link href="/auth/login" className={active === 'login' ? 'active' : ''}>ورود</Link>
    </nav>
  );
}
