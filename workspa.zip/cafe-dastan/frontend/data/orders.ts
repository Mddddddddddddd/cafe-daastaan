export const order = {
  id: '1042',
  branch: 'کافه داستان',
  table: 'میز فروغ',
  paymentMethod: 'پرداخت در میز',
  status: 'bar_preparing',
  items: [
    { id: '1', name: 'لاته همینگوی', price: 178000, qty: 1, station: 'bar' },
    { id: '2', name: 'چیزکیک پایان شیرین', price: 189000, qty: 1, station: 'kitchen' }
  ]
};