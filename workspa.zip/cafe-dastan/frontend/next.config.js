/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {},
  async rewrites() {
    return [
      {
        source: '/uploads/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://127.0.0.1:4000'}/uploads/:path*`,
      },
    ];
  },
  async headers() {
    return [
      // صفحات HTML و مسیرهای پویا — هرگز کش نشوند (تغییرات ادمین بلافاصله دیده شوند)
      {
        source: '/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, must-revalidate' },
          { key: 'Pragma', value: 'no-cache' },
          { key: 'Expires', value: '0' },
        ],
      },
      // فایل‌های استاتیک Next (hash دار) — کش immutable یک‌ساله
      // (در Next 14 قانون بعدی اولویت دارد؛ برای همین این قانون آخر است)
      {
        source: '/_next/static/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
    ];
  },
};

module.exports = nextConfig;
