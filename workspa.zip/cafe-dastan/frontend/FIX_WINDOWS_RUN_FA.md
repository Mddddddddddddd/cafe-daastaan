# رفع خطای اجرای Next.js روی ویندوز

اگر در `http://localhost:3000` با خطای مربوط به:
- `ERR_UNSUPPORTED_ESM_URL_SCHEME`
- یا `Received protocol 'c:'`

مواجه شدی، این مراحل را انجام بده.

## 1) Node.js را چک کن
در ترمینال بزن:
```bash
node -v
```

اگر نسخه‌ات خیلی قدیمی یا خیلی خاص است، بهتر است از **Node.js 18 LTS** یا **Node.js 20 LTS** استفاده کنی.

پیشنهاد:
- Node 20 LTS

---

## 2) وارد پوشه فرانت شو
```bash
cd cafe-dastan/frontend
```

---

## 3) پوشه‌ها و فایل‌های کش را پاک کن
### در PowerShell:
```powershell
Remove-Item -Recurse -Force .next
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json
```

### در CMD اگر PowerShell نبود:
```cmd
rmdir /s /q .next
rmdir /s /q node_modules
del package-lock.json
```

---

## 4) دوباره نصب کن
```bash
npm install
```

---

## 5) پروژه را اجرا کن
```bash
npm run dev
```

---

## 6) اگر باز هم خطا بود
این دستور را تست کن:
```bash
set NODE_OPTIONS=
npm run dev
```

اگر PowerShell بود:
```powershell
$env:NODE_OPTIONS=""
npm run dev
```

چون بعضی وقت‌ها یک `NODE_OPTIONS` خراب در سیستم باعث این خطا می‌شود.

---

## 7) اگر باز هم حل نشد
این‌ها را برای من بفرست:
```bash
node -v
npm -v
```
و خروجی کامل:
```bash
npm run dev
```

تا دقیق‌تر حلش کنم.
