export const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000';

export function resolveImageUrl(url?: string): string {
  const value = String(url || '').trim();
  if (!value) return '';
  if (value.startsWith('http://') || value.startsWith('https://') || value.startsWith('data:')) {
    return value;
  }
  // آدرس‌های /uploads به صورت «نسبی» برمی‌گردند تا مرورگر مشتری
  // آن را از همان دامنه درخواست کند و Next.js (rewrite در next.config.js)
  // به بک‌اند proxy کند. این روش هم روی سرور اصلی و هم در تست محلی کار می‌کند
  // و به localhost روی موبایل مشتری برخورد نمی‌کند.
  if (value.startsWith('/uploads/')) {
    return value;
  }
  return value;
}

const CUSTOMER_ROLE = 'customer';
const CUSTOMER_LOGIN_PATH = '/auth/login';
const STAFF_ROLES = ['admin', 'cashier', 'waiter', 'bar', 'kitchen'];

const ACTIVE_TOKEN_KEY = 'cafe_dastan_access_token';
const ACTIVE_REFRESH_KEY = 'cafe_dastan_refresh_token';
const ACTIVE_USER_KEY = 'cafe_dastan_user';
const CUSTOMER_TOKEN_KEY = 'cafe_dastan_customer_access_token';
const CUSTOMER_REFRESH_KEY = 'cafe_dastan_customer_refresh_token';
const CUSTOMER_USER_KEY = 'cafe_dastan_customer_user';
const CUSTOMER_LOGGED_IN_KEY = 'cafe_dastan_customer_logged_in';
const STAFF_TOKEN_KEY = 'cafe_dastan_staff_access_token';
const STAFF_USER_KEY = 'cafe_dastan_staff_user';
const STAFF_LOGGED_IN_KEY = 'cafe_dastan_staff_logged_in';
const STAFF_ROLE_KEY = 'cafe_dastan_staff_role';

function normalizeRole(role: any) {
  return String(role || '').trim().toLowerCase();
}

function isStaffRole(role: any) {
  return STAFF_ROLES.includes(normalizeRole(role));
}

function safeJsonParse(raw: string | null) {
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

function decodeJwtPayload(token: string) {
  try {
    const payload = token.split('.')[1];
    if (!payload) return null;
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), '=');
    return JSON.parse(atob(padded));
  } catch {
    return null;
  }
}

function normalizeUser(user: any, token?: string) {
  const tokenUser = token ? decodeJwtPayload(token) : null;
  const merged = { ...(tokenUser || {}), ...(user || {}) };
  const role = normalizeRole(merged.role) || CUSTOMER_ROLE;
  return { ...merged, role };
}

function staffTokenKey(role: string) { return `cafe_dastan_staff_${normalizeRole(role)}_access_token`; }
function staffUserKey(role: string) { return `cafe_dastan_staff_${normalizeRole(role)}_user`; }
function staffLoggedKey(role: string) { return `cafe_dastan_staff_${normalizeRole(role)}_logged_in`; }

function roleFromPath(path: string) {
  if (path.startsWith('/admin')) return 'admin';
  if (path.startsWith('/bar')) return 'bar';
  if (path.startsWith('/kitchen')) return 'kitchen';
  if (path.startsWith('/waiter')) return 'waiter';
  return '';
}

function isStaffPath(path: string) {
  return !!roleFromPath(path) || path.startsWith('/staff');
}

function getRawCustomerToken() {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(CUSTOMER_TOKEN_KEY)
    || (!isStaffRole(safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY))?.role) ? (localStorage.getItem(ACTIVE_TOKEN_KEY) || '') : '')
    || '';
}

function getRawStaffToken(preferredRole?: string) {
  if (typeof window === 'undefined') return '';
  const role = normalizeRole(preferredRole || roleFromPath(window.location.pathname || '') || localStorage.getItem(STAFF_ROLE_KEY) || '');
  if (role) {
    const exact = localStorage.getItem(staffTokenKey(role));
    if (exact) return exact;
    const admin = localStorage.getItem(staffTokenKey('admin'));
    if (admin) return admin;
  }
  return localStorage.getItem(STAFF_TOKEN_KEY)
    || (isStaffRole(safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY))?.role) ? (localStorage.getItem(ACTIVE_TOKEN_KEY) || '') : '')
    || '';
}

export function authHeaders() {
  if (typeof window === 'undefined') return {};
  const path = window.location.pathname || '';
  const token = isStaffPath(path)
    ? getRawStaffToken(roleFromPath(path)) || getRawCustomerToken()
    : getRawCustomerToken() || getRawStaffToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function saveAuth(data: any) {
  if (typeof window === 'undefined') return;
  const payload = data?.data && data.data.accessToken ? data.data : data;
  const accessToken = payload?.accessToken || payload?.token || getRawCustomerToken() || '';
  if (!accessToken) return;

  const refreshToken = payload?.refreshToken || localStorage.getItem(CUSTOMER_REFRESH_KEY) || localStorage.getItem(ACTIVE_REFRESH_KEY) || '';
  const user = normalizeUser(payload?.user || payload?.customer || getStoredUser() || {}, accessToken);
  const customerUser = { ...user, role: CUSTOMER_ROLE };

  localStorage.setItem(CUSTOMER_TOKEN_KEY, accessToken);
  if (refreshToken) localStorage.setItem(CUSTOMER_REFRESH_KEY, refreshToken);
  localStorage.setItem(CUSTOMER_USER_KEY, JSON.stringify(customerUser));
  localStorage.setItem(CUSTOMER_LOGGED_IN_KEY, '1');

  localStorage.setItem(ACTIVE_TOKEN_KEY, accessToken);
  if (refreshToken) localStorage.setItem(ACTIVE_REFRESH_KEY, refreshToken);
  localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(customerUser));
}

export function saveStaffAuth(data: any) {
  if (typeof window === 'undefined') return;
  const payload = data?.data && data.data.accessToken ? data.data : data;
  const accessToken = payload?.accessToken || payload?.token || '';
  if (!accessToken) return;
  const user = normalizeUser(payload?.user || {}, accessToken);
  const role = normalizeRole(user.role || payload?.role || 'admin');
  const staffUser = { ...user, role };

  // session مستقل برای همان پنل؛ ورود آشپزخانه دیگر بار/ویتر/ادمین را overwrite نمی‌کند.
  localStorage.setItem(staffTokenKey(role), accessToken);
  localStorage.setItem(staffUserKey(role), JSON.stringify(staffUser));
  localStorage.setItem(staffLoggedKey(role), '1');

  // کلیدهای legacy فقط برای سازگاری؛ معیار اصلی پنل‌ها کلید role-specific است.
  localStorage.setItem(STAFF_TOKEN_KEY, accessToken);
  localStorage.setItem(STAFF_USER_KEY, JSON.stringify(staffUser));
  localStorage.setItem(STAFF_LOGGED_IN_KEY, '1');
  localStorage.setItem(STAFF_ROLE_KEY, role);
  localStorage.setItem(ACTIVE_TOKEN_KEY, accessToken);
  localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(staffUser));
}

export function isStaffAuthenticated(requiredRole?: string) {
  if (typeof window === 'undefined') return false;
  const needed = normalizeRole(requiredRole || roleFromPath(window.location.pathname || '') || '');
  if (!needed) return localStorage.getItem(STAFF_LOGGED_IN_KEY) === '1' || !!localStorage.getItem(STAFF_TOKEN_KEY);

  const exactLogged = localStorage.getItem(staffLoggedKey(needed)) === '1';
  const exactToken = !!localStorage.getItem(staffTokenKey(needed));
  const adminLogged = localStorage.getItem(staffLoggedKey('admin')) === '1';
  const adminToken = !!localStorage.getItem(staffTokenKey('admin'));

  if (exactLogged || exactToken) {
    localStorage.setItem(staffLoggedKey(needed), '1');
    return true;
  }
  if (needed !== 'admin' && (adminLogged || adminToken)) return true;

  // migration برای نسخه‌های قبلی: اگر فقط legacy برای همین role هست، session همان role را بساز.
  const legacyUser = safeJsonParse(localStorage.getItem(STAFF_USER_KEY));
  const legacyRole = normalizeRole(localStorage.getItem(STAFF_ROLE_KEY) || legacyUser?.role);
  const legacyToken = localStorage.getItem(STAFF_TOKEN_KEY) || '';
  if (legacyToken && (legacyRole === needed || legacyRole === 'admin')) {
    localStorage.setItem(staffTokenKey(legacyRole), legacyToken);
    localStorage.setItem(staffUserKey(legacyRole), JSON.stringify({ ...(legacyUser || {}), role: legacyRole }));
    localStorage.setItem(staffLoggedKey(legacyRole), '1');
    return true;
  }
  return false;
}

export function clearAuth() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(CUSTOMER_TOKEN_KEY);
  localStorage.removeItem(CUSTOMER_REFRESH_KEY);
  localStorage.removeItem(CUSTOMER_USER_KEY);
  localStorage.removeItem(CUSTOMER_LOGGED_IN_KEY);

  const activeUser = safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY));
  if (!activeUser || !isStaffRole(activeUser.role)) {
    localStorage.removeItem(ACTIVE_TOKEN_KEY);
    localStorage.removeItem(ACTIVE_REFRESH_KEY);
    localStorage.removeItem(ACTIVE_USER_KEY);
  }
}

export function clearStaffAuth(role?: string) {
  if (typeof window === 'undefined') return;
  const target = normalizeRole(role || roleFromPath(window.location.pathname || '') || localStorage.getItem(STAFF_ROLE_KEY) || '');
  const roles = target ? [target] : STAFF_ROLES;
  for (const item of roles) {
    localStorage.removeItem(staffTokenKey(item));
    localStorage.removeItem(staffUserKey(item));
    localStorage.removeItem(staffLoggedKey(item));
  }

  localStorage.removeItem(STAFF_TOKEN_KEY);
  localStorage.removeItem(STAFF_USER_KEY);
  localStorage.removeItem(STAFF_LOGGED_IN_KEY);
  localStorage.removeItem(STAFF_ROLE_KEY);

  const activeUser = safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY));
  if (isStaffRole(activeUser?.role)) {
    localStorage.removeItem(ACTIVE_TOKEN_KEY);
    localStorage.removeItem(ACTIVE_REFRESH_KEY);
    localStorage.removeItem(ACTIVE_USER_KEY);
  }
}

export function getStoredUser() {
  if (typeof window === 'undefined') return null;
  const customer = safeJsonParse(localStorage.getItem(CUSTOMER_USER_KEY));
  if (customer) return normalizeUser({ ...customer, role: CUSTOMER_ROLE }, getRawCustomerToken());

  const active = safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY));
  if (active && !isStaffRole(active.role)) return normalizeUser({ ...active, role: CUSTOMER_ROLE }, getRawCustomerToken());
  return null;
}

export function getCustomerContext() {
  const user = getStoredUser();
  return {
    customerId: user?.id || '',
    phone: user?.phone || '',
    name: user?.username || user?.name || 'مهمان کافه داستان',
  };
}

export function isCustomerAuthenticated() {
  if (typeof window === 'undefined') return false;
  const loggedFlag = localStorage.getItem(CUSTOMER_LOGGED_IN_KEY) === '1';
  const customerToken = localStorage.getItem(CUSTOMER_TOKEN_KEY) || '';
  const customerUser = safeJsonParse(localStorage.getItem(CUSTOMER_USER_KEY));
  const activeToken = localStorage.getItem(ACTIVE_TOKEN_KEY) || '';
  const activeUser = safeJsonParse(localStorage.getItem(ACTIVE_USER_KEY));

  if (loggedFlag) return true;

  if (customerToken || customerUser) {
    localStorage.setItem(CUSTOMER_LOGGED_IN_KEY, '1');
    if (customerUser) localStorage.setItem(CUSTOMER_USER_KEY, JSON.stringify({ ...normalizeUser(customerUser, customerToken), role: CUSTOMER_ROLE }));
    return true;
  }

  if (activeToken && activeUser && !isStaffRole(activeUser.role)) {
    const fixedUser = { ...normalizeUser(activeUser, activeToken), role: CUSTOMER_ROLE };
    localStorage.setItem(CUSTOMER_TOKEN_KEY, activeToken);
    localStorage.setItem(CUSTOMER_USER_KEY, JSON.stringify(fixedUser));
    localStorage.setItem(CUSTOMER_LOGGED_IN_KEY, '1');
    return true;
  }

  return false;
}

export function requireCustomerAuth(nextPath?: string) {
  if (typeof window === 'undefined') return false;
  if (isCustomerAuthenticated()) return true;
  const target = nextPath || `${window.location.pathname}${window.location.search || ''}`;
  localStorage.setItem('cafe_dastan_post_login_redirect', target);
  window.location.href = `${CUSTOMER_LOGIN_PATH}?next=${encodeURIComponent(target)}`;
  return false;
}

export function consumePostLoginRedirect() {
  if (typeof window === 'undefined') return '/';
  const url = new URL(window.location.href);
  const next = url.searchParams.get('next') || localStorage.getItem('cafe_dastan_post_login_redirect') || '/';
  localStorage.removeItem('cafe_dastan_post_login_redirect');
  return next;
}

export async function apiGet(path: string) {
  const res = await fetch(`${API_BASE_URL}${path}`, { cache: 'no-store', headers: { ...authHeaders() } });
  return parseResponse(res);
}

export async function apiPost(path: string, body?: any) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  return parseResponse(res);
}

export async function apiPatch(path: string, body?: any) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  return parseResponse(res);
}

async function parseResponse(res: Response) {
  const data = await res.json().catch(() => ({}));
  // پاسخ‌های polling/شبکه نباید staff/customer را logout کنند.
  if ((res.status === 401 || res.status === 403) && typeof window !== 'undefined') {
    if (data?.forceCustomerLogout === true) clearAuth();
    if (data?.forceStaffLogout === true) clearStaffAuth();
  }
  return data;
}

export async function apiDelete(path: string) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: 'DELETE',
    headers: { ...authHeaders() },
  });
  return parseResponse(res);
}

export function getCustomerAccessToken() {
  if (typeof window === 'undefined') return '';
  return getRawCustomerToken();
}

export function getTableContext() {
  if (typeof window === 'undefined') return { tableName: '', tableQr: '' };
  try {
    const raw = localStorage.getItem('cafe_dastan_table_context');
    return raw ? JSON.parse(raw) : { tableName: '', tableQr: '' };
  } catch {
    return { tableName: '', tableQr: '' };
  }
}

export async function apiPut(path: string, body?: any) {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  return parseResponse(res);
}
