export const cartItems = [
  { id: 'p1', name: 'لاته همینگوی', option: 'شیر بادام · بزرگ', price: 178000, qty: 1 },
  { id: 'p3', name: 'چیزکیک پایان شیرین', option: '۱ عدد', price: 189000, qty: 1 },
];

export const cartTotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);