module.exports = {
  plugins: {},
};