/* Service Worker کافه داستان — نوتیفیکیشن سفارش جدید برای پنل‌های پرسنل */

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: 'سفارش جدید', body: event.data ? event.data.text() : '' };
  }
  const title = data.title || 'کافه داستان';
  const icon = data.icon || '/images/icon-192.png';
  event.waitUntil(
    (async () => {
      try {
        await self.registration.showNotification(title, {
          body: data.body || '',
          icon: icon,
          badge: icon,
          sound: '/notification-sound.wav',
          vibrate: [250, 120, 250],
          requireInteraction: true,
          data: { url: data.url || '/' },
        });
      } catch (err) {
        // فالی‌بک برای مرورگرهایی که showNotification ندارند
        try {
          const n = new Notification(title, { body: data.body || '', icon: icon, sound: '/notification-sound.wav' });
          n.onclick = () => { window.open(data.url || '/', '_self'); n.close(); };
        } catch (e2) { /* بدون نوتیفیکیشن */ }
      }
    })(),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ('focus' in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      return self.clients.openWindow(url);
    }),
  );
});
