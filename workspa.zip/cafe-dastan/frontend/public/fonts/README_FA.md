فایل‌های فونت را اینجا قرار بده:
- IRANSans-Regular.woff2
- IRANSans-Medium.woff2

اگر woff2 نداشتی می‌توانی نسخه woff را با همین نام‌ها جایگزین کنی و بعد مسیرها را در layout.tsx تنظیم کنی.