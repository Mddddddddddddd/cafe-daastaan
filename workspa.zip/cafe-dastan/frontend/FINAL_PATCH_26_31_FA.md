# پچ نهایی مشکلات 26 تا 31

## اعمال‌شده در فایل‌ها
- tracking دقیق‌تر و sync با bar/kitchen/waiter
- admin به‌صورت details/accordion کشویی
- دکمه‌های تایید قیمت/عکس در ادمین
- Home تصویری‌تر با بنر و کارت‌های تصویری و کد تخفیف
- نمایش QR میز در waiter و tracking
- فونت بهتر و دکمه‌های لطیف‌تر با hover/active انیمیشن کم

## بعد از دانلود پروژه
1. کل پوشه `cafe-dastan` را جایگزین کن
2. backend را restart کن
3. frontend را restart کن
4. اگر لازم شد `.next` را پاک کن و دوباره اجرا کن
