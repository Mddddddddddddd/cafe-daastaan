# فرانت‌اند اولیه کافه داستان

این پوشه، پایه‌ی واقعی فرانت‌اند با ساختار Next.js App Router را نگه می‌دارد.

## قابلیت‌های این مرحله
- Home منو را از بک‌اند می‌گیرد
- Notifications از بک‌اند خوانده می‌شود
- Checkout سفارش را به بک‌اند POST می‌کند
- Tracking وضعیت سفارش را از بک‌اند GET می‌کند
- فرم‌های لاگین و OTP به بک‌اند وصل‌اند

## اجرا
```bash
cd cafe-dastan/frontend
cp .env.local.example .env.local
npm install
npm run dev
```

## env نمونه
```env
NEXT_PUBLIC_API_BASE_URL="http://localhost:4000"
```
