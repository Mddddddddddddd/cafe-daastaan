"use client";

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { menu } from '@/data/menu';

type CartItem = { id: string; name: string; option: string; price: number; qty: number; product?: any; station?: string; };

type CartContextType = {
  items: CartItem[];
  addItem: (productId: string, option?: string, extraPrice?: number, productOverride?: any) => void;
  addMany: (product: any, qty?: number, option?: string) => void;
  decreaseItem: (productId: string, option?: string) => void;
  removeItem: (productId: string, option?: string) => void;
  clearCart: () => void;
  total: number;
};

const CartContext = createContext<CartContextType | null>(null);
const CART_STORAGE_KEY = 'cafe_dastan_cart_items';

function readInitialCart() {
  if (typeof window === 'undefined') return [] as CartItem[];
  try {
    const raw = localStorage.getItem(CART_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setItems(readInitialCart());
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      // ignore storage errors
    }
  }, [items, ready]);

  const addItem = (productId: string, option?: string, extraPrice = 0, productOverride?: any) => {
    const existing = items.find((item) => item.id === productId && (!option || item.option === option));
    const product = productOverride || existing?.product || existing || menu.find((item) => item.id === productId);
    if (!product) return;
    const finalOption = option || existing?.option || 'انتخاب پیش‌فرض';
    const basePrice = productOverride ? Number(productOverride.price || 0) : Number(existing?.price || product.price || 0);
    const finalPrice = productOverride ? basePrice + Number(extraPrice || 0) : basePrice;
    setItems((prev) => {
      const found = prev.find((i) => i.id === productId && i.option === finalOption);
      if (found) return prev.map((i) => (i.id === productId && i.option === finalOption ? { ...i, qty: i.qty + 1, product: productOverride || i.product || product, station: (productOverride as any)?.station || i.station || (product as any)?.station } : i));
      return [...prev, { id: product.id || productId, name: product.name || 'محصول', option: finalOption, price: finalPrice, qty: 1, product: productOverride || product, station: (productOverride as any)?.station || (product as any)?.station }];
    });
  };

  const addMany = (product: any, qty = 1, option = 'انتخاب پیش‌فرض') => {
    const count = Math.max(1, Number(qty || 1));
    setItems((prev) => {
      const id = product.id || product.productId;
      const found = prev.find((item) => item.id === id && item.option === option);
      if (found) {
        return prev.map((item) => item.id === id && item.option === option ? { ...item, qty: item.qty + count, product: item.product || product, station: (product as any)?.station || item.station } : item);
      }
      return [...prev, { id, name: product.name || 'محصول', option, price: Number(product.price || 0), qty: count, product, station: (product as any)?.station }];
    });
  };

  const decreaseItem = (productId: string, option?: string) => {
    setItems((prev) => prev.flatMap((item) => {
      if (item.id !== productId) return [item];
      if (option && item.option !== option) return [item];
      if (item.qty > 1) return [{ ...item, qty: item.qty - 1 }];
      return [];
    }));
  };

  const removeItem = (productId: string, option?: string) => {
    setItems((prev) => prev.filter((item) => item.id !== productId || (option && item.option !== option)));
  };

  const clearCart = () => setItems([]);
  const total = useMemo(() => items.reduce((sum, item) => sum + item.price * item.qty, 0), [items]);

  return <CartContext.Provider value={{ items, addItem, addMany, decreaseItem, removeItem, clearCart, total }}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
