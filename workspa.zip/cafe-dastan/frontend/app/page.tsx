import TopBar from '@/components/TopBar';
import BottomCartBar from '@/components/BottomCartBar';
import RemoteMenu from '@/components/RemoteMenu';
import Link from 'next/link';
import RemoteLoyaltyClub from '@/components/RemoteLoyaltyClub';

const quickItems = [
  { href: '/loyalty', icon: '🏆', title: 'باشگاه', text: 'امتیاز و جایزه' },
  { href: '/story#upload-story', icon: '📸', title: 'استوری', text: 'آپلود عکس' },
  { href: '/story', icon: '📖', title: 'داستان من', text: 'فصل‌های تو' },
  { href: '/cart#split-bill', icon: '🧮', title: 'دنگی‌دونگی', text: 'تقسیم هزینه سفارش' },
  { href: '/tracking/1042', icon: '🧾', title: 'رهگیری', text: 'وضعیت سفارش' },
  { href: '/profile', icon: '👤', title: 'پروفایل', text: 'نام کاربری من' },
  { href: '/#mood-action', icon: '✨', title: 'چی دوس داری؟', text: 'پیشنهاد هوشمند' },
  { href: '/#usual-order-action', icon: '☕', title: 'همون همیشگی', text: 'سفارش پرتکرار' },
  { href: '/feedback/1042', icon: '⭐', title: 'نظرسنجی', text: 'ثبت تجربه' },
];

export default function HomePage() {
  return (
    <main className="page">
      <TopBar />
      <RemoteMenu />
      <section className="section"><RemoteLoyaltyClub compact /></section>
      <section className="section">
        <div className="titleRow">
          <div className="title">دسترسی‌های داستانی</div>
          <div className="link">۳ ردیف × ۳ ستون</div>
        </div>
        <div className="quickGrid">
          {quickItems.map((item) => (
            <Link key={item.title} href={item.href} className="quickBox">
              <span className="quickIcon">{item.icon}</span>
              <strong>{item.title}</strong>
              <small>{item.text}</small>
            </Link>
          ))}
        </div>
      </section>
      <BottomCartBar />
    </main>
  );
}
