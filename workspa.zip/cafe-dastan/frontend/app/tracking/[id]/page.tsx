"use client";

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { apiGet, isCustomerAuthenticated, requireCustomerAuth } from '@/lib/api';

type Step = { key: string; label: string };

const statusChip: Record<string, string> = {
  PENDING: 'ثبت شده', ACCEPTED: 'تایید شده', BAR_PREPARING: 'در بار', KITCHEN_PREPARING: 'در آشپزخانه',
  READY_TO_SERVE: 'آماده سرو', ON_THE_WAY: 'در مسیر', DELIVERED: 'تحویل شده', CANCELLED: 'لغو شده',
};

// گام‌های رهگیری — پویا بر اساس ایستگاه‌های سفارش (کوتاه و بدون مراحل اضافی)
function buildTrackingSteps(order: any): Step[] {
  const stations = new Set(
    (order?.items || [])
      .map((i: any) => String(i.station || '').toLowerCase())
      .filter(Boolean),
  );
  const hasBar = stations.size ? stations.has('bar') : true;
  const hasKitchen = stations.size ? stations.has('kitchen') : true;
  const steps: Step[] = [{ key: 'pending', label: 'ثبت شد' }];
  if (hasBar) steps.push({ key: 'bar', label: 'آماده‌سازی بار' });
  if (hasKitchen) steps.push({ key: 'kitchen', label: 'آماده‌سازی آشپزخانه' });
  steps.push({ key: 'ready', label: 'آماده سرو' });
  steps.push({ key: 'delivered', label: 'تحویل شد' });
  return steps;
}

function statusToStepIndex(status: string, steps: Step[]): number {
  const idx = (key: string) => steps.findIndex((s) => s.key === key);
  const s = String(status || '');
  switch (s) {
    case 'PENDING':
    case 'ACCEPTED':
      return idx('pending');
    case 'BAR_PREPARING':
    case 'BAR_READY':
      return idx('bar') !== -1 ? idx('bar') : idx('pending');
    case 'KITCHEN_PREPARING':
    case 'KITCHEN_READY':
      return idx('kitchen') !== -1 ? idx('kitchen') : idx('pending');
    case 'READY_TO_SERVE':
    case 'ON_THE_WAY':
      return idx('ready');
    case 'DELIVERED':
      return idx('delivered');
    case 'CANCELLED':
      return 0;
    default:
      return 0;
  }
}

function statusHint(status: string) {
  const s = String(status || '');
  if (s === 'PENDING' || s === 'ACCEPTED') return 'سفارش ثبت شده و منتظر شروع آماده‌سازی است.';
  if (s === 'BAR_PREPARING') return 'نوشیدنی‌ها در بار در حال آماده‌سازی هستند.';
  if (s === 'KITCHEN_PREPARING') return 'آشپزخانه در حال آماده‌سازی سفارش است.';
  if (s === 'BAR_READY' || s === 'KITCHEN_READY') return 'بخشی از سفارش آماده است؛ در حال تکمیل است.';
  if (s === 'READY_TO_SERVE' || s === 'ON_THE_WAY') return 'سفارش آماده است؛ گارسون به‌زودی آن را تحویل می‌دهد.';
  if (s === 'DELIVERED') return 'سفارش تحویل شده؛ نوش جان.';
  if (s === 'CANCELLED') return 'سفارش لغو شده است.';
  return 'وضعیت سفارش در حال به‌روزرسانی است.';
}

function itemTitle(item: any) {
  return item.name || item.productName || item.product?.name || item.productId || 'آیتم سفارش';
}

function formatDateTime(value?: string) {
  if (!value) return '-';
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return '-';
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
  }).format(d);
}

function statusLabel(status?: string) {
  return statusChip[String(status || '')] || String(status || 'نامشخص');
}

function OrderHistoryCard({ order }: { order: any }) {
  const status = String(order.status || '');
  const isActive = !['DELIVERED', 'CANCELLED'].includes(status);
  const total = Number(order.finalTotal ?? order.subtotal ?? 0);
  return (
    <div style={{
      padding: '12px', borderRadius: '16px', background: '#f8fcfc', border: '1px solid var(--line)',
      display: 'grid', gap: '6px',
    }}>
      <div className="row" style={{ alignItems: 'center' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <strong style={{ fontSize: '13.5px' }}>سفارش #{order.id}</strong>
          <div style={{ fontSize: '11px', opacity: 0.75, marginTop: '2px' }}>{formatDateTime(order.createdAt)}</div>
        </div>
        <span className={`chip ${status === 'DELIVERED' ? '' : isActive ? 'active' : ''}`}>{statusLabel(status)}</span>
      </div>
      <div style={{ fontSize: '12px', lineHeight: 2, color: 'var(--primary-dark)' }}>
        {(order.items || []).map((it: any, i: number) => (
          <span key={`${it.productId || i}`}>{it.productNameSnapshot || it.name} ×{Number(it.qty || 1).toLocaleString('fa-IR')}{i < (order.items || []).length - 1 ? ' · ' : ''}</span>
        ))}
        {(order.items || []).length === 0 ? <span className="sub">جزئیات آیتم‌ها ثبت نشده</span> : null}
      </div>
      <div className="row" style={{ alignItems: 'center', justifyContent: 'space-between' }}>
        <strong style={{ fontSize: '12.5px' }}>{total.toLocaleString('fa-IR')} تومان</strong>
        {isActive ? (
          <Link href={`/tracking/${order.id}`} className="link" style={{ fontSize: '12px' }}>رهگیری زنده ←</Link>
        ) : status === 'DELIVERED' ? (
          <Link href={`/feedback/${order.id}`} className="link" style={{ fontSize: '12px' }}>ثبت نظرسنجی ←</Link>
        ) : null}
      </div>
    </div>
  );
}

export default function TrackingPage({ params }: { params: { id: string } }) {
  const target = useMemo(() => `/tracking/${params.id}`, [params.id]);
  const [ready, setReady] = useState(false);
  const [denied, setDenied] = useState('');
  const [orderId, setOrderId] = useState(params.id);
  const [tableQr, setTableQr] = useState('');
  const [order, setOrder] = useState<any>(null);
  const [currentFound, setCurrentFound] = useState<boolean | null>(null);
  const [activeOrders, setActiveOrders] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [surveyPrompt, setSurveyPrompt] = useState(false);

  // گام‌های پویا بر اساس ایستگاه‌های سفارش فعلی
  const steps = useMemo(() => buildTrackingSteps(order), [order]);
  const currentStatus = String(order?.status || '');
  const activeIndex = statusToStepIndex(currentStatus, steps);
  const progress = steps.length > 1 ? Math.round((activeIndex / (steps.length - 1)) * 100) : 0;
  const statusText = currentStatus === 'CANCELLED' ? 'لغو شده' : (steps[activeIndex]?.label || 'درحال بررسی');

  useEffect(() => {
    if (!isCustomerAuthenticated()) {
      requireCustomerAuth(target);
      return;
    }
    setReady(true);
  }, [target]);

  useEffect(() => {
    if (!ready) return;
    let cancelled = false;
    const load = () => {
      apiGet('/orders/active/mine').then((res) => {
        if (cancelled) return;
        const list = res?.data || [];
        setActiveOrders(list);
      }).catch(() => null);
      apiGet('/orders/mine').then((res) => {
        if (cancelled) return;
        setHistory(res?.data || []);
      }).catch(() => null);
      apiGet(`/orders/${params.id}`).then((res) => {
        if (cancelled) return;
        if (!res?.success) {
          setCurrentFound(false);
          return;
        }
        const data = res?.data || null;
        const oid = data?.id || params.id;
        const status = data?.status;
        setCurrentFound(true);
        setOrderId(oid);
        setOrder(data);
        setTableQr(data?.tableQr || '');
        // پاپ‌آپ نظرسنجی: بعد از ثبت سفارش (اولین بازدید) و بعد از تحویل — یک‌بار در هر نشست
        if (status && status !== 'CANCELLED' && typeof window !== 'undefined') {
          const prompted = sessionStorage.getItem(`survey_prompted_${oid}`) === '1';
          const seen = sessionStorage.getItem(`tracking_seen_${oid}`) === '1';
          if (!seen) sessionStorage.setItem(`tracking_seen_${oid}`, '1');
          const delivered = status === 'DELIVERED';
          if (!prompted && (delivered || !seen)) {
            apiGet(`/feedback/order/${oid}`).then((sres) => {
              if (sres?.success && sres.data?.alreadySubmitted) {
                sessionStorage.setItem(`survey_prompted_${oid}`, '1');
                return;
              }
              sessionStorage.setItem(`survey_prompted_${oid}`, '1');
              setSurveyPrompt(true);
            }).catch(() => {});
          }
        }
      }).catch(() => { if (!cancelled) setCurrentFound(false); });
    };
    load();
    const interval = setInterval(load, 2500);
    return () => { cancelled = true; clearInterval(interval); };
  }, [params.id, ready]);

  if (!ready) return null;
  if (denied) {
    return <main className="page"><section className="contentPad"><div className="card banner"><strong>دسترسی مجاز نیست</strong><p>{denied}</p><Link href="/" className="btn secondary">بازگشت</Link></div></section></main>;
  }

  const isDelivered = currentStatus === 'DELIVERED' || currentStatus === 'CANCELLED';
  const showLiveTracking = currentFound === true && !isDelivered;
  const showHistoryView = currentFound === false;

  // ---- نمای تاریخچه (سفارش فعال/معتبری پیدا نشد) ----
  if (showHistoryView) {
    return (
      <main className="page">
        <div className="row contentPad pageTitleRow">
          <Link href="/" className="link">بازگشت</Link>
          <div className="pageTitleCenter">
            <strong>سفارش‌های من</strong>
            <span className="pageTitleHint">وضعیت سفارش‌هایت یک‌جا</span>
          </div>
        </div>
        <section className="contentPad" style={{ display: 'grid', gap: '12px' }}>
          {activeOrders.length ? (
            <div style={{
              borderRadius: '20px', padding: '16px', color: '#fff',
              background: 'linear-gradient(135deg, var(--primary-deep), var(--primary))',
            }}>
              <strong style={{ fontSize: '14.5px' }}>🔥 {activeOrders.length.toLocaleString('fa-IR')} سفارش فعال داری</strong>
              <p style={{ opacity: 0.9, fontSize: '12px', marginTop: '4px' }}>رفیق! سفارش‌هایی که هنوز تحویل نشده‌اند را از همین‌جا پیگیری کن.</p>
              <div style={{ display: 'grid', gap: '8px', marginTop: '12px' }}>
                {activeOrders.map((item: any) => (
                  <Link key={item.id} href={`/tracking/${item.id}`} style={{
                    display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px',
                    borderRadius: '14px', background: 'rgba(255,255,255,0.16)', border: '1px solid rgba(255,255,255,0.3)',
                  }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <strong style={{ fontSize: '13px' }}>سفارش #{item.id}</strong>
                      <div style={{ fontSize: '11px', opacity: 0.85, marginTop: '2px' }}>{formatDateTime(item.createdAt)}</div>
                    </div>
                    <span style={{ fontSize: '11.5px', fontWeight: 700, background: '#ffd166', color: '#5b4300', padding: '3px 10px', borderRadius: '999px' }}>{statusLabel(item.status)} ←</span>
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div style={{
              borderRadius: '20px', padding: '22px 16px', textAlign: 'center',
              background: 'linear-gradient(135deg, #fff, var(--primary-tint))', border: '1px solid var(--line)',
            }}>
              <div style={{ fontSize: '44px', lineHeight: 1 }}>☕</div>
              <strong style={{ fontSize: '15.5px', display: 'block', marginTop: '10px' }}>فعلاً سفارش فعالی نداری</strong>
              <p style={{ fontSize: '12px', marginTop: '8px', lineHeight: 2, color: 'var(--primary-dark)' }}>
                هر وقت گرسنه یا تشنه شدی، از منو سفارش بده و اینجا لحظه‌به‌لحظه ردیابیش کن.
              </p>
              <Link href="/" className="btn" style={{ marginTop: '14px' }}>مشاهده منو و سفارش جدید</Link>
            </div>
          )}

          <div className="card banner">
            <div className="row" style={{ alignItems: 'center' }}>
              <div style={{ flex: 1 }}>
                <strong>سوابق سفارش‌ها</strong>
                <span className="sub" style={{ display: 'block', fontSize: '11px' }}>آخرین {history.length ? history.length.toLocaleString('fa-IR') : '۰'} سفارش تو</span>
              </div>
            </div>
            <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
              {history.length ? history.map((o: any) => <OrderHistoryCard key={o.id} order={o} />) : (
                <p className="sub" style={{ textAlign: 'center', padding: '18px 0' }}>هنوز سفارشی ثبت نشده است.</p>
              )}
            </div>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="page">
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>رهگیری سفارش</strong>
          <span className="pageTitleHint">لحظه‌به‌لحظه کنار سفارشت هستیم</span>
        </div>
      </div>
      <section className="contentPad">
        <div className="card banner brandPattern trackingCard">
          <div className="trackingHero">
            <div>
              <span>وضعیت فعلی سفارش</span>
              <strong>{statusText}</strong>
              <p>{statusHint(currentStatus)}</p>
            </div>
            <div className="trackingPercent">{progress.toLocaleString('fa-IR')}٪</div>
          </div>
          <div className="trackingProgress"><span style={{ width: `${progress}%` }} /></div>
          <div className="row trackingMeta">
            <span>سفارش #{orderId}</span>
            {tableQr ? <span>QR میز: {tableQr}</span> : null}
            <span className={order?.paymentStatus === 'PAID' ? 'trackingPaymentPaid' : 'trackingPaymentPending'}>{order?.paymentStatus === 'PAID' ? 'پرداخت شده' : 'پرداخت نشده'}</span>
          </div>
          <div className="row" style={{ marginTop: '12px', justifyContent: 'flex-start' }}>
            <Link href={`/feedback/${orderId}`} className="btn secondary">ثبت نظرسنجی سفارش</Link>
            <Link href="/loyalty" className="btn secondary">باشگاه مشتریان</Link>
          </div>
          <details className="orderDetails" open>
            <summary>
              <div>
                <strong>آیتم‌های همین سفارش</strong>
                <span>{(order?.items || []).length ? `${(order.items || []).length.toLocaleString('fa-IR')} ردیف سفارش` : 'نمایش جزئیات سفارش'}</span>
              </div>
              <b>باز/بستن</b>
            </summary>
            <div className="orderDetailsBody">
              {(order?.items || []).length ? (order.items || []).map((item: any, index: number) => (
                <div className="orderLine" key={`${item.productId || item.id}-${index}`}>
                  <div>
                    <strong>{itemTitle(item)}</strong>
                    {(item.customizations?.option || item.option) ? <span>{item.customizations?.option || item.option}</span> : null}
                  </div>
                  <b>×{Number(item.qty || 1).toLocaleString('fa-IR')}</b>
                </div>
              )) : <p>جزئیات آیتم‌ها برای این سفارش پیدا نشد.</p>}
            </div>
          </details>
          <div className="trackingSteps">
            {steps.map((step, index) => (
              <div key={step.key} className={`trackingStep ${index === activeIndex ? 'current' : ''} ${index < activeIndex ? 'done' : ''}`}>
                <div className="trackingDot">{index < activeIndex ? '✓' : index + 1}</div>
                <div>{step.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="card banner">
          <div className="row" style={{ alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <strong>سوابق سفارش‌های من</strong>
              <span className="sub" style={{ display: 'block', fontSize: '11px' }}>همه‌ی سفارش‌های تو، جدیدترین اول</span>
            </div>
          </div>
          <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
            {history.length ? history.map((o: any) => <OrderHistoryCard key={o.id} order={o} />) : <p>فعلاً سفارش تحویل‌نشده‌ای برای حساب شما ثبت نشده است.</p>}
          </div>
        </div>
      </section>

      {surveyPrompt ? (
        <div className="imageLightbox" role="dialog" aria-modal="true" aria-label="نظرسنجی سفارش" onClick={() => setSurveyPrompt(false)}>
          <div className="imageLightboxPanel" style={{ width: 'min(380px,100%)' }} onClick={(event) => event.stopPropagation()}>
            <div style={{ padding: '20px 16px', textAlign: 'center', background: 'linear-gradient(135deg,#fff,var(--primary-tint))' }}>
              <div style={{ fontSize: '38px', lineHeight: 1 }}>⭐</div>
              <strong style={{ fontSize: '16px' }}>نظرت درباره‌ی سفارش #{orderId} چقدر برای ما مهمه؟</strong>
              <p style={{ fontSize: '12.5px', marginTop: '10px', lineHeight: 2, color: 'var(--primary-dark)' }}>
                ثبت نظرسنجی <strong>کاملاً اختیاری</strong> است.
                <br />اگر نظرسنجی را کامل پر کنی، <strong>۳۵ امتیاز باشگاه مشتریان</strong> برایت ثبت می‌شود.
              </p>
              <div className="row" style={{ marginTop: '14px' }}>
                <Link href={`/feedback/${orderId}`} className="btn" style={{ flex: 1 }} onClick={() => setSurveyPrompt(false)}>نظرسنجی را پر کن</Link>
                <button type="button" className="btn secondary" style={{ flex: 1 }} onClick={() => setSurveyPrompt(false)}>بعداً</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
