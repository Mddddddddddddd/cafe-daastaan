"use client";

import BottomCartBar from '@/components/BottomCartBar';
import CafeStories from '@/components/CafeStories';
import Link from 'next/link';
import CustomerRouteGuard from '@/components/CustomerRouteGuard';
import TutorialLink from '@/components/TutorialLink';
import { apiGet, clearAuth } from '@/lib/api';
import { useEffect, useState } from 'react';

export default function StoryPage() {
  const [profile, setProfile] = useState<any>(null);
  useEffect(() => {
    apiGet('/me').then((res) => setProfile(res.data || null));
  }, []);

  return (
    <main className="page">
      <CustomerRouteGuard nextPath="/story" />
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>داستان من</strong>
          <TutorialLink />
        </div>
        <button className="link textOnlyAction dangerText" onClick={() => { clearAuth(); window.location.href = '/auth/login'; }}>خروج</button>
      </div>
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="card banner logoWatermark" style={{ background: 'linear-gradient(135deg,#fff,var(--primary-soft),var(--accent-soft))' }}>
          <strong>شخصیت تو: {profile?.personalityTitle || 'درحال تحلیل سلیقه تو'}</strong>
          <p>{profile?.username ? `نام کاربری: ${profile.username}` : 'هنوز نام کاربری انتخاب نشده است.'}</p>
          <Link href="/profile" className="profileEditLink">ویرایش پروفایل و نام کاربری</Link>
        </div>
      </section>
      <CafeStories upload />
      <section className="contentPad">
        <div className="metricGrid">
          <div className="card metric"><div className="metricNum">{profile?.favoriteDrink || '-'}</div><div className="sub">نوشیدنی محبوب</div></div>
          <div className="card metric"><div className="metricNum">{profile?.favoriteFood || '-'}</div><div className="sub">غذای محبوب</div></div>
          <div className="card metric"><div className="metricNum">{profile?.preferredHour || '-'}</div><div className="sub">ساعت محبوب</div></div>
          <div className="card metric"><div className="metricNum">{Number(profile?.storyCount || 0).toLocaleString('fa-IR')}</div><div className="sub">تعداد فصل‌ها</div></div>
        </div>
      </section>
      <section className="contentPad"><div className="card banner"><strong>آخرین سفارش</strong><p>{profile?.lastOrderTitle || 'هنوز سفارشی ثبت نشده'}</p></div></section>
      <section className="contentPad"><div className="card banner"><strong>ویژگی‌های داستانی تو</strong><p>{(profile?.storyTraits || []).join(' · ') || 'هنوز داده کافی برای تحلیل وجود ندارد.'}</p></div></section>
      <section className="contentPad"><div className="card banner"><strong>پیشنهاد فصل بعدی</strong><p>{profile?.nextSuggestion || 'بعد از چند سفارش دیگر، پیشنهاد دقیق‌تر می‌شود.'}</p></div></section>
      <BottomCartBar />
    </main>
  );
}
