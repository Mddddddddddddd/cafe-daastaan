"use client";

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiPost, consumePostLoginRedirect, isCustomerAuthenticated, saveAuth } from '@/lib/api';

const RESEND_SECONDS = 120;

function normalizePhone(value: string) {
  return value.replace(/[^0-9]/g, '').slice(0, 11);
}

function formatSeconds(value: number) {
  const safe = Math.max(0, value);
  const minutes = Math.floor(safe / 60).toString().padStart(2, '0');
  const seconds = (safe % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
}

export default function UserLoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<'phone' | 'code'>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [attempts, setAttempts] = useState(0);

  const canRequestOtp = useMemo(() => normalizePhone(phone).length >= 10, [phone]);
  const canVerifyOtp = useMemo(() => normalizePhone(phone).length >= 10 && code.trim().length >= 4, [phone, code]);
  const canResend = countdown <= 0 && attempts < 5 && !isSending;

  useEffect(() => {
    if (isCustomerAuthenticated()) {
      router.replace(consumePostLoginRedirect());
    }
  }, [router]);

  useEffect(() => {
    if (countdown <= 0) return;
    const timer = setTimeout(() => setCountdown((prev) => prev - 1), 1000);
    return () => clearTimeout(timer);
  }, [countdown]);

  const requestOtp = async (isResend = false) => {
    if ((!canRequestOtp && !isResend) || isSending) return;
    if (isResend && !canResend) return;

    setIsSending(true);
    setMessage(isResend ? 'درحال ارسال مجدد کد...' : 'درحال ارسال کد ورود...');
    const data = await apiPost('/auth/request-otp', { phone: normalizePhone(phone) });
    setIsSending(false);

    if (data?.success) {
      setAttempts((prev) => prev + 1);
      setCountdown(RESEND_SECONDS);
      setStep('code');
      setMessage(data.message || 'کد تایید ارسال شد.');
      return;
    }

    setMessage(data?.message || 'خطا در ارسال کد ورود');
  };

  const verifyOtp = async () => {
    if (!canVerifyOtp || isVerifying) return;
    setIsVerifying(true);
    setMessage('درحال بررسی کد...');
    const data = await apiPost('/auth/verify-otp', { phone: normalizePhone(phone), code });
    setIsVerifying(false);
    setMessage(data.success ? 'ورود موفق بود' : (data.message || 'خطا در ورود'));
    if (data.success) {
      saveAuth(data);
      setTimeout(() => router.push(consumePostLoginRedirect()), 500);
    }
  };

  return (
    <main className="page">
      <div className="contentPad" style={{ paddingTop: '18px' }}>
        <Link href="/" className="link">بازگشت</Link>

        <section className="card banner logoWatermark" style={{ marginTop: '14px', padding: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <img src="/images/cafedastan_logo_transparent.png" alt="لوگو" className="brandLogo" />
            <div>
              <h1 style={{ margin: 0, fontSize: '20px', color: 'var(--primary-deep)' }}>ورود مشتری</h1>
            </div>
          </div>

          {step === 'phone' ? (
            <>
              <input
                className="input loginInput"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                inputMode="numeric"
                placeholder="شماره موبایل"
                value={phone}
                onChange={(e) => setPhone(normalizePhone(e.target.value))}
              />
              <button className="btn loginPrimaryBtn" style={{ marginTop: '12px' }} onClick={() => requestOtp(false)} disabled={!canRequestOtp || isSending}>
                {isSending ? 'درحال ارسال...' : 'ارسال پیامک'}
              </button>
            </>
          ) : (
            <>
              <div className="loginStepHeader">
                <strong>کد تایید</strong>
                <button className="btn secondary" onClick={() => setStep('phone')}>ویرایش شماره</button>
              </div>
              <div className="sub" style={{ marginTop: '6px' }}>{normalizePhone(phone)}</div>
              <input
                className="input loginCodeInput"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                inputMode="numeric"
                placeholder="کد پیامک شده"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
              />
              <button className="btn loginPrimaryBtn" style={{ marginTop: '12px' }} onClick={verifyOtp} disabled={!canVerifyOtp || isVerifying}>
                {isVerifying ? 'درحال بررسی...' : 'ورود'}
              </button>

              <div className="loginOtpTools">
                <span className="loginCountdownText">ارسال مجدد تا {formatSeconds(countdown)}</span>
                <button className="btn secondary" onClick={() => requestOtp(true)} disabled={!canResend}>
                  ارسال مجدد
                </button>
              </div>

              {attempts >= 5 ? <p className="loginStatusText" style={{ color: 'var(--danger)!important' as any }}>تعداد درخواست کد موقتاً به سقف مجاز رسیده است.</p> : null}
            </>
          )}

          {message ? <p className="loginStatusText">{message}</p> : null}
        </section>
      </div>
    </main>
  );
}
