import Link from 'next/link';
import RemoteLoyaltyClub from '@/components/RemoteLoyaltyClub';
import CustomerRouteGuard from '@/components/CustomerRouteGuard';
import TutorialLink from '@/components/TutorialLink';

export default function LoyaltyPage() {
  return (
    <main className="page">
      <CustomerRouteGuard nextPath="/loyalty" />
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>باشگاه مشتریان</strong>
          <TutorialLink />
        </div>
      </div>
      <section className="contentPad"><RemoteLoyaltyClub /></section>
    </main>
  );
}
