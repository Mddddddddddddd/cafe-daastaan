export async function POST() {
  return Response.json({
    success: true,
    accessToken: 'mock-staff-token',
    user: { id: 'e1', role: 'admin' }
  });
}