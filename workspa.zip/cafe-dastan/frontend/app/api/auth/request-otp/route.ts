export async function POST() {
  return Response.json({ success: true, message: 'OTP sent successfully' });
}