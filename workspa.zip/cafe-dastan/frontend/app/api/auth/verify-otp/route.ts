export async function POST() {
  return Response.json({
    success: true,
    accessToken: 'mock-jwt-token',
    refreshToken: 'mock-refresh-token',
    user: { id: 'u1', role: 'customer', name: 'کاربر کافه داستان' }
  });
}