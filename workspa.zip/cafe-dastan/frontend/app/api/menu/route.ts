import { menu } from '@/data/menu';

export async function GET() {
  return Response.json({ success: true, data: menu });
}