import type { Metadata } from 'next';

// PWA جدا برای پنل گارسون
export const metadata: Metadata = {
  manifest: '/manifest-waiter.json',
};

export default function WaiterLayout({ children }: { children: React.ReactNode }) {
  return children;
}
