import Link from 'next/link';
import ProtectedPage from '@/components/ProtectedPage';
import RemoteAccounting from '@/components/RemoteAccounting';

export default function WaiterAccountingPage() {
  return (
    <ProtectedPage role="waiter" title="حسابداری گارسون">
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="row" style={{ justifyContent: 'flex-start' }}>
          <Link href="/waiter" className="btn secondary">بازگشت به پنل گارسون</Link>
        </div>
      </section>
      <section className="contentPad">
        <RemoteAccounting role="waiter" embedded />
      </section>
    </ProtectedPage>
  );
}
