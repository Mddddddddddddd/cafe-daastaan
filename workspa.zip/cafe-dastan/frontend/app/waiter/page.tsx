import Link from 'next/link';
import ProtectedPage from '@/components/ProtectedPage';
import RemoteWaiterTables from '@/components/RemoteWaiterTables';
import StaffPushBell from '@/components/StaffPushBell';
import InstallPwaButton from '@/components/InstallPwaButton';

export default function WaiterPage() {
  return (
    <ProtectedPage role="waiter" title="پنل گارسون">
      <div className="row contentPad" style={{ justifyContent: 'flex-end', gap: '6px', flexWrap: 'wrap' }}>
        <InstallPwaButton role="waiter" label="نصب گارسون" />
        <StaffPushBell role="waiter" />
      </div>
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="card banner brandPattern">
          <div className="row">
            <strong>حسابداری سفارش‌ها</strong>
            <Link href="/waiter/accounting" className="btn">مشاهده</Link>
          </div>
          <p>در این بخش فقط نام سفارش، تعداد و مبلغ برای گارسون نمایش داده می‌شود.</p>
        </div>
      </section>
      <RemoteWaiterTables />
    </ProtectedPage>
  );
}
