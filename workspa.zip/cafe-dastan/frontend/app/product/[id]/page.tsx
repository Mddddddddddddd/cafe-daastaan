import Link from 'next/link';
import RemoteProductDetail from '@/components/RemoteProductDetail';
import BottomCartBar from '@/components/BottomCartBar';

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  return (
    <main className="page">
      <div className="row contentPad">
        <Link href="/" className="link">بازگشت</Link>
        <strong>جزئیات محصول</strong>
      </div>
      <section className="contentPad">
        <RemoteProductDetail id={params.id} />
      </section>
      <BottomCartBar />
    </main>
  );
}