import ProtectedPage from '@/components/ProtectedPage';
import RemoteKitchenOrders from '@/components/RemoteKitchenOrders';
import StaffPushBell from '@/components/StaffPushBell';
import InstallPwaButton from '@/components/InstallPwaButton';

export default function KitchenPage() {
  return (
    <ProtectedPage role="kitchen" title="پنل آشپزخانه">
      <div className="row contentPad" style={{ justifyContent: 'flex-end', gap: '6px', flexWrap: 'wrap' }}>
        <InstallPwaButton role="kitchen" label="نصب آشپزخانه" />
        <StaffPushBell role="kitchen" />
      </div>
      <RemoteKitchenOrders />
    </ProtectedPage>
  );
}
