import Link from 'next/link';
import ProtectedPage from '@/components/ProtectedPage';
import RemoteStationProducts from '@/components/RemoteStationProducts';

export default function KitchenProductsPage() {
  return (
    <ProtectedPage role="kitchen" title="محصولات آشپزخانه">
      <div className="row contentPad">
        <Link href="/kitchen" className="link">بازگشت به سفارش‌ها</Link>
        <strong>ناموجود / پنهان کردن آیتم</strong>
      </div>
      <RemoteStationProducts role="kitchen" />
    </ProtectedPage>
  );
}
