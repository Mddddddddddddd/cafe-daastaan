import type { Metadata } from 'next';

// PWA جدا برای پنل آشپزخانه
export const metadata: Metadata = {
  manifest: '/manifest-kitchen.json',
};

export default function KitchenLayout({ children }: { children: React.ReactNode }) {
  return children;
}
