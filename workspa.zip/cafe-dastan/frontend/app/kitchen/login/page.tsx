"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { apiPost, isStaffAuthenticated, saveStaffAuth } from '@/lib/api';

export default function KitchenLoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (isStaffAuthenticated('kitchen')) window.location.replace('/kitchen');
  }, []);

  const login = async () => {
    const data = await apiPost('/auth/staff-login', { username, password });
    setMessage(data.success ? 'ورود موفق بود' : (data.message || 'ورود ناموفق'));
    if (data.success) { saveStaffAuth(data); window.location.href = '/kitchen'; }
  };

  return (
    <main className="page">
      <div className="contentPad">
        <Link href="/" className="link">بازگشت</Link>
        <div className="card banner" style={{ marginTop: '12px' }}>
          <h1 style={{ marginTop: 0, fontSize: '22px' }}>ورود آشپزخانه</h1>
          <input className="input" placeholder="نام کاربری" value={username} onChange={(e) => setUsername(e.target.value)} />
          <input className="input" type="password" placeholder="رمز عبور" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="btn" style={{ marginTop: '12px' }} onClick={login}>ورود به پنل آشپزخانه</button>
          {message ? <p style={{ color: 'var(--primary)', fontSize: '13px' }}>{message}</p> : null}
        </div>
      </div>
    </main>
  );
}