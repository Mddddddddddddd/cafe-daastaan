import type { Metadata, Viewport } from 'next';
import { CartProvider } from '@/context/CartContext';
import ClientExperienceBoot from '@/components/ClientExperienceBoot';
import WatermarkPreference from '@/components/WatermarkPreference';
import SpecialAdminNotificationPopup from '@/components/SpecialAdminNotificationPopup';

export const metadata: Metadata = {
  title: 'کافه داستان | Cafe Dastan',
  description: 'منوی دیجیتال و تجربه داستانی کافه داستان',
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.png',
    apple: '/images/apple-touch-icon.png',
  },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, maximumScale: 1, userScalable: false };

const globalCss = `
  @font-face { font-family: "IRANSansX"; src: url("/fonts/IRANSans-Regular.woff2") format("woff2"); font-weight: 400; font-style: normal; font-display: swap; }
  @font-face { font-family: "IRANSansX"; src: url("/fonts/IRANSans-Medium.woff2") format("woff2"); font-weight: 500; font-style: normal; font-display: swap; }
  :root{--primary:#79B4B7;--primary-dark:#1B6B70;--primary-deep:#12383C;--primary-ink:#0F2528;--primary-soft:#E7F4F5;--primary-tint:#F4FBFB;--accent:#FFB86B;--accent-dark:#B5651D;--accent-soft:#FFF1DE;--danger:#E45858;--success:#2E9D6F;--bg:#EEF5F6;--surface:#FFFFFF;--surface-warm:#FFFDFC;--text:#162B2E;--muted:#65777B;--line:#D7E4E6;--chip:#F3FAFA;--shadow:0 12px 28px rgba(18,56,60,.10);--shadow-strong:0 18px 42px rgba(18,56,60,.18);--radius:16px;--page-w:min(100vw,480px);--pad:clamp(10px,3.4vw,16px)}
  *{box-sizing:border-box}
  html,body{padding:0;margin:0;background:radial-gradient(circle at 10% -5%,rgba(121,180,183,.38),transparent 30%),radial-gradient(circle at 90% 8%,rgba(255,184,107,.24),transparent 28%),linear-gradient(180deg,#EEF5F6 0%,#F8FBFB 45%,#EEF5F6 100%);color:var(--text);font-family:"IRANSansX",Tahoma,Arial,system-ui,sans-serif;overflow-x:hidden}
  button,input,textarea,select{font-family:"IRANSansX",Tahoma,Arial,system-ui,sans-serif;touch-action:manipulation}
  input,textarea,select{font-size:16px!important;max-height:9999px}
  h1,h2,h3,h4,h5,h6,strong,.title,.brand,.metricNum,.adminSummary{font-weight:500}
  a{text-decoration:none;color:inherit}
  .page{width:100%;max-width:480px;margin:0 auto;min-height:100svh;padding-bottom:calc(88px + env(safe-area-inset-bottom));background:linear-gradient(180deg,#F7FBFB 0%,#EEF5F6 100%);overflow-x:hidden}
  .topbar{position:sticky;top:0;z-index:20;background:rgba(247,251,251,.94);backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
  .topbar-inner{padding:12px var(--pad)}
  .row{display:flex;justify-content:space-between;align-items:center;gap:8px}
  .brandLockup{display:flex;align-items:center;gap:9px;min-width:0}
  .brandLogo{width:58px;height:38px;border-radius:8px;object-fit:contain;border:1px solid rgba(121,180,183,.42);box-shadow:0 8px 18px rgba(18,56,60,.13);background:rgba(255,255,255,.88)}
  .brand{font-size:clamp(17px,4.5vw,19px);color:var(--primary-deep)}
  .sub{font-size:11px;color:var(--muted);margin-top:3px}
  .iconBtn{width:34px;height:34px;border:1px solid rgba(121,180,183,.28);border-radius:10px;background:linear-gradient(135deg,#fff,var(--primary-soft));box-shadow:0 8px 18px rgba(18,56,60,.10)}
  .topActions{display:flex;align-items:center;gap:7px;flex-shrink:0}
  .profilePillLink{height:34px;max-width:112px;padding:0 8px;border:1px solid rgba(121,180,183,.28);border-radius:999px;background:linear-gradient(135deg,#fff,var(--primary-soft));box-shadow:0 8px 18px rgba(18,56,60,.08);display:flex;align-items:center;gap:5px;color:var(--primary-deep)}
  .profilePillLink span{font-size:14px;line-height:1}
  .profilePillLink small{font-size:9.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:74px}
  .notifBadge{position:absolute;top:-5px;left:-5px;min-width:17px;height:17px;border-radius:999px;background:var(--danger);color:#fff;font-size:9px;display:flex;align-items:center;justify-content:center;border:2px solid #fff}
  .bootOverlay{position:fixed;inset:0;z-index:120;background:rgba(238,245,246,.94);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:20px}
  .bootCard,.tutorialSheet,.floatingExperienceCard,.installFullScreenCard,.tutorialPopupCard{width:min(100%,440px);background:linear-gradient(180deg,#fff,#fbfefe);border:1px solid var(--line);border-radius:22px;box-shadow:var(--shadow-strong)}
  .bootCard{padding:18px;text-align:center;display:grid;gap:10px}
  .bootLogoWrap{width:92px;height:92px;border-radius:28px;margin:0 auto;background:linear-gradient(135deg,#fff,var(--primary-soft));display:flex;align-items:center;justify-content:center;box-shadow:0 14px 30px rgba(18,56,60,.12)}
  .bootLogo{width:66px;height:66px;object-fit:contain;animation:bootFloat 1.1s ease-in-out infinite alternate}
  .bootDots{display:flex;justify-content:center;gap:7px}
  .bootDots span{width:9px;height:9px;border-radius:999px;background:var(--primary-dark);animation:bootPulse .9s ease-in-out infinite}
  .bootDots span:nth-child(2){animation-delay:.16s}.bootDots span:nth-child(3){animation-delay:.32s}
  .tutorialOverlay,.installOverlay{padding:14px}
  .installFullScreenCard{padding:18px;display:grid;gap:10px;text-align:right}
  .installLikeSampleCard{background:#fff;border:none;box-shadow:none;width:min(100%,430px);min-height:100svh;align-content:start;padding:14px 18px 24px;margin:0 auto}
  .installOverlayClean{background:#fff;backdrop-filter:none}
  .installLogoHolder{display:flex;justify-content:center;align-items:center;margin-top:8px;margin-bottom:10px;min-height:54px}
  .installMainLogo{width:min(30vw,110px);height:auto;max-height:52px;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(18,56,60,.08))}
  .installHeroText{text-align:center;font-size:clamp(13px,4vw,19px);font-weight:500;line-height:2;color:#20242a;max-width:320px;margin:0 auto 30px}
  .installStepsWrap{display:grid;gap:18px;max-width:320px;margin:0 auto}
  .installStepLine{display:flex;align-items:center;justify-content:space-between;gap:12px}
  .installStepText{display:grid;gap:6px;text-align:right}
  .installStepText strong{font-size:clamp(14px,4.8vw,22px);font-weight:500;color:#222}
  .installStepText span{font-size:clamp(11px,3.2vw,14px);color:#94a3b8;line-height:1.8}
  .installStepCircle{width:56px;height:56px;border-radius:999px;background:#eff6ff;color:#3b82f6;display:flex;align-items:center;justify-content:center;font-size:26px;flex:0 0 56px}
  .installMiniLogo{width:34px;height:34px;object-fit:contain}
  .installSkipRow{display:flex;justify-content:flex-start;max-width:320px;margin:4px auto 0}
  .installSkipBtn{border:none;background:transparent;color:#94a3b8;font-size:11px;cursor:pointer;padding:4px 0}
  .installBottomActions{display:grid;gap:8px;max-width:320px;margin:16px auto 0;text-align:center}
  .installBottomHint{font-size:11px;color:#94a3b8;line-height:1.8}
  .tutorialPopupCard{padding:18px;display:grid;gap:10px;text-align:center}
  .tutorialStepBadge{display:inline-flex;justify-content:center;align-items:center;margin:0 auto;padding:6px 12px;border-radius:999px;background:var(--primary-soft);color:var(--primary-deep);font-size:11px}
  .tutorialIconLarge{font-size:38px;line-height:1;margin-top:2px}
  .tutorialProgressBar{height:8px;border-radius:999px;background:#e5eff0;overflow:hidden;margin-top:4px}
  .tutorialProgressBar span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,var(--primary-dark),var(--accent));transition:width .25s ease}
  .floatingExperienceCard{position:fixed;right:50%;transform:translateX(50%);bottom:calc(78px + env(safe-area-inset-bottom));z-index:80;padding:14px;width:min(calc(100% - 18px),430px)}
  .installGuideList{margin:10px 0 0;padding:0 18px 0 0;display:grid;gap:7px;font-size:12px;line-height:1.9;color:var(--muted)}
  .installGuideLarge{font-size:13px;line-height:2}
@keyframes bootFloat{from{transform:translateY(-2px) scale(.98)}to{transform:translateY(3px) scale(1.02)}}
  @keyframes bootPulse{0%,100%{transform:translateY(0);opacity:.35}50%{transform:translateY(-4px);opacity:1}}
  .section{padding:12px var(--pad)}
  .titleRow{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
  .title{font-size:14px}
  .link{font-size:11px;color:var(--primary-dark);font-weight:500}
  .card{background:linear-gradient(180deg,var(--surface),var(--surface-warm));border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}
  .logoWatermark{position:relative;overflow:hidden}
  .logoWatermark:after{content:'';position:absolute;left:-22px;bottom:-28px;width:120px;height:120px;background:url('/images/cafedastan_logo_transparent.png') center/contain no-repeat;opacity:.07;pointer-events:none;z-index:0}
  .logoWatermark>*{position:relative;z-index:1}
  .brandPattern{position:relative;overflow:hidden}
  .brandPattern:after{content:'';position:absolute;left:-18px;bottom:-24px;width:96px;height:96px;background:url('/images/cafedastan_logo_transparent.png') center/contain no-repeat;opacity:.055;pointer-events:none;z-index:0}
  .brandPattern>*{position:relative;z-index:1}
  .banner{padding:12px}
  .banner p{margin:6px 0 0;font-size:11px;color:var(--muted);line-height:1.8}
  .chips{display:flex;gap:8px;overflow-x:auto!important;overflow-y:hidden;padding-bottom:2px;scrollbar-width:none;-ms-overflow-style:none;overscroll-behavior-inline:contain;max-width:100%;min-width:0;white-space:nowrap;flex-wrap:nowrap;touch-action:pan-x}
  .chips::-webkit-scrollbar{display:none;width:0;height:0}
  .categoryRail{background:linear-gradient(135deg,#fff,var(--primary-tint));border:1px solid #CFE0E3;border-radius:14px;padding:5px;box-shadow:0 8px 20px rgba(18,56,60,.075);max-width:100%;overflow:hidden;touch-action:pan-x}
  .categoryRail .chips{gap:6px;padding:0;overflow-x:scroll!important;-webkit-overflow-scrolling:touch}
  .categoryRail .chip{font-size:11px;padding:6px 9px}
  .menuCategoryRail{margin-bottom:10px}
  .chip{white-space:nowrap;padding:8px 11px;border-radius:999px;background:#fff;border:1px solid #D4E3E5;font-size:12px;transition:.18s all;color:#274449;box-shadow:0 3px 10px rgba(18,56,60,.035)}
  .chip:hover{transform:translateY(-1px)}
  .chip.active{background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;border-color:var(--primary-dark);box-shadow:0 8px 18px rgba(27,107,112,.22)}
  .grid{display:grid;gap:8px}
  .product{display:grid;grid-template-columns:clamp(86px,23vw,98px) minmax(0,1fr);gap:9px;padding:9px 10px;align-items:center;min-height:112px;border-color:#CFE0E3;box-shadow:0 10px 24px rgba(18,56,60,.095)}

  .productImageWatermark{position:relative;overflow:hidden}
  .productImageWatermark:after{content:'';position:absolute;inset:-32px;background-image:url('/images/product-watermark-tile.png');background-repeat:repeat;background-size:55px 55px;background-position:center;opacity:.72;filter:drop-shadow(0 1px 2px rgba(0,0,0,.08));pointer-events:none;z-index:2;transform:rotate(-18deg);transform-origin:center;mix-blend-mode:normal}
  html.wm-off .productImageWatermark:after{display:none}
  .productHeroImage{border-radius:0 0 22px 22px;margin-top:0;box-shadow:0 12px 28px rgba(18,56,60,.10)}
  .adminImagePreview{width:100%;height:135px;border-radius:13px;margin-top:8px;border:1px solid var(--line);background-size:cover;background-position:center;background-color:var(--primary-soft)}
  .productHeroImage.productImageWatermark:after{inset:-58px;background-image:url('/images/product-watermark-tile-hero.png');background-size:90px 90px;opacity:.68;transform:rotate(-18deg)}
  .adminImagePreview.productImageWatermark:after{background-image:url('/images/product-watermark-tile-admin.png');background-size:68px 68px;opacity:.68}

  .thumb{width:clamp(86px,23vw,98px);height:clamp(86px,23vw,98px);border-radius:13px;background:linear-gradient(135deg,var(--primary),var(--accent));box-shadow:inset 0 0 0 1px rgba(255,255,255,.52)}
  .productClickable{cursor:pointer;transition:.16s transform,.16s box-shadow,.16s border-color;touch-action:manipulation}
  .productClickable:hover{transform:translateY(-1px);box-shadow:0 14px 30px rgba(18,56,60,.13);border-color:#BFD8DC}
  .productThumbButton{border:0;padding:0;cursor:zoom-in;display:block;background-color:var(--primary-soft);background-repeat:no-repeat;position:relative;isolation:isolate}
  .productThumbButton:before{content:'';position:absolute;inset:0;background:linear-gradient(180deg,transparent 45%,rgba(15,37,40,.34));opacity:.0;transition:.18s opacity;z-index:3;pointer-events:none}
  .productThumbButton:hover:before,.productThumbButton:focus-visible:before{opacity:1}
  .imageZoomHint{position:absolute;left:6px;right:6px;bottom:6px;z-index:4;padding:4px 5px;border-radius:999px;background:rgba(255,255,255,.90);color:var(--primary-deep);font-size:9px;line-height:1.3;box-shadow:0 5px 14px rgba(0,0,0,.12);opacity:.0;transform:translateY(5px);transition:.18s all;pointer-events:none}
  .productThumbButton:hover .imageZoomHint,.productThumbButton:focus-visible .imageZoomHint{opacity:1;transform:translateY(0)}
  .imageLightbox{position:fixed;inset:0;z-index:90;background:rgba(9,24,27,.70);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;padding:18px;animation:lightboxFade .18s ease-out}
  .imageLightboxPanel{width:min(420px,100%);border-radius:26px;overflow:hidden;background:#fff;border:1px solid rgba(255,255,255,.55);box-shadow:0 28px 70px rgba(0,0,0,.32);animation:lightboxPop .22s cubic-bezier(.2,.8,.2,1)}
  .imageLightboxPhoto{height:min(72vh,520px);min-height:300px;background-color:#ffffff;background-repeat:no-repeat;background-position:center}
  .imageLightboxPhoto.productImageWatermark:after{inset:-58px;background-image:url('/images/product-watermark-tile-hero.png');background-size:90px 90px;opacity:.68}
  .imageLightboxCaption{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;background:linear-gradient(135deg,#fff,var(--primary-tint));color:var(--primary-deep)}
  .imageLightboxCaption strong{font-size:14px}.imageLightboxCaption span{font-size:12px;color:var(--primary-dark);white-space:nowrap}
  .imageLightboxClose{position:fixed;top:calc(14px + env(safe-area-inset-top));left:14px;z-index:91;width:42px;height:42px;border:1px solid rgba(255,255,255,.65);border-radius:50%;background:rgba(255,255,255,.92);color:var(--primary-deep);font-size:28px;line-height:1;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 28px rgba(0,0,0,.18);cursor:pointer}
  @keyframes lightboxFade{from{opacity:0}to{opacity:1}}
  @keyframes lightboxPop{from{opacity:0;transform:translateY(14px) scale(.94)}to{opacity:1;transform:translateY(0) scale(1)}}
  .product h3{margin:0;font-size:clamp(13px,3.45vw,14px);line-height:1.38;color:var(--primary-ink)}
  .meta{display:flex;gap:4px;flex-wrap:wrap;margin:4px 0}
  .mini{font-size:9px;background:var(--primary-soft);padding:3px 6px;border-radius:999px;color:var(--primary-dark);line-height:1.25;border:1px solid rgba(121,180,183,.20)}
  .desc{font-size:11.5px;color:var(--muted);line-height:1.75;margin:5px 0 8px 0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}
  .priceRow{display:flex;justify-content:space-between;align-items:center;gap:4px}
  .productInfo{min-width:0}
  .productBottom{display:flex;flex-direction:row;align-items:center;justify-content:space-between;gap:9px;margin-top:6px;direction:rtl}
  .productPriceBlock{direction:rtl;text-align:right;min-width:88px;flex-shrink:0}
  .productActions{direction:rtl;display:flex;align-items:center;justify-content:flex-end;gap:6px;flex-shrink:0}
  .productActionsLower{margin-top:7px;justify-content:flex-end}
  .qtyControl{display:flex;align-items:center;gap:5px}
  .qtyControl strong{font-size:12px;min-width:14px;text-align:center}
  .price{font-weight:500;color:var(--primary-deep);font-size:12.2px;line-height:1.35}
  .oldPrice{text-decoration:line-through;color:#9aa8aa;font-size:10px;line-height:1.25}
  .btn{border:none;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;box-shadow:0 8px 18px rgba(18,56,60,.18);border-radius:10px;padding:6px 8px;font-weight:500;display:inline-block;cursor:pointer;transition:.16s transform,.16s opacity,.16s box-shadow;font-size:11px;line-height:1.35}
  .btn:hover{transform:translateY(-1px)}
  .btn:active{transform:scale(.98)}
  .btn.secondary{background:#fff;color:var(--primary-deep);border:1px solid rgba(27,107,112,.26);box-shadow:0 5px 14px rgba(18,56,60,.07)}
  .bottomBar{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(8px + env(safe-area-inset-bottom));width:min(360px,calc(100% - 26px));background:linear-gradient(135deg,var(--primary-ink),var(--primary-dark));color:#fff;border-radius:14px;padding:7px 9px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 14px 30px rgba(0,0,0,.16);z-index:25;gap:8px}
  .bottomBar strong{font-size:11px;line-height:1.4}
  .bottomBar small{display:block;color:rgba(255,255,255,.78);font-size:9px;line-height:1.4}
  .bottomBar .btn{font-size:10px;padding:6px 8px;border-radius:9px;white-space:nowrap}
  .bottomNav{position:sticky;bottom:0;display:grid;grid-template-columns:repeat(4,1fr);padding:8px 6px calc(14px + env(safe-area-inset-bottom));background:rgba(255,255,255,.96);backdrop-filter:blur(10px);border-top:1px solid var(--line);margin-top:16px}
  .bottomNav a{text-align:center;font-size:10px;color:#6C7D80}
  .bottomNav a.active{color:var(--primary-deep);font-weight:500}
  .largeImage{height:clamp(190px,52vw,250px);border-radius:0 0 20px 20px;background:linear-gradient(135deg,var(--primary-soft),var(--accent-soft))}
  .contentPad{padding:14px var(--pad)}
  .pageTitleRow{align-items:center;padding-top:12px;padding-bottom:10px}
  .pageTitleCenter{display:grid;gap:3px;text-align:center;justify-items:center;min-width:0}
  .pageTitleCenter strong{font-size:13px;color:var(--primary-deep);line-height:1.5}
  .pageTitleHint{font-size:9.5px;color:var(--muted);line-height:1.6}
  .helpTextLink{font-size:9.5px;color:var(--primary-dark);line-height:1.6;border-bottom:1px dashed rgba(27,107,112,.45);cursor:pointer;user-select:none}
  .helpTextLink:active{opacity:.72}
  .textOnlyAction{border:0;background:transparent;padding:0;font-size:10px;cursor:pointer;color:var(--primary-dark)}
  .dangerText{color:var(--danger)!important}
  .profileEditLink{display:inline-flex;margin-top:10px;font-size:10.5px;color:var(--primary-dark);border-bottom:1px dashed rgba(27,107,112,.4)}
  .smartActionGrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
  .smartActionCard{border:1px solid #CFE0E3;border-radius:16px;padding:11px 10px;text-align:right;background:linear-gradient(135deg,#fff,var(--primary-tint));box-shadow:0 8px 18px rgba(18,56,60,.07);display:grid;gap:5px;color:var(--primary-ink);cursor:pointer;min-height:104px}
  .smartActionCard span{width:30px;height:30px;border-radius:12px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;display:flex;align-items:center;justify-content:center}
  .smartActionCard strong{font-size:12px;color:var(--primary-deep)}
  .smartActionCard small{font-size:9.5px;line-height:1.65;color:var(--muted)}
  .usualCardAction{background:linear-gradient(135deg,#fff,#FFF8EF)}
  .moodCardAction{background:linear-gradient(135deg,#fff,var(--primary-tint))}
  .smartActionMessage{margin-top:8px;padding:8px 10px;border-radius:12px;background:var(--primary-soft);color:var(--primary-deep);font-size:10px;line-height:1.7}
  .smartPopupOverlay{z-index:140}
  .smartPopupCard{width:min(calc(100% - 24px),410px)}
  .smartChoiceGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
  .splitBillCard{border-color:#C7DCDF}
  .splitBillBody{display:grid;gap:10px;margin-top:12px}
  .splitPeopleRow{display:flex;gap:7px;overflow-x:auto;padding-bottom:3px}
  .splitPersonInput{min-width:92px;margin:0!important;padding:8px!important;font-size:16px!important}
  .splitItemList{display:grid;gap:7px;max-height:260px;overflow:auto;padding-left:2px}
  .splitItemRow{display:grid;grid-template-columns:minmax(0,1fr) 112px;gap:8px;align-items:center;padding:8px;border-radius:12px;background:#fff;border:1px solid var(--line)}
  .splitItemRow strong{font-size:10.5px;color:var(--primary-ink)}
  .splitItemRow span{display:block;margin-top:3px;font-size:9px;color:var(--muted);line-height:1.5}
  .splitSelect{margin:0!important;padding:8px!important;font-size:10px!important}
  .splitTotalsGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .splitTotalBox{padding:9px;border-radius:12px;background:linear-gradient(135deg,var(--primary-tint),#fff);border:1px solid #D4E5E7;display:grid;gap:4px}
  .splitTotalBox span{font-size:10px;color:var(--muted)}
  .splitTotalBox strong{font-size:11px;color:var(--primary-deep)}
  .infoGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}
  .infoBox{background:linear-gradient(135deg,#fff,var(--primary-tint));border-radius:12px;padding:9px;font-size:11px;color:#35555A;border:1px solid #D9E9EA}
  .input{width:100%;padding:12px;border:1px solid #D3E2E4;border-radius:12px;margin-top:10px;background:#fff;font-size:16px!important;color:var(--text);outline:none;box-shadow:0 3px 10px rgba(18,56,60,.035)}
  .input:focus{border-color:var(--primary-dark);box-shadow:0 0 0 3px rgba(121,180,183,.20)}
  .metricGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .metric{padding:14px;background:linear-gradient(135deg,#fff,var(--primary-tint));border-color:#D2E4E6}
  .metricNum{font-size:20px;color:var(--primary-deep)}
  .cartItem{padding:9px 10px;border-radius:14px}
  .cartItem strong{font-size:12px}
  .cartItem .sub{font-size:10px}
  .cartItem .btn{font-size:10px;padding:5px 7px;border-radius:9px}
  .cartItemRow{margin-top:8px}
  .cartSummaryCard > strong{font-size:12px}
  .cartSummaryItem .btn{font-size:9.5px;padding:5px 7px}
  .cartItemName{font-size:11px;line-height:1.7;color:var(--primary-ink)}
  .cartItemMeta{font-size:9.5px!important;line-height:1.6}
  .cartQtyNum{font-size:10.5px}
  .cartItemPrice{font-size:11px!important}
  .checkoutCard{padding:10px;border-radius:14px}
  .checkoutCard strong{font-size:12.5px}
  .checkoutCard p,.checkoutCard .sub{font-size:10.5px;line-height:1.65}
  .checkoutCard .chip{font-size:10.5px;padding:6px 9px}
  .checkoutCard .btn{font-size:10.5px;padding:6px 9px}
  .checkoutRow{padding:6px 0!important}
  .checkoutSummaryRow{align-items:flex-start}
  .checkoutItemName{font-size:10.5px;line-height:1.7;color:var(--primary-ink)}
  .checkoutItemMeta{font-size:9.3px!important;line-height:1.6}
  .checkoutItemPrice{font-size:10.8px!important}
  .checkoutAddress{margin-top:10px}
  details.adminSection{margin-bottom:14px;border-radius:18px;background:linear-gradient(180deg,#fff,var(--primary-tint));border:1px solid #D3E5E7;box-shadow:var(--shadow);padding:7px}
  .adminSummary{list-style:none;cursor:pointer;padding:13px 14px;border-radius:14px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));border:1px solid rgba(255,255,255,.28);font-size:13.5px;color:#fff;display:flex;align-items:center;gap:8px}
  .adminSummary:before{content:'⌄';width:22px;height:22px;border-radius:8px;background:rgba(255,255,255,.18);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:13px}
  details[open]>.adminSummary:before{content:'⌃'}
  .adminSummary::-webkit-details-marker{display:none}
  .adminPanelBody{margin:10px 0 4px 0;padding:10px 9px;border-right:4px solid var(--primary-dark);display:grid;gap:10px;background:rgba(255,255,255,.62);border-radius:0 14px 14px 0;min-width:0;max-width:100%;overflow:hidden}
  .adminSection .adminPanelBody > .card,.adminSubCard{width:100%;min-width:0;max-width:100%;overflow:hidden;border-right:3px solid var(--primary);box-shadow:0 6px 14px rgba(16,24,20,.045);position:relative}
  .adminSubCard{background:#fbfefe;border:1px dashed #cbe1e2;border-right:3px solid var(--primary);border-radius:14px;padding:10px}
  .adminSubTitle{font-size:12px;color:#354d4f}
  .adminSection p{font-size:10px;color:var(--muted);line-height:1.8;margin:6px 0 0}
  .adminSection .input{font-size:16px!important;padding:10px;border-radius:11px;max-width:100%;min-width:0;display:block}
  .adminSection .row{min-width:0;flex-wrap:wrap}
  .adminChipScroller{width:100%;max-width:100%;overflow-x:scroll!important;overflow-y:hidden;-webkit-overflow-scrolling:touch;scrollbar-width:none;touch-action:pan-x;border:1px solid var(--line);border-radius:13px;padding:7px;background:#fff;margin-top:8px}
  .adminChipScroller::-webkit-scrollbar{display:none;width:0;height:0}
  .adminChipScroller .chips{width:max-content!important;min-width:100%;display:flex!important;overflow:visible!important;flex-wrap:nowrap!important;gap:7px;padding:0;margin:0}
  .adminChipScroller .chip{flex:0 0 auto}
  .adminSection .chip{flex:0 0 auto}
  .adminSection .sub{font-size:10px}
  .adminSection .chip{font-size:10.5px;padding:6px 9px}
  .adminToggleGrid{display:grid;grid-template-columns:1fr;gap:8px;margin-top:10px}
  .adminNestedCard{width:100%;max-width:100%;overflow:hidden}
  .adminInlineForm{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end}
  .adminInlineForm .input{min-width:0}
  .adminActionRow{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}
  .adminProductDetails{border:1px solid var(--line);border-radius:16px;background:#fff;box-shadow:0 5px 14px rgba(16,24,20,.045);overflow:hidden;margin-bottom:10px}
  .adminProductSummary{list-style:none;cursor:pointer;padding:11px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;background:linear-gradient(135deg,#fff,var(--primary-tint));border-right:3px solid var(--primary-dark)}
  .adminProductSummary::-webkit-details-marker{display:none}
  .adminProductSummary:before{content:'⌄';width:22px;height:22px;border-radius:8px;background:var(--primary-dark);color:#fff;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;order:-1}
  .adminProductDetails[open]>.adminProductSummary:before{content:'⌃'}
  .adminProductSummary strong{font-size:12.5px}
  .adminProductSummary .price{font-size:10.5px;white-space:nowrap}
  .adminProductBody{border-radius:0;border:0;border-top:1px solid var(--line);box-shadow:none}
  .adminNestedDetails{border:1px dashed #cbe1e2;border-radius:14px;background:#fbfefe;overflow:hidden}
  .adminNestedSummary{list-style:none;cursor:pointer;padding:10px 11px;display:flex;align-items:center;justify-content:space-between;gap:8px;background:linear-gradient(135deg,#fff,var(--primary-tint));color:var(--primary-deep);font-size:12px;font-weight:500}
  .adminNestedSummary::-webkit-details-marker{display:none}
  .adminNestedSummary:before{content:'⌄';width:20px;height:20px;border-radius:7px;background:var(--primary);color:#fff;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;order:-1}
  .adminNestedDetails[open]>.adminNestedSummary:before{content:'⌃'}
  .adminNestedSummary small{font-size:10px;color:var(--muted)}
  .adminNestedDetailsBody{margin-top:0;border:0;border-top:1px dashed #cbe1e2;border-radius:0;box-shadow:none}
  .adminOptionGrid{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(84px,.8fr);gap:8px;align-items:end}
  .adminOptionGrid .input{margin-top:0}
  .notificationCard strong{font-size:12.5px}
  .notificationCard p{font-size:10.5px;line-height:1.75}
  .accountingFilters{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}
  .accountingFilters label{font-size:10px;color:var(--muted)}
  .accountingFilters .input{margin-top:5px;padding:9px;font-size:16px!important}
  .accountingGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}
  .accountingItem{padding:10px;border-radius:14px;background:#fff;border:1px solid var(--line)}
  .accountingItem strong{font-size:12px}
  .accountingItem p{font-size:10.5px;margin:5px 0 0;color:var(--muted)}
  .storyRail{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:7px 8px;background:linear-gradient(135deg,#fff,var(--primary-tint));border:1px solid var(--line);border-radius:16px;box-shadow:0 6px 16px rgba(16,24,20,.045)}
  .storyRail::-webkit-scrollbar{display:none}
  .storyBubble{border:none;background:transparent;display:grid;gap:4px;justify-items:center;min-width:54px;color:var(--text);font-size:9px;cursor:pointer;padding:0}
  .storyBubble img,.addStory{width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid #fff;outline:2px solid var(--primary-dark);box-shadow:0 5px 12px rgba(16,24,20,.08);background:#eef5f6}
  .storyBubbleHighlight img{outline:3px solid var(--accent);box-shadow:0 0 0 4px rgba(255,184,107,.24),0 5px 12px rgba(16,24,20,.08)}
  .addStory{display:grid;place-items:center;background:var(--primary-soft);color:var(--primary-dark);font-size:24px;position:relative;overflow:hidden}
  .addStory input{position:absolute;inset:0;opacity:0;cursor:pointer}
  .addStory span{font-size:8px;position:absolute;bottom:3px;background:rgba(255,255,255,.86);padding:1px 4px;border-radius:999px}
  .storyViewer{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:60;display:flex;align-items:center;justify-content:center;padding:18px}
  .storyModal{width:min(380px,100%);height:min(680px,88vh);background:#111;border-radius:24px;overflow:hidden;position:relative;box-shadow:0 30px 70px rgba(0,0,0,.35)}
  .storyModal>img{width:100%;height:100%;object-fit:cover;display:block}
  .storyClose{position:absolute;top:12px;left:12px;z-index:8;width:40px;height:40px;border:2px solid rgba(255,255,255,.95);border-radius:50%;background:rgba(10,18,14,.72);color:#fff;font-size:28px;line-height:1;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 22px rgba(0,0,0,.35)}
  .storyProgress{position:absolute;top:8px;right:12px;left:60px;z-index:7;display:flex;gap:4px;direction:ltr}
  .storyProgress span{height:3px;flex:1;border-radius:999px;background:rgba(255,255,255,.35);box-shadow:0 1px 4px rgba(0,0,0,.25);position:relative;overflow:hidden}
  .storyProgress span.seen{background:#fff}
  .storyProgress span.current{background:rgba(255,255,255,.35)}
  .storyProgress span i{display:block;height:100%;background:#fff;border-radius:999px;box-shadow:0 0 8px rgba(255,255,255,.35)}
  .storyMetaTop{position:absolute;top:18px;z-index:7;color:#fff;pointer-events:none}
  .storyMetaTopRight{right:14px}
  .storyMetaTopLeft{left:14px}
  .storyTinyUser{font-size:9px;font-weight:400;line-height:1.2;color:rgba(255,255,255,.95);text-shadow:0 1px 3px rgba(0,0,0,.5)}
  .storyTinyTime{font-size:8px;font-weight:400;line-height:1.2;color:rgba(255,255,255,.9);text-shadow:0 1px 3px rgba(0,0,0,.5)}
  .storyTapZone{position:absolute;top:54px;bottom:145px;z-index:4;border:none;background:transparent;cursor:pointer}
  .storyTapZone:disabled{cursor:default}
  .storyTapRight{right:0;width:50%}
  .storyTapLeft{left:0;width:50%}
  .storyLikeBtn{min-width:70px;background:#e91e63;box-shadow:0 6px 16px rgba(233,30,99,.22)}
  .storyOverlay{position:absolute;inset:auto 0 0 0;padding:16px;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.78));display:grid;gap:8px;z-index:6}
  .storyOverlay p{font-size:12px;line-height:1.8;margin:0;color:rgba(255,255,255,.88)}
  .storyComments{display:grid;gap:4px;max-height:70px;overflow:auto;font-size:11px;color:rgba(255,255,255,.86)}
  .storyCommentBox{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}
  .storyCommentBox .input{margin:0;background:rgba(255,255,255,.92);padding:9px;font-size:16px!important}
  .ratingStars{display:flex;gap:4px;margin-top:8px;justify-content:flex-end}
  .ratingStars button{border:none;background:transparent;color:#c8c1b4;font-size:23px;line-height:1;cursor:pointer;padding:0 1px;text-shadow:0 1px 0 rgba(255,255,255,.7)}
  .ratingStars button.active{color:var(--accent);filter:drop-shadow(0 2px 4px rgba(255,184,107,.30))}
  .feedbackCard textarea.input{min-height:78px;resize:vertical;line-height:1.8}
  .feedbackBlock{margin-top:12px;padding:10px;border:1px solid var(--line);border-radius:14px;background:rgba(255,255,255,.58)}

  .notificationHead{display:flex;align-items:center;justify-content:space-between;gap:10px}
  .notifClose{width:28px;height:28px;border:none;border-radius:50%;background:#FFE8E8;color:#B42318;font-size:20px;line-height:1;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 12px rgba(180,35,24,.10)}
  .discountBox{margin-top:12px;padding:10px;border-radius:14px;background:linear-gradient(135deg,var(--primary-tint),#fff);border:1px solid #CFE0E3}
  .discountApplyRow{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;margin-top:8px}
  .discountApplyRow .input{margin:0}
  .checkoutTotals{display:grid;gap:7px;margin-top:12px;padding-top:10px;border-top:1px dashed var(--line)}
  .checkoutTotals .row{font-size:11px}
  .discountSaved{color:var(--success)}
  .finalPay{padding-top:7px;border-top:1px solid var(--line)}
  .copyCodeChip,.copyDiscountCode{cursor:pointer}
  .copyDiscountCode{width:100%;border:1px dashed rgba(27,107,112,.34);border-radius:13px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;padding:10px;margin-top:8px;font-size:14px;font-weight:500;letter-spacing:.6px;box-shadow:0 8px 18px rgba(18,56,60,.14)}
  .discountAdminCard{background:linear-gradient(135deg,#fff,var(--primary-tint));border-color:#CFE0E3}

  .surveyPrompt{margin-top:10px;padding:10px;border-radius:14px;background:linear-gradient(135deg,var(--accent-soft),#fff);border:1px solid rgba(181,101,29,.22);display:grid;gap:6px}
  .surveyPrompt p{color:#5F4327;margin:0;font-size:10.5px;line-height:1.8}
  .quickGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}
  .quickBox{min-height:82px;padding:8px 6px;border-radius:16px;background:linear-gradient(135deg,#fff,var(--primary-tint));border:1px solid #CFE0E3;box-shadow:0 8px 18px rgba(18,56,60,.075);display:grid;align-content:start;gap:4px;color:var(--primary-ink)}
  .quickBox strong{font-size:10.5px;line-height:1.45;color:var(--primary-deep)}
  .quickBox small{font-size:8.5px;line-height:1.6;color:#586D72}
  .quickIcon{width:28px;height:28px;border-radius:12px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 7px 15px rgba(18,56,60,.14)}
  .orderDetails{margin-top:12px;border:1px solid #CFE0E3;border-radius:14px;background:linear-gradient(135deg,#fff,var(--primary-tint));overflow:hidden}
  .orderDetails summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;color:var(--primary-deep)}
  .orderDetails summary::-webkit-details-marker{display:none}
  .orderDetails summary span{display:block;margin-top:3px;font-size:10px;color:var(--muted);font-weight:400}
  .orderDetails summary b{font-size:10px;padding:5px 8px;border-radius:999px;background:var(--primary-soft);color:var(--primary-dark)}
  .orderDetails[open] summary b{background:var(--primary-deep);color:#fff}
  .orderDetailsBody{padding:0 10px 10px;display:grid;gap:7px}
  .orderLine{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 10px;border-radius:12px;background:#fff;border:1px solid var(--line)}
  .orderLine strong{font-size:11px;color:var(--primary-ink)}
  .orderLine span{display:block;margin-top:3px;font-size:9.5px;color:var(--muted)}
  .orderLine b{color:var(--primary-dark);font-size:12px}
  .activeOrderTrackItem{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px;border-radius:13px;background:linear-gradient(135deg,#fff,var(--primary-tint));border:1px solid var(--line)}
  .activeOrderTrackItem strong{display:block;font-size:11px;color:var(--primary-deep)}
  .activeOrderTrackItem span{display:block;margin-top:4px;font-size:9.5px;color:var(--muted);line-height:1.6}
  .activeOrderTrackItem b{font-size:10px;color:var(--primary-dark);white-space:nowrap}
  .loyaltyCard{background:linear-gradient(135deg,#FFFFFF 0%,#F4FBFB 48%,#FFF8EF 100%);border-color:#C7DCDF;color:var(--primary-ink)}
  .loyaltyCard>p,.loyaltyCard .row p{color:#4F656A!important}
  .loyaltyCard .row strong{color:var(--primary-deep)}
  .loyaltyCard .chip.active{background:linear-gradient(135deg,var(--accent),var(--accent-dark));color:#fff;border-color:rgba(181,101,29,.25)}
  .loyaltyHero{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px;padding:12px;border-radius:16px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));border:1px solid rgba(255,255,255,.22);color:#fff;box-shadow:var(--shadow-strong)}
  .loyaltyHero .metricNum,.loyaltyHero strong{color:#fff!important;text-shadow:0 1px 2px rgba(0,0,0,.18)}
  .loyaltyHero .sub{color:rgba(255,255,255,.82)!important}
  .loyaltyProgress{height:9px;background:#fff;border:1px solid var(--line);border-radius:999px;overflow:hidden;margin-top:10px}
  .loyaltyProgress span{display:block;height:100%;background:linear-gradient(90deg,var(--primary-deep),var(--primary),var(--accent));border-radius:999px}
  .loyaltyReward{padding:10px;background:linear-gradient(135deg,#fff,var(--primary-tint));border-color:#D2E5E7}
  .loyaltyReward p{margin:4px 0 0;font-size:10.5px;color:var(--muted);line-height:1.7}
  .loyaltyHistory{padding:8px 10px;border-radius:12px;background:#fff;border:1px solid var(--line);font-size:11px}
  .loyaltyHistory .earn{color:var(--primary-dark)}
  .loyaltyHistory .burn{color:var(--accent-dark)}

  .storyUploadBox{margin-top:10px;min-height:160px;border:1.5px dashed rgba(27,107,112,.35);border-radius:16px;background:linear-gradient(135deg,#fff,var(--primary-tint));display:flex;align-items:center;justify-content:center;text-align:center;color:var(--primary-dark);font-size:12px;font-weight:500;overflow:hidden;cursor:pointer}
  .storyUploadBoxPreview{min-height:260px;background:#f8fcfc}
  .storyUploadBox input{display:none}
  .storyUploadBox img{width:100%;height:190px;object-fit:cover;display:block}
  .storyPreviewFull{width:100%!important;height:260px!important;object-fit:contain!important;background:#f8fcfc;display:block}
  .storyUploadBox span{padding:18px;line-height:1.8}
  .loginHeroBadge{display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border-radius:999px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;font-size:10px;box-shadow:0 8px 18px rgba(18,56,60,.14)}
  .loginFeatureGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
  .loginFeatureBox{padding:9px 8px;border-radius:12px;background:linear-gradient(135deg,#fff,var(--primary-tint));border:1px solid #D7E7E8;color:var(--primary-ink);font-size:10px;line-height:1.7;text-align:center}
  .loginInput,.loginCodeInput{font-size:16px!important;padding:13px!important}
  .loginCodeInput{letter-spacing:2px;text-align:center}
  .loginPrimaryBtn{width:100%;padding:10px 12px!important;font-size:12px!important}
  .loginPrimaryBtn:disabled{opacity:.6;cursor:not-allowed;transform:none}
  .loginDivider{display:flex;align-items:center;gap:10px;margin-top:14px;color:var(--muted);font-size:10px}
  .loginDivider:before,.loginDivider:after{content:'';height:1px;flex:1;background:linear-gradient(90deg,transparent,#d7e4e6,transparent)}
  .loginStatusText{margin-top:12px!important;font-size:11px!important;color:var(--primary-dark)!important;line-height:1.9!important}
  .loginStepHeader{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px}
  .loginOtpTools{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:12px;flex-wrap:wrap}
  .loginCountdownText{font-size:10px;color:var(--muted)}
  .trackingCard{border-color:#C7DCDF}
  .trackingHero{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px;border-radius:18px;background:linear-gradient(135deg,var(--primary-deep),var(--primary-dark));color:#fff;box-shadow:var(--shadow-strong)}
  .trackingHero span{font-size:10px;color:rgba(255,255,255,.78)}
  .trackingHero strong{display:block;margin-top:5px;font-size:20px;color:#fff;line-height:1.5}
  .trackingHero p{margin:5px 0 0!important;color:rgba(255,255,255,.86)!important;font-size:11px!important;line-height:1.8!important}
  .trackingPercent{width:56px;height:56px;border-radius:18px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.24);display:flex;align-items:center;justify-content:center;font-weight:500;font-size:15px;flex-shrink:0}
  .trackingProgress{height:10px;border-radius:999px;background:#fff;border:1px solid var(--line);overflow:hidden;margin-top:10px}
  .trackingProgress span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,var(--accent),var(--primary),var(--primary-deep))}
  .trackingMeta{justify-content:flex-start;margin-top:8px;gap:8px;flex-wrap:wrap}
  .trackingMeta span{font-size:10px;padding:5px 8px;border-radius:999px;background:var(--primary-soft);color:var(--primary-dark);border:1px solid rgba(121,180,183,.24)}
  .trackingPaymentPending{background:#FFF1DE!important;color:#B5651D!important;border-color:rgba(181,101,29,.24)!important}
  .trackingPaymentPaid{background:#E8F8F0!important;color:#2E9D6F!important;border-color:rgba(46,157,111,.24)!important}
  .paymentBadge{display:inline-flex;margin-top:8px;padding:5px 8px;border-radius:999px;font-size:10px;border:1px solid var(--line)}
  .paymentBadge.pending{background:#F3F6F7;color:#65777B;border-color:rgba(101,119,123,.24)}
  .paymentBadge.unpaid{background:#FFF1DE;color:#B5651D;border-color:rgba(181,101,29,.24)}
  .paymentBadge.paid{background:#E8F8F0;color:#2E9D6F;border-color:rgba(46,157,111,.24)}
  .trackingSteps{display:grid;gap:7px;margin-top:12px}
  .trackingStep{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:13px;background:#fff;border:1px solid var(--line);color:#607175;font-size:11px}
  .trackingStep.current{background:linear-gradient(135deg,var(--accent-soft),#fff);border-color:rgba(181,101,29,.26);color:var(--primary-ink);font-weight:500;box-shadow:0 8px 18px rgba(18,56,60,.07)}
  .trackingStep.done{background:linear-gradient(135deg,#fff,var(--primary-tint));color:var(--primary-dark)}
  .trackingDot{width:24px;height:24px;border-radius:50%;background:#E8F1F2;color:var(--primary-dark);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:500;flex-shrink:0}
  .trackingStep.current .trackingDot{background:var(--accent);color:#fff}
  .trackingStep.done .trackingDot{background:var(--primary-dark);color:#fff}

  .selectedOptions{padding:10px 12px;border-radius:14px}
  .selectedOptionRow{background:linear-gradient(135deg,#fff,var(--primary-soft));border-radius:10px;padding:6px 8px;gap:6px}
  .selectedOptionRow strong{font-size:11px}
  .selectedOptionRow span{font-size:10px;color:var(--muted)}
  .removeSelection{width:22px;height:22px;border:none;border-radius:50%;background:#ffe8e8;color:#b42318;display:inline-flex;align-items:center;justify-content:center;font-size:16px;line-height:1;cursor:pointer;flex-shrink:0}
  .link{color:var(--primary-dark)}
  .brand{color:var(--primary-deep)}
  .metricNum{color:var(--primary-deep)}
  @media (min-width:430px){.product{grid-template-columns:100px minmax(0,1fr)}.thumb{width:100px;height:100px}.page{border-inline:1px solid rgba(0,0,0,.04)}}
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <link rel="apple-touch-icon" href="/images/apple-touch-icon.png" />
        <link rel="icon" href="/favicon.png" />
      </head>
      <body style={{ margin: 0, background: '#EEF5F6', color: '#162B2E' }}>
        <style suppressHydrationWarning dangerouslySetInnerHTML={{ __html: globalCss }} />
        <CartProvider>
          <ClientExperienceBoot />
          <WatermarkPreference />
          <SpecialAdminNotificationPopup />
          {children}
        </CartProvider>
      </body>
    </html>
  );
}
