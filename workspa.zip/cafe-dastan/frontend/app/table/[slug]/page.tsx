"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { apiGet } from '@/lib/api';

const defaultTableMap: Record<string, { tableName: string; tableQr: string }> = {
  'forough-01': { tableName: 'میز فروغ ۱', tableQr: 'QR-FOROUGH-01' },
  'forough-02': { tableName: 'میز فروغ ۲', tableQr: 'QR-FOROUGH-02' },
  'dastan-01': { tableName: 'میز داستان ۱', tableQr: 'QR-DASTAN-01' },
  'dastan-02': { tableName: 'میز داستان ۲', tableQr: 'QR-DASTAN-02' },
  'rooftop-01': { tableName: 'میز روف‌تاپ ۱', tableQr: 'QR-ROOFTOP-01' },
  'vip-01': { tableName: 'میز VIP ۱', tableQr: 'QR-VIP-01' },
};

export default function TableQrEntryPage({ params }: { params: { slug: string } }) {
  const router = useRouter();

  useEffect(() => {
    const slug = params.slug || '';
    let foundTable = defaultTableMap[slug];

    try {
      const adminTablesRaw = localStorage.getItem('cafe_dastan_admin_tables');
      if (adminTablesRaw) {
        const adminTables: any[] = JSON.parse(adminTablesRaw);
        const match = adminTables.find((t) => t.slug === slug || t.id === slug);
        if (match) {
          foundTable = { tableName: match.name, tableQr: match.code || `QR-${slug.toUpperCase()}` };
        }
      }
    } catch {}

    const saveAndRedirect = (tableObj: { tableName: string; tableQr: string }) => {
      localStorage.setItem('cafe_dastan_table_context', JSON.stringify(tableObj));
      window.dispatchEvent(new Event('cafe-dastan-table-update'));
      router.replace('/');
    };

    if (foundTable) {
      saveAndRedirect(foundTable);
    } else {
      apiGet('/menu').then((res) => {
        const tables = res?.homeSections?.tables || [];
        const match = tables.find((t: any) => t.slug === slug || t.id === slug);
        if (match) {
          saveAndRedirect({ tableName: match.name, tableQr: match.code || `QR-${slug.toUpperCase()}` });
        } else {
          saveAndRedirect({ tableName: `میز ${decodeURIComponent(slug)}`, tableQr: `QR-${slug.toUpperCase()}` });
        }
      }).catch(() => {
        saveAndRedirect({ tableName: `میز ${decodeURIComponent(slug)}`, tableQr: `QR-${slug.toUpperCase()}` });
      });
    }
  }, [params.slug, router]);

  return null;
}
