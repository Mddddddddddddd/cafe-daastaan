"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/context/CartContext';
import TutorialLink from '@/components/TutorialLink';
import SplitBillTool from '@/components/SplitBillTool';

export default function CartPage() {
  const { items, total, addItem, decreaseItem, removeItem, clearCart } = useCart();
  const [tableContext, setTableContext] = useState<{ tableName?: string }>({});
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('cafe_dastan_table_context');
        if (raw) setTableContext(JSON.parse(raw));
      } catch {}
    }
  }, []);

  return (
    <main className="page">
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>سبد خرید</strong>
          <TutorialLink />
        </div>
      </div>

      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="row" style={{ gap: '8px' }}>
          <button className="btn secondary" onClick={clearCart}>حذف همه</button>
          <Link href="/" className="btn secondary">بازگشت به منو</Link>
        </div>
      </section>

      <section className="contentPad">
        <div className="card banner cartSummaryCard">
          <strong>آیتم‌های سفارش</strong>
          {!items.length ? (
            <p style={{ marginTop: '12px' }}>سبد خریدت خالی است.</p>
          ) : (
            <div style={{ display: 'grid', gap: '10px', marginTop: '12px' }}>
              {items.map((item) => (
                <div key={`${item.id}-${item.option}`} className="cartSummaryItem" style={{ padding: '10px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)' }}>
                  <div className="row">
                    <div>
                      <strong className="cartItemName">{item.name}</strong>
                      <div className="sub cartItemMeta">{item.option}</div>
                    </div>
                    <button className="btn secondary" onClick={() => removeItem(item.id, item.option)}>حذف کامل</button>
                  </div>
                  <div className="row cartItemRow">
                    <div className="row" style={{ gap: '8px', justifyContent: 'flex-start' }}>
                      <button className="btn secondary" onClick={() => decreaseItem(item.id, item.option)}>-</button>
                      <strong className="cartQtyNum">{item.qty}</strong>
                      <button className="btn secondary" onClick={() => addItem(item.id, item.option, 0, item.product || item)}>+</button>
                    </div>
                    <strong className="price cartItemPrice">{(item.price * item.qty).toLocaleString('fa-IR')}</strong>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <SplitBillTool />

      <section className="contentPad">
        <div className="card banner">
          <strong>نوع سفارش</strong>
          <p>داخل کافه · {tableContext.tableName || 'سالن اصلی کافه'}</p>
          <div className="row" style={{ marginTop: '12px' }}>
            <strong>جمع کل</strong>
            <strong className="price">{total.toLocaleString('fa-IR')} تومان</strong>
          </div>
          <div style={{ marginTop: '14px', display: 'flex', gap: '10px' }}>
            {items.length ? (
              <Link href="/checkout" className="btn">ادامه تا پرداخت</Link>
            ) : (
              <Link href="/" className="btn">افزودن محصول از منو</Link>
            )}
            <Link href="/" className="btn secondary">بازگشت</Link>
          </div>
          {!items.length ? <p className="sub" style={{ marginTop: '8px' }}>سبد خالی است؛ اول محصولی از منو انتخاب کن.</p> : null}
        </div>
      </section>
    </main>
  );
}
