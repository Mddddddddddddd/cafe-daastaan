import Link from 'next/link';
import RemoteNotifications from '@/components/RemoteNotifications';
import BottomCartBar from '@/components/BottomCartBar';
import CustomerRouteGuard from '@/components/CustomerRouteGuard';
import TutorialLink from '@/components/TutorialLink';

export default function NotificationsPage() {
  return (
    <main className="page">
      <CustomerRouteGuard nextPath="/notifications" />
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>اعلان‌ها</strong>
          <TutorialLink />
        </div>
      </div>
      <RemoteNotifications />
      <BottomCartBar />
    </main>
  );
}