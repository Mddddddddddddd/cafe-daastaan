"use client";

import Link from 'next/link';
import { useCart } from '@/context/CartContext';
import { apiPost, getCustomerContext, getTableContext, requireCustomerAuth } from '@/lib/api';
import { useState } from 'react';
import CustomerRouteGuard from '@/components/CustomerRouteGuard';
import TutorialLink from '@/components/TutorialLink';

type OrderType = 'DINE_IN' | 'TAKE_AWAY' | 'DELIVERY';
type PaymentMethod = 'pay_at_table' | 'pos';

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const [message, setMessage] = useState('');
  const [orderType, setOrderType] = useState<OrderType>('DINE_IN');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pay_at_table');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [discount, setDiscount] = useState<any>(null);
  const [discountMessage, setDiscountMessage] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const tableContext = typeof window !== 'undefined' ? getTableContext() : { tableName: '', tableQr: '' };

  const chooseOrderType = (type: OrderType) => {
    setOrderType(type);
    if (type === 'DELIVERY') setPaymentMethod('pos');
  };

  const applyDiscount = async () => {
    if (!discountCode.trim()) {
      setDiscountMessage('کد تخفیف را وارد کن.');
      return;
    }

    const res = await apiPost('/discounts/validate', { code: discountCode, total });

    if (res.success) {
      setDiscount(res.data);
      setDiscountMessage('کد تخفیف اعمال شد.');
    } else {
      setDiscount(null);
      setDiscountMessage(res.message || 'کد تخفیف معتبر نیست.');
    }
  };

  const submitOrder = async () => {
    if (!requireCustomerAuth('/checkout')) return;

    if (!items.length) {
      setMessage('سبد خرید خالی است');
      return;
    }

    if (orderType === 'DELIVERY' && !address.trim()) {
      setMessage('برای ارسال، آدرس را وارد کن');
      return;
    }

    if (orderType === 'DELIVERY' && !phone.trim()) {
      setMessage('برای ارسال، شماره تلفن را وارد کن');
      return;
    }

    const finalPaymentMethod = orderType === 'DELIVERY' ? 'pos' : paymentMethod;
    const customer = getCustomerContext();

    const payload = {
      branchId: 'branch-seed-1',
      orderType,
      tableId:
        orderType === 'DINE_IN'
          ? (tableContext.tableQr || 'QR-MAIN-HALL')
          : orderType === 'TAKE_AWAY'
            ? 'TAKEAWAY'
            : 'DELIVERY',
      tableName:
        orderType === 'DINE_IN'
          ? (tableContext.tableName || 'سالن اصلی کافه')
          : orderType === 'TAKE_AWAY'
            ? 'تحویل حضوری'
            : 'ارسال به آدرس',
      tableQr:
        orderType === 'DINE_IN'
          ? (tableContext.tableQr || 'QR-MAIN-HALL')
          : orderType === 'TAKE_AWAY'
            ? 'QR-TAKEAWAY'
            : 'QR-DELIVERY',
      address: orderType === 'DELIVERY' ? address : '',
      phone: orderType === 'DELIVERY' ? phone : '',
      paymentMethod: finalPaymentMethod,
      discountCode: discount?.discount?.code || discountCode.trim(),
      note: orderNote.trim() || undefined,
      items: items.map((item) => ({
        productId: item.id,
        name: item.name,
        qty: item.qty,
        price: item.price,
        station: (item as any).station || (item as any).product?.station,
        customizations: { option: item.option },
      })),
    };

    const data = await apiPost(
      `/orders?customerId=${encodeURIComponent(customer.customerId || '')}`,
      payload
    );

    if (data?.success) {
      setMessage(`سفارش ثبت شد. امتیاز باشگاه بعد از تایید پرداخت توسط ویتر ثبت می‌شود.`);
      // بعد از ثبت سفارش، سبد خرید خالی می‌شود تا با بازگشت به خانه آیتم‌های قبلی نماند
      const redirectUrl = `/tracking/${data.data.id}`;
      clearCart();
      try { localStorage.removeItem('cafe_dastan_cart_items'); } catch { /* ignore */ }
      window.location.href = redirectUrl;
    } else {
      setMessage(data?.message || 'خطا در ثبت سفارش');
    }
  };

  const orderTypes = [
    { id: 'DINE_IN', label: 'داخل کافه' },
    { id: 'TAKE_AWAY', label: 'بیرون‌بر' },
    { id: 'DELIVERY', label: 'ارسال به آدرس' },
  ] as const;

  const paymentMethods = [
    { id: 'pay_at_table', label: 'پرداخت در میز' },
    { id: 'pos', label: 'کارتخوان' },
  ] as const;

  if (!items.length) {
    return (
      <main className="page">
        <CustomerRouteGuard nextPath="/checkout" />
        <div className="row contentPad pageTitleRow">
          <Link href="/cart" className="link">بازگشت</Link>
          <div className="pageTitleCenter"><strong>نهایی‌سازی سفارش</strong></div>
        </div>
        <section className="contentPad">
          <div className="card banner" style={{ textAlign: 'center', padding: '30px 18px' }}>
            <div style={{ fontSize: '42px' }}>🛒</div>
            <strong>سبد خریدت خالی است</strong>
            <p style={{ marginTop: '8px' }}>اول از منو محصولی به سبد اضافه کن تا بتوانی سفارش ثبت کنی.</p>
            <Link href="/" className="btn" style={{ marginTop: '14px' }}>مشاهده منو</Link>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="page">
      <CustomerRouteGuard nextPath="/checkout" />

      <div className="row contentPad pageTitleRow">
        <Link href="/cart" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>نهایی‌سازی سفارش</strong>
          <TutorialLink />
        </div>
      </div>

      <section className="contentPad">
        <div className="card banner checkoutCard logoWatermark">
          <strong>نوع سفارش</strong>
          <div className="chips" style={{ marginTop: '8px' }}>
            {orderTypes.map((type) => (
              <button
                key={type.id}
                className={`chip ${orderType === type.id ? 'active' : ''}`}
                onClick={() => chooseOrderType(type.id)}
              >
                {type.label}
              </button>
            ))}
          </div>

          {orderType === 'DINE_IN' ? (
            <p>میز انتخاب‌شده: {tableContext.tableName || 'سالن اصلی کافه'} · {tableContext.tableQr || 'QR-MAIN-HALL'}</p>
          ) : null}

          {orderType === 'TAKE_AWAY' ? (
            <p>سفارش برای تحویل حضوری آماده می‌شود.</p>
          ) : null}

          {orderType === 'DELIVERY' ? (
            <div className="checkoutAddress">
              <input
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                placeholder="آدرس کامل برای ارسال *"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <input
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                placeholder="شماره تلفن مشتری *"
                inputMode="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
              <p>برای ارسال، پرداخت به‌صورت خودکار روی کارتخوان قرار می‌گیرد.</p>
            </div>
          ) : null}

          <div style={{ marginTop: '14px', paddingTop: '12px', borderTop: '1px dashed var(--line)' }}>
            <strong style={{ fontSize: '13px', display: 'block' }}>توضیحات و یادداشت سفارش (اختیاری)</strong>
            <textarea
              className="input"
              style={{ fontSize: '16px', touchAction: 'manipulation', minHeight: '65px', marginTop: '6px' }}
              placeholder="مثلاً: کم‌شیرین باشد، بدون یخ، قهوه داغ‌تر باشد یا یادداشت خاص..."
              value={orderNote}
              onChange={(e) => setOrderNote(e.target.value)}
            />
          </div>
        </div>
      </section>

      <section className="contentPad">
        <div className="card banner checkoutCard">
          <strong>روش پرداخت</strong>
          <div className="chips" style={{ marginTop: '8px' }}>
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                className={`chip ${paymentMethod === method.id ? 'active' : ''}`}
                onClick={() => orderType !== 'DELIVERY' ? setPaymentMethod(method.id) : setPaymentMethod('pos')}
              >
                {method.label}
              </button>
            ))}
          </div>
          <p>{orderType === 'DELIVERY' ? 'برای ارسال به آدرس فقط کارتخوان فعال است.' : 'در این نسخه فقط پرداخت در میز یا کارتخوان فعال است.'}</p>
        </div>
      </section>

      <section className="contentPad">
        <div className="card banner checkoutCard">
          <strong>خلاصه سفارش</strong>

          <div style={{ marginTop: '8px' }}>
            {items.map((item) => (
              <div key={`${item.id}-${item.option}`} className="row checkoutRow checkoutSummaryRow">
                <div>
                  <div className="checkoutItemName">{item.name}</div>
                  <div className="sub checkoutItemMeta">{item.option} · تعداد {item.qty}</div>
                </div>
                <strong className="price checkoutItemPrice">
                  {(item.price * item.qty).toLocaleString('fa-IR')}
                </strong>
              </div>
            ))}
          </div>

          <div className="discountBox">
            <strong>کد تخفیف</strong>
            <p>اگر از پنل ادمین یا باشگاه مشتریان کد گرفتی، قبل از پرداخت نهایی اینجا وارد کن.</p>
            <div className="discountApplyRow">
              <input
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                placeholder="مثلاً DASTAN20"
                value={discountCode}
                onChange={(e) => {
                  setDiscountCode(e.target.value);
                  setDiscount(null);
                  setDiscountMessage('');
                }}
              />
              <button className="btn secondary" onClick={applyDiscount}>اعمال</button>
            </div>
            {discountMessage ? (
              <p style={{ color: discount ? 'var(--success)' : 'var(--accent-dark)' }}>
                {discountMessage}
              </p>
            ) : null}
          </div>

          <div className="checkoutTotals">
            <div className="row">
              <span>جمع سفارش</span>
              <strong>{total.toLocaleString('fa-IR')} تومان</strong>
            </div>

            {discount ? (
              <div className="row discountSaved">
                <span>تخفیف {discount.discount?.code}</span>
                <strong>-{Number(discount.discountAmount || 0).toLocaleString('fa-IR')} تومان</strong>
              </div>
            ) : null}

            <div className="row finalPay">
              <strong>مبلغ نهایی</strong>
              <strong className="price">
                {Number(discount?.finalTotal ?? total).toLocaleString('fa-IR')} تومان
              </strong>
            </div>
          </div>

          <div style={{ marginTop: '12px' }}>
            <button className="btn" onClick={submitOrder}>ثبت نهایی سفارش</button>
          </div>

          {message ? <p style={{ color: 'var(--primary)', fontSize: '11px' }}>{message}</p> : null}
        </div>
      </section>
    </main>
  );
}
