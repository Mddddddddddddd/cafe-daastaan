"use client";

import Link from 'next/link';
import { apiGet, apiPatch, saveAuth, clearAuth, getStoredUser, requireCustomerAuth, getCustomerContext } from '@/lib/api';
import { useCallback, useEffect, useState } from 'react';

const statusLabel: Record<string, string> = {
  PENDING: 'ثبت شده', ACCEPTED: 'تایید شده', BAR_PREPARING: 'در حال آماده‌سازی (بار)',
  KITCHEN_PREPARING: 'در حال آماده‌سازی (آشپزخانه)', READY_TO_SERVE: 'آماده سرو',
  ON_THE_WAY: 'در مسیر', DELIVERED: 'تحویل شده', CANCELLED: 'لغو شده',
};

function formatFa(value?: string) {
  if (!value) return '-';
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return value;
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(d);
}

function formatPersianDate(iso?: string) {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return iso;
  return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long', day: 'numeric' }).format(d);
}

export default function ProfilePage() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [birthday, setBirthday] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [profile, setProfile] = useState<any>(null);
  const [loyalty, setLoyalty] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [editing, setEditing] = useState(false);
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  const loadLoyalty = useCallback(() => {
    const customer = getCustomerContext();
    const params = new URLSearchParams();
    if (customer?.customerId) params.set('customerId', customer.customerId);
    if (customer?.phone) params.set('phone', customer.phone);
    if (customer?.name) params.set('name', customer.name);
    apiGet(`/loyalty?${params.toString()}`).then((res) => setLoyalty(res?.data || null)).catch(() => {});
  }, []);

  useEffect(() => {
    if (!requireCustomerAuth('/profile')) return;
    apiGet('/me').then((res) => {
      const data = res?.data || {};
      setName(data.name || '');
      setUsername(data.username || '');
      setBirthday(data.birthday || '');
      setAddress(data.address || '');
      setPhone(data.phone || '');
      setProfile(data);
    }).catch(() => {});
    loadLoyalty();
    apiGet('/orders/mine').then((res) => setOrders(res?.data || [])).catch(() => {});
  }, [loadLoyalty]);

  const save = async () => {
    setSaving(true);
    setMessage('');
    const res = await apiPatch('/me', { name, username, birthday, address });
    if (res?.success) {
      const current = getStoredUser() || {};
      saveAuth({ accessToken: localStorage.getItem('cafe_dastan_access_token'), refreshToken: localStorage.getItem('cafe_dastan_refresh_token'), user: { ...current, ...res.data, role: 'customer' } });
      setProfile(res.data);
      setEditing(false);
      setMessage('✅ اطلاعات پروفایل با موفقیت ذخیره شد.');
    } else {
      setMessage('❌ ' + (res?.message || 'خطا در ذخیره پروفایل'));
    }
    setSaving(false);
  };

  const logout = () => {
    clearAuth();
    window.location.href = '/';
  };

  const member = loyalty?.member;
  const nextReward = loyalty?.nextReward;
  const displayName = name || profile?.name || 'مهمان کافه داستان';
  const initial = (displayName.trim()[0] || 'ک');

  return (
    <main className="page">
      <div className="row contentPad pageTitleRow">
        <Link href="/" className="link">بازگشت</Link>
        <div className="pageTitleCenter">
          <strong>پروفایل من</strong>
          <span className="pageTitleHint">حساب، باشگاه مشتریان و سوابق سفارش</span>
        </div>
      </div>

      <section className="contentPad" style={{ display: 'grid', gap: '12px' }}>
        {/* هدر اصلی */}
        <div style={{
          borderRadius: '22px', overflow: 'hidden', position: 'relative',
          background: 'linear-gradient(135deg, var(--primary-deep) 0%, var(--primary) 100%)',
          padding: '24px 18px', color: '#fff',
          boxShadow: '0 10px 30px rgba(18,56,60,0.25)',
        }}>
          <div className="row" style={{ alignItems: 'center', gap: '14px' }}>
            <div style={{
              width: '72px', height: '72px', borderRadius: '50%', flexShrink: 0,
              background: 'rgba(255,255,255,0.18)', border: '2px solid rgba(255,255,255,0.55)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '30px', fontWeight: 800,
            }}>{initial}</div>
            <div style={{ minWidth: 0 }}>
              <strong style={{ fontSize: '18px', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{displayName}</strong>
              {username ? <div style={{ opacity: 0.85, fontSize: '12.5px', marginTop: '2px' }}>@{username}</div> : null}
              {profile?.personalityTitle ? (
                <span style={{
                  display: 'inline-block', marginTop: '8px', padding: '3px 10px', borderRadius: '999px',
                  background: 'rgba(255,255,255,0.2)', fontSize: '11px', border: '1px solid rgba(255,255,255,0.35)',
                }}>✨ {profile.personalityTitle}</span>
              ) : null}
            </div>
          </div>
          {(profile?.totalOrders != null || profile?.totalAmount != null) ? (
            <div className="row" style={{ marginTop: '16px', gap: '8px', flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: '90px', background: 'rgba(255,255,255,0.14)', borderRadius: '14px', padding: '10px 12px', textAlign: 'center' }}>
                <div style={{ fontSize: '17px', fontWeight: 800 }}>{Number(profile.totalOrders || 0).toLocaleString('fa-IR')}</div>
                <div style={{ fontSize: '10.5px', opacity: 0.85, marginTop: '2px' }}>سفارش ثبت‌شده</div>
              </div>
              <div style={{ flex: 1, minWidth: '90px', background: 'rgba(255,255,255,0.14)', borderRadius: '14px', padding: '10px 12px', textAlign: 'center' }}>
                <div style={{ fontSize: '17px', fontWeight: 800 }}>{Number(profile.totalAmount || 0).toLocaleString('fa-IR')}</div>
                <div style={{ fontSize: '10.5px', opacity: 0.85, marginTop: '2px' }}>مجموع خرید (تومان)</div>
              </div>
              <div style={{ flex: 1, minWidth: '90px', background: 'rgba(255,255,255,0.14)', borderRadius: '14px', padding: '10px 12px', textAlign: 'center' }}>
                <div style={{ fontSize: '17px', fontWeight: 800 }}>{Number(profile.storyCount || 0).toLocaleString('fa-IR')}</div>
                <div style={{ fontSize: '10.5px', opacity: 0.85, marginTop: '2px' }}>استوری داستانی</div>
              </div>
            </div>
          ) : null}
        </div>

        {/* اطلاعات شخصی */}
        <div className="card banner">
          <div className="row" style={{ alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <strong>اطلاعات شخصی</strong>
              <p className="sub">مشتری عزیز، اطلاعات خودت را کامل کن.</p>
            </div>
            {!editing ? (
              <button className="btn secondary" style={{ padding: '6px 14px', fontSize: '12px' }} onClick={() => { setEditing(true); setMessage(''); }}>ویرایش</button>
            ) : null}
          </div>

          {editing ? (
            <div style={{ display: 'grid', gap: '10px', marginTop: '12px' }}>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>نام و نام خانوادگی</label>
                <input className="input" style={{ fontSize: '16px' }} placeholder="مثلاً: سارا محمدی" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>نام کاربری</label>
                <input className="input" style={{ fontSize: '16px' }} dir="ltr" placeholder="username" value={username} onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_؀-ۿ]/g, ''))} />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>تاریخ تولد {birthday ? <span style={{ color: 'var(--primary)', fontWeight: 400 }}>({formatPersianDate(birthday)})</span> : null}</label>
                <input className="input" type="date" style={{ fontSize: '16px' }} value={birthday} onChange={(e) => setBirthday(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>آدرس {address ? '' : '(برای سفارش ارسال به آدرس)'}</label>
                <textarea className="input" rows={2} style={{ fontSize: '16px', resize: 'vertical' }} placeholder="محله، خیابان، پلاک..." value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>شماره موبایل (ثبت‌نام)</label>
                <input className="input" style={{ fontSize: '16px', opacity: 0.6 }} dir="ltr" value={phone} readOnly />
              </div>
              <div className="row" style={{ gap: '8px', marginTop: '4px' }}>
                <button className="btn" style={{ flex: 1 }} onClick={save} disabled={saving}>{saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}</button>
                <button className="btn secondary" style={{ flex: 1 }} onClick={() => { setEditing(false); setMessage(''); }} disabled={saving}>انصراف</button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: '8px', marginTop: '12px' }}>
              <div className="row" style={{ padding: '10px 12px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)' }}>
                <span style={{ fontSize: '18px' }}>👤</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '11px', color: 'var(--muted, #6b7c80)' }}>نام و نام خانوادگی</div>
                  <strong style={{ fontSize: '13.5px', wordBreak: 'break-word' }}>{displayName}</strong>
                </div>
              </div>
              <div className="row" style={{ padding: '10px 12px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)' }}>
                <span style={{ fontSize: '18px' }}>📱</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '11px', color: 'var(--muted, #6b7c80)' }}>شماره موبایل</div>
                  <strong style={{ fontSize: '13.5px', direction: 'ltr', display: 'inline-block' }}>{phone || '—'}</strong>
                </div>
              </div>
              <div className="row" style={{ padding: '10px 12px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)' }}>
                <span style={{ fontSize: '18px' }}>🎂</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '11px', color: 'var(--muted, #6b7c80)' }}>تاریخ تولد</div>
                  <strong style={{ fontSize: '13.5px' }}>{birthday ? formatPersianDate(birthday) : 'ثبت نشده'}</strong>
                </div>
              </div>
              <div className="row" style={{ padding: '10px 12px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)', alignItems: 'flex-start' }}>
                <span style={{ fontSize: '18px' }}>📍</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '11px', color: 'var(--muted, #6b7c80)' }}>آدرس</div>
                  <strong style={{ fontSize: '13px', fontWeight: 600, wordBreak: 'break-word' }}>{address || 'ثبت نشده'}</strong>
                </div>
              </div>
            </div>
          )}
          {message ? <p style={{ marginTop: '10px', fontSize: '12.5px' }}>{message}</p> : null}
        </div>

        {/* دنج داستانی */}
        {(profile?.favoriteDrink || profile?.favoriteFood || profile?.preferredHour || profile?.nextSuggestion) ? (
          <div className="card banner">
            <strong>دنج داستانی تو</strong>
            <p className="sub">بر اساس سفارش‌هایت به‌صورت خودکار ساخته می‌شود.</p>
            <div className="row" style={{ flexWrap: 'wrap', gap: '6px' }}>
              {profile.favoriteDrink ? <span className="chip">☕ نوشیدنی محبوب: {profile.favoriteDrink}</span> : null}
              {profile.favoriteFood ? <span className="chip">🍽️ غذا: {profile.favoriteFood}</span> : null}
              {profile.preferredHour ? <span className="chip">🕐 ساعت معمول: {profile.preferredHour}</span> : null}
            </div>
            {profile.nextSuggestion ? <p style={{ marginTop: '10px', fontSize: '12.5px', lineHeight: 2, padding: '10px 12px', borderRadius: '14px', background: 'var(--primary-tint, #eaf4f5)' }}>{profile.nextSuggestion}</p> : null}
          </div>
        ) : null}

        {/* باشگاه مشتریان */}
        <div className="card banner">
          <div className="row" style={{ alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <strong>باشگاه مشتریان</strong>
              <p className="sub">{member ? `${member.tier} · امتیاز فعلی: ${Number(member.points || 0).toLocaleString('fa-IR')}` : 'عضویت در حال آماده‌سازی...'}</p>
            </div>
            <Link href="/loyalty" className="btn secondary">مشاهده کامل</Link>
          </div>
          {member ? (
            <div style={{ marginTop: '10px' }}>
              <div style={{ height: '10px', borderRadius: '999px', background: 'var(--primary-soft)', overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${Math.min(100, (Number(member.points || 0) / 500) * 100)}%`, background: 'linear-gradient(135deg,var(--primary-deep),var(--primary))' }} />
              </div>
              {nextReward ? <p className="sub" style={{ marginTop: '8px' }}>تا جایزه بعدی ({nextReward.title}) هنوز {Math.max(0, Number(nextReward.points) - Number(member.points || 0)).toLocaleString('fa-IR')} امتیاز فاصله داری.</p> : <p className="sub" style={{ marginTop: '8px' }}>به بالاترین سطح جایزه رسیدی. 🏆</p>}
            </div>
          ) : null}
        </div>

        {/* سوابق سفارش */}
        <div className="card banner">
          <strong>سوابق سفارش</strong>
          {!orders.length ? <p className="sub">هنوز سفارشی ثبت نشده است.</p> : (
            <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
              {orders.map((o: any) => (
                <div key={o.id} style={{ padding: '10px', borderRadius: '14px', background: '#f8fcfc', border: '1px solid var(--line)' }}>
                  <div className="row" style={{ alignItems: 'center' }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <strong>سفارش #{o.id}</strong>
                      <div className="sub">{formatFa(o.createdAt)}</div>
                    </div>
                    <span className="chip">{statusLabel[String(o.status || '')] || o.status}</span>
                  </div>
                  <div className="sub" style={{ marginTop: '6px' }}>
                    {(o.items || []).map((it: any, i: number) => (
                      <span key={`${it.productId || i}`}>{it.productNameSnapshot || it.name} ×{Number(it.qty || 1).toLocaleString('fa-IR')}{i < (o.items || []).length - 1 ? ' · ' : ''}</span>
                    ))}
                  </div>
                  {!['DELIVERED', 'CANCELLED'].includes(String(o.status || '')) ? (
                    <Link href={`/tracking/${o.id}`} className="link" style={{ display: 'inline-block', marginTop: '6px', fontSize: '12px' }}>رهگیری سفارش ←</Link>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* خروج */}
        <div className="card banner">
          <button className="btn secondary" onClick={logout}>خروج از حساب</button>
        </div>
      </section>
    </main>
  );
}
