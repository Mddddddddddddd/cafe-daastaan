"use client";

import React, { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import ProtectedPage from '@/components/ProtectedPage';
import { apiDelete, apiGet, apiPatch, apiPost, resolveImageUrl } from '@/lib/api';
import CustomizationEditor, { normalizeCustomizations } from '@/components/CustomizationEditor';

const menuIcons = [
  { label: 'قهوه گرم', path: '/images/menu/coffee.svg' },
  { label: 'نوشیدنی سرد', path: '/images/menu/cold.svg' },
  { label: 'دسر و چیزکیک', path: '/images/menu/dessert.svg' },
  { label: 'صبحانه', path: '/images/menu/breakfast.svg' },
  { label: 'چای و دمنوش', path: '/images/menu/tea.svg' },
  { label: 'غذای سبک', path: '/images/menu/food.svg' },
  { label: 'قهوه تخصصی', path: '/images/menu/specialty.svg' },
  { label: 'کیک خانگی', path: '/images/menu/cake.svg' },
  { label: 'شیک و فصلی', path: '/images/menu/shake.svg' },
];

function ImagePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const onFile = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onChange(String(reader.result || ''));
    reader.readAsDataURL(file);
    // بعد از انتخاب، مقدار input پاک می‌شود تا انتخاب دوباره‌ی همان فایل هم فعال باشد.
    if (fileRef.current) fileRef.current.value = '';
  };
  const isUploaded = value && !value.startsWith('/images/');

  return (
    <div className="adminSubCard" style={{ marginTop: '10px', borderRadius: '14px', padding: '12px' }}>
      <strong className="adminSubTitle" style={{ fontSize: '13px' }}>تصویر محصول</strong>
      <div className="row" style={{ gap: '12px', marginTop: '10px', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <div style={{ width: '84px', height: '84px', borderRadius: '14px', overflow: 'hidden', background: '#f0f4f5', border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          {value ? (
            <img src={resolveImageUrl(value)} alt="پیش‌نمایش" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <span style={{ fontSize: '10px', color: 'var(--muted)' }}>بدون عکس</span>
          )}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <label className="btn secondary" style={{ cursor: 'pointer', textAlign: 'center', width: '100%', marginBottom: '6px' }}>
            📷 آپلود عکس اختصاصی از دستگاه
            <input ref={fileRef} type="file" accept="image/*" onChange={(e) => onFile(e.target.files?.[0])} style={{ display: 'none' }} />
          </label>
          <button type="button" className="btn secondary" style={{ width: '100%', fontSize: '11px' }} onClick={() => onChange('/images/menu/coffee.svg')}>
            استفاده از آیکون پیش‌فرض کافه
          </button>
          {isUploaded ? (
            <button type="button" className="btn secondary" style={{ width: '100%', fontSize: '11px', marginTop: '6px', color: 'var(--danger)' }} onClick={() => onChange('')}>
              🗑️ حذف عکس بارگذاری‌شده
            </button>
          ) : null}
        </div>
      </div>
      <div style={{ fontSize: '11px', color: 'var(--muted)', margin: '10px 0 6px 0' }}>یا یک آیکون آماده انتخاب کنید:</div>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        {menuIcons.map((ic) => (
          <button
            key={ic.path}
            type="button"
            className={`chip ${value === ic.path ? 'active' : ''}`}
            onClick={() => onChange(ic.path)}
            style={{ fontSize: '11px', padding: '6px 10px' }}
          >
            {ic.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function ProductsManagerPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [activeTab, setActiveTab] = useState<'quick-add' | 'list' | 'bulk-import'>('quick-add');

  // Filter & Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('همه');

  // Quick Add state
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [oldPrice, setOldPrice] = useState('');
  const [desc, setDesc] = useState('');
  const [selectedCats, setSelectedCats] = useState<string[]>(['نوشیدنی گرم']);
  const [station, setStation] = useState<'bar' | 'kitchen'>('bar');
  const [image, setImage] = useState('/images/menu/coffee.svg');
  const [imageKey, setImageKey] = useState(0);
  const [featured, setFeatured] = useState(false);
  const [discounted, setDiscounted] = useState(false);
  const [newCustomizations, setNewCustomizations] = useState<any[]>([]);
  const [savingAdd, setSavingAdd] = useState(false);

  // Edit Modal state
  const [editingItem, setEditingItem] = useState<any>(null);

  // Bulk Paste state
  const [bulkText, setBulkText] = useState('');
  const [bulkCategory, setBulkCategory] = useState('ویژه کافه');
  const [bulkStation, setBulkStation] = useState<'bar' | 'kitchen'>('bar');
  const [bulkSaving, setBulkSaving] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    const res = await apiGet('/admin/products');
    if (res?.success) {
      setProducts(res.data || []);
      setCategories(res.categories || []);
    } else {
      setStatus(res?.message || 'خطا در دریافت اطلاعات محصولات');
    }
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, []);

  const toggleCatSelection = (cat: string) => {
    setSelectedCats((prev) => prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]);
  };

  const handleQuickAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { setStatus('⚠️ نام محصول الزامی است.'); return; }
    if (!price.trim()) { setStatus('⚠️ قیمت محصول الزامی است.'); return; }

    setSavingAdd(true);
    setStatus('⏳ درحال ثبت محصول...');
    try {
      const res = await apiPost('/admin/products', {
        name: name.trim(),
        price: Number(price.replace(/[^0-9]/g, '')),
        oldPrice: oldPrice ? Number(oldPrice.replace(/[^0-9]/g, '')) : undefined,
        desc: desc.trim(),
        categories: selectedCats.length ? selectedCats : ['ویژه کافه'],
        image: image || '/images/menu/coffee.svg',
        station,
        featured,
        discounted,
        active: true,
        customizations: normalizeCustomizations(newCustomizations),
      });

      if (res?.success) {
        setStatus(`✅ محصول «${name.trim()}» ثبت شد. فرم برای محصول بعدی پاک شد.`);
        setName('');
        setPrice('');
        setOldPrice('');
        setDesc('');
        setFeatured(false);
        setDiscounted(false);
        setNewCustomizations([]);
        setImage('/images/menu/coffee.svg');
        setImageKey((k) => k + 1); // ریست input فایل تا بتوان محصول بعدی را دوباره آپلود کرد
        loadAll();
      } else {
        setStatus(res?.message || '❌ خطا در افزودن محصول.');
      }
    } catch (err) {
      setStatus('❌ خطای شبکه یا سرور هنگام ثبت محصول. لطفاً دوباره تلاش کنید.');
    } finally {
      setSavingAdd(false); // همیشه دکمه را از حالت «درحال ذخیره» خارج کن تا گیر نکند
    }
  };

  const handleQuickToggleActive = async (item: any) => {
    const nextActive = item.active === false ? true : false;
    // optimistic update
    setProducts((prev) => prev.map((p) => p.id === item.id ? { ...p, active: nextActive } : p));
    await apiPatch(`/admin/products/${item.id}`, { active: nextActive });
  };

  const handleQuickToggleFeatured = async (item: any) => {
    const nextFeatured = !item.featured;
    setProducts((prev) => prev.map((p) => p.id === item.id ? { ...p, featured: nextFeatured } : p));
    await apiPatch(`/admin/products/${item.id}`, { featured: nextFeatured });
  };

  const handleUpdatePrice = async (item: any, newPriceVal: number) => {
    await apiPatch(`/admin/products/${item.id}`, { price: newPriceVal });
    setStatus(`قیمت «${item.name}» بروز شد.`);
  };

  const handleDeleteProduct = async (id: string, itemName: string) => {
    if (typeof window !== 'undefined' && !window.confirm(`آیا از حذف محصول «${itemName}» اطمینان دارید؟`)) return;
    setProducts((prev) => prev.filter((p) => p.id !== id));
    await apiDelete(`/admin/products/${id}`);
    setStatus(`محصول «${itemName}» حذف شد.`);
  };

  const handleSaveEditModal = async () => {
    if (!editingItem) return;
    setStatus('درحال ذخیره تغییرات...');
    try {
      const res = await apiPatch(`/admin/products/${editingItem.id}`, {
        name: editingItem.name,
        price: Number(editingItem.price),
        oldPrice: editingItem.oldPrice ? Number(editingItem.oldPrice) : null,
        desc: editingItem.desc,
        categories: editingItem.categories,
        image: editingItem.image,
        station: editingItem.station,
        featured: editingItem.featured,
        discounted: editingItem.discounted,
        customizations: normalizeCustomizations(editingItem.customizations || []),
      });
      if (res?.success) {
        setStatus(`✅ محصول «${editingItem.name}» ویرایش شد.`);
        setEditingItem(null);
        loadAll();
      } else {
        setStatus(res?.message || 'خطا در ذخیره ویرایش.');
      }
    } catch (err) {
      setStatus('❌ خطای شبکه در ذخیره ویرایش. دوباره تلاش کنید.');
    }
  };

  const handleBulkImport = async () => {
    if (!bulkText.trim()) { setStatus('متن محصولات را پیست کنید.'); return; }
    const lines = bulkText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines.length) return;

    setBulkSaving(true);
    setStatus(`درحال پردازش و ثبت ${lines.length} خط...`);
    let added = 0;
    try {
      for (const line of lines) {
        // expected format: نام محصول | قیمت | توضیحات (اختیاری)
        const parts = line.split(/[|#,-]/).map((p) => p.trim());
        const pName = parts[0];
        const pPrice = parts[1] ? Number(parts[1].replace(/[^0-9]/g, '')) : 0;
        const pDesc = parts[2] || '';
        if (pName && pPrice > 500) {
          await apiPost('/admin/products', {
            name: pName,
            price: pPrice,
            desc: pDesc,
            categories: [bulkCategory],
            image: '/images/menu/coffee.svg',
            station: bulkStation,
            active: true,
          });
          added++;
        }
      }
      setStatus(`🎉 تعداد ${added} محصول به صورت دسته‌جمعی با موفقیت اضافه شد!`);
      setBulkText('');
      loadAll();
    } catch (err) {
      setStatus(`❌ خطا در ثبت دسته‌جمعی. ${added} محصول قبل از خطا ثبت شد. دوباره تلاش کنید.`);
    } finally {
      setBulkSaving(false);
    }
  };

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchCat = selectedCategory === 'همه' ? true : (p.categories || []).includes(selectedCategory);
      const matchSearch = searchQuery.trim()
        ? p.name?.includes(searchQuery.trim()) || p.desc?.includes(searchQuery.trim())
        : true;
      return matchCat && matchSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  return (
    <ProtectedPage role="admin" title="مدیریت پیشرفته محصولات">
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="card banner brandPattern">
          <div className="row">
            <div>
              <strong style={{ fontSize: '16px', color: 'var(--primary-deep)' }}>پنل اختصاصی مدیریت سریع محصولات</strong>
              <div className="sub">تعداد کل محصولات ثبت‌شده: {products.length.toLocaleString('fa-IR')} آیتم</div>
            </div>
            <Link href="/admin" className="btn secondary">بازگشت به پنل اصلی</Link>
          </div>
        </div>

        {status ? (
          <div className="card banner" style={{ marginTop: '10px', background: '#E8F8F0', borderColor: '#2E9D6F', color: '#1A6B4B', fontWeight: 500, fontSize: '13px' }}>
            {status}
          </div>
        ) : null}

        {/* Navigation Tabs */}
        <div className="chips" style={{ marginTop: '14px', marginBottom: '14px' }}>
          <button type="button" className={`chip ${activeTab === 'quick-add' ? 'active' : ''}`} onClick={() => setActiveTab('quick-add')}>
            ⚡ افزودن سریع و متوالی (تکی)
          </button>
          <button type="button" className={`chip ${activeTab === 'list' ? 'active' : ''}`} onClick={() => setActiveTab('list')}>
            📋 مدیریت و ویرایش سریع ۸۰ محصول ({filteredProducts.length})
          </button>
          <button type="button" className={`chip ${activeTab === 'bulk-import' ? 'active' : ''}`} onClick={() => setActiveTab('bulk-import')}>
            📑 افزودن دسته‌جمعی (متن اکسل / کپی‌پیست)
          </button>
        </div>

        {/* TAB 1: QUICK ADD */}
        {activeTab === 'quick-add' ? (
          <form onSubmit={handleQuickAdd} className="card banner">
            <strong style={{ fontSize: '15px', color: 'var(--primary-deep)', display: 'block', marginBottom: '6px' }}>
              افزودن سریع محصول به منو (مخصوص ثبت متوالی بدون توقف)
            </strong>
            <p style={{ fontSize: '11px', color: 'var(--muted)', margin: '0 0 12px 0' }}>
              بعد از کلیک روی دکمه ثبت، فرم در کمتر از ۱ ثانیه پاک می‌شود تا محصول بعدی را بلافاصله وارد کنید.
            </p>

            <label style={{ display: 'block', marginTop: '10px' }}>
              <span className="sub">نام محصول *</span>
              <input
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation' }}
                placeholder="مثلاً: اسپرسو دابل کلمبیا یا چیزکیک اورئو"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </label>

            <div className="row" style={{ marginTop: '10px', gap: '10px' }}>
              <label style={{ flex: 1 }}>
                <span className="sub">قیمت اصلی (تومان) *</span>
                <input
                  className="input"
                  style={{ fontSize: '16px', touchAction: 'manipulation' }}
                  inputMode="numeric"
                  placeholder="مثلاً: 145000"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </label>
              <label style={{ flex: 1 }}>
                <span className="sub">قیمت قبل از تخفیف (اختیاری)</span>
                <input
                  className="input"
                  style={{ fontSize: '16px', touchAction: 'manipulation' }}
                  inputMode="numeric"
                  placeholder="مثلاً: 170000"
                  value={oldPrice}
                  onChange={(e) => setOldPrice(e.target.value)}
                />
              </label>
            </div>

            <label style={{ display: 'block', marginTop: '10px' }}>
              <span className="sub">توضیحات کوتاه محصول</span>
              <textarea
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation', minHeight: '60px' }}
                placeholder="ترکیبات یا توضیحات اشتهاآور محصول..."
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
              />
            </label>

            <div style={{ marginTop: '12px' }}>
              <span className="sub" style={{ display: 'block', marginBottom: '6px' }}>انتخاب دسته‌بندی‌ها (می‌توانید چند دسته را انتخاب کنید):</span>
              <div className="chips" style={{ flexWrap: 'wrap', overflow: 'visible' }}>
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    className={`chip ${selectedCats.includes(cat) ? 'active' : ''}`}
                    onClick={() => toggleCatSelection(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ marginTop: '12px', padding: '10px', background: '#f8fcfc', borderRadius: '12px', border: '1px solid var(--line)' }}>
              <span className="sub" style={{ display: 'block', marginBottom: '6px', fontWeight: 700, color: 'var(--primary-deep)' }}>انتخاب ایستگاه آماده‌سازی (سفارش این محصول به کدام پنل ارسال شود؟):</span>
              <div className="row" style={{ justifyContent: 'flex-start', gap: '16px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input type="radio" name="station" checked={station === 'bar'} onChange={() => setStation('bar')} />
                  <span style={{ fontSize: '12.5px', fontWeight: station === 'bar' ? 700 : 400 }}>☕ ارسال به پنل بار و کافه (/bar)</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input type="radio" name="station" checked={station === 'kitchen'} onChange={() => setStation('kitchen')} />
                  <span style={{ fontSize: '12.5px', fontWeight: station === 'kitchen' ? 700 : 400 }}>🍳 ارسال به پنل آشپزخانه (/kitchen)</span>
                </label>
              </div>
            </div>

            <ImagePicker key={imageKey} value={image} onChange={setImage} />

            <div className="row" style={{ marginTop: '12px', justifyContent: 'flex-start', gap: '16px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                <input type="checkbox" checked={featured} onChange={(e) => setFeatured(e.target.checked)} />
                <span style={{ fontSize: '12px' }}>⭐ نمایش در «پیشنهادهای ما»</span>
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                <input type="checkbox" checked={discounted} onChange={(e) => setDiscounted(e.target.checked)} />
                <span style={{ fontSize: '12px' }}>🏷️ نمایش در «سفارش‌های تخفیف‌دار»</span>
              </label>
            </div>

            <CustomizationEditor value={newCustomizations} onChange={setNewCustomizations} />

            <button type="submit" className="btn" style={{ marginTop: '18px', width: '100%', padding: '13px', fontSize: '14px', fontWeight: 700 }} disabled={savingAdd}>
              {savingAdd ? '⏳ درحال ذخیره و آپلود...' : '➕ ثبت فوری محصول و آماده برای بعدی'}
            </button>
            <p style={{ fontSize: '11px', color: 'var(--muted)', margin: '8px 0 0 0', textAlign: 'center' }}>
              بعد از ثبت، فرم خودکار پاک می‌شود تا محصول بعدی را بی‌درنگ وارد کنید.
            </p>
          </form>
        ) : null}

        {/* TAB 2: FAST LIST & EDIT */}
        {activeTab === 'list' ? (
          <div>
            {/* Search & Filter Bar */}
            <div className="card banner" style={{ marginBottom: '12px', padding: '12px' }}>
              <input
                className="input"
                style={{ fontSize: '16px', touchAction: 'manipulation', marginTop: 0 }}
                placeholder="🔍 جستجوی نام یا توضیحات در بین محصولات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="chips" style={{ marginTop: '10px' }}>
                <button type="button" className={`chip ${selectedCategory === 'همه' ? 'active' : ''}`} onClick={() => setSelectedCategory('همه')}>
                  همه ({products.length})
                </button>
                {categories.map((cat) => {
                  const count = products.filter((p) => (p.categories || []).includes(cat)).length;
                  return (
                    <button key={cat} type="button" className={`chip ${selectedCategory === cat ? 'active' : ''}`} onClick={() => setSelectedCategory(cat)}>
                      {cat} ({count})
                    </button>
                  );
                })}
              </div>
            </div>

            {loading ? (
              <div className="card banner" style={{ textAlign: 'center' }}>درحال بارگذاری لیست محصولات...</div>
            ) : filteredProducts.length === 0 ? (
              <div className="card banner" style={{ textAlign: 'center' }}>هیچ محصولی با این فیلتر یا جستجو یافت نشد.</div>
            ) : (
              <div style={{ display: 'grid', gap: '10px' }}>
                {filteredProducts.map((p) => (
                  <div key={p.id} className="card" style={{ padding: '12px', borderRight: `4px solid ${p.active !== false ? 'var(--primary-dark)' : '#ccc'}` }}>
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                      <img src={resolveImageUrl(p.image || '/images/menu/coffee.svg')} alt={p.name} style={{ width: '60px', height: '60px', borderRadius: '10px', objectFit: 'cover', background: '#f0f4f5' }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="row" style={{ alignItems: 'center' }}>
                          <strong style={{ fontSize: '14px', color: p.active !== false ? 'var(--primary-deep)' : '#888' }}>
                            {p.name} <span style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '6px', background: p.station === 'kitchen' ? '#FFF1DE' : '#E8F4F5', color: p.station === 'kitchen' ? '#B5651D' : '#1B6B70' }}>{p.station === 'kitchen' ? '🍳 آشپزخانه' : '☕ بار'}</span>
                          </strong>
                          <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--primary)' }}>{Number(p.price || 0).toLocaleString('fa-IR')} تومان</span>
                        </div>
                        <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '4px' }}>{(p.categories || []).join(' · ')}</div>
                        {p.desc ? <div style={{ fontSize: '11px', color: '#666', marginTop: '4px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.desc}</div> : null}
                      </div>
                    </div>

                    <div className="row" style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed var(--line)', flexWrap: 'wrap', gap: '8px' }}>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          type="button"
                          onClick={() => handleQuickToggleActive(p)}
                          className={`btn ${p.active !== false ? '' : 'secondary'}`}
                          style={{ fontSize: '11px', padding: '5px 10px' }}
                        >
                          {p.active !== false ? '✅ فعال در منو' : '🚫 غیرفعال (ناموجود)'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleQuickToggleFeatured(p)}
                          className={`btn ${p.featured ? '' : 'secondary'}`}
                          style={{ fontSize: '11px', padding: '5px 10px' }}
                        >
                          {p.featured ? '⭐ ویژه' : 'عادی'}
                        </button>
                      </div>

                      <div style={{ display: 'flex', gap: '6px' }}>
                        <button type="button" className="btn secondary" style={{ fontSize: '11px', padding: '5px 10px' }} onClick={() => setEditingItem({ ...p, categories: p.categories || [] })}>
                          ✏️ ویرایش کامل
                        </button>
                        <button type="button" className="btn secondary" style={{ fontSize: '11px', padding: '5px 10px', color: 'var(--danger)' }} onClick={() => handleDeleteProduct(p.id, p.name)}>
                          🗑️ حذف
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : null}

        {/* TAB 3: BULK PASTE IMPORT */}
        {activeTab === 'bulk-import' ? (
          <div className="card banner">
            <strong style={{ fontSize: '15px', color: 'var(--primary-deep)', display: 'block', marginBottom: '8px' }}>
              وارد کردن دسته‌جمعی محصولات (مخصوص ثبت ۸۰ محصول در ۱ دقیقه)
            </strong>
            <p style={{ fontSize: '11px', color: 'var(--muted)', lineHeight: 1.8 }}>
              محصولات خود را به صورت خط به خط در کادر زیر وارد کنید. فرمت هر خط به شکل زیر باشد:
              <br />
              <code>نام محصول | قیمت (تومان) | توضیحات</code>
              <br />
              مثال:
              <br />
              اسپرسو سینگل عربیکا | 65000 | ۱۰۰ درصد عربیکا کلمبیا
              <br />
              لته آرت ویژه | 145000 | شیر تازه و فوم مخملی
            </p>

            <label style={{ display: 'block', marginTop: '12px' }}>
              <span className="sub">انتخاب دسته‌بندی برای این گروه از محصولات:</span>
              <select className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} value={bulkCategory} onChange={(e) => setBulkCategory(e.target.value)}>
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </label>

            <div style={{ marginTop: '12px', padding: '10px', background: '#f8fcfc', borderRadius: '12px', border: '1px solid var(--line)' }}>
              <span className="sub" style={{ display: 'block', marginBottom: '6px', fontWeight: 700 }}>ایستگاه آماده‌سازی این گروه:</span>
              <div className="row" style={{ justifyContent: 'flex-start', gap: '16px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input type="radio" name="bulkStation" checked={bulkStation === 'bar'} onChange={() => setBulkStation('bar')} />
                  <span style={{ fontSize: '12.5px' }}>☕ پنل بار</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input type="radio" name="bulkStation" checked={bulkStation === 'kitchen'} onChange={() => setBulkStation('kitchen')} />
                  <span style={{ fontSize: '12.5px' }}>🍳 پنل آشپزخانه</span>
                </label>
              </div>
            </div>

            <textarea
              className="input"
              style={{ fontSize: '16px', touchAction: 'manipulation', minHeight: '180px', marginTop: '12px' }}
              placeholder="لیست محصولات خود را اینجا پیست کنید (هر محصول در یک خط)..."
              value={bulkText}
              onChange={(e) => setBulkText(e.target.value)}
            />

            <button
              type="button"
              className="btn"
              style={{ marginTop: '14px', width: '100%', padding: '12px' }}
              disabled={bulkSaving || !bulkText.trim()}
              onClick={handleBulkImport}
            >
              {bulkSaving ? 'درحال ثبت محصولات...' : '🚀 ثبت یک‌جای تمام این محصولات در منو'}
            </button>
          </div>
        ) : null}

        {/* EDIT MODAL */}
        {editingItem ? (
          <div className="bootOverlay" style={{ zIndex: 150 }}>
            <div className="card banner" style={{ width: 'min(100% - 20px, 440px)', maxHeight: '90vh', overflow: 'auto' }}>
              <div className="row" style={{ marginBottom: '12px' }}>
                <strong style={{ fontSize: '16px' }}>ویرایش محصول «{editingItem.name}»</strong>
                <button type="button" className="textOnlyAction" onClick={() => setEditingItem(null)}>بستن ×</button>
              </div>

              <label style={{ display: 'block', marginTop: '8px' }}>
                <span className="sub">نام محصول</span>
                <input className="input" style={{ fontSize: '16px' }} value={editingItem.name || ''} onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })} />
              </label>

              <div className="row" style={{ gap: '8px', marginTop: '8px' }}>
                <label style={{ flex: 1 }}>
                  <span className="sub">قیمت (تومان)</span>
                  <input className="input" style={{ fontSize: '16px' }} inputMode="numeric" value={editingItem.price ?? ''} onChange={(e) => setEditingItem({ ...editingItem, price: e.target.value })} />
                </label>
                <label style={{ flex: 1 }}>
                  <span className="sub">قیمت قبل تخفیف</span>
                  <input className="input" style={{ fontSize: '16px' }} inputMode="numeric" value={editingItem.oldPrice ?? ''} onChange={(e) => setEditingItem({ ...editingItem, oldPrice: e.target.value })} />
                </label>
              </div>

              <label style={{ display: 'block', marginTop: '8px' }}>
                <span className="sub">توضیحات</span>
                <textarea className="input" style={{ fontSize: '16px', minHeight: '60px' }} value={editingItem.desc || ''} onChange={(e) => setEditingItem({ ...editingItem, desc: e.target.value })} />
              </label>

              <div style={{ marginTop: '10px' }}>
                <span className="sub">دسته‌بندی‌ها:</span>
                <div className="chips" style={{ flexWrap: 'wrap', overflow: 'visible', marginTop: '6px' }}>
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      className={`chip ${(editingItem.categories || []).includes(cat) ? 'active' : ''}`}
                      onClick={() => {
                        const cats = editingItem.categories || [];
                        const nextCats = cats.includes(cat) ? cats.filter((c: string) => c !== cat) : [...cats, cat];
                        setEditingItem({ ...editingItem, categories: nextCats });
                      }}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ marginTop: '10px', padding: '8px', background: '#f8fcfc', borderRadius: '12px', border: '1px solid var(--line)' }}>
                <span className="sub" style={{ display: 'block', marginBottom: '6px', fontWeight: 700 }}>ایستگاه آماده‌سازی:</span>
                <div className="row" style={{ justifyContent: 'flex-start', gap: '16px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                    <input type="radio" name="editStation" checked={editingItem.station !== 'kitchen'} onChange={() => setEditingItem({ ...editingItem, station: 'bar' })} />
                    <span style={{ fontSize: '12px' }}>☕ پنل بار</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                    <input type="radio" name="editStation" checked={editingItem.station === 'kitchen'} onChange={() => setEditingItem({ ...editingItem, station: 'kitchen' })} />
                    <span style={{ fontSize: '12px' }}>🍳 پنل آشپزخانه</span>
                  </label>
                </div>
              </div>

              <ImagePicker value={editingItem.image || ''} onChange={(val) => setEditingItem({ ...editingItem, image: val })} />

              <CustomizationEditor value={normalizeCustomizations(editingItem.customizations || [])} onChange={(next) => setEditingItem({ ...editingItem, customizations: next })} />

              <div className="row" style={{ marginTop: '16px' }}>
                <button type="button" className="btn" style={{ flex: 1 }} onClick={handleSaveEditModal}>💾 ذخیره تغییرات</button>
                <button type="button" className="btn secondary" onClick={() => setEditingItem(null)}>انصراف</button>
              </div>
            </div>
          </div>
        ) : null}
      </section>
    </ProtectedPage>
  );
}
