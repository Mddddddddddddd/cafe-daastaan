import RemoteAccounting from '@/components/RemoteAccounting';

export default function AdminAccountingPage() {
  return <RemoteAccounting role="admin" />;
}
