import type { Metadata } from 'next';

// PWA جدا برای پنل مدیریت
export const metadata: Metadata = {
  manifest: '/manifest-admin.json',
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return children;
}
