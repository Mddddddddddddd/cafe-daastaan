"use client";

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { API_BASE_URL, apiDelete, apiGet, apiPatch, apiPost, authHeaders, resolveImageUrl } from '@/lib/api';
import RemoteFeedbackReport from '@/components/RemoteFeedbackReport';
import ProtectedPage from '@/components/ProtectedPage';
import InstallPwaButton from '@/components/InstallPwaButton';
import CustomizationEditor, { normalizeCustomizations } from '@/components/CustomizationEditor';

function formatStoryDate(value: string) {
  try {
    return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
  } catch {
    return value;
  }
}

function getAdminStoryPreviewUrl(value?: string) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  // /uploads به صورت نسبی برمی‌گردد تا از طریق rewrite در Next.js نمایش داده شود
  if (raw.startsWith('/uploads/') || raw.startsWith('/images/')) return raw;
  return raw;
}

const emptyCard = (title = '') => ({ id: `card-${Date.now()}`, title, text: '', image: '', visible: true });

// فشرده‌سازی تصویر در مرورگر تا حجم base64 کوچک بماند و خطای 413 (Request Too Large)
// روی Nginx/سرور رخ ندهد. برای ویدیو داده خام برمی‌گردد (فشرده نمی‌شود).
function compressImageFile(file: File, maxSize = 1600, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = reject;
      reader.readAsDataURL(file);
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const ratio = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * ratio));
        const h = Math.max(1, Math.round(img.height * ratio));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) { resolve(String(URL.createObjectURL(file))); return; }
        ctx.drawImage(img, 0, 0, w, h);
        const out = canvas.toDataURL('image/jpeg', quality);
        URL.revokeObjectURL(url);
        resolve(out);
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('تصویر خوانده نشد')); };
    img.src = url;
  });
}

// تبدیل dataURL به Blob برای ارسال multipart
function dataUrlToBlob(dataUrl: string): Blob {
  const commaIndex = dataUrl.indexOf(',');
  const meta = dataUrl.slice(0, commaIndex);
  const b64 = dataUrl.slice(commaIndex + 1);
  const mime = /data:(.*?)(;|$)/.exec(meta)?.[1] || 'application/octet-stream';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

// آپلود مستقیم فایل با multipart + نمایش پیشرفت — مخصوص استوری‌های حجیم ادمین.
// برخلاف fetch، با XMLHttpRequest پیشرفت آپلود برمی‌گردد و timeout ندارد (فایل‌های بزرگ).
function uploadMediaFile(file: File | Blob, fileName: string, onProgress?: (pct: number) => void): Promise<string> {
  return new Promise((resolve, reject) => {
    const fd = new FormData();
    fd.append('file', file as any, fileName);
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${API_BASE_URL}/stories/admin/media`);
    const headers = authHeaders();
    Object.entries(headers).forEach(([key, value]) => xhr.setRequestHeader(key, value));
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(Math.min(99, Math.round((e.loaded / e.total) * 100)));
    };
    xhr.onload = () => {
      let json: any = {};
      try { json = JSON.parse(xhr.responseText || '{}'); } catch { /* پاسخ غیر-JSON */ }
      if (xhr.status >= 200 && xhr.status < 300 && json?.success && json?.url) {
        resolve(json.url);
      } else {
        const err: any = new Error(json?.message || `HTTP ${xhr.status}`);
        err.status = xhr.status;
        reject(err);
      }
    };
    xhr.onerror = () => reject(new Error('خطای شبکه هنگام آپلود فایل.'));
    xhr.ontimeout = () => reject(new Error('آپلود زمان‌بست (timeout).'));
    xhr.timeout = 0;
    xhr.send(fd);
  });
}

// انتخاب‌گر رسانه استوری ادمین: فایل حجیم را به‌صورت File نگه می‌دارد (نه base64)
// تا هنگام انتشار مستقیم با multipart آپلود شود — بدون تورم ۳۳٪ حجمی base64.
function StoryMediaPicker({ file, url, onFile, onUrl, onClear }: { file: File | null; url: string; onFile: (f: File) => void; onUrl: (v: string) => void; onClear: () => void }) {
  const [previewUrl, setPreviewUrl] = useState('');
  useEffect(() => {
    if (file) {
      const u = URL.createObjectURL(file);
      setPreviewUrl(u);
      return () => URL.revokeObjectURL(u);
    }
    setPreviewUrl('');
  }, [file]);
  const isVideo = file ? file.type.startsWith('video') : /\.(mp4|webm|mov)(\?|$)/i.test(url);
  const previewSrc = previewUrl || (url ? resolveImageUrl(url) : '');

  return (
    <div className="adminSubCard" style={{ marginTop: '10px' }}>
      <strong className="adminSubTitle">{file ? `فایل انتخاب‌شده: ${file.name}` : 'عکس یا ویدیوی استوری ادمین'}</strong>
      <p>فایل مستقیم با آپلود multipart بارگذاری می‌شود و حجم بالا پشتیبانی می‌شود (ویدیو تا ۵۰۰ مگابایت / عکس تا ۵۰ مگابایت — قابل تنظیم با env). عکس قبل از آپلود در مرورگر فشرده می‌شود.</p>
      {previewSrc ? (isVideo
        ? <video src={previewSrc} controls style={{ width: '100%', maxHeight: '240px', marginTop: '8px', background: '#000', borderRadius: '8px' }} />
        : <div className="adminImagePreview productImageWatermark" style={{ backgroundImage: `url(${previewSrc})` }} />) : null}
      <input className="input" placeholder="لینک عکس یا ویدیو؛ اختیاری (به جای آپلود فایل)" value={url || ''} onChange={(e) => onUrl(e.target.value)} />
      <label className="btn secondary" style={{ marginTop: '8px', width: '100%', textAlign: 'center' }}>
        بارگذاری عکس یا ویدیو از سیستم (حجم بالا پشتیبانی می‌شود)
        <input type="file" accept="image/*,video/*" onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ''; }} style={{ display: 'none' }} />
      </label>
      {(file || url) ? <button className="btn secondary" style={{ marginTop: '8px', width: '100%' }} onClick={onClear}>حذف فایل / لینک</button> : null}
    </div>
  );
}

function ImagePicker({ value, onChange, label = 'عکس محصول', accept = 'image/*' }: { value: string; onChange: (value: string) => void; label?: string; accept?: string }) {
  const onFile = (file?: File) => {
    if (!file) return;
    compressImageFile(file).then(onChange).catch((err) => window.alert('خطا در خواندن فایل: ' + (err?.message || err)));
  };

  return (
    <div className="adminSubCard" style={{ marginTop: '10px' }}>
      <strong className="adminSubTitle">{label}</strong>
      <p>می‌تونی عکس را مستقیم بارگذاری کنی یا اگر خواستی لینک عکس بدهی. در حالت دیتابیس، فایل روی بک‌اند ذخیره می‌شود و URL آن داخل دیتابیس می‌ماند.</p>
      {value ? <div className="adminImagePreview productImageWatermark" style={{ backgroundImage: `url(${resolveImageUrl(value)})` }} /> : null}
      <input className="input" placeholder="لینک عکس؛ اختیاری" value={value || ''} onChange={(e) => onChange(e.target.value)} />
      <label className="btn secondary" style={{ marginTop: '8px', width: '100%', textAlign: 'center' }}>
        {accept.includes('video') ? 'بارگذاری عکس یا ویدیو از سیستم' : 'بارگذاری عکس از سیستم'}
        <input type="file" accept={accept} onChange={(e) => onFile(e.target.files?.[0])} style={{ display: 'none' }} />
      </label>
      {value ? <button className="btn secondary" style={{ marginTop: '8px', width: '100%' }} onClick={() => onChange('')}>حذف عکس</button> : null}
    </div>
  );
}

// CustomizationEditor + normalizeCustomizations در کامپوننت مشترک: components/CustomizationEditor.tsx

function Section({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  return (
    <details className="adminSection" open={defaultOpen}>
      <summary className="adminSummary">{title}</summary>
      <div className="adminPanelBody">{children}</div>
    </details>
  );
}

export default function AdminPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [homeSections, setHomeSections] = useState<any>({ promoCards: [] });
  const [status, setStatus] = useState('');
  const [publishingStory, setPublishingStory] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newOldPrice, setNewOldPrice] = useState('');
  const [newCategories, setNewCategories] = useState<string[]>(['نوشیدنی گرم']);
  const [newImage, setNewImage] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newFeatured, setNewFeatured] = useState(true);
  const [newDiscounted, setNewDiscounted] = useState(false);
  const [newStation, setNewStation] = useState<'bar' | 'kitchen'>('bar');
  const [newCustomizations, setNewCustomizations] = useState<any[]>([]);
  const [addingProduct, setAddingProduct] = useState(false);
  const [drafts, setDrafts] = useState<Record<string, any>>({});
  const [notificationTitle, setNotificationTitle] = useState('');
  const [notificationBody, setNotificationBody] = useState('');
  const [specialTitle, setSpecialTitle] = useState('');
  const [specialBody, setSpecialBody] = useState('');
  const [specialQuestion, setSpecialQuestion] = useState('');
  const [specialYesLabel, setSpecialYesLabel] = useState('بله، هستم');
  const [specialNoLabel, setSpecialNoLabel] = useState('خیر، نیستم');
  const [specialReports, setSpecialReports] = useState<any[]>([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [categoryDrafts, setCategoryDrafts] = useState<Record<string, string>>({});
  const [discountCodes, setDiscountCodes] = useState<any[]>([]);
  const [stories, setStories] = useState<any[]>([]);
  const [discountTitle, setDiscountTitle] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [discountType, setDiscountType] = useState<'percent' | 'fixed' | 'free_order'>('percent');
  const [discountValue, setDiscountValue] = useState('20');
  const [adminStoryCaption, setAdminStoryCaption] = useState('');
  const [adminStoryImage, setAdminStoryImage] = useState('');
  const [adminStoryFile, setAdminStoryFile] = useState<File | null>(null);
  const [adminStoryDuration, setAdminStoryDuration] = useState('72');
  const [adminStoryMediaType, setAdminStoryMediaType] = useState<'image' | 'video'>('image');
  const [adminStoryHighlight, setAdminStoryHighlight] = useState(false);

  // ===== مدیریت باشگاه مشتریان =====
  const [loyaltyMembers, setLoyaltyMembers] = useState<any[]>([]);
  const [loyaltyCodes, setLoyaltyCodes] = useState<any[]>([]);
  const [loyaltyQuery, setLoyaltyQuery] = useState('');
  const [loyaltyBusy, setLoyaltyBusy] = useState(false);
  const [loyaltyDeltas, setLoyaltyDeltas] = useState<Record<string, string>>({});
  const [loyaltyTiers, setLoyaltyTiers] = useState<Record<string, string>>({});
  const LOYALY_TIERS = ['راوی تازه‌وارد', 'راوی نقره‌ای', 'راوی طلایی', 'راوی پلاتینی'];

  const loadLoyalty = async (q?: string) => {
    setLoyaltyBusy(true);
    try {
      const [mRes, cRes] = await Promise.all([
        apiGet(`/loyalty/admin/members${q ? `?q=${encodeURIComponent(q)}` : ''}`),
        apiGet('/loyalty/admin/reward-codes'),
      ]);
      if (mRes?.success) setLoyaltyMembers(mRes.data || []);
      if (cRes?.success) setLoyaltyCodes(cRes.data || []);
    } catch { /* بدون اتصال */ } finally { setLoyaltyBusy(false); }
  };

  useEffect(() => { loadLoyalty(); }, []);

  const applyLoyaltyCredit = async (id: string) => {
    const v = Number((loyaltyDeltas[id] || '').replace(/\D/g, '')) || 0;
    if (!v) { setStatus('⚠️ مبلغ امتیاز را وارد کن.'); return; }
    const res = await apiPatch(`/loyalty/admin/members/${id}`, { delta: v, tier: loyaltyTiers[id] || undefined });
    if (res?.success) { setStatus('✅ امتیاز اعطا شد.'); setLoyaltyDeltas((d) => ({ ...d, [id]: '' })); loadLoyalty(loyaltyQuery); }
    else setStatus('❌ ' + (res?.message || 'خطا در اعطای امتیاز.'));
  };

  const applyLoyaltyDebit = async (id: string) => {
    const v = Number((loyaltyDeltas[id] || '').replace(/\D/g, '')) || 0;
    if (!v) { setStatus('⚠️ مبلغ امتیاز را وارد کن.'); return; }
    const res = await apiPatch(`/loyalty/admin/members/${id}`, { delta: -v, tier: loyaltyTiers[id] || undefined });
    if (res?.success) { setStatus('✅ امتیاز کسر شد.'); setLoyaltyDeltas((d) => ({ ...d, [id]: '' })); loadLoyalty(loyaltyQuery); }
    else setStatus('❌ ' + (res?.message || 'خطا در کسر امتیاز.'));
  };

  const applyLoyaltyTier = async (id: string) => {
    const res = await apiPatch(`/loyalty/admin/members/${id}`, { delta: 0, tier: loyaltyTiers[id] || undefined });
    if (res?.success) { setStatus('✅ تیر عضو به‌روزرسانی شد.'); loadLoyalty(loyaltyQuery); }
    else setStatus('❌ ' + (res?.message || 'خطا در تغییر تیر.'));
  };

  const disableLoyaltyCode = async (id: string) => {
    const res = await apiPost(`/loyalty/admin/reward-codes/${id}/disable`);
    if (res?.success) { setStatus('✅ کد جایزه غیرفعال شد.'); loadLoyalty(loyaltyQuery); }
    else setStatus('❌ ' + (res?.message || 'خطا در غیرفعال‌سازی کد.'));
  };

  // ===== بکاپ و بازیابی =====
  const [backupBusy, setBackupBusy] = useState('');
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [clearingCache, setClearingCache] = useState(false);

  const clearCaches = async () => {
    setClearingCache(true);
    setStatus('⏳ در حال پاک‌سازی کش...');
    try {
      // ۱) کش‌های محلی مرورگر (اطلاعات ورود و سبد خرید دست‌نخورده می‌ماند)
      ['cafe_dastan_admin_tables', 'seenNotificationsCount', 'cafe_dastan_install_dismissed', 'cafe_dastan_pwa_installed'].forEach((k) => {
        try { localStorage.removeItem(k); } catch { /* ignore */ }
      });
      for (const storage of [localStorage, sessionStorage]) {
        for (let i = storage.length - 1; i >= 0; i--) {
          const key = storage.key(i);
          if (key && (key.startsWith('survey_') || key.startsWith('tracking_seen_'))) storage.removeItem(key);
        }
      }
      // ۲) به‌روزرسانی service worker (کش فایل ندارد؛ فقط مطمئن می‌شویم نسخه جدید فعال است)
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map((reg) => reg.update().catch(() => null)));
      }
      // ۳) تطبیق کش سمت سرور
      await apiPost('/admin/cache/clear', {});
      setStatus('✅ کش پاک شد؛ صفحه با داده‌های تازه بارگذاری می‌شود...');
      setTimeout(() => { window.location.href = `/admin?fresh=${Date.now()}`; }, 700);
    } catch {
      setStatus('❌ پاک‌سازی کش با خطا روبه‌رو شد.');
    }
    setClearingCache(false);
  };

  const downloadBackupZip = async (kind: 'products' | 'full') => {
    setBackupBusy(kind);
    setStatus('⏳ در حال ساخت فایل بکاپ (بکاپ کامل ممکن است ۱ تا ۲ دقیقه طول بکشد)...');
    try {
      const res = await fetch(`${API_BASE_URL}/admin/backup/${kind}`, { headers: authHeaders() });
      if (!res.ok) {
        let msg = 'درخواست بکاپ ناموفق بود.';
        try { const j = await res.json(); if (j?.message) msg = j.message; } catch { /* بدنه خطا JSON نیست */ }
        throw new Error(msg);
      }
      const blob = await res.blob();
      if (!blob.size) throw new Error('فایل بکاپ خالی برگشت؛ دوباره تلاش کن.');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const day = new Date().toISOString().slice(0, 10);
      a.download = kind === 'products' ? `cafe-dastan-products-${day}.zip` : `cafe-dastan-full-${day}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      // revoke دیرهنگام — revoke فوری در مرورگرهای موبایل دانلود را نصفه‌کاره می‌کند
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      setStatus('✅ فایل بکاپ آماده شد؛ دانلود در مرورگر شروع شد (در فهرست دانلودها چک کن).');
    } catch (error) {
      setStatus('❌ ' + ((error as Error)?.message || 'ساخت فایل بکاپ ناموفق بود.'));
    } finally { setBackupBusy(''); }
  };

  const handleRestoreProducts = async () => {
    if (!restoreFile) { setStatus('⚠️ اول فایل products.json را انتخاب کن.'); return; }
    setBackupBusy('restore');
    setStatus('⏳ در حال بازیابی محصولات...');
    try {
      const text = await restoreFile.text();
      const json = JSON.parse(text);
      const res = await apiPost('/admin/backup/restore-products', json);
      if (res?.success) { setStatus(res.message || '✅ محصولات بازیابی شد.'); setRestoreFile(null); load(); }
      else setStatus('❌ ' + (res?.message || 'خطا در بازیابی.'));
    } catch {
      setStatus('❌ فایل انتخابی یک JSON معتبر نیست (فایل products.json داخل ZIP بکاپ محصولات).');
    } finally { setBackupBusy(''); }
  };
  const [newTableName, setNewTableName] = useState('');
  const [newTableSlug, setNewTableSlug] = useState('');
  const [newTableCode, setNewTableCode] = useState('');
  const [activeQrTable, setActiveQrTable] = useState<any>(null);
  const [selectedStaffUser, setSelectedStaffUser] = useState('admin');
  const [newStaffPassword, setNewStaffPassword] = useState('');

  const toggleCategory = (arr: string[], cat: string) => arr.includes(cat) ? arr.filter((c) => c !== cat) : [...arr, cat];

  const scrollStatusIntoView = () => {
    if (typeof window === 'undefined') return;
    window.setTimeout(() => {
      const el = document.getElementById('admin-status-banner');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 50);
  };

  const load = async () => {
    const res = await apiGet('/admin/products');
    if (!res?.success) {
      setStatus(res?.message || 'دسترسی مجاز نیست.');
      return;
    }
    setProducts(res.data || []);
    setCategories(res.categories || []);
    const categoryDraftMap: Record<string, string> = {};
    (res.categories || []).forEach((cat: string) => { categoryDraftMap[cat] = cat; });
    setCategoryDrafts(categoryDraftMap);
    setHomeSections({ promoCards: [], showHero: false, showMemoryMood: false, showSuggested: true, showDiscounted: true, ...(res.homeSections || {}) });
    setDiscountCodes(res.discountCodes || []);
    const storyRes = await apiGet('/stories/admin/all');
    setStories(storyRes?.data || []);
    const specialRes = await apiGet('/notifications/special/report');
    setSpecialReports(specialRes?.data || []);
    const nextDrafts: Record<string, any> = {};
    (res.data || []).forEach((p: any) => { nextDrafts[p.id] = { ...p, customizations: normalizeCustomizations(p.customizations || []), featured: !!p.featured, discounted: !!p.discounted, active: p.active !== false }; });
    setDrafts(nextDrafts);
  };

  useEffect(() => { load(); }, []);

  const addProduct = async () => {
    if (!newName || !newPrice) return;
    setAddingProduct(true);
    setStatus('درحال افزودن محصول...');
    try {
      const res = await apiPost('/admin/products', { name: newName, price: Number(newPrice), oldPrice: newOldPrice ? Number(newOldPrice) : undefined, categories: newCategories, image: newImage, desc: newDesc, station: newStation, featured: newFeatured, discounted: newDiscounted || !!newOldPrice, customizations: normalizeCustomizations(newCustomizations) });
      if (res?.success) {
        setNewName(''); setNewPrice(''); setNewOldPrice(''); setNewCategories([categories[0] || 'نوشیدنی گرم']); setNewImage(''); setNewDesc(''); setNewCustomizations([]); setNewFeatured(true); setNewDiscounted(false); setNewStation('bar');
        setStatus('✅ محصول جدید اضافه شد.');
      } else {
        setStatus(res?.message || '❌ خطا در افزودن محصول.');
      }
      load();
    } catch (err) {
      setStatus('❌ خطای شبکه در افزودن محصول. دوباره تلاش کنید.');
    } finally {
      setAddingProduct(false);
    }
  };

  const saveProduct = async (id: string) => { await apiPatch(`/admin/products/${id}`, { ...drafts[id], customizations: normalizeCustomizations(drafts[id]?.customizations || []) }); setStatus('محصول ذخیره شد.'); load(); };
  const removeProduct = async (id: string) => { await apiDelete(`/admin/products/${id}`); setStatus('محصول حذف شد.'); load(); };
  const addCategory = async () => { if (!newCategoryName.trim()) return; await apiPost('/admin/products/categories', { name: newCategoryName }); setNewCategoryName(''); setStatus('دسته‌بندی اضافه شد.'); load(); };
  const saveCategory = async (oldName: string) => { const nextName = categoryDrafts[oldName]; if (!nextName?.trim()) return; await apiPatch(`/admin/products/categories/${encodeURIComponent(oldName)}`, { name: nextName }); setStatus('دسته‌بندی به‌روزرسانی شد.'); load(); };
  const removeCategory = async (name: string) => { await apiDelete(`/admin/products/categories/${encodeURIComponent(name)}`); setStatus('دسته‌بندی حذف شد.'); load(); };
  const createDiscount = async () => { const res = await apiPost('/admin/products/discounts', { title: discountTitle || 'کد تخفیف', code: discountCode, type: discountType, value: discountType === 'free_order' ? 999999999 : Number(discountValue || 0), once: true, active: true }); if (res.success) { setDiscountTitle(''); setDiscountCode(''); setDiscountValue('20'); setStatus('کد تخفیف ساخته شد.'); load(); } };
  const removeDiscount = async (id: string) => { await apiDelete(`/admin/products/discounts/${id}`); setStatus('کد تخفیف حذف شد.'); load(); };
  const updateHome = (patch: any) => setHomeSections((h: any) => ({ ...h, ...patch }));
  const updatePromoCard = (index: number, patch: any) => setHomeSections((h: any) => ({ ...h, promoCards: (h.promoCards || []).map((c: any, i: number) => i === index ? { ...c, ...patch } : c) }));
  const addPromoCard = () => setHomeSections((h: any) => ({ ...h, promoCards: [...(h.promoCards || []), emptyCard('کارت جدید')] }));
  const removePromoCard = (index: number) => setHomeSections((h: any) => ({ ...h, promoCards: (h.promoCards || []).filter((_: any, i: number) => i !== index) }));
  const saveHome = async () => { await apiPatch('/admin/products/home/sections/update', homeSections); setStatus('صفحه اصلی ذخیره شد.'); load(); };
  const sendNotification = async () => { if (!notificationTitle || !notificationBody) return; await apiPost('/notifications/broadcast', { title: notificationTitle, body: notificationBody }); setNotificationTitle(''); setNotificationBody(''); setStatus('اعلان ارسال شد.'); };
  const sendSpecialNotification = async () => {
    if (!specialTitle || !specialBody) return;
    const res = await apiPost('/notifications/special', {
      title: specialTitle,
      body: specialBody,
      question: specialQuestion || specialTitle,
      yesLabel: specialYesLabel || 'بله، هستم',
      noLabel: specialNoLabel || 'خیر، نیستم',
      durationHours: 10,
    });
    if (res?.success) {
      setSpecialTitle('');
      setSpecialBody('');
      setSpecialQuestion('');
      setSpecialYesLabel('بله، هستم');
      setSpecialNoLabel('خیر، نیستم');
      setStatus('اعلان ویژه ۱۰ ساعته ارسال شد.');
      load();
      return;
    }
    setStatus(res?.message || 'ارسال اعلان ویژه ناموفق بود.');
  };
  const removeSpecialNotification = async (id: string) => {
    const res = await apiDelete(`/notifications/special/${id}`);
    setStatus(res?.success ? 'اعلان ویژه حذف شد.' : (res?.message || 'حذف اعلان ویژه ناموفق بود.'));
    load();
  };
  const removeStory = async (id: string) => { await apiDelete(`/stories/${id}/admin`); setStatus('استوری حذف شد.'); load(); };
  const publishAdminStory = async () => {
    if (publishingStory) return;
    if (!adminStoryFile && !adminStoryImage) {
      setStatus('⚠️ اول عکس یا ویدیوی استوری ادمین را انتخاب کن.');
      scrollStatusIntoView();
      return;
    }
    setPublishingStory(true);
    scrollStatusIntoView();
    try {
      let mediaUrl = '';
      let mediaType: 'image' | 'video';

      if (adminStoryFile) {
        // فایل از سیستم: آپلود مستقیم multipart با پیشرفت (حجم بالا)
        mediaType = adminStoryFile.type.startsWith('video') ? 'video' : 'image';
        let uploadBlob: Blob = adminStoryFile;
        let uploadName = adminStoryFile.name || 'story';
        if (mediaType === 'image') {
          // عکس را قبل از آپلود فشرده کن تا سریع‌تر و کوچک‌تر برود
          setStatus('⏳ در حال فشرده‌سازی تصویر...');
          try {
            uploadBlob = dataUrlToBlob(await compressImageFile(adminStoryFile));
            uploadName = 'story-image.jpg';
          } catch { /* اگر فشرده‌سازی شکست، فایل اصلی ارسال می‌شود */ }
        }
        setStatus('⏳ آپلود فایل استوری: 0%');
        scrollStatusIntoView();
        try {
          mediaUrl = await uploadMediaFile(uploadBlob, uploadName, (pct) => setStatus(`⏳ آپلود فایل استوری: ${pct}%`));
        } catch (upErr: any) {
          const status = upErr?.status;
          if ((status === 404 || status === 405) && adminStoryFile.size <= 20 * 1024 * 1024) {
            // بک‌اند قدیمی (بدون endpoint آپلود): fallback به روش base64 برای فایل‌های زیر 20MB
            setStatus('⏳ بک‌اند قدیمی است؛ آپلود با روش قدیمی (base64)...');
            mediaUrl = await compressImageFile(adminStoryFile);
          } else if (status === 404 || status === 405) {
            throw new Error('برای فایل‌های بزرگ، بک‌اند به‌روز باید روی سرور باشد. اول بک‌اند را deploy کن.');
          } else {
            throw upErr;
          }
        }
      } else {
        // لینک دستی / base64 قدیمی
        mediaUrl = adminStoryImage;
        const detectedType: 'image' | 'video' =
          (mediaUrl.startsWith('data:video') || /\.(mp4|webm|mov)(\?|$)/i.test(mediaUrl)) ? 'video' : 'image';
        mediaType = adminStoryMediaType === 'video' || detectedType === 'video' ? 'video' : 'image';
      }

      setStatus('⏳ در حال انتشار استوری...');
      const res = await apiPost('/stories/admin', {
        userName: 'ادمین کافه',
        caption: adminStoryCaption,
        image: mediaUrl,
        mediaType,
        isHighlight: adminStoryHighlight,
        ownerId: 'admin-story-owner',
        durationHours: Number(adminStoryDuration || 72),
      });
      if (res?.success) {
        setAdminStoryCaption('');
        setAdminStoryImage('');
        setAdminStoryFile(null);
        setAdminStoryDuration('72');
        setAdminStoryMediaType('image');
        setAdminStoryHighlight(false);
        setStatus('✅ استوری ادمین منتشر شد.');
        load();
      } else {
        const msg = res?.message || 'خطا در انتشار استوری ادمین.';
        setStatus('❌ ' + msg);
        console.error('Story publish failed:', res);
        if (typeof window !== 'undefined') window.alert('خطای انتشار استوری: ' + msg);
      }
    } catch (err: any) {
      console.error('Story publish threw:', err);
      setStatus('❌ خطای شبکه در انتشار استوری. دوباره تلاش کنید.');
      if (typeof window !== 'undefined') window.alert('خطای شبکه هنگام انتشار استوری:\n' + (err?.message || err));
    } finally {
      setPublishingStory(false);
      scrollStatusIntoView();
    }
  };

  const defaultAdminTables = [
    { id: 't1', name: 'میز فروغ ۱', slug: 'forough-01', code: 'QR-FOROUGH-01' },
    { id: 't2', name: 'میز فروغ ۲', slug: 'forough-02', code: 'QR-FOROUGH-02' },
    { id: 't3', name: 'میز داستان ۱', slug: 'dastan-01', code: 'QR-DASTAN-01' },
    { id: 't4', name: 'میز VIP ۱', slug: 'vip-01', code: 'QR-VIP-01' },
  ];

  const tablesList = Array.isArray(homeSections.tables) && homeSections.tables.length
    ? homeSections.tables
    : (typeof window !== 'undefined' && localStorage.getItem('cafe_dastan_admin_tables')
        ? JSON.parse(localStorage.getItem('cafe_dastan_admin_tables')!)
        : defaultAdminTables);

  const saveTablesList = async (nextTables: any[]) => {
    if (typeof window !== 'undefined') localStorage.setItem('cafe_dastan_admin_tables', JSON.stringify(nextTables));
    setHomeSections((prev: any) => ({ ...prev, tables: nextTables }));
    await apiPatch('/admin/products/home/sections/update', { ...homeSections, tables: nextTables });
    setStatus('لیست میزها و بارکدها ذخیره شد.');
  };

  const addTableItem = () => {
    if (!newTableName.trim()) { setStatus('نام میز را وارد کنید.'); return; }
    const slug = newTableSlug.trim() || newTableName.trim().replace(/\s+/g, '-').toLowerCase();
    const code = newTableCode.trim() || `QR-${slug.toUpperCase()}`;
    const next = [...tablesList, { id: `tbl_${Date.now()}`, name: newTableName.trim(), slug, code }];
    saveTablesList(next);
    setNewTableName('');
    setNewTableSlug('');
    setNewTableCode('');
  };

  const removeTableItem = (index: number) => {
    const next = [...tablesList];
    next.splice(index, 1);
    saveTablesList(next);
  };

  return (
    <ProtectedPage role="admin" title="پنل ادمین">
      <div className="row contentPad" style={{ justifyContent: 'flex-end', gap: '6px', flexWrap: 'wrap', paddingBottom: 0 }}>
        <InstallPwaButton role="admin" label="نصب مدیریت" />
      </div>
      <section className="contentPad" style={{ paddingTop: 0 }}>
        <div className="card banner brandPattern">
          <div className="row"><strong>مدیریت کامل کافه داستان</strong><Link href="/admin/accounting" className="btn">حسابداری</Link></div>
          <p>از اینجا می‌تونی محصولات، دسته‌بندی، تخفیف، صفحه اصلی و اعلان‌ها را مدیریت کنی.</p>
          <div className="row" style={{ marginTop: '10px', gap: '8px', alignItems: 'center' }}>
            <button className="btn secondary" style={{ flex: 1 }} onClick={clearCaches} disabled={clearingCache}>
              {clearingCache ? '⏳ در حال پاک‌سازی...' : '🧹 پاک‌سازی کش و اعمال آپدیت‌ها'}
            </button>
          </div>
          {status ? <p id="admin-status-banner">{status}</p> : null}
        </div>

        <div className="card banner" style={{ marginTop: '12px', background: 'linear-gradient(135deg, #12383C, #1B6B70)', color: '#fff', border: '1px solid rgba(255,255,255,.2)', boxShadow: '0 12px 28px rgba(18,56,60,.22)' }}>
          <div className="row" style={{ alignItems: 'center' }}>
            <div>
              <strong style={{ fontSize: '15px', color: '#fff', display: 'block', marginBottom: '4px' }}>🚀 پنل اختصاصی افزودن و مدیریت پیشرفته محصولات (مخصوص ۸۰+ محصول)</strong>
              <div style={{ fontSize: '11px', color: 'rgba(255,255,255,.85)', lineHeight: 1.8 }}>محیطی سریع، جداگانه و حرفه‌ای برای ثبت متوالی در ۰.۵ ثانیه، ویرایش آنی قیمت‌ها و مدیریت دسته‌جمعی.</div>
            </div>
          </div>
          <Link href="/admin/products-manager" className="btn" style={{ marginTop: '12px', width: '100%', textAlign: 'center', background: '#FFB86B', color: '#12383C', fontWeight: 700, padding: '12px', fontSize: '14px', boxShadow: '0 8px 20px rgba(255,184,107,.3)' }}>
            ⚡ ورود به پنل مدیریت سریع و پیشرفته محصولات →
          </Link>
        </div>
      </section>

      <section className="contentPad" style={{ display: 'grid', gap: '14px' }}>
        <Section title="افزودن محصول" defaultOpen>
          <div className="card banner">
            <input className="input" placeholder="نام محصول" value={newName} onChange={(e) => setNewName(e.target.value)} />
            <input className="input" inputMode="numeric" placeholder="قیمت" value={newPrice} onChange={(e) => setNewPrice(e.target.value)} />
            <input className="input" inputMode="numeric" placeholder="قیمت قبل از تخفیف" value={newOldPrice} onChange={(e) => setNewOldPrice(e.target.value)} />
            <textarea className="input" placeholder="توضیح محصول" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} />
            <ImagePicker value={newImage} onChange={setNewImage} />
            <div className="adminChipScroller"><div className="chips">{categories.map((cat) => <button key={cat} className={`chip ${newCategories.includes(cat) ? 'active' : ''}`} onClick={() => setNewCategories(toggleCategory(newCategories, cat))}>{cat}</button>)}</div></div>
            <div className="row"><label><input type="checkbox" checked={newFeatured} onChange={(e) => setNewFeatured(e.target.checked)} /> ویژه</label><label><input type="checkbox" checked={newDiscounted} onChange={(e) => setNewDiscounted(e.target.checked)} /> تخفیف‌دار</label></div>
            <div className="adminSubCard" style={{ marginTop: '10px' }}>
              <strong className="adminSubTitle">ایستگاه آماده‌سازی (این محصول به کدام پنل برود؟)</strong>
              <div className="row" style={{ justifyContent: 'flex-start', gap: '16px', marginTop: '6px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}><input type="radio" name="adminStation" checked={newStation === 'bar'} onChange={() => setNewStation('bar')} /> ☕ پنل بار</label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}><input type="radio" name="adminStation" checked={newStation === 'kitchen'} onChange={() => setNewStation('kitchen')} /> 🍳 پنل آشپزخانه</label>
              </div>
            </div>
            <CustomizationEditor value={newCustomizations} onChange={setNewCustomizations} />
            <button className="btn" onClick={addProduct} disabled={addingProduct}>{addingProduct ? 'درحال افزودن...' : 'افزودن محصول'}</button>
          </div>
        </Section>

        

        <Section title="مدیریت محصولات">
          {products.map((p) => (
            <details key={p.id} className="adminProductDetails">
              <summary className="adminProductSummary"><strong>{drafts[p.id]?.name || p.name}</strong><span className="price">{Number(drafts[p.id]?.price || p.price || 0).toLocaleString('fa-IR')} تومان</span></summary>
              <div className="card banner adminProductBody">
                <input className="input" value={drafts[p.id]?.name || ''} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], name: e.target.value } }))} />
                <input className="input" inputMode="numeric" value={drafts[p.id]?.price ?? ''} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], price: e.target.value } }))} />
                <input className="input" inputMode="numeric" value={drafts[p.id]?.oldPrice ?? ''} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], oldPrice: e.target.value } }))} />
                <textarea className="input" value={drafts[p.id]?.desc || ''} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], desc: e.target.value } }))} />
                <ImagePicker value={drafts[p.id]?.image || ''} onChange={(value) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], image: value } }))} />
                <div className="adminChipScroller"><div className="chips">{categories.map((cat) => <button key={cat} className={`chip ${drafts[p.id]?.categories?.includes(cat) ? 'active' : ''}`} onClick={() => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], categories: toggleCategory(d[p.id]?.categories || [], cat) } }))}>{cat}</button>)}</div></div>
                <div className="row"><label><input type="checkbox" checked={!!drafts[p.id]?.featured} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], featured: e.target.checked } }))} /> ویژه</label><label><input type="checkbox" checked={!!drafts[p.id]?.discounted} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], discounted: e.target.checked } }))} /> تخفیف‌دار</label><label><input type="checkbox" checked={drafts[p.id]?.active !== false} onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], active: e.target.checked } }))} /> فعال</label></div>
                <CustomizationEditor value={drafts[p.id]?.customizations || []} onChange={(next) => setDrafts((d) => ({ ...d, [p.id]: { ...d[p.id], customizations: next } }))} />
                <div className="adminActionRow"><button className="btn" onClick={() => saveProduct(p.id)}>ذخیره</button><button className="btn secondary" onClick={() => removeProduct(p.id)}>حذف</button></div>
              </div>
            </details>
          ))}
        </Section>

        <Section title="مدیریت دسته‌بندی‌ها">
          <div className="card banner">
            <div className="adminInlineForm"><input className="input" placeholder="نام دسته‌بندی جدید" value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)} /><button className="btn" onClick={addCategory}>افزودن</button></div>
            <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>{categories.map((cat) => <div key={cat} className="adminInlineForm"><input className="input" value={categoryDrafts[cat] || ''} onChange={(e) => setCategoryDrafts((d) => ({ ...d, [cat]: e.target.value }))} /><button className="btn" onClick={() => saveCategory(cat)}>ذخیره</button><button className="btn secondary" onClick={() => removeCategory(cat)}>حذف</button></div>)}</div>
          </div>
        </Section>

        <Section title="کدهای تخفیف">
          <div className="card banner">
            <input className="input" placeholder="عنوان تخفیف" value={discountTitle} onChange={(e) => setDiscountTitle(e.target.value)} />
            <input className="input" placeholder="کد تخفیف" value={discountCode} onChange={(e) => setDiscountCode(e.target.value)} />
            <select className="input" value={discountType} onChange={(e) => setDiscountType(e.target.value as any)}><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت</option><option value="free_order">سفارش رایگان</option></select>
            <input className="input" inputMode="numeric" placeholder="مقدار" value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} />
            <button className="btn" onClick={createDiscount}>ساخت کد</button>
            <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>{discountCodes.map((d) => <div key={d.id} className="row"><span>{d.code} - {d.title}</span><button className="btn secondary" onClick={() => removeDiscount(d.id)}>حذف</button></div>)}</div>
          </div>
        </Section>

        <Section title="مدیریت صفحه اصلی">
          <div className="card banner">
            <input className="input" placeholder="عنوان هدر" value={homeSections.heroTitle || ''} onChange={(e) => updateHome({ heroTitle: e.target.value })} />
            <textarea className="input" placeholder="زیرعنوان هدر" value={homeSections.heroSubtitle || ''} onChange={(e) => updateHome({ heroSubtitle: e.target.value })} />
            <input className="input" placeholder="کد تبلیغاتی" value={homeSections.promoCode || ''} onChange={(e) => updateHome({ promoCode: e.target.value })} />
            <ImagePicker value={homeSections.heroImage || ''} onChange={(value) => updateHome({ heroImage: value })} label="عکس هدر" />
            <div className="row"><label><input type="checkbox" checked={!!homeSections.showHero} onChange={(e) => updateHome({ showHero: e.target.checked })} /> نمایش هدر</label><label><input type="checkbox" checked={homeSections.showSuggested !== false} onChange={(e) => updateHome({ showSuggested: e.target.checked })} /> پیشنهادها</label><label><input type="checkbox" checked={homeSections.showDiscounted !== false} onChange={(e) => updateHome({ showDiscounted: e.target.checked })} /> تخفیف‌ها</label><label><input type="checkbox" checked={homeSections.watermark === true} onChange={(e) => updateHome({ watermark: e.target.checked })} /> واترمارک روی عکس محصولات</label></div>
            <div style={{ display: 'grid', gap: '12px', marginTop: '10px' }}>{(homeSections.promoCards || []).map((card: any, index: number) => <div key={card.id || index} className="card"><input className="input" value={card.title || ''} onChange={(e) => updatePromoCard(index, { title: e.target.value })} /><textarea className="input" value={card.text || ''} onChange={(e) => updatePromoCard(index, { text: e.target.value })} /><ImagePicker value={card.image || ''} onChange={(value) => updatePromoCard(index, { image: value })} label="عکس کارت" /><label><input type="checkbox" checked={card.visible !== false} onChange={(e) => updatePromoCard(index, { visible: e.target.checked })} /> نمایش</label><button className="btn secondary" onClick={() => removePromoCard(index)}>حذف کارت</button></div>)}</div>
            <div className="adminActionRow"><button className="btn secondary" onClick={addPromoCard}>افزودن کارت</button><button className="btn" onClick={saveHome}>ذخیره</button></div>
          </div>
        </Section>

        <Section title="مدیریت میزها و ساخت بارکد (QR Code)">
          <div className="card banner">
            <p>در این بخش می‌توانید نام میزها، آدرس اختصاصی هر میز و بارکد (QR Code) اختصاصی آن را بسازید. مشتری با اسکن بارکد مستقیماً روی میز انتخاب‌شده قرار می‌گیرد.</p>
            <div className="adminSubCard" style={{ marginTop: '10px' }}>
              <strong className="adminSubTitle">افزودن میز جدید</strong>
              <input className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} placeholder="نام میز (مثلاً: میز فروغ ۱ یا میز بالکن ۲)" value={newTableName} onChange={(e) => { setNewTableName(e.target.value); if (!newTableSlug) setNewTableSlug(e.target.value.replace(/[^a-zA-Z0-9-]/g, '').toLowerCase()); }} />
              <input className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} placeholder="شناسه یا لینک انگلیسی میز (مثلاً: forough-01)" value={newTableSlug} onChange={(e) => setNewTableSlug(e.target.value)} />
              <input className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} placeholder="کد بارکد (مثلاً: QR-FOROUGH-01)" value={newTableCode} onChange={(e) => setNewTableCode(e.target.value)} />
              {newTableSlug ? <div className="sub" style={{ marginTop: '4px', color: 'var(--primary-dark)' }}>لینک ورود مشتری: cafedaastaan.ir/table/{newTableSlug}</div> : null}
              <button className="btn" style={{ marginTop: '10px', width: '100%' }} onClick={addTableItem}>افزودن میز و ساخت بارکد</button>
            </div>

            <div style={{ display: 'grid', gap: '8px', marginTop: '14px' }}>
              {tablesList.map((tbl: any, index: number) => (
                <div key={tbl.id || index} className="card" style={{ padding: '10px', display: 'grid', gap: '6px', borderRight: '4px solid var(--primary-dark)' }}>
                  <div className="row">
                    <strong>{tbl.name}</strong>
                    <span className="mini">{tbl.code}</span>
                  </div>
                  <div className="sub">لینک: /table/{tbl.slug}</div>
                  <div className="row" style={{ marginTop: '4px' }}>
                    <button className="btn" style={{ fontSize: '11px', padding: '6px 10px' }} onClick={() => setActiveQrTable(tbl)}>مشاهده و چاپ بارکد (QR Code)</button>
                    <button className="btn secondary" style={{ fontSize: '11px', padding: '6px 10px' }} onClick={() => removeTableItem(index)}>حذف میز</button>
                  </div>
                </div>
              ))}
            </div>

            {activeQrTable ? (
              <div id="printable-qr-box" className="card banner" style={{ marginTop: '16px', padding: '16px', background: '#f8fcfc', border: '2px solid var(--primary-dark)', textAlign: 'center' }}>
                <div className="row" style={{ marginBottom: '12px' }}>
                  <strong>بارکد اختصاصی میز</strong>
                  <button className="textOnlyAction" onClick={() => setActiveQrTable(null)}>بستن ×</button>
                </div>
                <div style={{ background: '#fff', padding: '18px', borderRadius: '16px', display: 'inline-block', border: '1px solid var(--line)', boxShadow: '0 8px 24px rgba(18,56,60,.12)' }}>
                  <img src="/images/cafedastan_logo_transparent.png" alt="لوگو" style={{ height: '36px', objectFit: 'contain', marginBottom: '8px', display: 'block', margin: '0 auto 8px' }} />
                  <strong style={{ fontSize: '16px', color: 'var(--primary-deep)', display: 'block', marginBottom: '10px' }}>{activeQrTable.name}</strong>
                  <img src={`https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(`https://cafedaastaan.ir/table/${activeQrTable.slug}`)}`} alt="QR Code" style={{ width: '220px', height: '220px', display: 'block', margin: '0 auto', border: '1px solid #eee', borderRadius: '12px' }} />
                  <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '10px' }}>کد میز: {activeQrTable.code}</div>
                  <div style={{ fontSize: '10px', color: '#1B6B70', marginTop: '2px', direction: 'ltr' }}>cafedaastaan.ir/table/{activeQrTable.slug}</div>
                </div>
                <div style={{ marginTop: '14px' }}>
                  <button className="btn" onClick={() => window.print()}>چاپ این بارکد (Print / Save PDF)</button>
                </div>
              </div>
            ) : null}
          </div>
        </Section>

        <Section title="تغییر رمز عبور بخش‌های پرسنلی (ادمین، بار، آشپزخانه، ویتر)">
          <div className="card banner">
            <p>از این بخش می‌توانید رمز عبور ورود به پنل‌های مختلف کارکنان و ادمین را به دلخواه خود تغییر دهید. بعد از تغییر، کاربر در تلاش بعدی باید با رمز جدید وارد شود.</p>
            <div className="adminSubCard" style={{ marginTop: '10px' }}>
              <strong className="adminSubTitle">انتخاب بخش و تعیین رمز جدید</strong>
              <select className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} value={selectedStaffUser} onChange={(e) => setSelectedStaffUser(e.target.value)}>
                <option value="admin">مدیریت کل (admin)</option>
                <option value="bar">مسئول بار و کافه (bar)</option>
                <option value="kitchen">مسئول آشپزخانه (kitchen)</option>
                <option value="waiter">سالن‌کار / ویتر (waiter)</option>
              </select>
              <input className="input" style={{ fontSize: '16px', touchAction: 'manipulation' }} type="text" placeholder="رمز عبور جدید (حداقل ۴ کاراکتر)" value={newStaffPassword} onChange={(e) => setNewStaffPassword(e.target.value)} />
              <button
                className="btn"
                style={{ marginTop: '12px', width: '100%' }}
                onClick={async () => {
                  if (!newStaffPassword || newStaffPassword.trim().length < 4) {
                    setStatus('رمز عبور باید حداقل ۴ کاراکتر باشد.');
                    return;
                  }
                  const res = await apiPatch(`/admin/products/staff/${selectedStaffUser}/password`, { password: newStaffPassword.trim() });
                  setStatus(res?.message || (res?.success ? 'رمز عبور با موفقیت تغییر کرد.' : 'خطا در تغییر رمز عبور.'));
                  if (res?.success) setNewStaffPassword('');
                }}
              >
                تغییر و ذخیره رمز عبور
              </button>
            </div>
            <div className="sub" style={{ marginTop: '10px', lineHeight: 1.8 }}>
              💡 نکته برای سرور اصلی: اگر دسترسی به پنل ادمین را فراموش کردید، همیشه می‌توانید در ترمینال سرور دستور زیر را بزنید تا رمزها به حالت اولیه (admin123 و...) ریست شوند:
              <br />
              <code style={{ background: '#eef7f7', padding: '2px 6px', borderRadius: '6px', direction: 'ltr', display: 'inline-block', marginTop: '4px' }}>cd /var/www/cafe-dastan/backend && npm run prisma:seed</code>
            </div>
          </div>
        </Section>

        <Section title="مدیریت استوری‌ها">
          <div className="card banner">
            <p>از این بخش می‌توانی استوری‌های ثبت‌شده را ببینی و حذف کنی. ادمین می‌تواند استوری با زمان بیشتر از ۲۴ ساعت هم منتشر کند.</p>
            <div className="adminSubCard" style={{ marginTop: '10px' }}>
              <strong className="adminSubTitle">انتشار استوری ادمین</strong>
              <input className="input" placeholder="کپشن استوری ادمین" value={adminStoryCaption} onChange={(e) => setAdminStoryCaption(e.target.value)} />
              <select className="input" value={adminStoryMediaType} onChange={(e) => setAdminStoryMediaType(e.target.value as 'image' | 'video')}>
                <option value="image">استوری تصویری</option>
                <option value="video">استوری ویدیویی</option>
              </select>
              <input className="input" inputMode="numeric" placeholder="مدت نمایش به ساعت" value={adminStoryDuration} onChange={(e) => setAdminStoryDuration(e.target.value)} />
              <label><input type="checkbox" checked={adminStoryHighlight} onChange={(e) => setAdminStoryHighlight(e.target.checked)} /> highlight / ویژه</label>
              <StoryMediaPicker
                file={adminStoryFile}
                url={adminStoryImage}
                onFile={(f) => { setAdminStoryFile(f); setAdminStoryImage(''); }}
                onUrl={(v) => { setAdminStoryImage(v); if (v.trim()) setAdminStoryFile(null); }}
                onClear={() => { setAdminStoryFile(null); setAdminStoryImage(''); }}
              />
              <button className="btn" style={{ marginTop: '10px', width: '100%' }} onClick={publishAdminStory} disabled={publishingStory}>{publishingStory ? '⏳ درحال انتشار استوری...' : '📢 انتشار استوری ادمین'}</button>
            </div>
            <div style={{ display: 'grid', gap: '10px', marginTop: '10px' }}>
              {stories.map((story) => (
                <div key={story.id} className="card" style={{ padding: '10px', background: '#f8fcfc' }}>
                  <div className="row" style={{ alignItems: 'flex-start' }}>
                    <div style={{ display: 'grid', gap: '6px', minWidth: 0, flex: 1 }}>
                      <strong>{story.userName || 'کاربر'}</strong>
                      <div className="sub">{formatStoryDate(story.createdAt)}</div>
                      <div className="sub">{story.caption || 'بدون کپشن'}</div>
                      <div className="sub">مدت نمایش: {Number(story.durationHours || 24).toLocaleString('fa-IR')} ساعت</div>
                      <div className="sub">نوع: {story.mediaType === 'video' ? 'ویدیویی' : 'تصویری'}{story.isHighlight ? ' · ویژه' : ''}{story.isAdmin ? ' · ادمین' : ''}</div>
                    </div>
                    <button className="btn secondary" onClick={() => removeStory(story.id)}>حذف</button>
                  </div>
                  {story.image ? (
                    story.mediaType === 'video'
                      ? <video src={getAdminStoryPreviewUrl(story.image)} className="adminImagePreview" style={{ marginTop: '10px', objectFit: 'cover', background: '#dfeff0' }} muted playsInline controls />
                      : <div className="adminImagePreview productImageWatermark" style={{ backgroundImage: `url(${getAdminStoryPreviewUrl(story.image)})`, marginTop: '10px' }} />
                  ) : null}
                </div>
              ))}
              {!stories.length ? <div className="card">فعلاً استوری‌ای ثبت نشده.</div> : null}
            </div>
          </div>
        </Section>

        <Section title="بکاپ و بازیابی (Backup)">
          <div className="card banner">
            <p>قبل از هر آپدیت یا تغییر مهم، بکاپ بگیر تا اگر اتفاقی افتاد، زحمتت برگردد.</p>
            <div className="row">
              <button className="btn" onClick={() => downloadBackupZip('products')} disabled={!!backupBusy}>{backupBusy === 'products' ? 'در حال ساخت...' : '📦 بکاپ محصولات (ZIP)'}</button>
              <button className="btn" onClick={() => downloadBackupZip('full')} disabled={!!backupBusy}>{backupBusy === 'full' ? 'در حال ساخت...' : '🗄️ بکاپ کامل سایت (ZIP)'}</button>
            </div>
            <div className="sub" style={{ marginTop: '8px' }}>
              بکاپ محصولات: products.json + عکس‌های محصولات. بکاپ کامل: همه‌ی داده‌های سایت (db.json) + کل پوشه‌ی uploads (عکس محصولات، استوری‌ها و ...).
            </div>
            <div className="row" style={{ marginTop: '12px' }}>
              <input type="file" accept="application/json,.json" className="input" onChange={(e) => setRestoreFile(e.target.files?.[0] || null)} />
              <button className="btn secondary" onClick={handleRestoreProducts} disabled={!!backupBusy}>{backupBusy === 'restore' ? 'در حال بازیابی...' : 'بازیابی محصولات'}</button>
            </div>
            <div className="sub" style={{ marginTop: '6px' }}>برای بازیابی: فایل products.json را از داخل ZIP بکاپ محصولات انتخاب کن. محصولات با شناسه‌ی قبلی به‌روز می‌شوند (حذف‌شده‌ها دوباره فعال می‌شوند).</div>
          </div>
        </Section>

        <Section title="مدیریت باشگاه مشتریان">
          <div className="card banner">
            <p>اعضای باشگاه را پیدا کن، امتیاز اعطا/کسر کن و تیر را تغییر بده. سه تراکنش آخر هر عضو هم نمایش داده می‌شود.</p>
            <div className="row">
              <input className="input" placeholder="جستجوی عضو (نام یا تلفن)" value={loyaltyQuery} onChange={(e) => setLoyaltyQuery(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') loadLoyalty(loyaltyQuery); }} />
              <button className="btn" onClick={() => loadLoyalty(loyaltyQuery)} disabled={loyaltyBusy}>{loyaltyBusy ? 'در حال بارگذاری...' : 'جستجو'}</button>
            </div>
            <div style={{ display: 'grid', gap: '10px', marginTop: '10px' }}>
              {loyaltyMembers.length === 0 ? <div className="sub">عضویی یافت نشد.</div> : loyaltyMembers.map((m) => (
                <div key={m.id} className="card" style={{ padding: '10px', background: '#f8fcfc' }}>
                  <div className="row" style={{ alignItems: 'center' }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <strong>{m.name}</strong>
                      <div className="sub">{m.phone || 'بدون تلفن'} · امتیاز: {Number(m.points).toLocaleString('fa-IR')} · کل عمر: {Number(m.lifetimePoints).toLocaleString('fa-IR')}</div>
                    </div>
                    <select className="input" style={{ maxWidth: '160px' }} value={loyaltyTiers[m.id] || m.tier} onChange={(e) => setLoyaltyTiers((t) => ({ ...t, [m.id]: e.target.value }))} onBlur={() => applyLoyaltyTier(m.id)}>
                      {LOYALY_TIERS.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="row" style={{ marginTop: '8px' }}>
                    <input className="input" inputMode="numeric" placeholder="مبلغ امتیاز (مثلاً 100)" value={loyaltyDeltas[m.id] || ''} onChange={(e) => setLoyaltyDeltas((d) => ({ ...d, [m.id]: e.target.value }))} style={{ maxWidth: '180px' }} />
                    <button className="btn" onClick={() => applyLoyaltyCredit(m.id)} disabled={loyaltyBusy}>اعطا</button>
                    <button className="btn secondary" onClick={() => applyLoyaltyDebit(m.id)} disabled={loyaltyBusy}>کسر</button>
                  </div>
                  {m.recentHistory?.length ? <div className="sub" style={{ marginTop: '8px' }}>{m.recentHistory.map((h: any, i: number) => <div key={i}>· {h.title} ({h.points > 0 ? '+' : ''}{h.points}){h.note ? ' — ' + h.note : ''}</div>)}</div> : null}
                </div>
              ))}
            </div>
          </div>
          <div className="card banner" style={{ marginTop: '10px' }}>
            <strong className="adminSubTitle">کدهای جایزه صادرشده</strong>
            <div style={{ display: 'grid', gap: '8px', marginTop: '8px' }}>
              {loyaltyCodes.length === 0 ? <div className="sub">کد جایزه‌ای صادر نشده است.</div> : loyaltyCodes.map((c) => (
                <div key={c.id} className="row" style={{ alignItems: 'center', padding: '8px', background: c.status === 'active' ? '#f0f9f1' : '#f2f2f2', borderRadius: '10px' }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <strong dir="ltr">{c.code}</strong>
                    <div className="sub">{c.title} · {c.memberName}{c.memberPhone ? ` (${c.memberPhone})` : ''} · {Number(c.points).toLocaleString('fa-IR')} امتیاز</div>
                  </div>
                  {c.status === 'active'
                    ? <button className="btn secondary" onClick={() => disableLoyaltyCode(c.id)} disabled={loyaltyBusy}>غیرفعال</button>
                    : <span className="chip">غیرفعال</span>}
                </div>
              ))}
            </div>
          </div>
        </Section>

        <Section title="ارسال اعلان">
          <div className="card banner notificationCard">
            <input className="input" placeholder="عنوان اعلان" value={notificationTitle} onChange={(e) => setNotificationTitle(e.target.value)} />
            <textarea className="input" placeholder="متن اعلان" value={notificationBody} onChange={(e) => setNotificationBody(e.target.value)} />
            <button className="btn" onClick={sendNotification}>ارسال برای کاربران</button>
          </div>
        </Section>

        <Section title="اعلان ویژه تعاملی ۱۰ ساعته">
          <div className="card banner notificationCard">
            <strong>فقط ادمین می‌تواند این اعلان را بفرستد</strong>
            <p>این اعلان ویژه تا ۱۰ ساعت فعال می‌ماند و تا پایان زمانش، هر کاربری که وارد سایت شود اول آن را به‌صورت پاپ‌آپ می‌بیند و می‌تواند بله/خیر پاسخ بدهد.</p>
            <input className="input" placeholder="عنوان اعلان ویژه" value={specialTitle} onChange={(e) => setSpecialTitle(e.target.value)} />
            <textarea className="input" placeholder="متن اعلان ویژه" value={specialBody} onChange={(e) => setSpecialBody(e.target.value)} />
            <input className="input" placeholder="سوال اصلی؛ مثلا: امشب مافیا داریم، تشریف میارید؟" value={specialQuestion} onChange={(e) => setSpecialQuestion(e.target.value)} />
            <input className="input" placeholder="متن دکمه بله" value={specialYesLabel} onChange={(e) => setSpecialYesLabel(e.target.value)} />
            <input className="input" placeholder="متن دکمه خیر" value={specialNoLabel} onChange={(e) => setSpecialNoLabel(e.target.value)} />
            <button className="btn" onClick={sendSpecialNotification}>ارسال اعلان ویژه ۱۰ ساعته</button>

            <div style={{ display: 'grid', gap: '8px', marginTop: '12px' }}>
              {specialReports.map((item) => (
                <div key={item.id} className="card" style={{ padding: '10px', background: 'linear-gradient(135deg,#fff,var(--primary-tint))' }}>
                  <div className="row" style={{ alignItems: 'flex-start' }}>
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <strong style={{ fontSize: '11px', lineHeight: '1.8' }}>{item.title}</strong>
                      <p style={{ fontSize: '9.5px', lineHeight: '1.9', marginTop: '4px' }}>{item.body}</p>
                      <div className="sub" style={{ fontSize: '9px' }}>تا: {item.expiresAt || '---'}</div>
                    </div>
                    <button className="btn secondary" style={{ fontSize: '10px', padding: '6px 8px' }} onClick={() => removeSpecialNotification(item.id)}>حذف</button>
                  </div>
                  <div className="row" style={{ justifyContent: 'flex-start', marginTop: '8px' }}>
                    <span className="chip active">بله: {Number(item.responseYes || 0).toLocaleString('fa-IR')}</span>
                    <span className="chip">خیر: {Number(item.responseNo || 0).toLocaleString('fa-IR')}</span>
                  </div>
                  <div style={{ display: 'grid', gap: '8px', marginTop: '10px' }}>
                    <div className="card" style={{ padding: '8px', background: '#fff' }}>
                      <strong style={{ fontSize: '10px' }}>پاسخ داده‌اند: بله</strong>
                      <div style={{ display: 'grid', gap: '6px', marginTop: '6px' }}>
                        {(item.yesUsers || []).map((user: any, idx: number) => (
                          <div key={`${item.id}-yes-${idx}`} className="row" style={{ justifyContent: 'space-between', alignItems: 'center', gap: '8px' }}>
                            <span style={{ fontSize: '9.5px', color: 'var(--primary-deep)' }}>{user.name || 'کاربر'}</span>
                            <span style={{ fontSize: '9px', color: 'var(--muted)' }}>{user.phone || 'بدون شماره'}</span>
                          </div>
                        ))}
                        {!(item.yesUsers || []).length ? <div className="sub" style={{ fontSize: '9px' }}>فعلاً کسی بله نزده.</div> : null}
                      </div>
                    </div>
                    <div className="card" style={{ padding: '8px', background: '#fff' }}>
                      <strong style={{ fontSize: '10px' }}>پاسخ داده‌اند: خیر</strong>
                      <div style={{ display: 'grid', gap: '6px', marginTop: '6px' }}>
                        {(item.noUsers || []).map((user: any, idx: number) => (
                          <div key={`${item.id}-no-${idx}`} className="row" style={{ justifyContent: 'space-between', alignItems: 'center', gap: '8px' }}>
                            <span style={{ fontSize: '9.5px', color: 'var(--primary-deep)' }}>{user.name || 'کاربر'}</span>
                            <span style={{ fontSize: '9px', color: 'var(--muted)' }}>{user.phone || 'بدون شماره'}</span>
                          </div>
                        ))}
                        {!(item.noUsers || []).length ? <div className="sub" style={{ fontSize: '9px' }}>فعلاً کسی خیر نزده.</div> : null}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              {!specialReports.length ? <div className="card" style={{ padding: '10px' }}>فعلاً اعلان ویژه فعالی ثبت نشده.</div> : null}
            </div>
          </div>
        </Section>

        <Section title="نظرسنجی مشتریان">
          <RemoteFeedbackReport />
        </Section>
      </section>
    </ProtectedPage>
  );
}
