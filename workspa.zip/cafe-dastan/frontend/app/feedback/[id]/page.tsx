"use client";

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import RemoteFeedbackForm from '@/components/RemoteFeedbackForm';
import { isCustomerAuthenticated, requireCustomerAuth } from '@/lib/api';

export default function FeedbackPage({ params }: { params: { id: string } }) {
  const target = useMemo(() => `/feedback/${params.id}`, [params.id]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!isCustomerAuthenticated()) {
      requireCustomerAuth(target);
      return;
    }
    setReady(true);
  }, [target]);

  if (!ready) return null;

  return (
    <main className="page">
      <div className="row contentPad">
        <Link href={`/tracking/${params.id}`} className="link">بازگشت</Link>
        <strong>نظرسنجی</strong>
      </div>
      <section className="contentPad">
        <RemoteFeedbackForm orderId={params.id} />
      </section>
    </main>
  );
}
