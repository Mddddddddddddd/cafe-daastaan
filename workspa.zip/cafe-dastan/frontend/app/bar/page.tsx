import ProtectedPage from '@/components/ProtectedPage';
import RemoteBarOrders from '@/components/RemoteBarOrders';
import StaffPushBell from '@/components/StaffPushBell';
import InstallPwaButton from '@/components/InstallPwaButton';

export default function BarPage() {
  return (
    <ProtectedPage role="bar" title="پنل بار">
      <div className="row contentPad" style={{ justifyContent: 'flex-end', gap: '6px', flexWrap: 'wrap' }}>
        <InstallPwaButton role="bar" label="نصب بار" />
        <StaffPushBell role="bar" />
      </div>
      <RemoteBarOrders />
    </ProtectedPage>
  );
}
