import Link from 'next/link';
import ProtectedPage from '@/components/ProtectedPage';
import RemoteStationProducts from '@/components/RemoteStationProducts';

export default function BarProductsPage() {
  return (
    <ProtectedPage role="bar" title="محصولات بار و کافه">
      <div className="row contentPad">
        <Link href="/bar" className="link">بازگشت به سفارش‌ها</Link>
        <strong>ناموجود / پنهان کردن آیتم</strong>
      </div>
      <RemoteStationProducts role="bar" />
    </ProtectedPage>
  );
}
