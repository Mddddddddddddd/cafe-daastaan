import type { Metadata } from 'next';

// PWA جدا برای پنل بار
export const metadata: Metadata = {
  manifest: '/manifest-bar.json',
};

export default function BarLayout({ children }: { children: React.ReactNode }) {
  return children;
}
