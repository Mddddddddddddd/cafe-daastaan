# وضعیت لحظه‌ای پروژه — تاییدشده در چت (۲۰۲۶-08-29)

## ورودی‌ها (تاییدشده)
- رمزهای پرسنل: **همین پیش‌فرض‌های seed**
  - admin/admin123 · bar/bar123 · kitchen/kitchen123 · waiter/waiter123
- ورود مشتری: موبایل + OTP (sms.ir, template production: **207464**)
- `AUTH_ENFORCE=true`

## سرور VPS (تأییدشده از خروجی کاربر)
- PM2: `cafe-dastan-backend` (online, port 4000) + `cafe-dastan-frontend` (online, تک‌نسخه, port 3000)
- Nginx: `sites-available/cafedaastaan` (→:3000) و `sites-available/api-cafedaastaan` (→:4000)
  - ⚠️ هر دو فاقد `client_max_body_size` → ریشه باگ 413. نسخه فیکس‌شده: `DEPLOY/*.conf`
  - مقدار لازم: **API = 550m** (ویدیو 500MB) / دامنه اصلی = 30m
  - دستور اعمال فیکس: `DEPLOY/README_DEPLOY_FA.md`

## آخرین تغییر کد (تغییر ۱۳۱)
- استوری ادمین با حجم خیلی بزرگ: endpoint جدید `POST /stories/admin/media` (multipart + multer diskStorage)
- لیمیت‌ها: `MEDIA_MAX_VIDEO_MB=500` / `MEDIA_MAX_IMAGE_MB=50` (env بک‌اند)
- فرانت: `StoryMediaPicker` با پیشرفت آپلود + فالبک base64 برای بک‌اند قدیمی
- جزئیات: `CHANGES_131_STORY_LARGE_UPLOAD_FA.md`

## کارهای در انتظار اعمال روی سرور
1. **فایکس Nginx (API = 550m، اصلی = 30m)** (دستور در `DEPLOY/README_DEPLOY_FA.md`) — لازم برای تغییر ۱۳۱
2. **تغییر JWT_SECRET / JWT_REFRESH_SECRET** — فعلاً "change-me" است (سوراخ امنیتی). مقادیر جدید قوی:
   - JWT_SECRET: `c69ffb3f4d3f750a6bbc9652f450be440d7712473baab5c3c8349c30db861525`
   - JWT_REFRESH: `845f825c35234fe7dcfb653325ebb139611e8eb6d790facb2cac7bdbe73fe91f`
   - ⚠️ با اعمال، همه لاگین‌های فعال یک‌بار بیرون می‌خورند.

## مقادیر env
- `backend/.env` و `frontend/.env.local` در همین پروژه نسخه دقیق پراکشن هستند.
- ⚠️ در ZIP تحویل، `.env` حذف می‌شود (نشتی امنیتی).
