# بک‌اند اولیه کافه داستان

این پوشه اسکلت واقعی بک‌اند با ساختار NestJS + Prisma را نگه می‌دارد.

## قابلیت‌های این مرحله
- JWT mock service برای scaffolding
- AuthGuard mock
- Roles scaffold
- endpointهای auth/menu/orders/notifications آماده اتصال به فرانت
- seed data اولیه

## اجرای پروژه
```bash
cd cafe-dastan/backend
cp .env.example .env
npm install
npx prisma generate
npm run start:dev
```

## seed دیتابیس
```bash
npx prisma db push
npx ts-node prisma/seed.ts
```

## endpointهای مهم
- `POST /auth/request-otp`
- `POST /auth/verify-otp`
- `POST /auth/staff-login`
- `GET /menu`
- `GET /menu/:id`
- `POST /orders`
- `GET /orders/:id`
- `PATCH /orders/:id/status`
- `GET /notifications`
- `POST /notifications/broadcast`
