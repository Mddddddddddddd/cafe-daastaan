import { PrismaClient, StaffRole, StationType } from '@prisma/client';
import { hashPassword } from '../src/modules/auth/password.service';

const prisma = new PrismaClient();

const categories = ['نوشیدنی گرم','نوشیدنی سرد','قهوه تخصصی','دمنوش','صبحانه','دسر','کیک','غذای سبک','فصلی','ویژه کافه'];

const homeSections = {
  showHero: false,
  heroTitle: 'امشب دوست داری چه داستانی را مزه کنی؟',
  heroSubtitle: 'پیشنهادهای شخصی‌سازی‌شده، دسرهای ویژه و تجربه‌ای شبیه منوهای مدرن ولی با حال‌وهوای کافه داستان.',
  promoCode: 'DASTAN20',
  heroImage: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200&auto=format&fit=crop',
  showSuggested: true,
  showDiscounted: true,
  promoCards: [
    { id: 'pr1', title: 'پیشنهاد ما', text: 'لاته همینگوی + چیزکیک پایان شیرین', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
    { id: 'pr2', title: 'سفارش‌های تخفیف‌دار', text: 'دسرهای منتخب با کد DASTAN20', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true },
  ],
  showMemoryMood: false,
  memoryCard: { id: 'memory', title: 'حافظه کافه', text: 'دفعه قبل لاته و چیزکیک سفارش دادی.', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
  moodCard: { id: 'mood', title: 'حال و هوای امروز', text: 'آرام، رمانتیک یا ماجراجو؟', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true },
};

async function connectCategories(productId: string, names: string[]) {
  for (const name of names) {
    const category = await prisma.category.upsert({
      where: { name },
      update: {},
      create: { name, displayOrder: categories.indexOf(name) + 1 },
    });
    await prisma.productCategory.upsert({
      where: { productId_categoryId: { productId, categoryId: category.id } },
      update: {},
      create: { productId, categoryId: category.id },
    });
  }
}

async function main() {
  for (const [index, name] of categories.entries()) {
    await prisma.category.upsert({
      where: { name },
      update: { displayOrder: index + 1, active: true },
      create: { name, displayOrder: index + 1, active: true },
    });
  }

  await prisma.cafeTable.upsert({
    where: { id: 'table-seed-1' },
    update: { name: 'میز فروغ', qrCode: 'QR-FOROUGH-01', active: true },
    create: { id: 'table-seed-1', name: 'میز فروغ', qrCode: 'QR-FOROUGH-01', active: true },
  });

  await prisma.staffUser.upsert({
    where: { username: 'admin' },
    update: { role: StaffRole.ADMIN, isActive: true, passwordHash: hashPassword('admin123') },
    create: { username: 'admin', passwordHash: hashPassword('admin123'), role: StaffRole.ADMIN },
  });
  await prisma.staffUser.upsert({
    where: { username: 'bar' },
    update: { role: StaffRole.BAR, isActive: true, passwordHash: hashPassword('bar123') },
    create: { username: 'bar', passwordHash: hashPassword('bar123'), role: StaffRole.BAR },
  });
  await prisma.staffUser.upsert({
    where: { username: 'kitchen' },
    update: { role: StaffRole.KITCHEN, isActive: true, passwordHash: hashPassword('kitchen123') },
    create: { username: 'kitchen', passwordHash: hashPassword('kitchen123'), role: StaffRole.KITCHEN },
  });
  await prisma.staffUser.upsert({
    where: { username: 'waiter' },
    update: { role: StaffRole.WAITER, isActive: true, passwordHash: hashPassword('waiter123') },
    create: { username: 'waiter', passwordHash: hashPassword('waiter123'), role: StaffRole.WAITER },
  });

  await prisma.homeSettings.upsert({
    where: { id: 'default' },
    update: {},
    create: { id: 'default', data: homeSections },
  });

  const products = [
    { id: 'p1', name: 'لاته همینگوی', categories: ['نوشیدنی گرم','قهوه تخصصی'], price: 168000, oldPrice: 198000, discounted: true, featured: true, desc: 'لاته‌ای آرام برای شروع یک فصل نرم با فوم لطیف و شیر بخاردیده.', active: true, image: '/images/menu/coffee.svg', customizations: [{ id: 'c1', name: 'نوع شیر', values: ['شیر معمولی', 'شیر بادام', 'شیر جو', 'بدون لاکتوز'] }, { id: 'c2', name: 'اندازه', values: ['کوچک', 'متوسط', 'بزرگ'] }] },
    { id: 'p4', name: 'اسپرسو سینگل ۱۰۰٪ عربیکا', categories: ['نوشیدنی گرم','قهوه تخصصی'], price: 65000, desc: 'عصاره‌گیری استاندارد از دانه‌های تخصصی عربیکا با کرمای مخملی و طعم‌یاد فندق.', active: true, image: '/images/menu/coffee.svg', customizations: [{ id: 'c6', name: 'نوع دانه', values: ['۱۰۰٪ عربیکا کلمبیا', 'ترکیب ۷۰/۳۰ ویژه'] }] },
    { id: 'p5', name: 'آمریکانو داغ کلاسیک', categories: ['نوشیدنی گرم'], price: 75000, desc: 'دابل اسپرسو همراه با آب داغ تصفیه‌شده، ملایم، شفاف و انرژی‌بخش برای مطالعه.', active: true, image: '/images/menu/coffee.svg', customizations: [] },
    { id: 'p6', name: 'کاپوچینو ونیزی', categories: ['نوشیدنی گرم'], price: 155000, desc: 'اسپرسو، شیر گرم و لایه‌ای ضخیم و مخملی از فوم شیر با گارنیش پودر کاکائو.', active: true, image: '/images/menu/coffee.svg', customizations: [] },
    { id: 'p7', name: 'هات چاکلت بلژیکی', categories: ['نوشیدنی گرم','ویژه کافه'], price: 170000, featured: true, desc: 'نوشیدنی شکلات داغ غلیظ تهیه شده از تکه‌های شکلات تلخ بلژیکی و شیر تازه.', active: true, image: '/images/menu/coffee.svg', customizations: [] },

    { id: 'p2', name: 'آیس موکا باران', categories: ['نوشیدنی سرد','ویژه کافه'], price: 184000, featured: true, desc: 'ترکیب اسپرسو، سیروپ شکلات تلخ، شیر سرد و یخ؛ خنک، سبک و مناسب عصرهای گرم.', active: true, image: '/images/menu/cold.svg', customizations: [{ id: 'c3', name: 'یخ', values: ['کم', 'متوسط', 'زیاد'] }, { id: 'c4', name: 'سیروپ', values: ['وانیل', 'کارامل', 'بدون سیروپ'] }] },
    { id: 'p8', name: 'آیس لاته کاراملی', categories: ['نوشیدنی سرد'], price: 175000, desc: 'اسپرسو دابل عصاره‌گیری شده روی شیر سرد و یخ بلوری همراه با سیروپ کارامل نمکی.', active: true, image: '/images/menu/cold.svg', customizations: [] },
    { id: 'p9', name: 'موخیتا لیمو و نعناع تازه', categories: ['نوشیدنی سرد','فصلی'], price: 150000, desc: 'عصاره لیموترش شیرازی، نعناع ساطوری تازه، سودا و یخ کراش؛ فوق‌العاده طراوت‌بخش.', active: true, image: '/images/menu/cold.svg', customizations: [] },

    { id: 'p10', name: 'V60 دمی کلمبیا', categories: ['قهوه تخصصی'], price: 145000, desc: 'قهوه دمی موج سوم خاستگاه کلمبیا با اسیدیته شفاف و طعم‌یادهای کارامل و هلو.', active: true, image: '/images/menu/specialty.svg', customizations: [] },
    { id: 'p11', name: 'کمیکس اتیوپی', categories: ['قهوه تخصصی'], price: 160000, desc: 'دم‌آوری با فیلتر ضخیم کمیکس، بادی سبک شبیه چای با عطر یاس و مرکبات.', active: true, image: '/images/menu/specialty.svg', customizations: [] },

    { id: 'p12', name: 'دمنوش آرامش شب‌بو', categories: ['دمنوش'], price: 120000, desc: 'ترکیب طبیعی گل گاوزبان، بهارنارنج، اسطوخودوس و هل؛ آرام‌بخش اعصاب و روان.', active: true, image: '/images/menu/tea.svg', customizations: [] },
    { id: 'p13', name: 'چای ماسالا اصیل هندی', categories: ['دمنوش','نوشیدنی گرم'], price: 140000, desc: 'چای سیاه دم‌کشیده با ادویه‌های گرم اصیل هندی (هل، دارچین، زنجبیل، میخک) و شیر.', active: true, image: '/images/menu/tea.svg', customizations: [] },

    { id: 'p14', name: 'بشقاب صبحانه انگلیسی کامل', categories: ['صبحانه','ویژه کافه'], price: 320000, featured: true, desc: 'دو عدد تخم‌مرغ نیمرو، سوسیس شکاری، خوراک لوبیا چیتی، قارچ طعم‌دار، گوجه و تست برشته.', active: true, image: '/images/menu/breakfast.svg', customizations: [] },
    { id: 'p15', name: 'املت اسفناج و پنیر گودا', categories: ['صبحانه'], price: 240000, desc: 'سه عدد تخم‌مرغ تازه همراه با برگ‌های اسفناج تفت‌داده با کره، قارچ و پنیر ذوب‌شده.', active: true, image: '/images/menu/breakfast.svg', customizations: [] },

    { id: 'p16', name: 'پنینی مرغ و پستو دست‌ساز', categories: ['غذای سبک'], price: 285000, desc: 'سینه مرغ گریل‌شده با سس پستو ریحان تازه، پنیر موزارلا و گوجه خشک در نان چیاباتا.', active: true, image: '/images/menu/food.svg', customizations: [] },
    { id: 'p17', name: 'سالاد سزار با مرغ گریل', categories: ['غذای سبک','فصلی'], price: 270000, desc: 'کاهو پیچ ترد، تکه‌های سینه مرغ گریل، کروتان سیر و کره، پنیر پارمزان و سس اصیل سزار.', active: true, image: '/images/menu/food.svg', customizations: [] },

    { id: 'p3', name: 'چیزکیک پایان شیرین سن‌سباستین', categories: ['دسر','کیک'], price: 189000, oldPrice: 219000, discounted: true, desc: 'چیزکیک سوخته اسپانیایی با بافت کرمی فوق‌العاده لطیف، سرو با سس شکلات بلژیکی.', active: true, image: '/images/menu/dessert.svg', customizations: [{ id: 'c5', name: 'تاپینگ', values: ['توت‌فرنگی', 'شکلات', 'بدون تاپینگ'] }] },
    { id: 'p18', name: 'کیک هویج و گردو با کرم چیز', categories: ['کیک','دسر'], price: 135000, desc: 'کیک خانگی تازه پخت پر از گردو و دارچین با لایه‌ای ضخیم از فراستینگ پنیر خامه‌ای.', active: true, image: '/images/menu/cake.svg', customizations: [] },
    { id: 'p19', name: 'تیرامیسو کلاسیک ایتالیایی', categories: ['دسر'], price: 175000, desc: 'لایه‌های بیسکویت لیدی فینگر آغشته به اسپرسو تخصصی و کرم ماسکارپونه لطیف.', active: true, image: '/images/menu/cake.svg', customizations: [] },

    { id: 'p20', name: 'شیک شاتوت و وانیل ویژه داستان', categories: ['فصلی','نوشیدنی سرد'], price: 195000, desc: 'ترکیب بستنی وانیلی پرچرب، پوره شاتوت تازه طبیعی و خامه قنادی؛ غلیظ و بی‌نظیر.', active: true, image: '/images/menu/shake.svg', customizations: [] },
  ];

  for (const item of products) {
    await prisma.product.upsert({
      where: { id: item.id },
      update: {
        name: item.name,
        desc: item.desc,
        price: item.price,
        oldPrice: item.oldPrice || null,
        image: item.image,
        active: item.active,
        featured: !!item.featured,
        discounted: !!item.discounted,
        customizations: item.customizations,
      } as any,
      create: {
        id: item.id,
        name: item.name,
        desc: item.desc,
        price: item.price,
        oldPrice: item.oldPrice || null,
        image: item.image,
        active: item.active,
        featured: !!item.featured,
        discounted: !!item.discounted,
        customizations: item.customizations,
      } as any,
    });
    await connectCategories(item.id, item.categories);
  }

  await prisma.discountCode.upsert({
    where: { code: 'DASTAN20' },
    update: { title: 'تخفیف افتتاحیه داستان', type: 'percent', value: 20, active: true, once: false, used: false, source: 'admin' },
    create: { id: 'dc-seed-20', code: 'DASTAN20', title: 'تخفیف افتتاحیه داستان', type: 'percent', value: 20, active: true, once: false, used: false, source: 'admin' },
  });

  const customer = await prisma.customer.upsert({
    where: { id: 'guest-1' },
    update: { name: 'مهمان کافه داستان', phone: '' },
    create: { id: 'guest-1', name: 'مهمان کافه داستان', phone: '' },
  });

  await prisma.loyaltyMember.upsert({
    where: { customerId: customer.id },
    update: {},
    create: { id: 'guest-loyalty-1', customerId: customer.id, name: 'مهمان کافه داستان', phone: '', points: 0, lifetimePoints: 0, tier: 'راوی تازه‌وارد' },
  });

  await prisma.notification.createMany({
    data: [
      { title: 'فصل تازه در منو', body: 'آیس موکا باران امروز در دسترس است.', type: 'general' },
      { title: 'سفارش تو در بار است', body: 'لاته همینگوی درحال آماده‌سازی است.', type: 'general' },
    ],
    skipDuplicates: true,
  }).catch(() => null);

  const existingSeedOrder = await prisma.order.findUnique({ where: { id: '1042' } });
  if (!existingSeedOrder) {
    await prisma.order.create({
      data: {
        id: '1042',
        customerId: customer.id,
        tableId: 'table-seed-1',
        tableName: 'میز فروغ',
        tableQr: 'QR-FOROUGH-01',
        orderType: 'DINE_IN',
        status: 'PENDING',
        subtotal: 357000,
        finalTotal: 357000,
        items: {
          create: [
            { productId: 'p1', productNameSnapshot: 'لاته همینگوی', station: StationType.BAR, qty: 1, unitPrice: 168000 },
            { productId: 'p3', productNameSnapshot: 'چیزکیک پایان شیرین', station: StationType.KITCHEN, qty: 1, unitPrice: 189000 },
          ],
        },
      },
    });
  }

  console.log('Cafe Dastan database seed completed');
}

main()
  .then(async () => prisma.$disconnect())
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
