@echo off
setlocal

echo ============================================
echo Cafe Dastan - Reset + Prisma DB Setup Windows
echo ============================================

echo.
echo [1/7] Stop any running backend/frontend terminals before continuing.
pause

echo.
echo [2/7] Cleaning old build/cache that can keep stale Nest guards...
if exist dist rmdir /s /q dist
if exist .turbo rmdir /s /q .turbo
if exist node_modules\.prisma rmdir /s /q node_modules\.prisma

echo.
echo [3/7] Installing dependencies...
call npm install
if errorlevel 1 goto failed

echo.
echo [4/7] Generating Prisma Client...
call npm run prisma:generate
if errorlevel 1 goto failed

echo.
echo [5/7] Pushing Prisma schema to PostgreSQL...
call npm run prisma:push
if errorlevel 1 goto failed

echo.
echo [6/7] Seeding default cafe data and staff users...
call npm run prisma:seed
if errorlevel 1 goto failed

echo.
echo [7/7] Building backend...
call npm run build
if errorlevel 1 goto failed

echo.
echo ============================================
echo DONE. Now run: npm run start:dev
echo Default staff: admin/admin123, bar/bar123, kitchen/kitchen123, waiter/waiter123
echo ============================================
goto end

:failed
echo.
echo ============================================
echo FAILED. Check the error above.
echo If PostgreSQL is not installed/running, fix DATABASE_URL and run this file again.
echo ============================================

:end
pause
