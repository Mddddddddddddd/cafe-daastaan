export function requireFields<T extends Record<string, any>>(payload: T, fields: string[]) {
  const missing = fields.filter((field) => {
    const value = payload?.[field];
    return value === undefined || value === null || value === '';
  });

  return {
    ok: missing.length === 0,
    missing,
  };
}