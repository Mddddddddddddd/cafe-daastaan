import { mkdir, writeFile, rename, unlink } from 'fs/promises';
import { extname, join } from 'path';

const DATA_URL_RE = /^data:(image\/(png|jpeg|jpg|webp|gif)|video\/(mp4|webm|quicktime));base64,(.+)$/i;

// لیمیت‌های حجمی — از env خوانده می‌شوند تا روی سرور قابل تنظیم باشند:
// MEDIA_MAX_IMAGE_MB (پیش‌فرض 50) و MEDIA_MAX_VIDEO_MB (پیش‌فرض 500)
function envLimitMb(name: string, def: number): number {
  const v = Number(process.env[name]);
  return Number.isFinite(v) && v > 0 ? v : def;
}

export function mediaMaxBytes(isVideo: boolean): number {
  return (isVideo ? envLimitMb('MEDIA_MAX_VIDEO_MB', 500) : envLimitMb('MEDIA_MAX_IMAGE_MB', 50)) * 1024 * 1024;
}

function safeExt(mimeExt: string) {
  const clean = String(mimeExt || '').toLowerCase();
  if (clean === 'jpeg' || clean === 'jpg') return 'jpg';
  if (clean === 'png') return 'png';
  if (clean === 'webp') return 'webp';
  if (clean === 'gif') return 'gif';
  if (clean === 'mp4') return 'mp4';
  if (clean === 'webm') return 'webm';
  if (clean === 'quicktime') return 'mov';
  return 'jpg';
}

function isExternalOrPublicUrl(value: string) {
  return value.startsWith('http://') || value.startsWith('https://') || value.startsWith('/images/') || value.startsWith('/uploads/');
}

export async function saveBase64Media(input?: string, folder = 'general') {
  const value = String(input || '').trim();
  if (!value) return '';
  if (isExternalOrPublicUrl(value)) return value;

  const match = value.match(DATA_URL_RE);
  if (!match) return value;

  // match[2] گروه تصویر، match[3] گروه ویدیو است؛ برای ویدیو پسوند از گروه ویدیو خوانده می‌شود.
  const ext = safeExt(match[2] || match[3]);
  const base64 = match[4];
  const buffer = Buffer.from(base64, 'base64');
  const isVideo = ['mp4', 'webm', 'mov'].includes(ext);
  const maxBytes = mediaMaxBytes(isVideo);
  if (buffer.length > maxBytes) throw new Error(isVideo ? `Video is too large. Maximum allowed size is ${Math.round(maxBytes / 1024 / 1024)}MB.` : `Image is too large. Maximum allowed size is ${Math.round(maxBytes / 1024 / 1024)}MB.`);

  const safeFolder = String(folder || 'general').replace(/[^a-z0-9-_]/gi, '').toLowerCase() || 'general';
  const uploadRoot = join(process.cwd(), 'uploads');
  const targetDir = join(uploadRoot, safeFolder);
  await mkdir(targetDir, { recursive: true });

  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}.${ext}`;
  const filePath = join(targetDir, fileName);
  await writeFile(filePath, buffer);

  return `/uploads/${safeFolder}/${fileName}`;
}

export async function saveBase64Image(input?: string, folder = 'general') {
  return saveBase64Media(input, folder);
}

const MIME_EXT_MAP: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/quicktime': 'mov',
  'video/x-m4v': 'mp4',
};

// ذخیره‌ی مستقیم فایل آپلودشده با multer (multipart) — بدون base64 و بدون ۳۳٪ تورم حجمی.
// فایل را از مسیر موقت multer به uploads/<folder>/ منتقل می‌کند و URL برمی‌گرداند.
export async function saveIncomingUploadFile(file: { originalname?: string; mimetype?: string; path: string; size?: number }, folder = 'general') {
  if (!file || !file.path) throw new Error('No file received.');
  const mime = String(file.mimetype || '').toLowerCase();
  let ext = MIME_EXT_MAP[mime];
  if (!ext) {
    const extFromName = extname(String(file.originalname || '')).replace('.', '').toLowerCase();
    const allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'webm', 'mov'];
    ext = allowed.includes(extFromName) ? (extFromName === 'jpeg' ? 'jpg' : extFromName) : undefined;
  }
  if (!ext) {
    await unlink(file.path).catch(() => {});
    throw new Error('Unsupported file type. Allowed: jpg, png, webp, gif, mp4, webm, mov.');
  }

  const isVideo = ['mp4', 'webm', 'mov'].includes(ext);
  const size = typeof file.size === 'number' ? file.size : undefined;
  if (size !== undefined && size > mediaMaxBytes(isVideo)) {
    await unlink(file.path).catch(() => {});
    throw new Error(isVideo ? `Video is too large. Maximum allowed size is ${Math.round(mediaMaxBytes(true) / 1024 / 1024)}MB.` : `Image is too large. Maximum allowed size is ${Math.round(mediaMaxBytes(false) / 1024 / 1024)}MB.`);
  }

  const safeFolder = String(folder || 'general').replace(/[^a-z0-9-_]/gi, '').toLowerCase() || 'general';
  const targetDir = join(process.cwd(), 'uploads', safeFolder);
  await mkdir(targetDir, { recursive: true });

  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}.${ext}`;
  const filePath = join(targetDir, fileName);
  await rename(file.path, filePath).catch(async () => {
    // در صورتی که rename بین دو filesystem ممکن نباشد، کپی دستی انجام می‌شود.
    const { copyFile } = await import('fs/promises');
    await copyFile(file.path, filePath);
    await unlink(file.path).catch(() => {});
  });

  return `/uploads/${safeFolder}/${fileName}`;
}

export function isUploadPath(value?: string) {
  return String(value || '').startsWith('/uploads/');
}

export function getFileExtFromUrl(value?: string) {
  const ext = extname(String(value || '').split('?')[0]).replace('.', '').toLowerCase();
  return ext || 'jpg';
}
