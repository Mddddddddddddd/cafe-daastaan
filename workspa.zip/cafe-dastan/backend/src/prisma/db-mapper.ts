import { StationStatus, StationType } from '@prisma/client';

export const DEFAULT_HOME_SETTINGS = {
  showHero: false,
  heroTitle: 'امشب دوست داری چه داستانی را مزه کنی؟',
  heroSubtitle: 'پیشنهادهای شخصی‌سازی‌شده، دسرهای ویژه و تجربه‌ای شبیه منوهای مدرن ولی با حال‌وهوای کافه داستان.',
  promoCode: 'DASTAN20',
  heroImage: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200&auto=format&fit=crop',
  showSuggested: true,
  showDiscounted: true,
  promoCards: [
    { id: 'pr1', title: 'پیشنهاد ما', text: 'لاته همینگوی + چیزکیک پایان شیرین', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
    { id: 'pr2', title: 'سفارش‌های تخفیف‌دار', text: 'دسرهای منتخب با کد DASTAN20', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true },
  ],
  showMemoryMood: false,
  memoryCard: { id: 'memory', title: 'حافظه کافه', text: 'دفعه قبل لاته و چیزکیک سفارش دادی.', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
  moodCard: { id: 'mood', title: 'حال و هوای امروز', text: 'آرام، رمانتیک یا ماجراجو؟', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true },
};

export function normalizeOrderType(value?: string) {
  if (value === 'DELIVERY') return 'DELIVERY' as const;
  if (value === 'TAKE_AWAY' || value === 'TAKEAWAY') return 'TAKE_AWAY' as const;
  return 'DINE_IN' as const;
}

export function mapProduct(product: any) {
  return {
    id: product.id,
    name: product.name,
    categories: (product.categories || []).map((item: any) => item.category?.name).filter(Boolean),
    price: Number(product.price || 0),
    desc: product.desc || '',
    active: !!product.active,
    outOfStock: !!product.outOfStock,
    image: product.image || '',
    customizations: Array.isArray(product.customizations) ? product.customizations : [],
    featured: !!product.featured,
    discounted: !!product.discounted,
    station: product.station || 'bar',
    oldPrice: product.oldPrice ?? undefined,
  };
}

export function mapDiscount(discount: any) {
  return {
    id: discount.id,
    code: discount.code,
    title: discount.title,
    type: discount.type,
    value: Number(discount.value || 0),
    active: !!discount.active,
    once: !!discount.once,
    used: !!discount.used,
    source: discount.source,
    rewardId: discount.rewardId || undefined,
    createdAt: discount.createdAt instanceof Date ? discount.createdAt.toISOString() : discount.createdAt,
  };
}

export function mapNotification(item: any) {
  return {
    id: item.id,
    title: item.title,
    body: item.body,
    createdAt: item.createdAt instanceof Date ? item.createdAt.toISOString() : item.createdAt,
    expiresAt: item.expiresAt instanceof Date ? item.expiresAt.toISOString() : item.expiresAt,
    type: item.type,
    orderId: item.orderId || undefined,
    status: item.status || undefined,
    customerId: item.customerId || undefined,
    requiresAction: !!item.requiresAction,
    actionYesLabel: item.actionYesLabel || undefined,
    actionNoLabel: item.actionNoLabel || undefined,
    actionQuestion: item.actionQuestion || undefined,
    responseYes: Number(item.responseYes || 0),
    responseNo: Number(item.responseNo || 0),
    responsesJson: item.responsesJson || undefined,
  };
}

export function faStatusToStationStatus(status: string): StationStatus {
  if (status === 'درحال آماده‌سازی') return StationStatus.PREPARING;
  if (status === 'آماده تحویل') return StationStatus.READY;
  if (status === 'تحویل شد') return StationStatus.DELIVERED;
  return StationStatus.NEW;
}

export function stationStatusToFa(status: StationStatus) {
  if (status === StationStatus.PREPARING) return 'درحال آماده‌سازی';
  if (status === StationStatus.READY) return 'آماده تحویل';
  if (status === StationStatus.DELIVERED) return 'تحویل شد';
  return 'جدید';
}

export function stationFromCategories(categories: string[]): StationType {
  return categories.some((cat) => cat.includes('نوشیدنی') || cat.includes('قهوه') || cat.includes('دمنوش') || cat.includes('شیک') || cat.includes('آبمیوه') || cat.includes('بستنی') || cat.includes('لاته') || cat.includes('موکا') || cat.includes('اسپرسو') || cat.includes('آمریکانو') || cat.includes('چای') || cat.includes('ماسالا') || cat.includes('کاپوچینو')) ? StationType.BAR : StationType.KITCHEN;
}

export function mapOrder(order: any) {
  return {
    id: order.id,
    table: order.tableName || order.table?.name || 'میز فروغ',
    tableQr: order.tableQr || order.table?.qrCode || 'QR-FOROUGH-01',
    status: order.status,
    createdAt: order.createdAt instanceof Date ? order.createdAt.toISOString() : order.createdAt,
    paymentMethod: order.paymentMethod,
    paymentStatus: order.paymentStatus || 'PENDING',
    paymentStatusFa: order.paymentStatus === 'PAID' ? 'پرداخت شده' : order.paymentStatus === 'FAILED' ? 'پرداخت نشده' : 'نامشخص',
    orderType: order.orderType,
    address: order.address || '',
    phone: order.phone || '',
    total: Number(order.subtotal || 0),
    discountCode: order.discountCode || '',
    discountAmount: Number(order.discountAmount || 0),
    finalTotal: Number(order.finalTotal || 0),
    loyalty: order.loyaltySnapshot || null,
    items: (order.items || []).map((item: any) => ({
      productId: item.productId,
      name: item.productNameSnapshot,
      qty: item.qty,
      price: item.unitPrice,
      station: item.station,
      option: Array.isArray(item.selectedOptions) ? item.selectedOptions.map((o: any) => o?.name || o).filter(Boolean).join('، ') : undefined,
      selectedOptions: item.selectedOptions || [],
    })),
  };
}

export function mapStaffQueueItem(order: any, station: StationType) {
  const items = (order.items || []).filter((item: any) => item.station === station);
  const totalQty = items.reduce((sum: number, item: any) => sum + Number(item.qty || 1), 0);
  const id = `${station === StationType.BAR ? 'bar' : 'kitchen'}-${order.id}`;
  return {
    id,
    productId: items[0]?.productId || '',
    name: items.map((item: any) => `${item.qty}× ${item.productNameSnapshot}`).join('، '),
    items: items.map((item: any) => ({ productId: item.productId, name: item.productNameSnapshot, qty: item.qty })),
    qty: totalQty,
    tableName: order.tableName || order.table?.name || 'میز فروغ',
    tableQr: order.tableQr || order.table?.qrCode || 'QR-FOROUGH-01',
    time: `${Math.max(4, totalQty * 3)} دقیقه`,
    status: stationStatusToFa(items[0]?.stationStatus || StationStatus.NEW),
    station: station === StationType.BAR ? 'bar' : 'kitchen',
    orderId: order.id,
  };
}
