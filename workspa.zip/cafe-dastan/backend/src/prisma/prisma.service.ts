import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private available = false;

  async onModuleInit() {
    try {
      await this.$connect();
      this.available = true;
      console.log('[Prisma] Connected to PostgreSQL');
    } catch (error: any) {
      this.available = false;
      console.warn('[Prisma] PostgreSQL is not available. Backend will use in-memory fallback until DATABASE_URL/database is ready.');
      console.warn(error?.message || error);
    }
  }

  async onModuleDestroy() {
    if (this.available) await this.$disconnect();
  }

  isAvailable() {
    return this.available;
  }

  markUnavailable(error?: any) {
    // فقط خطای «اتصال واقعی» (Prisma P1xxx) بک‌اند را به حالت حافظه می‌برد.
    // خطاهای سطح داده (P2xxx مثل برخورد unique) نباید کل سایت را به حالت دمو بکند.
    if (error && !this.isConnectionError(error)) {
      console.warn('[Prisma] Data-level error — staying on PostgreSQL:', error?.code || '', String(error?.message || '').slice(0, 300));
      return;
    }
    this.available = false;
    if (error) console.warn('[Prisma] Falling back to in-memory store:', error?.message || error);
  }

  isConnectionError(error: any): boolean {
    const code = String(error?.code || '');
    // خطاهای اتصال/دیتابیس Prisma: P1001..P1025
    return code.startsWith('P1');
  }
}
