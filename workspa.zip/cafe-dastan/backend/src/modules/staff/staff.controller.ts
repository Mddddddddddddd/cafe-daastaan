import { Body, Controller, Get, Param, Patch, Query, UseGuards } from '@nestjs/common';
import { StaffService } from './staff.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

@UseGuards(AuthGuardMock, RolesGuardMock)
@Controller('staff')
export class StaffController {
  constructor(private readonly staffService: StaffService) {}

  @RequireRoles(Roles.ADMIN, Roles.BAR)
  @Get('bar/orders')
  getBarOrders() {
    return this.staffService.getBarOrders();
  }

  @RequireRoles(Roles.ADMIN, Roles.KITCHEN)
  @Get('kitchen/orders')
  getKitchenOrders() {
    return this.staffService.getKitchenOrders();
  }

  @RequireRoles(Roles.ADMIN, Roles.WAITER)
  @Get('waiter/tables')
  getWaiterTables() {
    return this.staffService.getWaiterTables();
  }

  @RequireRoles(Roles.ADMIN, Roles.WAITER)
  @Get('waiter/accounting/report')
  getWaiterAccounting(@Query('from') from?: string, @Query('to') to?: string) {
    return this.staffService.getAccounting(from, to);
  }

  @RequireRoles(Roles.ADMIN, Roles.BAR)
  @Get('bar/products')
  getBarProducts() {
    return this.staffService.getStationProducts('bar');
  }

  @RequireRoles(Roles.ADMIN, Roles.KITCHEN)
  @Get('kitchen/products')
  getKitchenProducts() {
    return this.staffService.getStationProducts('kitchen');
  }

  @RequireRoles(Roles.ADMIN, Roles.BAR)
  @Patch('bar/products/:id')
  updateBarProduct(@Param('id') id: string, @Body() body: any) {
    return this.staffService.updateStationProduct('bar', id, body);
  }

  @RequireRoles(Roles.ADMIN, Roles.KITCHEN)
  @Patch('kitchen/products/:id')
  updateKitchenProduct(@Param('id') id: string, @Body() body: any) {
    return this.staffService.updateStationProduct('kitchen', id, body);
  }

  @RequireRoles(Roles.ADMIN, Roles.BAR)
  @Patch('bar/orders/:id/status')
  setBarOrderStatus(@Param('id') id: string, @Body() body: { status: string }) {
    return this.staffService.setBarOrderStatus(id, body.status);
  }

  @RequireRoles(Roles.ADMIN, Roles.KITCHEN)
  @Patch('kitchen/orders/:id/status')
  setKitchenOrderStatus(@Param('id') id: string, @Body() body: { status: string }) {
    return this.staffService.setKitchenOrderStatus(id, body.status);
  }

  @RequireRoles(Roles.ADMIN, Roles.WAITER)
  @Patch('waiter/tables/:id/action')
  waiterAction(@Param('id') id: string, @Body() body: { action: string }) {
    return this.staffService.waiterAction(id, body.action);
  }
}