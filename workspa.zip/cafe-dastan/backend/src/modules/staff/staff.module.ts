import { Module } from '@nestjs/common';
import { StaffController } from './staff.controller';
import { StaffService } from './staff.service';
import { AuthModule } from '../auth/auth.module';
import { LoyaltyModule } from '../loyalty/loyalty.module';

@Module({
  imports: [AuthModule, LoyaltyModule],
  controllers: [StaffController],
  providers: [StaffService],
})
export class StaffModule {}
