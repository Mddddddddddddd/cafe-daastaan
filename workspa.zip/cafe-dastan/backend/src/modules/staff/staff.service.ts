import { Injectable } from '@nestjs/common';
import { OrderStatus, PaymentStatus, StationStatus, StationType } from '@prisma/client';
import { store } from '../../store/data.store';
import { createOrderStatusNotification } from '../notifications/notifications.service';
import { buildAccountingReport } from '../admin/admin.service';
import { PrismaService } from '../../prisma/prisma.service';
import { calculateLoyaltyPoints, getTier, LoyaltyService } from '../loyalty/loyalty.service';
import { faStatusToStationStatus, mapProduct, mapStaffQueueItem } from '../../prisma/db-mapper';

@Injectable()
export class StaffService {
  constructor(private readonly prisma: PrismaService, private readonly loyaltyService: LoyaltyService) {}

  // ===== مدیریت محصولات ایستگاه (بار / آشپزخانه) =====

  async getStationProducts(station: 'bar' | 'kitchen') {
    if (!this.prisma.isAvailable()) {
      return { success: true, data: (store.products || []).filter((p: any) => (p.station || 'bar') === station) };
    }
    try {
      const products = await this.prisma.product.findMany({
        where: { station, deletedAt: null },
        include: { categories: { include: { category: true } } },
        orderBy: { name: 'asc' },
      });
      return { success: true, data: products.map(mapProduct) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'دریافت محصولات ناموفق بود.' };
    }
  }

  async updateStationProduct(station: 'bar' | 'kitchen', id: string, body: any) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const product = await this.prisma.product.findFirst({ where: { id, deletedAt: null } });
      if (!product) return { success: false, message: 'محصول پیدا نشد.' };
      if (product.station !== station) return { success: false, message: 'این محصول متعلق به بخش شما نیست.' };
      const data: any = {};
      if (body?.active !== undefined) data.active = !!body.active;
      if (body?.outOfStock !== undefined) data.outOfStock = !!body.outOfStock;
      if (!Object.keys(data).length) return { success: false, message: 'بدون تغییر.' };
      await this.prisma.product.update({ where: { id }, data });
      const updated = await this.prisma.product.findFirst({ where: { id }, include: { categories: { include: { category: true } } } });
      return { success: true, data: mapProduct(updated) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'به‌روزرسانی ناموفق بود.' };
    }
  }

  private notifyIfOrderReady(orderId: string) {
    const barItems = store.barOrders.filter((o) => o.orderId === orderId);
    const kitchenItems = store.kitchenOrders.filter((o) => o.orderId === orderId);
    const barReady = barItems.length === 0 || barItems.every((o) => o.status === 'آماده تحویل');
    const kitchenReady = kitchenItems.length === 0 || kitchenItems.every((o) => o.status === 'آماده تحویل');
    if (barReady && kitchenReady) {
      createOrderStatusNotification(orderId, 'READY_TO_SERVE', 'سفارش تو آماده شد', `سفارش #${orderId} آماده سرو است. گارسون به‌زودی آن را تحویل می‌دهد.`);
    }
  }

  async getBarOrders() {
    if (!this.prisma.isAvailable()) return { success: true, data: store.barOrders };
    try {
      const orders = await this.prisma.order.findMany({
        where: { items: { some: { station: StationType.BAR, stationStatus: { notIn: [StationStatus.DELIVERED, StationStatus.CANCELLED] } } } },
        include: { items: true, table: true },
        orderBy: { createdAt: 'desc' },
      });
      return { success: true, data: orders.map((order) => mapStaffQueueItem(order, StationType.BAR)).filter((item) => item.items.length) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.barOrders };
    }
  }

  async getKitchenOrders() {
    if (!this.prisma.isAvailable()) return { success: true, data: store.kitchenOrders };
    try {
      const orders = await this.prisma.order.findMany({
        where: { items: { some: { station: StationType.KITCHEN, stationStatus: { notIn: [StationStatus.DELIVERED, StationStatus.CANCELLED] } } } },
        include: { items: true, table: true },
        orderBy: { createdAt: 'desc' },
      });
      return { success: true, data: orders.map((order) => mapStaffQueueItem(order, StationType.KITCHEN)).filter((item) => item.items.length) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.kitchenOrders };
    }
  }

  async getWaiterTables() {
    if (!this.prisma.isAvailable()) return { success: true, data: store.waiterTables };
    try {
      const orders = await this.prisma.order.findMany({
        where: { status: { notIn: [OrderStatus.CANCELLED] } },
        include: { table: true },
        orderBy: { createdAt: 'desc' },
      });
      return {
        success: true,
        data: orders.map((order) => ({
          id: `wt-${order.id}`,
          name: order.tableName || order.table?.name || 'میز',
          qrCode: order.tableQr || order.table?.qrCode || '',
          status: order.status === OrderStatus.READY_TO_SERVE ? 'آماده تحویل' : order.status === OrderStatus.ON_THE_WAY ? 'آماده تحویل' : order.status === OrderStatus.DELIVERED ? 'تحویل شده' : order.status === OrderStatus.ACCEPTED ? 'تایید شده' : 'سفارش فعال',
          rawStatus: order.status,
          note: order.orderType === 'DELIVERY' ? `سفارش ارسالی ${order.id}` : `سفارش فعال ${order.id}`,
          orderId: order.id,
          orderType: order.orderType,
          address: order.address || '',
          phone: order.phone || '',
          paymentStatus: order.paymentStatus || 'PENDING',
          paymentStatusFa: order.paymentStatus === PaymentStatus.PAID ? 'پرداخت شده' : order.paymentStatus === PaymentStatus.FAILED ? 'پرداخت نشده' : 'نامشخص',
          finalTotal: Number(order.finalTotal || order.subtotal || 0),
          createdAt: order.createdAt.toISOString(),
        })),
      };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.waiterTables };
    }
  }

  async getAccounting(from?: string, to?: string) {
    if (!this.prisma.isAvailable()) return buildAccountingReport(from, to);
    try {
      const fromDate = from ? new Date(`${from}T00:00:00`) : undefined;
      const toDate = to ? new Date(`${to}T23:59:59`) : undefined;
      const dbOrders = await this.prisma.order.findMany({
        where: { status: OrderStatus.DELIVERED, paymentStatus: { not: PaymentStatus.PENDING }, createdAt: { ...(fromDate ? { gte: fromDate } : {}), ...(toDate ? { lte: toDate } : {}) } },
        include: { items: true, table: true },
        orderBy: { createdAt: 'desc' },
      });
      const orders = dbOrders.map((order) => ({
        id: order.id,
        date: order.createdAt.toISOString(),
        table: order.tableName || order.table?.name || 'میز',
        status: order.status,
        items: (order.items || []).map((item) => ({ productId: item.productId, name: item.productNameSnapshot, qty: item.qty, price: item.unitPrice, total: item.qty * item.unitPrice })),
        grossTotal: Number(order.subtotal || 0),
        discountAmount: Number(order.discountAmount || 0),
        total: Number(order.finalTotal || 0),
      }));
      const totalSales = orders.reduce((sum, order) => sum + Number(order.total || 0), 0);
      const totalDiscount = orders.reduce((sum, order) => sum + Number(order.discountAmount || 0), 0);
      return { success: true, data: { orders, totalSales, totalCost: 0, totalProfit: 0, totalDiscount, orderCount: orders.length } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return buildAccountingReport(from, to);
    }
  }

  async setBarOrderStatus(id: string, status: string) {
    if (!this.prisma.isAvailable()) return this.setMemoryBarOrderStatus(id, status);
    try {
      const orderId = id.replace(/^bar-/, '');
      const next = faStatusToStationStatus(status);
      await this.prisma.orderItem.updateMany({ where: { orderId, station: StationType.BAR }, data: { stationStatus: next } });
      if (next === StationStatus.PREPARING) {
        await this.prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.BAR_PREPARING } });
        await this.createNotificationDb(orderId, 'BAR_PREPARING', 'سفارش تو وارد بار شد', `آیتم‌های نوشیدنی سفارش #${orderId} درحال آماده‌سازی هستند.`);
      }
      if (next === StationStatus.READY) {
        await this.createNotificationDb(orderId, 'BAR_READY', 'نوشیدنی‌های سفارش آماده شد', `نوشیدنی‌های سفارش #${orderId} آماده تحویل به گارسون هستند.`);
        await this.notifyIfOrderReadyDb(orderId);
      }
      const orders = await this.getBarOrders();
      return { success: true, data: (orders.data || []).find((item: any) => item.id === id) || null };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.setMemoryBarOrderStatus(id, status);
    }
  }

  async setKitchenOrderStatus(id: string, status: string) {
    if (!this.prisma.isAvailable()) return this.setMemoryKitchenOrderStatus(id, status);
    try {
      const orderId = id.replace(/^kitchen-/, '');
      const next = faStatusToStationStatus(status);
      await this.prisma.orderItem.updateMany({ where: { orderId, station: StationType.KITCHEN }, data: { stationStatus: next } });
      if (next === StationStatus.PREPARING) {
        await this.prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.KITCHEN_PREPARING } });
        await this.createNotificationDb(orderId, 'KITCHEN_PREPARING', 'سفارش تو وارد آشپزخانه شد', `آیتم‌های آشپزخانه سفارش #${orderId} درحال آماده‌سازی هستند.`);
      }
      if (next === StationStatus.READY) {
        await this.createNotificationDb(orderId, 'KITCHEN_READY', 'آیتم‌های آشپزخانه آماده شد', `آیتم‌های آشپزخانه سفارش #${orderId} آماده تحویل هستند.`);
        await this.notifyIfOrderReadyDb(orderId);
      }
      const orders = await this.getKitchenOrders();
      return { success: true, data: (orders.data || []).find((item: any) => item.id === id) || null };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.setMemoryKitchenOrderStatus(id, status);
    }
  }

  async waiterAction(id: string, action: string) {
    if (!this.prisma.isAvailable()) return this.memoryWaiterAction(id, action);
    try {
      const orderId = id.replace(/^wt-/, '');
      if (action === 'confirmPayment') {
        await this.prisma.order.update({
          where: { id: orderId },
          data: { paymentStatus: PaymentStatus.PAID },
        });
        await this.createNotificationDb(orderId, 'PAYMENT_PAID', 'پرداخت سفارش تایید شد', `پرداخت سفارش #${orderId} توسط گارسون پرداخت‌شده ثبت شد.`);
        const tables = await this.getWaiterTables();
        return { success: true, data: (tables.data || []).find((item: any) => item.id === id) || { id, orderId } };
      }
      if (action === 'markUnpaid') {
        await this.prisma.order.update({
          where: { id: orderId },
          data: { paymentStatus: PaymentStatus.FAILED },
        });
        await this.createNotificationDb(orderId, 'PAYMENT_UNPAID', 'پرداخت سفارش ثبت نشد', `سفارش #${orderId} توسط گارسون پرداخت‌نشده ثبت شد.`);
        const tables = await this.getWaiterTables();
        return { success: true, data: (tables.data || []).find((item: any) => item.id === id) || { id, orderId } };
      }
      if (action === 'serving') {
        await this.prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.ON_THE_WAY, statusLogs: { create: { status: OrderStatus.ON_THE_WAY, note: 'گارسون سفارش را برداشت' } } } });
        await this.createNotificationDb(orderId, 'ON_THE_WAY', 'سفارش در مسیر میز است', `سفارش #${orderId} توسط گارسون در مسیر تحویل قرار گرفت.`);
      }
      if (action === 'deliver') {
        const current = await this.prisma.order.findUnique({ where: { id: orderId }, include: { customer: true } });
        if (!current || current.paymentStatus === PaymentStatus.PENDING) {
          return { success: false, message: 'قبل از تحویل، باید وضعیت پرداخت را پرداخت شده یا پرداخت نشده مشخص کنید.' };
        }
        const updatedOrder = await this.prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.DELIVERED, statusLogs: { create: { status: OrderStatus.DELIVERED, note: 'سفارش تحویل شد' } } }, include: { customer: true, items: true } });
        await this.prisma.orderItem.updateMany({ where: { orderId }, data: { stationStatus: StationStatus.DELIVERED } });
        let loyalty: any = { awarded: false, message: 'برای سفارش پرداخت‌نشده امتیاز ثبت نمی‌شود.' };
        if (updatedOrder.paymentStatus === PaymentStatus.PAID) {
          loyalty = await this.awardOrderLoyaltyAfterPayment(updatedOrder);
        }
        await this.createNotificationDb(orderId, 'DELIVERED', 'سفارش تحویل شد', `سفارش #${orderId} تحویل شد. نوش جان! اگر دوست داشتی نظرت را ثبت کن.`);
        const tables = await this.getWaiterTables();
        return { success: true, data: (tables.data || []).find((item: any) => item.id === id) || { id, orderId }, loyalty };
      }
      const tables = await this.getWaiterTables();
      return { success: true, data: (tables.data || []).find((item: any) => item.id === id) || { id, orderId } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.memoryWaiterAction(id, action);
    }
  }

  private async awardOrderLoyaltyAfterPayment(order: any) {
    if (!order?.customerId) return { awarded: false, message: 'مشتری برای سفارش ثبت نشده است.' };
    const existingMember = await this.loyaltyService.getOrCreateDbMember({
      customerId: order.customerId,
      phone: order.phone || order.customer?.phone || '',
      name: order.customer?.name || 'مهمان کافه داستان',
    });
    const existing = await this.prisma.loyaltyHistory.findFirst({
      where: { memberId: existingMember.id, type: 'order', orderId: order.id },
    });
    if (existing) return { awarded: false, alreadyAwarded: true, message: 'امتیاز این سفارش قبلاً ثبت شده است.' };

    const itemCount = (order.items || []).reduce((sum: number, i: any) => sum + Number(i.qty || 1), 0);
    const calc = calculateLoyaltyPoints(Number(order.finalTotal || order.subtotal || 0), order.orderType, itemCount);
    const nextLifetime = existingMember.lifetimePoints + calc.points;
    const tier = getTier(nextLifetime).title;
    const parts = [
      `مبلغ ${Math.round(calc.toman).toLocaleString('fa-IR')} تومان → ${calc.base.toLocaleString('fa-IR')} امتیاز`,
      itemCount > 3 ? `${itemCount.toLocaleString('fa-IR')} آیتم → +${calc.itemBonus.toLocaleString('fa-IR')}` : null,
      order.orderType === 'DELIVERY' ? 'ضریب ارسال ×۱٫۲' : order.orderType === 'TAKE_AWAY' ? 'ضریب بیرون‌بر ×۰٫۹' : null,
      calc.bonus ? `بونوس سفارش پربار +${calc.bonus.toLocaleString('fa-IR')}` : null,
    ].filter(Boolean).join(' · ');
    const updated = await this.prisma.loyaltyMember.update({
      where: { id: existingMember.id },
      data: {
        points: { increment: calc.points },
        lifetimePoints: { increment: calc.points },
        tier,
        history: { create: { type: 'order', title: `امتیاز سفارش #${order.id}`, points: calc.points, orderId: order.id, note: `${parts} · ثبت بعد از تایید پرداخت توسط ویتر` } },
      },
    });
    await this.prisma.order.update({
      where: { id: order.id },
      data: { loyaltySnapshot: { ...calc, awarded: true, pending: false, memberId: updated.id, awardedAt: new Date().toISOString() } },
    });
    return { ...calc, awarded: true, pending: false };
  }

  private async notifyIfOrderReadyDb(orderId: string) {
    const order = await this.prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
    if (!order) return;
    const allReady = order.items.every((item) => item.stationStatus === StationStatus.READY || item.stationStatus === StationStatus.DELIVERED);
    if (allReady) {
      await this.prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.READY_TO_SERVE } });
      await this.createNotificationDb(orderId, 'READY_TO_SERVE', 'سفارش تو آماده شد', `سفارش #${orderId} آماده سرو است. گارسون به‌زودی آن را تحویل می‌دهد.`);
    }
  }

  private async createNotificationDb(orderId: string, status: string, title: string, body: string) {
    const order = await this.prisma.order.findUnique({ where: { id: orderId } }).catch(() => null);
    const customerId = order?.customerId || null;
    const exists = await this.prisma.notification.findFirst({ where: { orderId, status, deletedAt: null, ...(customerId ? { customerId } : {}) } });
    if (exists) return null;
    return this.prisma.notification.create({ data: { orderId, customerId, status, title, body, type: 'order-status' } });
  }

  private setMemoryBarOrderStatus(id: string, status: string) { const item = store.barOrders.find((o) => o.id === id); if (item && (status === 'جدید' || status === 'درحال آماده‌سازی' || status === 'آماده تحویل')) { item.status = status; if (status === 'درحال آماده‌سازی') createOrderStatusNotification(item.orderId, 'BAR_PREPARING', 'سفارش تو وارد بار شد', `آیتم‌های نوشیدنی سفارش #${item.orderId} درحال آماده‌سازی هستند.`); if (status === 'آماده تحویل') { createOrderStatusNotification(item.orderId, 'BAR_READY', 'نوشیدنی‌های سفارش آماده شد', `نوشیدنی‌های سفارش #${item.orderId} آماده تحویل به گارسون هستند.`); this.notifyIfOrderReady(item.orderId); } } return { success: true, data: item }; }
  private setMemoryKitchenOrderStatus(id: string, status: string) { const item = store.kitchenOrders.find((o) => o.id === id); if (item && (status === 'جدید' || status === 'درحال آماده‌سازی' || status === 'آماده تحویل')) { item.status = status; if (status === 'درحال آماده‌سازی') createOrderStatusNotification(item.orderId, 'KITCHEN_PREPARING', 'سفارش تو وارد آشپزخانه شد', `آیتم‌های آشپزخانه سفارش #${item.orderId} درحال آماده‌سازی هستند.`); if (status === 'آماده تحویل') { createOrderStatusNotification(item.orderId, 'KITCHEN_READY', 'آیتم‌های آشپزخانه آماده شد', `آیتم‌های آشپزخانه سفارش #${item.orderId} آماده تحویل هستند.`); this.notifyIfOrderReady(item.orderId); } } return { success: true, data: item }; }
  private memoryWaiterAction(id: string, action: string) {
    const item = store.waiterTables.find((t) => t.id === id);
    if (!item) return { success: false, message: 'Table not found' };
    if (action === 'resolve') item.status = 'انجام شد';
    if (action === 'move') item.status = 'جابجا شد';
    if (action === 'merge') item.status = 'ادغام شد';
    if (action === 'confirmPayment') { item.paymentStatus = 'PAID'; item.paymentStatusFa = 'پرداخت شده'; return { success: true, data: item }; }
    if (action === 'markUnpaid') { item.paymentStatus = 'FAILED'; item.paymentStatusFa = 'پرداخت نشده'; return { success: true, data: item }; }
    if (action === 'serving') item.status = 'در مسیر میز';
    if (action === 'serving') createOrderStatusNotification(item.orderId, 'ON_THE_WAY', 'سفارش در مسیر میز است', `سفارش #${item.orderId} توسط گارسون در مسیر تحویل قرار گرفت.`);
    if (action === 'deliver') {
      if (!item.paymentStatus || item.paymentStatus === 'PENDING') return { success: false, message: 'قبل از تحویل، وضعیت پرداخت را مشخص کنید.' };
      item.status = 'تحویل شد';
      createOrderStatusNotification(item.orderId, 'DELIVERED', 'سفارش تحویل شد', `سفارش #${item.orderId} تحویل شد. نوش جان! اگر دوست داشتی نظرت را ثبت کن.`);
    }
    return { success: true, data: item };
  }
}
