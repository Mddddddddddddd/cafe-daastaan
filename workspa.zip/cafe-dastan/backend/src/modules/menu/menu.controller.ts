import { Controller, Get, Param, Query } from '@nestjs/common';
import { MenuService } from './menu.service';

@Controller('menu')
export class MenuController {
  constructor(private readonly menuService: MenuService) {}

  @Get()
  getMenu(@Query('category') category?: string) {
    return this.menuService.getMenu(category);
  }

  @Get('categories')
  getCategories() {
    return this.menuService.getCategories();
  }

  @Get('home')
  getHome() {
    return this.menuService.getHomeSections();
  }

  @Get(':id')
  getProduct(@Param('id') id: string) {
    return this.menuService.getProduct(id);
  }
}