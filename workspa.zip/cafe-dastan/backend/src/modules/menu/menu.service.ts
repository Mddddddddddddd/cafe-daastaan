import { Injectable } from '@nestjs/common';
import { store, categories as memoryCategories } from '../../store/data.store';
import { PrismaService } from '../../prisma/prisma.service';
import { DEFAULT_HOME_SETTINGS, mapProduct } from '../../prisma/db-mapper';

@Injectable()
export class MenuService {
  constructor(private readonly prisma: PrismaService) {}

  // دسته‌بندی‌های فعال از دیتابیس (همان‌هایی که ادمین در «مدیریت دسته‌بندی» ساخته)
  async getCategories() {
    if (!this.prisma.isAvailable()) return { success: true, data: memoryCategories };
    try {
      const cats = await this.prisma.category.findMany({ where: { active: true }, orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }] });
      return { success: true, data: cats.map((c) => c.name) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return { success: true, data: memoryCategories };
      return { success: false, message: 'دریافت دسته‌بندی‌ها موقتا امکان‌پذیر نیست.' };
    }
  }

  // تنظیمات صفحه اصلی (برای خواندن سبک بدون کل منو — مثلاً حالت واترمارک)
  async getHomeSections() {
    if (!this.prisma.isAvailable()) return { success: true, homeSections: (store as any).homeSections || DEFAULT_HOME_SETTINGS };
    try {
      const home = await this.prisma.homeSettings.findUnique({ where: { id: 'default' } });
      return { success: true, homeSections: home?.data || DEFAULT_HOME_SETTINGS };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return { success: true, homeSections: (store as any).homeSections || DEFAULT_HOME_SETTINGS };
      return { success: false, message: 'دریافت تنظیمات موقتا امکان‌پذیر نیست.' };
    }
  }

  async getMenu(category?: string) {
    if (!this.prisma.isAvailable()) return this.getMemoryMenu(category);
    try {
      const products = await this.prisma.product.findMany({
        where: {
          active: true,
          deletedAt: null,
          ...(category ? { categories: { some: { category: { name: category } } } } : {}),
        },
        include: { categories: { include: { category: true } } },
        orderBy: [{ featured: 'desc' }, { createdAt: 'desc' }],
      });
      const home = await this.prisma.homeSettings.findUnique({ where: { id: 'default' } });
      return { success: true, data: products.map(mapProduct), homeSections: home?.data || DEFAULT_HOME_SETTINGS };
    } catch (error) {
      this.prisma.markUnavailable(error);
      // فقط اگر واقعاً از دیتابیس قطع شده‌ایم به حافظه برمی‌گردیم؛ خطای سطح داده (مثلاً P2xxx) نباید محصول دمو نشان دهد
      if (!this.prisma.isAvailable()) return this.getMemoryMenu(category);
      return { success: false, message: 'دریافت منو موقتا امکان‌پذیر نیست.' };
    }
  }

  async getProduct(id: string) {
    if (!this.prisma.isAvailable()) return { success: true, data: store.products.find((item) => item.id === id) || null };
    try {
      const product = await this.prisma.product.findFirst({ where: { id, deletedAt: null }, include: { categories: { include: { category: true } } } });
      return { success: true, data: product ? mapProduct(product) : null };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return { success: true, data: store.products.find((item) => item.id === id) || null };
      return { success: false, message: 'دریافت محصول موقتا امکان‌پذیر نیست.' };
    }
  }

  private getMemoryMenu(category?: string) {
    const activeProducts = store.products.filter((item) => item.active);
    return {
      success: true,
      data: category ? activeProducts.filter((item) => item.categories.includes(category)) : activeProducts,
      homeSections: store.homeSections,
    };
  }
}
