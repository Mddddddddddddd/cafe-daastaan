export class CreateOrderDto {
  branchId!: string;
  orderType!: 'DINE_IN' | 'TAKEAWAY' | 'DELIVERY';
  tableId?: string;
  paymentMethod?: string;
  items!: Array<{
    productId: string;
    qty: number;
    customizations?: Record<string, any>;
  }>;
}