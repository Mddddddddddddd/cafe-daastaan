import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { OrderStatus, PaymentStatus, StationStatus, StationType } from '@prisma/client';
import { store } from '../../store/data.store';
import { calculateLoyaltyPoints, getTier, LoyaltyService } from '../loyalty/loyalty.service';
import { createOrderStatusNotification } from '../notifications/notifications.service';
import { PushService } from '../notifications/push.service';
import { consumeDiscountCode, normalizeDiscountCode, calculateDiscount } from '../discounts/discounts.service';
import { PrismaService } from '../../prisma/prisma.service';
import { mapOrder, normalizeOrderType, stationFromCategories } from '../../prisma/db-mapper';
import { ensureCustomerOwnsResource } from '../auth/customer-auth';

function deriveOrderStatus(orderId: string) {
  const barItems = store.barOrders.filter((o) => o.orderId === orderId);
  const kitchenItems = store.kitchenOrders.filter((o) => o.orderId === orderId);
  const waiterTable = store.waiterTables.find((t: any) => t.orderId === orderId);

  if (waiterTable?.status === 'تحویل شد') return 'DELIVERED';
  if (waiterTable?.status === 'در مسیر میز') return 'ON_THE_WAY';

  const all = [...barItems, ...kitchenItems];
  if (all.length === 0) return 'PENDING';

  const anyKitchenPreparing = kitchenItems.some((i) => i.status === 'درحال آماده‌سازی');
  const anyBarPreparing = barItems.some((i) => i.status === 'درحال آماده‌سازی');
  const barReady = barItems.length > 0 && barItems.every((i) => i.status === 'آماده تحویل');
  const kitchenReady = kitchenItems.length > 0 && kitchenItems.every((i) => i.status === 'آماده تحویل');
  const anyNew = all.some((i) => i.status === 'جدید');

  if (anyKitchenPreparing) return 'KITCHEN_PREPARING';
  if (anyBarPreparing) return 'BAR_PREPARING';
  if ((barItems.length === 0 || barReady) && (kitchenItems.length === 0 || kitchenReady)) return 'READY_TO_SERVE';
  if (anyNew) return 'PENDING';
  return 'PENDING';
}

@Injectable()
export class OrdersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly loyaltyService: LoyaltyService,
    private readonly pushService: PushService,
  ) {}

  async getOrder(id: string, user?: any) {
    if (!this.prisma.isAvailable()) return this.getMemoryOrder(id);
    try {
      const order = await this.prisma.order.findUnique({ where: { id }, include: { items: true, table: true, customer: true } });
      if (!order) throw new NotFoundException('سفارش پیدا نشد.');
      ensureCustomerOwnsResource(user, order.customerId || '');
      const status = await this.deriveDbOrderStatus(id);
      const updated = status !== order.status ? await this.prisma.order.update({ where: { id }, data: { status }, include: { items: true, table: true, customer: true } }) : order;
      return { success: true, data: mapOrder(updated) };
    } catch (error) {
      if (error instanceof ForbiddenException || error instanceof NotFoundException) throw error;
      this.prisma.markUnavailable(error);
      return this.getMemoryOrder(id, user);
    }
  }

  async getMyActiveOrders(user?: any) {
    const customerId = String(user?.id || '').trim();
    if (!customerId) return { success: true, data: [] };
    if (!this.prisma.isAvailable()) {
      return { success: true, data: store.orders.filter((order: any) => String(order.customerId || '') === customerId && !['DELIVERED', 'CANCELLED'].includes(String(order.status || ''))).sort((a: any, b: any) => new Date(b.createdAt || b.id).getTime() - new Date(a.createdAt || a.id).getTime()) };
    }
    try {
      const orders = await this.prisma.order.findMany({
        where: { customerId, status: { notIn: [OrderStatus.DELIVERED, OrderStatus.CANCELLED] } },
        include: { items: true, table: true, customer: true },
        orderBy: { createdAt: 'desc' },
      });
      return { success: true, data: orders.map(mapOrder) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: [] };
    }
  }

  // سوابق سفارش مشتری (همه‌ی وضعیت‌ها) — برای صفحه پروفایل
  async getMyOrders(user?: any) {
    const customerId = String(user?.id || '').trim();
    if (!customerId) return { success: true, data: [] };
    if (!this.prisma.isAvailable()) {
      return { success: true, data: store.orders.filter((order: any) => String(order.customerId || '') === customerId).sort((a: any, b: any) => new Date(b.createdAt || b.id).getTime() - new Date(a.createdAt || a.id).getTime()).slice(0, 20) };
    }
    try {
      const orders = await this.prisma.order.findMany({
        where: { customerId },
        include: { items: true, table: true },
        orderBy: { createdAt: 'desc' },
        take: 20,
      });
      return { success: true, data: orders.map(mapOrder) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return { success: true, data: [] };
      return { success: false, message: 'دریافت سوابق سفارش موقتا امکان‌پذیر نیست.' };
    }
  }

  async createOrder(body: any) {
    if (!this.prisma.isAvailable()) return this.createMemoryOrder(body);
    try {
      const id = `${Date.now()}`;
      const tableName = body.tableName || body.tableId || 'میز فروغ';
      const tableQr = body.tableQr || 'QR-FOROUGH-01';
      const productIds = (body.items || []).map((item: any) => item.productId).filter(Boolean);
      const products = await this.prisma.product.findMany({ where: { id: { in: productIds }, deletedAt: null }, include: { categories: { include: { category: true } } } });
      const productMap = new Map(products.map((product) => [product.id, product]));
      const customer = await this.resolveCustomer(body);

      const orderItems = (body.items || []).map((item: any) => {
        const product = productMap.get(item.productId);
        const qty = Number(item.qty || 1);
        const unitPrice = Number(item.price || product?.price || 0);
        const categoryNames = (product?.categories || []).map((pc: any) => pc.category.name);
        const station = item.station === 'bar' || (product as any)?.station === 'bar' ? StationType.BAR : item.station === 'kitchen' || (product as any)?.station === 'kitchen' ? StationType.KITCHEN : product ? stationFromCategories(categoryNames) : StationType.KITCHEN;
        return {
          productId: product?.id,
          productNameSnapshot: product?.name || item.name || item.productId,
          unitPrice,
          qty,
          selectedOptions: item.customizations || item.selectedOptions || [],
          station,
        };
      });

      const subtotal = orderItems.reduce((sum: number, item: any) => sum + item.unitPrice * item.qty, 0);
      const discountResult = body.discountCode ? await this.consumeDiscountCodeDb(body.discountCode, subtotal) : null;
      const discountAmount = discountResult?.success ? Number(discountResult.data.discountAmount || 0) : 0;
      const finalTotal = Math.max(0, subtotal - discountAmount);
      const pendingLoyalty = calculateLoyaltyPoints(finalTotal, body.orderType, orderItems.reduce((sum: number, i: any) => sum + Number(i.qty || 1), 0));
      const loyalty = { ...pendingLoyalty, awarded: false, pending: true, message: 'امتیاز بعد از تایید پرداخت توسط ویتر ثبت می‌شود.' };

      const order = await this.prisma.order.create({
        data: {
          id,
          customerId: customer.id,
          tableName,
          tableQr,
          orderType: normalizeOrderType(body.orderType),
          status: OrderStatus.PENDING,
          paymentStatus: PaymentStatus.PENDING,
          paymentMethod: body.paymentMethod,
          address: body.address || '',
          phone: body.phone || customer.phone || '',
          subtotal,
          discountCode: discountResult?.success ? discountResult.data.discount.code : '',
          discountAmount,
          finalTotal,
          loyaltySnapshot: loyalty,
          items: { create: orderItems },
          statusLogs: { create: { status: OrderStatus.PENDING, note: 'سفارش ثبت شد' } },
        },
        include: { items: true, table: true, customer: true },
      });

      await this.createOrderStatusNotificationDb(customer.id, id, 'PENDING', 'سفارش ثبت شد', `سفارش #${id} ثبت شد و وارد صف آماده‌سازی شد.`);

      // Web Push به پنل‌های پرسنلی (fire-and-forget — هرگز ثبت سفارش را نگه نمی‌دارد)
      try {
        const hasBar = orderItems.some((it: any) => it.station === StationType.BAR);
        const hasKitchen = orderItems.some((it: any) => it.station === StationType.KITCHEN);
        if (hasBar) void this.pushService.pushToRole('bar', 'سفارش جدید ☕', `سفارش #${id} برای بخش بار ثبت شد`, '/bar');
        if (hasKitchen) void this.pushService.pushToRole('kitchen', 'سفارش جدید 🍳', `سفارش #${id} برای آشپزخانه ثبت شد`, '/kitchen');
        void this.pushService.pushToRole('waiter', 'سفارش جدید', `سفارش #${id} ثبت شد · مقصد: ${tableName}`, '/waiter');
      } catch { /* push باید هیچ‌وقت ثبت سفارش را مختل نکند */ }

      return { success: true, message: 'Order created successfully', data: mapOrder(order) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.createMemoryOrder(body);
    }
  }

  async updateStatus(id: string, status: string) {
    if (!this.prisma.isAvailable()) return this.updateMemoryStatus(id, status);
    try {
      const existing = await this.prisma.order.findUnique({ where: { id } });
      const nextStatus = status as OrderStatus;
      const updated = await this.prisma.order.update({ where: { id }, data: { status: nextStatus, statusLogs: { create: { status: nextStatus, note: 'تغییر وضعیت سفارش' } } } });
      const titles: Record<string, string> = { ACCEPTED: 'سفارش پذیرفته شد', READY_TO_SERVE: 'سفارش تو آماده شد', ON_THE_WAY: 'سفارش در مسیر میز است', DELIVERED: 'سفارش تحویل شد' };
      if (existing?.customerId) await this.createOrderStatusNotificationDb(existing.customerId, id, status, titles[status] || 'وضعیت سفارش تغییر کرد', `وضعیت سفارش #${id} به ${status} تغییر کرد.`);
      return { success: true, message: 'Order status updated', data: { id, status: updated.status } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.updateMemoryStatus(id, status);
    }
  }

  private async resolveCustomer(body: any) {
    const customerId = String(body?.customerId || '').trim();
    const phone = String(body?.phone || body?.customerPhone || '').trim();
    const name = String(body?.customerName || 'مهمان کافه داستان').trim() || 'مهمان کافه داستان';

    if (customerId) {
      const existing = await this.prisma.customer.findUnique({ where: { id: customerId } });
      if (existing) {
        return this.prisma.customer.update({ where: { id: existing.id }, data: { phone: phone || existing.phone, name: name || existing.name } });
      }
    }
    if (phone) {
      const existingByPhone = await this.prisma.customer.findUnique({ where: { phone } }).catch(() => null);
      if (existingByPhone) return existingByPhone;
    }
    return this.prisma.customer.create({ data: { phone: phone || null, name } });
  }

  private async deriveDbOrderStatus(orderId: string): Promise<OrderStatus> {
    const order = await this.prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
    if (!order) return OrderStatus.PENDING;
    if (order.status === OrderStatus.ON_THE_WAY || order.status === OrderStatus.DELIVERED || order.status === OrderStatus.CANCELLED) return order.status;
    const barItems = order.items.filter((item) => item.station === StationType.BAR);
    const kitchenItems = order.items.filter((item) => item.station === StationType.KITCHEN);
    const anyKitchenPreparing = kitchenItems.some((item) => item.stationStatus === StationStatus.PREPARING);
    const anyBarPreparing = barItems.some((item) => item.stationStatus === StationStatus.PREPARING);
    const barReady = barItems.length === 0 || barItems.every((item) => item.stationStatus === StationStatus.READY || item.stationStatus === StationStatus.DELIVERED);
    const kitchenReady = kitchenItems.length === 0 || kitchenItems.every((item) => item.stationStatus === StationStatus.READY || item.stationStatus === StationStatus.DELIVERED);
    if (anyKitchenPreparing) return OrderStatus.KITCHEN_PREPARING;
    if (anyBarPreparing) return OrderStatus.BAR_PREPARING;
    if (barReady && kitchenReady && order.items.length) return OrderStatus.READY_TO_SERVE;
    return OrderStatus.PENDING;
  }

  private async consumeDiscountCodeDb(code: string, total: number) {
    const normalized = normalizeDiscountCode(code);
    const discount = await this.prisma.discountCode.findUnique({ where: { code: normalized } });
    if (!normalized || !discount) return { success: false, message: 'کد تخفیف پیدا نشد.' };
    if (!discount.active) return { success: false, message: 'این کد تخفیف غیرفعال است.' };
    if (discount.once && discount.used) return { success: false, message: 'این کد تخفیف قبلاً استفاده شده است.' };
    const discountAmount = calculateDiscount(discount, total);
    if (discountAmount <= 0) return { success: false, message: 'این کد برای این سفارش قابل اعمال نیست.' };
    if (discount.once) await this.prisma.discountCode.update({ where: { id: discount.id }, data: { used: true } });
    return { success: true, data: { discount, discountAmount, finalTotal: Math.max(0, total - discountAmount) } };
  }

  private async awardLoyaltyForOrderDb(customerId: string, orderId: string, body: any, total: number) {
    const member = await this.loyaltyService.getOrCreateDbMember({ customerId, phone: body.phone || '', name: body.customerName || 'مهمان کافه داستان' });
    const calc = calculateLoyaltyPoints(total, body.orderType);
    const nextLifetime = member.lifetimePoints + calc.points;
    const tier = getTier(nextLifetime).title;
    const updated = await this.prisma.loyaltyMember.update({
      where: { id: member.id },
      data: {
        points: { increment: calc.points },
        lifetimePoints: { increment: calc.points },
        tier,
        history: { create: { type: 'earn', title: `امتیاز سفارش #${orderId}`, points: calc.points, orderId, note: `مبلغ ${Number(total || 0).toLocaleString('fa-IR')} تومان · ضریب ${calc.multiplier}` } },
      },
      include: { history: { orderBy: { createdAt: 'desc' } }, vouchers: { orderBy: { createdAt: 'desc' } } },
    });
    return { ...calc, member: updated };
  }

  private async createOrderStatusNotificationDb(customerId: string, orderId: string, status: string, title: string, body: string) {
    const exists = await this.prisma.notification.findFirst({ where: { customerId, orderId, status, deletedAt: null } });
    if (exists) return null;
    return this.prisma.notification.create({ data: { customerId, orderId, status, title, body, type: 'order-status' } });
  }

  private getMemoryOrder(id: string, user?: any) {
    const order = store.orders.find((o) => o.id === id);
    if (order) {
      order.status = deriveOrderStatus(id);
      return { success: true, data: order };
    }
    return { success: true, data: { id, table: 'میز فروغ', tableQr: 'QR-FOROUGH-01', status: deriveOrderStatus(id), items: [] } };
  }

  private createMemoryOrder(body: any) {
    const id = `${Date.now()}`;
    const tableName = body.tableName || body.tableId || 'میز فروغ';
    const tableQr = body.tableQr || 'QR-FOROUGH-01';
    const total = (body.items || []).reduce((sum: number, item: any) => {
      const product = store.products.find((p) => p.id === item.productId);
      const qty = Number(item.qty || 1);
      const unitPrice = Number(item.price || product?.price || 0);
      return sum + unitPrice * qty;
    }, 0);
    const discountResult = body.discountCode ? consumeDiscountCode(body.discountCode, total) : null;
    const discountAmount = discountResult?.success ? Number(discountResult.data.discountAmount || 0) : 0;
    const finalTotal = Math.max(0, total - discountAmount);
    const pendingLoyalty = calculateLoyaltyPoints(finalTotal, body.orderType, (body.items || []).reduce((sum: number, i: any) => sum + Number(i.qty || 1), 0));
    const created = { id, customerId: body.customerId || '', table: tableName, tableQr, status: 'PENDING', paymentStatus: 'PENDING', createdAt: new Date().toISOString(), paymentMethod: body.paymentMethod, orderType: body.orderType, address: body.address || '', phone: body.phone || '', total, discountCode: discountResult?.success ? discountResult.data.discount.code : '', discountAmount, finalTotal, loyalty: { ...pendingLoyalty, awarded: false, pending: true, message: 'امتیاز بعد از تایید پرداخت توسط ویتر ثبت می‌شود.' } as any, items: body.items || [] };
    store.orders.push(created);
    const grouped: Record<'bar' | 'kitchen', any[]> = { bar: [], kitchen: [] };
    for (const item of body.items || []) {
      const product = store.products.find((p) => p.id === item.productId);
      if (!product) continue;
      const productCategories = product.categories || [];
      const station: 'bar' | 'kitchen' = item.station === 'kitchen' || (product as any)?.station === 'kitchen' ? 'kitchen' : item.station === 'bar' || (product as any)?.station === 'bar' ? 'bar' : productCategories.some((cat) => cat.includes('نوشیدنی') || cat.includes('قهوه') || cat.includes('دمنوش') || cat.includes('شیک') || cat.includes('لاته') || cat.includes('موکا') || cat.includes('اسپرسو') || cat.includes('آمریکانو') || cat.includes('چای') || cat.includes('ماسالا') || cat.includes('کاپوچینو')) ? 'bar' : 'kitchen';
      grouped[station].push({ productId: product.id, name: product.name, qty: Number(item.qty || 1) });
    }
    (['bar', 'kitchen'] as const).forEach((station) => {
      const stationItems = grouped[station];
      if (!stationItems.length) return;
      const totalQty = stationItems.reduce((sum, item) => sum + item.qty, 0);
      const queueItem = { id: `${station}-${id}`, productId: stationItems[0].productId, name: stationItems.map((item) => `${item.qty}× ${item.name}`).join('، '), items: stationItems, qty: totalQty, tableName, tableQr, time: `${Math.max(4, totalQty * 3)} دقیقه`, status: 'جدید' as const, station, orderId: id };
      if (station === 'bar') store.barOrders.unshift(queueItem as any);
      else store.kitchenOrders.unshift(queueItem as any);
    });
    store.waiterTables.unshift({ id: `wt-${id}`, name: tableName, qrCode: tableQr, status: 'سفارش جدید', note: body.orderType === 'DELIVERY' ? `سفارش ارسالی ${id}` : `سفارش فعال ${id}`, orderId: id, orderType: body.orderType, address: body.address || '', phone: body.phone || '' } as any);
    created.status = deriveOrderStatus(id);
    createOrderStatusNotification(id, 'PENDING', 'سفارش ثبت شد', `سفارش #${id} ثبت شد و وارد صف آماده‌سازی شد.`);
    return { success: true, message: 'Order created successfully', data: created };
  }

  private updateMemoryStatus(id: string, status: string) {
    const order = store.orders.find((o) => o.id === id);
    if (order) order.status = status;
    const titles: Record<string, string> = { ACCEPTED: 'سفارش پذیرفته شد', READY_TO_SERVE: 'سفارش تو آماده شد', ON_THE_WAY: 'سفارش در مسیر میز است', DELIVERED: 'سفارش تحویل شد' };
    createOrderStatusNotification(id, status, titles[status] || 'وضعیت سفارش تغییر کرد', `وضعیت سفارش #${id} به ${status} تغییر کرد.`);
    return { success: true, message: 'Order status updated', data: { id, status } };
  }
}
