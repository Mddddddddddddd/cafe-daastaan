import { Body, Controller, Get, Param, Patch, Post, BadRequestException, Query, Req, UseGuards } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { requireFields } from '../../common/validation';
import { AuthGuardMock } from '../auth/auth.guard';

@Controller('orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @UseGuards(AuthGuardMock)
  @Get('active/mine')
  getMyActiveOrders(@Req() req: any) {
    return this.ordersService.getMyActiveOrders(req.user);
  }

  @UseGuards(AuthGuardMock)
  @Get('mine')
  getMyOrders(@Req() req: any) {
    return this.ordersService.getMyOrders(req.user);
  }

  @UseGuards(AuthGuardMock)
  @Get(':id')
  getOrder(@Param('id') id: string, @Req() req: any) {
    return this.ordersService.getOrder(id, req.user);
  }

  @Post()
  createOrder(@Body() body: CreateOrderDto, @Query('customerId') customerId?: string) {
    const check = requireFields(body as any, ['branchId', 'orderType', 'items']);
    if (!check.ok) throw new BadRequestException({ message: 'branchId, orderType and items are required', missing: check.missing });
    return this.ordersService.createOrder({ ...(body as any), customerId });
  }

  @Patch(':id/status')
  updateStatus(@Param('id') id: string, @Body() body: UpdateOrderStatusDto) {
    const check = requireFields(body as any, ['status']);
    if (!check.ok) throw new BadRequestException({ message: 'status is required', missing: check.missing });
    return this.ordersService.updateStatus(id, body.status);
  }
}