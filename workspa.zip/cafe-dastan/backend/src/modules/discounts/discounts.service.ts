import { Injectable } from '@nestjs/common';
import { store } from '../../store/data.store';
import { PrismaService } from '../../prisma/prisma.service';
import { mapDiscount } from '../../prisma/db-mapper';

export function normalizeDiscountCode(code: string) {
  return String(code || '').trim().toUpperCase().replace(/\s+/g, '');
}

export function generateDiscountCode(prefix = 'DASTAN') {
  return `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

export function calculateDiscount(discount: any, total: number) {
  const safeTotal = Math.max(0, Number(total || 0));
  if (!discount || discount.active === false || discount.used) return 0;
  if (discount.type === 'percent') return Math.min(safeTotal, Math.round(safeTotal * Math.min(100, Math.max(0, Number(discount.value || 0))) / 100));
  if (discount.type === 'free_order') return Math.min(safeTotal, Number(discount.value || safeTotal));
  return Math.min(safeTotal, Number(discount.value || 0));
}

export function validateDiscount(code: string, total: number) {
  const normalized = normalizeDiscountCode(code);
  const discount = store.discountCodes.find((d: any) => normalizeDiscountCode(d.code) === normalized);
  if (!normalized || !discount) return { success: false, message: 'کد تخفیف پیدا نشد.' };
  if (discount.active === false) return { success: false, message: 'این کد تخفیف غیرفعال است.' };
  if (discount.once && discount.used) return { success: false, message: 'این کد تخفیف قبلاً استفاده شده است.' };
  const discountAmount = calculateDiscount(discount, total);
  if (discountAmount <= 0) return { success: false, message: 'این کد برای این سفارش قابل اعمال نیست.' };
  return { success: true, data: { discount, discountAmount, finalTotal: Math.max(0, Number(total || 0) - discountAmount) } };
}

export function createDiscountCode(payload: any, source: 'admin' | 'loyalty' = 'admin') {
  const code = normalizeDiscountCode(payload?.code || generateDiscountCode(source === 'loyalty' ? 'CLUB' : 'DASTAN'));
  const existing = store.discountCodes.find((d: any) => normalizeDiscountCode(d.code) === code);
  if (existing) return existing;
  const discount = {
    id: `dc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    code,
    title: payload?.title || 'کد تخفیف کافه داستان',
    type: payload?.type || 'fixed',
    value: Number(payload?.value || 0),
    active: payload?.active !== false,
    once: payload?.once !== false,
    used: false,
    source,
    rewardId: payload?.rewardId || undefined,
    createdAt: new Date().toISOString(),
  };
  store.discountCodes.unshift(discount as any);
  return discount;
}

export function consumeDiscountCode(code: string, total: number) {
  const validation = validateDiscount(code, total);
  if (!validation.success) return validation;
  const discount = validation.data.discount;
  if (discount.once) discount.used = true;
  return validation;
}

@Injectable()
export class DiscountsService {
  constructor(private readonly prisma: PrismaService) {}

  async validate(body: any) {
    const total = Number(body?.total || 0);
    if (!this.prisma.isAvailable()) return validateDiscount(body?.code, total);
    try {
      const normalized = normalizeDiscountCode(body?.code);
      const discount = await this.prisma.discountCode.findUnique({ where: { code: normalized } });
      if (!normalized || !discount) return { success: false, message: 'کد تخفیف پیدا نشد.' };
      if (!discount.active) return { success: false, message: 'این کد تخفیف غیرفعال است.' };
      if (discount.once && discount.used) return { success: false, message: 'این کد تخفیف قبلاً استفاده شده است.' };
      const discountAmount = calculateDiscount(discount, total);
      if (discountAmount <= 0) return { success: false, message: 'این کد برای این سفارش قابل اعمال نیست.' };
      return { success: true, data: { discount: mapDiscount(discount), discountAmount, finalTotal: Math.max(0, total - discountAmount) } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return validateDiscount(body?.code, total);
    }
  }
}
