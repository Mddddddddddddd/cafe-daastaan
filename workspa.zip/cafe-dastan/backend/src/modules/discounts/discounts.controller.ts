import { Body, Controller, Post } from '@nestjs/common';
import { DiscountsService } from './discounts.service';

@Controller('discounts')
export class DiscountsController {
  constructor(private readonly discountsService: DiscountsService) {}

  @Post('validate')
  validate(@Body() body: any) { return this.discountsService.validate(body); }
}
