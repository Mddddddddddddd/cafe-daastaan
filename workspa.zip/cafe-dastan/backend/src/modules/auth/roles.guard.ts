import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { ROLES_KEY, RoleKey } from './roles';

function readRoles(target: any): RoleKey[] {
  if (!target || typeof Reflect === 'undefined' || typeof Reflect.getMetadata !== 'function') return [];
  return Reflect.getMetadata(ROLES_KEY, target) || [];
}

@Injectable()
export class RolesGuardMock implements CanActivate {
  // عمداً constructor ندارد تا Nest هیچ dependency اضافه‌ای مثل Array تزریق نکند.
  // این دقیقاً خطای RolesGuardMock (Reflector, ?) را برای همیشه حذف می‌کند.
  canActivate(context: ExecutionContext): boolean {
    const allowedRoles = [...readRoles(context.getClass()), ...readRoles(context.getHandler())];
    if (!allowedRoles.length) return true;

    const req = context.switchToHttp().getRequest();
    const role = req.user?.role;
    if (!allowedRoles.includes(role)) throw new ForbiddenException('Access denied for this role');
    return true;
  }
}
