import { ForbiddenException, UnauthorizedException } from '@nestjs/common';

export type CustomerAuthUser = {
  id: string;
  role?: string;
  phone?: string;
  name?: string;
  username?: string;
};

export function assertCustomerUser(user?: any): CustomerAuthUser {
  if (!user) throw new UnauthorizedException('احراز هویت مشتری انجام نشده است.');
  if (String(user.role || '').toLowerCase() !== 'customer') {
    throw new ForbiddenException('این مسیر فقط برای مشتری واردشده قابل دسترسی است.');
  }
  return user as CustomerAuthUser;
}

export function ensureCustomerOwnsResource(user: any, customerId?: string | null) {
  const customer = assertCustomerUser(user);
  if (customerId && String(customer.id) !== String(customerId)) {
    throw new ForbiddenException('شما به اطلاعات مشتری دیگر دسترسی ندارید.');
  }
  return customer;
}
