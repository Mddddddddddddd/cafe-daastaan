import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtServiceMock } from './jwt.service';
import { AuthGuardMock } from './auth.guard';
import { RolesGuardMock } from './roles.guard';
import { ProfileController } from './profile.controller';

@Module({
  controllers: [AuthController, ProfileController],
  providers: [AuthService, JwtServiceMock, AuthGuardMock, RolesGuardMock],
  exports: [JwtServiceMock, AuthGuardMock, RolesGuardMock],
})
export class AuthModule {}