import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtServiceMock } from './jwt.service';

function authEnforced() {
  return String(process.env.AUTH_ENFORCE || '').toLowerCase() === 'true';
}

@Injectable()
export class AuthGuardMock implements CanActivate {
  constructor(private readonly jwtService: JwtServiceMock) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    const auth = req.headers['authorization'];

    if (!auth) {
      if (!authEnforced()) {
        req.user = { id: 'dev-admin', role: 'admin', devBypass: true };
        return true;
      }
      throw new UnauthorizedException('Missing authorization header');
    }
    const token = String(auth).replace('Bearer ', '');
    const payload = this.jwtService.verify(token);
    if (!payload) throw new UnauthorizedException('Invalid token');
    req.user = payload;
    return true;
  }
}
