import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';

const KEY_LEN = 64;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(String(password || ''), salt, KEY_LEN).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash?: string) {
  const stored = String(storedHash || '');
  if (!stored) return false;

  // پشتیبانی مهاجرتی برای داده‌های قدیمی seed که plain/mock بودند.
  // بعد از اجرای دوباره seed، همه رمزها scrypt می‌شوند.
  if (!stored.startsWith('scrypt:')) return String(password || '') === stored;

  const [, salt, expectedHex] = stored.split(':');
  if (!salt || !expectedHex) return false;
  const actual = Buffer.from(scryptSync(String(password || ''), salt, KEY_LEN).toString('hex'), 'hex');
  const expected = Buffer.from(expectedHex, 'hex');
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}
