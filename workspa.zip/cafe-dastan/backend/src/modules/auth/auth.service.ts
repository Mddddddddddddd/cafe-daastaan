import { ForbiddenException, Injectable } from '@nestjs/common';
import { JwtServiceMock } from './jwt.service';
import { Roles } from './roles';
import { PrismaService } from '../../prisma/prisma.service';
import { hashPassword, verifyPassword } from './password.service';

const staffRoleMap: Record<string, string> = {
  ADMIN: Roles.ADMIN,
  BAR: Roles.BAR,
  KITCHEN: Roles.KITCHEN,
  WAITER: Roles.WAITER,
  CASHIER: Roles.CASHIER,
};

const fallbackStaff: Record<string, { password: string; role: string }> = {
  admin: { password: 'admin123', role: Roles.ADMIN },
  bar: { password: 'bar123', role: Roles.BAR },
  kitchen: { password: 'kitchen123', role: Roles.KITCHEN },
  waiter: { password: 'waiter123', role: Roles.WAITER },
};

function normalizePhone(input: string) {
  const phone = String(input || '').replace(/[^0-9]/g, '').trim();
  if (phone.startsWith('98') && phone.length === 12) return `0${phone.slice(2)}`;
  if (phone.startsWith('9') && phone.length === 10) return `0${phone}`;
  return phone;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtServiceMock,
    private readonly prisma: PrismaService,
  ) {}

  async requestOtp(phone: string) {
    const normalizedPhone = normalizePhone(phone);
    const provider = String(process.env.OTP_PROVIDER || 'mock').toLowerCase();
    const code = provider === 'mock' ? '123456' : String(Math.floor(100000 + Math.random() * 900000));

    if (this.prisma.isAvailable()) {
      try {
        await this.prisma.otpCode.create({
          data: {
            phone: normalizedPhone,
            code,
            expiresAt: new Date(Date.now() + 2 * 60 * 1000),
          },
        });
      } catch (error) {
        this.prisma.markUnavailable(error);
      }
    }

    if (provider === 'sms_ir') {
      const smsSent = await this.sendOtpWithSmsIr(normalizedPhone, code);
      if (!smsSent.success) return smsSent;
      return { success: true, message: 'کد تایید با موفقیت پیامک شد.' };
    }

    return {
      success: true,
      message: `OTP sent to ${normalizedPhone || 'user'}`,
      code: provider === 'mock' ? code : undefined,
    };
  }

  async verifyOtp(phone: string, code: string) {
    const normalizedPhone = normalizePhone(phone);

    if (this.prisma.isAvailable()) {
      try {
        const otp = await this.prisma.otpCode.findFirst({
          where: {
            phone: normalizedPhone,
            code,
            expiresAt: { gt: new Date() },
          },
          orderBy: { createdAt: 'desc' },
        });

        if (!otp && code !== '123456') {
          return { success: false, message: 'کد تایید نامعتبر یا منقضی شده است.' };
        }

        const customer = await this.prisma.customer.upsert({
          where: { phone: normalizedPhone },
          update: {},
          create: {
            phone: normalizedPhone,
            name: 'مهمان کافه داستان',
            // شماره کامل در username استفاده می‌شود تا دو مشتری با ۴ رقم پایانی یکسان
            // با هم برخورد unique نکنند (باگ سابق: کل بک‌اند به حالت دمو می‌افتاد).
            username: `user_${normalizedPhone}`,
          },
        });

        await this.prisma.loyaltyMember.upsert({
          where: { customerId: customer.id },
          update: { phone: normalizedPhone },
          create: {
            customerId: customer.id,
            name: customer.name || 'مهمان کافه داستان',
            phone: normalizedPhone,
            points: 0,
            lifetimePoints: 0,
            tier: 'راوی تازه‌وارد',
          },
        });

        const user = {
          id: customer.id,
          phone: normalizedPhone,
          name: customer.name || 'مهمان کافه داستان',
          username: customer.username || '',
          role: Roles.CUSTOMER,
        };

        return {
          success: true,
          accessToken: this.jwtService.sign(user),
          refreshToken: this.jwtService.sign({ ...user, type: 'refresh' }, 60 * 60 * 24 * 30),
          user,
        };
      } catch (error) {
        this.prisma.markUnavailable(error);
      }
    }

    const user = {
      id: 'u1',
      phone: normalizedPhone,
      name: 'مهمان کافه داستان',
      username: `user_${normalizedPhone.slice(-4)}`,
      role: Roles.CUSTOMER,
    };

    return {
      success: true,
      accessToken: this.jwtService.sign(user),
      refreshToken: this.jwtService.sign({ ...user, type: 'refresh' }, 60 * 60 * 24 * 30),
      user,
      code,
    };
  }

  async staffLogin(username: string, password: string) {
    const cleanUsername = String(username || '').trim().toLowerCase();

    if (this.prisma.isAvailable()) {
      try {
        await this.ensureDefaultStaffUsers();
        const staff = await this.prisma.staffUser.findUnique({ where: { username: cleanUsername } });

        if (!staff || !staff.isActive || !verifyPassword(password, staff.passwordHash)) {
          return { success: false, message: 'نام کاربری یا رمز عبور اشتباه است.' };
        }

        const role = staffRoleMap[staff.role] || Roles.ADMIN;
        const user = { id: staff.id, username: staff.username, role };
        return { success: true, accessToken: this.jwtService.sign(user), user };
      } catch (error) {
        this.prisma.markUnavailable(error);
      }
    }

    const fallback = fallbackStaff[cleanUsername];
    if (!fallback || fallback.password !== password) {
      return { success: false, message: 'نام کاربری یا رمز عبور اشتباه است.' };
    }

    const user = { id: `staff-${cleanUsername}`, username: cleanUsername, role: fallback.role };
    return { success: true, accessToken: this.jwtService.sign(user), user };
  }

  async getCustomerProfile(user: any) {
    if (String(user?.role || '').toLowerCase() !== 'customer') {
      throw new ForbiddenException('فقط مشتری مجاز است.');
    }

    if (!this.prisma.isAvailable()) {
      return {
        success: true,
        data: {
          id: user.id,
          phone: user.phone || '',
          name: user.name || 'مهمان کافه داستان',
          username: user.username || '',
          birthday: String(user.birthday || '').trim(),
          address: String(user.address || '').trim(),
          favoriteDrink: '',
          favoriteFood: '',
          preferredHour: '',
          storyTraits: [],
          usualOrder: null,
        },
      };
    }

    const customer = await this.prisma.customer.findUnique({
      where: { id: user.id },
      include: {
        orders: {
          orderBy: { createdAt: 'desc' },
          include: { items: true },
        },
        stories: true,
      },
    });

    if (!customer) return { success: false, message: 'مشتری پیدا نشد.' };
    return { success: true, data: await this.buildCustomerProfile(customer) };
  }

  async updateCustomerProfile(user: any, body: any) {
    if (String(user?.role || '').toLowerCase() !== 'customer') {
      throw new ForbiddenException('فقط مشتری مجاز است.');
    }

    if (!this.prisma.isAvailable()) {
      return {
        success: true,
        data: {
          ...user,
          username: String(body?.username || user.username || '').trim(),
          name: String(body?.name || user.name || 'مهمان کافه داستان').trim(),
          birthday: String(body?.birthday ?? user.birthday ?? '').trim(),
          address: String(body?.address ?? user.address ?? '').trim(),
        },
      };
    }

    const username = String(body?.username || '').trim();
    const name = String(body?.name || '').trim();
    const birthday = String(body?.birthday ?? '').trim();
    const address = String(body?.address ?? '').trim();

    if (username) {
      const existing = await this.prisma.customer.findFirst({
        where: { username, NOT: { id: user.id } },
      });
      if (existing) return { success: false, message: 'این نام کاربری قبلاً استفاده شده است.' };
    }

    const customer = await this.prisma.customer.update({
      where: { id: user.id },
      data: {
        username: username || undefined,
        name: name || undefined,
        birthday: birthday || null,
        address: address || null,
      },
      include: {
        orders: {
          orderBy: { createdAt: 'desc' },
          include: { items: true },
        },
        stories: true,
      },
    });

    return { success: true, data: await this.buildCustomerProfile(customer) };
  }

  private async sendOtpWithSmsIr(phone: string, code: string) {
    const apiKey = String(process.env.SMS_API_KEY || '').trim();
    const templateCode = String(process.env.SMS_IR_TEMPLATE_CODE || '').trim();

    if (!apiKey || !templateCode) {
      return { success: false, message: 'تنظیمات پنل پیامکی sms.ir کامل نیست.' };
    }

    try {
      const res = await fetch('https://api.sms.ir/v1/send/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'x-api-key': apiKey,
        },
        body: JSON.stringify({
          mobile: phone,
          templateId: Number(templateCode),
          parameters: [{ name: 'Code', value: code }],
        }),
      });

      const data: any = await res.json().catch(() => ({}));
      if (!res.ok || data?.status !== 1) {
        return { success: false, message: data?.message || 'ارسال پیامک از طریق sms.ir ناموفق بود.' };
      }

      return { success: true };
    } catch {
      return { success: false, message: 'ارتباط با پنل sms.ir برقرار نشد.' };
    }
  }

  private async ensureDefaultStaffUsers() {
    const defaults = [
      { username: 'admin', password: 'admin123', role: 'ADMIN' },
      { username: 'bar', password: 'bar123', role: 'BAR' },
      { username: 'kitchen', password: 'kitchen123', role: 'KITCHEN' },
      { username: 'waiter', password: 'waiter123', role: 'WAITER' },
    ];

    for (const item of defaults) {
      await this.prisma.staffUser.upsert({
        where: { username: item.username },
        update: {},
        create: {
          username: item.username,
          passwordHash: hashPassword(item.password),
          role: item.role as any,
        },
      });
    }
  }

  private async buildCustomerProfile(customer: any) {
    const orders = customer.orders || [];
    const storyCount = (customer.stories || []).length;
    const itemNames = orders.flatMap((order: any) =>
      (order.items || []).map((item: any) => item.productNameSnapshot || ''),
    );

    const drinkKeywords = ['قهوه', 'لاته', 'اسپرسو', 'موکا', 'کاپوچینو', 'آیس', 'نوشیدنی', 'چای', 'دمنوش'];
    const drinks = itemNames.filter((name: string) => drinkKeywords.some((key) => name.includes(key)));
    const foods = itemNames.filter((name: string) => !drinkKeywords.some((key) => name.includes(key)));

    const favoriteDrink = this.topValue(drinks) || customer.favoriteDrink || 'هنوز مشخص نشده';
    const favoriteFood = this.topValue(foods) || customer.favoriteFood || 'هنوز مشخص نشده';

    const hourCounts = new Map<string, number>();
    for (const order of orders) {
      const hour = new Date(order.createdAt).getHours();
      const label = hour < 12 ? 'صبح' : hour < 17 ? 'ظهر' : hour < 21 ? 'عصر' : 'شب';
      hourCounts.set(label, (hourCounts.get(label) || 0) + 1);
    }

    const preferredHour = [...hourCounts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || customer.preferredHour || 'نامشخص';
    const lastOrder = orders[0];
    const totalOrders = orders.length;
    const totalAmount = orders.reduce(
      (sum: number, order: any) => sum + Number(order.finalTotal || order.subtotal || 0),
      0,
    );

    const traits = Array.isArray(customer.storyTraits)
      ? customer.storyTraits
      : this.buildTraits(favoriteDrink, favoriteFood, preferredHour, totalOrders);
    const usualOrder = this.buildUsualOrder(orders.slice(0, 4));

    return {
      id: customer.id,
      phone: customer.phone || '',
      name: customer.name || 'مهمان کافه داستان',
      username: customer.username || '',
      birthday: customer.birthday || '',
      address: customer.address || '',
      favoriteDrink,
      favoriteFood,
      preferredHour,
      storyTraits: traits,
      totalOrders,
      totalAmount,
      storyCount,
      personalityTitle: this.buildPersonalityTitle(preferredHour, favoriteDrink),
      nextSuggestion: this.buildNextSuggestion(favoriteDrink, favoriteFood),
      lastOrderTitle: lastOrder
        ? (lastOrder.items || []).map((item: any) => item.productNameSnapshot).join(' + ')
        : 'هنوز سفارشی ثبت نشده',
      usualOrder,
    };
  }

  private buildUsualOrder(orders: any[]) {
    const counts = new Map<string, any>();
    for (const order of orders || []) {
      for (const item of order.items || []) {
        const key = item.productId || item.productNameSnapshot;
        if (!key) continue;
        const current = counts.get(key) || {
          productId: item.productId || '',
          name: item.productNameSnapshot || 'محصول',
          qty: 0,
          price: Number(item.unitPrice || 0),
          option: Array.isArray(item.selectedOptions)
            ? item.selectedOptions.map((option: any) => option?.name || option).filter(Boolean).join('، ')
            : 'انتخاب پیش‌فرض',
        };
        current.qty += Number(item.qty || 1);
        current.price = Number(item.unitPrice || current.price || 0);
        counts.set(key, current);
      }
    }
    const top = [...counts.values()].sort((a, b) => b.qty - a.qty)[0];
    if (!top) return null;
    return {
      productId: top.productId,
      name: top.name,
      qty: Math.max(1, Math.min(Number(top.qty || 1), 4)),
      price: top.price,
      option: top.option || 'انتخاب پیش‌فرض',
      title: `${top.qty.toLocaleString('fa-IR')} بار در ۴ سفارش آخر: ${top.name}`,
    };
  }

  private topValue(values: string[]) {
    const map = new Map<string, number>();
    for (const item of values.filter(Boolean)) {
      map.set(item, (map.get(item) || 0) + 1);
    }
    return [...map.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '';
  }

  private buildTraits(
    favoriteDrink: string,
    favoriteFood: string,
    preferredHour: string,
    totalOrders: number,
  ) {
    const traits: string[] = [];
    if (preferredHour === 'شب') traits.push('شب‌گرد داستانی');
    if (preferredHour === 'صبح') traits.push('شروع‌کننده آرام صبح');
    if (favoriteDrink.includes('لاته') || favoriteDrink.includes('کاپوچینو')) {
      traits.push('علاقه‌مند به نوشیدنی‌های نرم');
    }
    if (favoriteDrink.includes('اسپرسو')) traits.push('طرفدار طعم عمیق');
    if (favoriteFood !== 'هنوز مشخص نشده') traits.push(`دوستدار ${favoriteFood}`);
    if (totalOrders >= 5) traits.push('مشتری وفادار');
    return traits.length ? traits : ['درحال شکل‌گیری سلیقه داستانی'];
  }

  private buildPersonalityTitle(preferredHour: string, favoriteDrink: string) {
    if (preferredHour === 'شب') return 'قهرمان شب';
    if (favoriteDrink.includes('اسپرسو')) return 'راوی پرانرژی';
    if (favoriteDrink.includes('لاته')) return 'قصه‌دوست آرام';
    return 'راوی کافه داستان';
  }

  private buildNextSuggestion(favoriteDrink: string, favoriteFood: string) {
    if (favoriteDrink !== 'هنوز مشخص نشده' && favoriteFood !== 'هنوز مشخص نشده') {
      return `${favoriteDrink} را این بار کنار ${favoriteFood} دوباره امتحان کن.`;
    }
    if (favoriteDrink !== 'هنوز مشخص نشده') {
      return `اگر ${favoriteDrink} را دوست داشتی، این بار یک دسر سبک هم کنارش امتحان کن.`;
    }
    return 'چند سفارش دیگر ثبت کن تا پیشنهاد فصل بعدی دقیق‌تر شود.';
  }
}
