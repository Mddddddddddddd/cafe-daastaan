import { Injectable } from '@nestjs/common';
import { createHmac, timingSafeEqual } from 'crypto';

function base64Url(input: Buffer | string) {
  return Buffer.from(input).toString('base64url');
}

function decodeBase64Url(input: string) {
  return Buffer.from(input, 'base64url').toString('utf8');
}

@Injectable()
export class JwtServiceMock {
  private get secret() {
    return process.env.JWT_SECRET || 'dev-only-change-me';
  }

  sign(payload: Record<string, any>, expiresInSeconds = 60 * 60 * 8) {
    const header = { alg: 'HS256', typ: 'JWT' };
    const now = Math.floor(Date.now() / 1000);
    const body = { ...payload, iat: now, exp: now + expiresInSeconds };
    const encodedHeader = base64Url(JSON.stringify(header));
    const encodedPayload = base64Url(JSON.stringify(body));
    const signature = this.signRaw(`${encodedHeader}.${encodedPayload}`);
    return `${encodedHeader}.${encodedPayload}.${signature}`;
  }

  verify(token: string) {
    try {
      const [header, payload, signature] = String(token || '').split('.');
      if (!header || !payload || !signature) return null;
      const expected = this.signRaw(`${header}.${payload}`);
      const a = Buffer.from(signature);
      const b = Buffer.from(expected);
      if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
      const data = JSON.parse(decodeBase64Url(payload));
      if (data.exp && Math.floor(Date.now() / 1000) > data.exp) return null;
      return data;
    } catch {
      return null;
    }
  }

  private signRaw(value: string) {
    return createHmac('sha256', this.secret).update(value).digest('base64url');
  }
}
