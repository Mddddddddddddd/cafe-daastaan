import { Body, Controller, Post, BadRequestException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { RequestOtpDto } from './dto/request-otp.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { StaffLoginDto } from './dto/staff-login.dto';
import { requireFields } from '../../common/validation';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('request-otp')
  requestOtp(@Body() body: RequestOtpDto) {
    const check = requireFields(body, ['phone']);
    if (!check.ok) throw new BadRequestException({ message: 'phone is required', missing: check.missing });
    return this.authService.requestOtp(body.phone);
  }

  @Post('verify-otp')
  verifyOtp(@Body() body: VerifyOtpDto) {
    const check = requireFields(body, ['phone', 'code']);
    if (!check.ok) throw new BadRequestException({ message: 'phone and code are required', missing: check.missing });
    return this.authService.verifyOtp(body.phone, body.code);
  }

  @Post('staff-login')
  staffLogin(@Body() body: StaffLoginDto) {
    const check = requireFields(body, ['username', 'password']);
    if (!check.ok) throw new BadRequestException({ message: 'username and password are required', missing: check.missing });
    return this.authService.staffLogin(body.username, body.password);
  }
}