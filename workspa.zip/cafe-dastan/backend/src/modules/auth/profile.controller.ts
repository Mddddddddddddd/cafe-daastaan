import { Body, Controller, Get, Patch, Req, UseGuards } from '@nestjs/common';
import { AuthGuardMock } from './auth.guard';
import { AuthService } from './auth.service';

@Controller('me')
@UseGuards(AuthGuardMock)
export class ProfileController {
  constructor(private readonly authService: AuthService) {}

  @Get()
  getMe(@Req() req: any) {
    return this.authService.getCustomerProfile(req.user);
  }

  @Patch()
  updateMe(@Req() req: any, @Body() body: any) {
    return this.authService.updateCustomerProfile(req.user, body);
  }
}
