import { SetMetadata } from '@nestjs/common';

export const Roles = {
  CUSTOMER: 'customer',
  ADMIN: 'admin',
  CASHIER: 'cashier',
  WAITER: 'waiter',
  BAR: 'bar',
  KITCHEN: 'kitchen',
} as const;

export type RoleKey = (typeof Roles)[keyof typeof Roles];

export const ROLES_KEY = 'roles';
export const RequireRoles = (...roles: RoleKey[]) => SetMetadata(ROLES_KEY, roles);
