import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { LoyaltyService } from './loyalty.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

// مدیریت باشگاه مشتریان توسط ادمین
@UseGuards(AuthGuardMock, RolesGuardMock)
@RequireRoles(Roles.ADMIN)
@Controller('loyalty/admin')
export class LoyaltyAdminController {
  constructor(private readonly loyaltyService: LoyaltyService) {}

  @Get('members')
  getMembers(@Query('q') q?: string) {
    return this.loyaltyService.adminGetMembers(q);
  }

  @Patch('members/:id')
  adjustMember(@Param('id') id: string, @Body() body: any) {
    return this.loyaltyService.adminAdjustMember(id, body);
  }

  @Get('reward-codes')
  getRewardCodes() {
    return this.loyaltyService.adminGetRewardCodes();
  }

  @Post('reward-codes/:id/disable')
  disableRewardCode(@Param('id') id: string) {
    return this.loyaltyService.adminDisableRewardCode(id);
  }
}
