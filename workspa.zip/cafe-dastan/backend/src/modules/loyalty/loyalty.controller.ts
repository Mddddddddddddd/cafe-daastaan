import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { LoyaltyService } from './loyalty.service';

@Controller('loyalty')
export class LoyaltyController {
  constructor(private readonly loyaltyService: LoyaltyService) {}

  @Get()
  getMember(@Query('customerId') customerId?: string, @Query('phone') phone?: string, @Query('name') name?: string) {
    return this.loyaltyService.getMember({ customerId, phone, name });
  }

  @Post('redeem')
  redeem(@Body() body: any) { return this.loyaltyService.redeem(body); }

  @Post('reward-code')
  createRewardCode(@Body() body: any) { return this.loyaltyService.createRewardCode(body); }
}
