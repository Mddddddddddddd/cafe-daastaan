import { Injectable } from '@nestjs/common';
import { store } from '../../store/data.store';
import { createDiscountCode, generateDiscountCode, normalizeDiscountCode } from '../discounts/discounts.service';
import { PrismaService } from '../../prisma/prisma.service';

export const loyaltyRewards = [
  { id: 'free-delivery', title: 'ارسال رایگان', points: 200, description: 'حذف هزینه ارسال برای سفارش ارسالی بعدی.' },
  { id: 'free-coffee', title: 'نوشیدنی رایگان', points: 300, description: 'یک نوشیدنی گرم یا سرد منتخب مهمان کافه داستان.' },
  { id: 'free-dessert', title: 'دسر رایگان', points: 500, description: 'یک دسر منتخب کنار سفارش بعدی.' },
  { id: 'free-order', title: 'سفارش رایگان تا ۵۰۰ هزار تومان', points: 1000, description: 'یک سفارش کامل تا سقف ۵۰۰ هزار تومان.' },
  { id: 'vip-night', title: 'دعوت VIP کافه داستان', points: 1500, description: 'یک تجربه ویژه برای مشتری وفادار؛ مناسب کمپین‌های آینده.' },
];

function normalizeCustomerIdentity(input?: any) {
  return {
    customerId: String(input?.customerId || '').trim(),
    phone: String(input?.phone || '').trim(),
    name: String(input?.name || 'مهمان کافه داستان').trim() || 'مهمان کافه داستان',
  };
}

export function getTier(points: number) {
  if (points >= 1500) return { id: 'platinum', title: 'راوی پلاتینی', next: null, color: '#B99B6B' };
  if (points >= 800) return { id: 'gold', title: 'راوی طلایی', next: 1500, color: '#B99B6B' };
  if (points >= 300) return { id: 'silver', title: 'راوی نقره‌ای', next: 800, color: '#79B4B7' };
  return { id: 'starter', title: 'راوی تازه‌وارد', next: 300, color: '#3F6F72' };
}

// قیمت‌های منوی اصلی به «تومان بدون سه صفر آخر» ثبت شده‌اند (مثلاً ۶۵ = ۶۵٬۰۰۰ تومان).
// مقدارهای ۱۰٬۰۰۰ و به بالا (محصولات دموی قدیمی) تومان کامل فرض می‌شوند.
// امتیازدهی شفاف و متناسب با مبلغ + تعداد آیتم + نوع سفارش:
//  • هر ۵٬۰۰۰ تومان واقعی = ۱ امتیاز (پایه)
//  • هر آیتم بیش از ۳ آیتم = +۵ امتیاز
//  • ضریب نوع سفارش: ارسال ×۱٫۲ · بیرون‌بر ×۰٫۹ · میز ×۱
//  • بونوس سفارش پربار (تومان واقعی): ۲۵۰ه+ → +۱۰ · ۵۰۰ه+ → +۲۰ · ۱م+ → +۴۰ · ۲م+ → +۸۰
export function calculateLoyaltyPoints(total: number, orderType?: string, itemCount = 0) {
  const t = Math.max(0, Number(total || 0));
  const toman = t < 10000 ? t * 1000 : t;
  const base = Math.floor(toman / 10000);
  const itemBonus = Math.max(0, Number(itemCount || 0) - 3) * 5;
  const multiplier = orderType === 'DELIVERY' ? 1.2 : orderType === 'TAKE_AWAY' ? 0.9 : 1;
  const bonus = toman >= 2000000 ? 80 : toman >= 1000000 ? 40 : toman >= 500000 ? 20 : toman >= 250000 ? 10 : 0;
  const points = Math.max(1, Math.round((base + itemBonus) * multiplier) + bonus);
  return { points, base, itemBonus, bonus, multiplier, toman };
}

export function awardLoyaltyForOrder(order: any, total: number) {
  const member = store.loyalty.member;
  const calc = calculateLoyaltyPoints(total, order.orderType);
  member.points += calc.points;
  member.lifetimePoints += calc.points;
  member.tier = getTier(member.lifetimePoints).title;
  member.history.unshift({
    id: `lh-${Date.now()}`,
    type: 'earn',
    title: `امتیاز سفارش #${order.id}`,
    points: calc.points,
    orderId: order.id,
    createdAt: new Date().toISOString(),
    note: `مبلغ ${Number(total || 0).toLocaleString('fa-IR')} تومان · ضریب ${calc.multiplier}`,
  });
  return { ...calc, member };
}


function rewardDiscountMeta(rewardId: string) {
  switch (String(rewardId || '').trim()) {
    case 'free-delivery':
      return { discountType: 'fixed', discountValue: 60000 };
    case 'free-order':
      return { discountType: 'free_order', discountValue: 500000 };
    case 'free-dessert':
      return { discountType: 'fixed', discountValue: 120000 };
    case 'vip-night':
      return { discountType: 'fixed', discountValue: 250000 };
    case 'free-coffee':
    default:
      return { discountType: 'fixed', discountValue: 90000 };
  }
}

export function awardLoyaltyForFeedback(orderId: string) {
  const member = store.loyalty.member;
  const existing = (member.history || []).find((item: any) => item.type === 'feedback' && item.orderId === orderId);
  if (existing) return { awarded: false, points: 0, member };
  const points = 35;
  member.points += points;
  member.lifetimePoints += points;
  member.tier = getTier(member.lifetimePoints).title;
  member.history.unshift({
    id: `lh-${Date.now()}`,
    type: 'feedback',
    title: `امتیاز نظرسنجی سفارش #${orderId}`,
    points,
    orderId,
    createdAt: new Date().toISOString(),
    note: 'امتیاز تشکر بابت ثبت نظر و کمک به بهتر شدن تجربه کافه داستان',
  });
  return { awarded: true, points, member };
}

function mapMember(member: any) {
  return {
    id: member.id,
    customerId: member.customerId || '',
    name: member.name,
    phone: member.phone || '',
    points: member.points,
    lifetimePoints: member.lifetimePoints,
    tier: member.tier,
    vouchers: (member.vouchers || []).map((v: any) => ({
      id: v.id,
      code: v.code,
      discountCodeId: v.discountCodeId,
      rewardId: v.rewardId,
      title: v.title,
      points: v.points,
      status: v.status,
      createdAt: v.createdAt instanceof Date ? v.createdAt.toISOString() : v.createdAt,
    })),
    history: (member.history || []).map((h: any) => ({
      id: h.id,
      type: h.type,
      title: h.title,
      points: h.points,
      orderId: h.orderId || undefined,
      note: h.note || '',
      createdAt: h.createdAt instanceof Date ? h.createdAt.toISOString() : h.createdAt,
    })),
  };
}

@Injectable()
export class LoyaltyService {
  constructor(private readonly prisma: PrismaService) {}

  async getMember(identity?: any) {
    if (!this.prisma.isAvailable()) return this.getMemoryMember();
    try {
      const member = await this.getOrCreateDbMember(identity);
      const mapped = mapMember(member);
      const tier = getTier(mapped.lifetimePoints);
      const nextReward = loyaltyRewards.find((r) => r.points > mapped.points) || null;
      return { success: true, data: { member: mapped, tier, rewards: loyaltyRewards, nextReward } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.getMemoryMember();
    }
  }

  async redeem(body: any) {
    if (!this.prisma.isAvailable()) return this.memoryRedeem(body);
    try {
      const reward = loyaltyRewards.find((r) => r.id === body?.rewardId);
      if (!reward) return { success: false, message: 'Reward not found' };
      const member = await this.getOrCreateDbMember(body);
      if (member.points < reward.points) return { success: false, message: 'امتیاز کافی نیست', data: { member: mapMember(member), reward } };
      const { discountType, discountValue } = rewardDiscountMeta(reward.id);
      const code = normalizeDiscountCode(generateDiscountCode('CLUB'));
      const result = await this.prisma.$transaction(async (tx) => {
        const discount = await tx.discountCode.create({
          data: { code, title: reward.title, type: discountType as any, value: discountValue, active: true, once: true, used: false, source: 'loyalty', rewardId: reward.id },
        });
        const voucher = await tx.voucher.create({
          data: { memberId: member.id, code: discount.code, discountCodeId: discount.id, rewardId: reward.id, title: reward.title, points: reward.points, status: 'active', metadata: { reward } },
        });
        await tx.loyaltyHistory.create({
          data: { memberId: member.id, type: 'redeem', title: `دریافت جایزه: ${reward.title}`, points: -reward.points, note: `کد جایزه: ${voucher.code}` },
        });
        const updated = await tx.loyaltyMember.update({
          where: { id: member.id },
          data: { points: { decrement: reward.points } },
          include: { history: { orderBy: { createdAt: 'desc' } }, vouchers: { orderBy: { createdAt: 'desc' } } },
        });
        return { discount, voucher, member: updated };
      });
      const mapped = mapMember(result.member);
      return { success: true, data: { member: mapped, reward, voucher: result.voucher, tier: getTier(mapped.lifetimePoints), rewards: loyaltyRewards } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.memoryRedeem(body);
    }
  }

  async createRewardCode(body: any) {
    if (!this.prisma.isAvailable()) return this.memoryCreateRewardCode(body);
    try {
      const reward = loyaltyRewards.find((r) => r.id === body?.rewardId);
      if (!reward) return { success: false, message: 'Reward not found' };
      const member = await this.getOrCreateDbMember(body);
      const existingVoucher = (member.vouchers || []).find((v: any) => v.rewardId === reward.id && v.status === 'active');
      if (existingVoucher) {
        const discountCodes = await this.prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
        return { success: true, data: { member: mapMember(member), voucher: existingVoucher, discountCodes } };
      }
      if (member.points < reward.points) return { success: false, message: 'امتیاز کافی نیست', data: { member: mapMember(member), reward } };
      return this.redeem({ ...body, rewardId: reward.id });
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.memoryCreateRewardCode(body);
    }
  }

  async getOrCreateDbMember(identity?: any) {
    const normalized = normalizeCustomerIdentity(identity);
    let customer = null as any;

    if (normalized.customerId) {
      customer = await this.prisma.customer.findUnique({ where: { id: normalized.customerId } });
    }
    if (!customer && normalized.phone) {
      customer = await this.prisma.customer.findUnique({ where: { phone: normalized.phone } });
    }
    if (!customer) {
      customer = await this.prisma.customer.create({ data: { phone: normalized.phone || null, name: normalized.name } });
    } else if ((normalized.phone && customer.phone !== normalized.phone) || (normalized.name && customer.name !== normalized.name)) {
      customer = await this.prisma.customer.update({ where: { id: customer.id }, data: { phone: normalized.phone || customer.phone, name: normalized.name || customer.name } });
    }

    return this.prisma.loyaltyMember.upsert({
      where: { customerId: customer.id },
      update: { phone: customer.phone || '', name: customer.name || normalized.name },
      create: { customerId: customer.id, name: customer.name || normalized.name, phone: customer.phone || '', points: 0, lifetimePoints: 0, tier: 'راوی تازه‌وارد' },
      include: { history: { orderBy: { createdAt: 'desc' } }, vouchers: { orderBy: { createdAt: 'desc' } } },
    });
  }

  private getMemoryMember() {
    const member = store.loyalty.member;
    const tier = getTier(member.lifetimePoints);
    const nextReward = loyaltyRewards.find((r) => r.points > member.points) || null;
    return { success: true, data: { member, tier, rewards: loyaltyRewards, nextReward } };
  }

  private memoryRedeem(body: any) {
    const reward = loyaltyRewards.find((r) => r.id === body?.rewardId);
    if (!reward) return { success: false, message: 'Reward not found' };
    const member = store.loyalty.member;
    if (member.points < reward.points) return { success: false, message: 'امتیاز کافی نیست', data: { member, reward } };
    member.points -= reward.points;
    const { discountType, discountValue } = rewardDiscountMeta(reward.id);
    const discount = createDiscountCode({ title: reward.title, type: discountType, value: discountValue, once: true, active: true, rewardId: reward.id }, 'loyalty');
    const voucher = { id: `vc-${Date.now()}`, code: discount.code, discountCodeId: discount.id, rewardId: reward.id, title: reward.title, points: reward.points, status: 'active', createdAt: new Date().toISOString() };
    member.vouchers.unshift(voucher as any);
    member.history.unshift({ id: `lh-${Date.now()}`, type: 'redeem', title: `دریافت جایزه: ${reward.title}`, points: -reward.points, createdAt: new Date().toISOString(), note: `کد جایزه: ${voucher.code}` });
    return { success: true, data: { member, reward, voucher, tier: getTier(member.lifetimePoints), rewards: loyaltyRewards } };
  }

  private memoryCreateRewardCode(body: any) {
    const reward = loyaltyRewards.find((r) => r.id === body?.rewardId);
    if (!reward) return { success: false, message: 'Reward not found' };
    const member = store.loyalty.member;
    const existingVoucher = (member.vouchers || []).find((v: any) => v.rewardId === reward.id && v.status === 'active');
    if (existingVoucher) return { success: true, data: { member, voucher: existingVoucher, discountCodes: store.discountCodes } };
    if (member.points < reward.points) return { success: false, message: 'امتیاز کافی نیست', data: { member, reward } };
    return this.memoryRedeem({ rewardId: reward.id });
  }

  // ===== مدیریت ادمین =====

  async adminGetMembers(q?: string) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است؛ مدیریت اعضا فقط با دیتابیس فعال ممکن است.' };
    try {
      // فقط اعضایی که مشتری ثبت‌نام‌کرده (با تلفن) دارند — مهمان‌های بدون ثبت‌نام نمایش داده نمی‌شوند
      const where: any = {
        customer: { phone: { not: null } },
        ...(q ? { OR: [{ name: { contains: q } }, { phone: { contains: q } }] } : {}),
      };
      const members = await this.prisma.loyaltyMember.findMany({
        where,
        include: { customer: true, history: { orderBy: { createdAt: 'desc' }, take: 3 } },
        orderBy: { updatedAt: 'desc' },
        take: 300,
      });
      return { success: true, data: members.map((m: any) => ({ ...mapMember(m), recentHistory: (m.history || []).map((h: any) => ({ type: h.type, title: h.title, points: h.points, note: h.note || '', createdAt: h.createdAt })) })) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'دریافت اعضا ناموفق بود.' };
    }
  }

  async adminAdjustMember(id: string, body: any) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const delta = Number(body?.delta ?? 0);
      const tier = body?.tier ? String(body.tier) : undefined;
      const note = body?.note ? String(body.note) : undefined;
      if (!delta && !tier) return { success: false, message: 'بدون تغییر.' };
      const result = await this.prisma.$transaction(async (tx) => {
        const member = await tx.loyaltyMember.findUnique({ where: { id } });
        if (!member) return null;
        if (delta !== 0) {
          await tx.loyaltyHistory.create({
            data: {
              memberId: id,
              type: delta > 0 ? 'admin-credit' : 'admin-debit',
              title: delta > 0 ? 'اعتماد امتیاز توسط ادمین' : 'کسر امتیاز توسط ادمین',
              points: delta,
              note,
            },
          });
        }
        return tx.loyaltyMember.update({
          where: { id },
          data: {
            points: Math.max(0, member.points + delta),
            lifetimePoints: Math.max(0, member.lifetimePoints + Math.max(0, delta)),
            ...(tier ? { tier } : {}),
          },
          include: { history: { orderBy: { createdAt: 'desc' } }, vouchers: { orderBy: { createdAt: 'desc' } } },
        });
      });
      if (!result) return { success: false, message: 'عضو پیدا نشد.' };
      return { success: true, data: mapMember(result) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: error?.message || 'خطا در ویرایش عضو.' };
    }
  }

  async adminGetRewardCodes() {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const vouchers = await this.prisma.voucher.findMany({
        include: { member: true, discountCode: true },
        orderBy: { createdAt: 'desc' },
        take: 200,
      });
      return {
        success: true,
        data: vouchers.map((v: any) => ({
          id: v.id,
          code: v.code,
          title: v.title,
          points: v.points,
          status: v.status,
          memberName: v.member?.name || '',
          memberPhone: v.member?.phone || '',
          createdAt: v.createdAt,
        })),
      };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'دریافت کدها ناموفق بود.' };
    }
  }

  async adminDisableRewardCode(id: string) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const voucher = await this.prisma.voucher.findUnique({ where: { id } });
      if (!voucher) return { success: false, message: 'کد پیدا نشد.' };
      if (voucher.status === 'disabled') return { success: true };
      await this.prisma.$transaction([
        this.prisma.voucher.update({ where: { id }, data: { status: 'disabled' } }),
        ...(voucher.discountCodeId ? [this.prisma.discountCode.update({ where: { id: voucher.discountCodeId }, data: { active: false } })] : []),
      ]);
      return { success: true };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'غیرفعال‌سازی ناموفق بود.' };
    }
  }
}
