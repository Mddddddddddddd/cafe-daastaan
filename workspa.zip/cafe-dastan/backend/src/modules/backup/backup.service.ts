import { Injectable } from '@nestjs/common';
import { createWriteStream, existsSync, readdirSync, statSync, unlinkSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { unlink } from 'fs/promises';
import * as archiver from 'archiver';
import { PrismaService } from '../../prisma/prisma.service';

const UPLOADS_ROOT = join(process.cwd(), 'uploads');

function stamp() {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

@Injectable()
export class BackupService {
  constructor(private readonly prisma: PrismaService) {}

  private requireDb() {
    if (!this.prisma.isAvailable()) throw new Error('بکاپ فقط با دیتابیس فعال ممکن است.');
  }

  private mapProductForBackup(p: any) {
    return {
      id: p.id,
      name: p.name,
      desc: p.desc || '',
      price: Number(p.price || 0),
      oldPrice: p.oldPrice ?? null,
      image: p.image || '',
      active: !!p.active,
      outOfStock: !!p.outOfStock,
      featured: !!p.featured,
      discounted: !!p.discounted,
      station: p.station === 'kitchen' ? 'kitchen' : 'bar',
      customizations: Array.isArray(p.customizations) ? p.customizations : [],
      categories: (p.categories || []).map((c: any) => (c.category ? c.category.name : c.name)).filter(Boolean),
    };
  }

  // بازیابی محصولات از فایل products.json (آپ‌sert بر اساس id + همگام‌سازی دسته‌ها)
  async restoreProducts(body: any) {
    this.requireDb();
    const incoming = Array.isArray(body?.products) ? body.products : Array.isArray(body) ? body : null;
    if (!incoming) return { success: false, message: 'فرمت فایل بکاپ معتبر نیست (فایل products.json را انتخاب کن).' };
    let restored = 0;
    let skipped = 0;
    try {
      for (const p of incoming) {
        if (!p || !p.name) { skipped++; continue; }
        const cats: string[] = Array.isArray(p.categories)
          ? p.categories.map((c: any) => (typeof c === 'string' ? c : c?.name)).filter(Boolean)
          : [];
        const catIds: string[] = [];
        for (const name of cats) {
          const cat = await this.prisma.category.upsert({ where: { name }, update: {}, create: { name } });
          catIds.push(cat.id);
        }
        const id = p.id || `restore-${Date.now()}-${restored + skipped}`;
        const data: any = {
          name: p.name,
          desc: p.desc || null,
          price: Number(p.price || 0),
          oldPrice: p.oldPrice ? Number(p.oldPrice) : null,
          image: p.image || null,
          active: p.active !== false,
          outOfStock: !!p.outOfStock,
          featured: !!p.featured,
          discounted: !!p.discounted,
          station: p.station === 'kitchen' ? 'kitchen' : 'bar',
          customizations: Array.isArray(p.customizations) ? p.customizations : [],
          deletedAt: null,
        };
        await this.prisma.product.upsert({
          where: { id },
          update: { ...data, categories: { set: catIds.map((categoryId) => ({ categoryId })) } },
          create: { id, ...data, categories: { create: catIds.map((categoryId) => ({ categoryId })) } },
        });
        restored++;
      }
      return { success: true, message: `${restored.toLocaleString('fa-IR')} محصول بازیابی شد${skipped ? `، ${skipped.toLocaleString('fa-IR')} رد شد` : ''}.`, data: { restored, skipped } };
    } catch (error) {
      return { success: false, message: 'بازیابی محصولات ناموفق بود: ' + ((error as any)?.message || '') };
    }
  }

  // ساخت کامل ZIP روی دیسک (temp) — تا اگر خطایی رخ داد، قبل از ارسال هدرهای فایل جواب داده شود
  private async buildZipFile(prefix: string, fill: (archive: any) => Promise<void>): Promise<{ filePath: string; filename: string }> {
    this.requireDb();
    const filePath = join(tmpdir(), `${prefix}-${Date.now()}.zip`);
    try {
      await new Promise<void>((resolve, reject) => {
        const out = createWriteStream(filePath);
        const archive = archiver('zip', { zlib: { level: 6 } });
        archive.pipe(out);
        archive.on('error', (err: Error) => reject(err));
        out.on('error', (err: Error) => reject(err));
        out.on('close', () => resolve());
        (async () => {
          try {
            await fill(archive);
            await archive.finalize();
          } catch (err) {
            reject(err as Error);
          }
        })();
      });
      return { filePath, filename: `${prefix}-${stamp()}.zip` };
    } catch (error) {
      try { unlinkSync(filePath); } catch { /* ignore */ }
      throw error;
    }
  }

  // ZIP بکاپ محصولات: products.json + فایل عکس‌های محصولات
  async buildProductsZip(): Promise<{ filePath: string; filename: string }> {
    const { filePath, filename } = await this.buildZipFile('cafe-dastan-products', async (archive: any) => {
      const products = await this.prisma.product.findMany({
        where: { deletedAt: null },
        include: { categories: { include: { category: true } } },
        orderBy: { createdAt: 'asc' },
      });
      const payload = {
        app: 'cafe-dastan',
        type: 'products',
        exportedAt: new Date().toISOString(),
        count: products.length,
        products: products.map((p) => this.mapProductForBackup(p)),
      };
      archive.append(JSON.stringify(payload, null, 2), { name: 'products.json' });
      const added = new Set<string>();
      for (const p of products) {
        const url = p.image || '';
        if (url.startsWith('/uploads/')) {
          const abs = join(process.cwd(), url);
          if (existsSync(abs) && !added.has(abs)) {
            added.add(abs);
            archive.file(abs, { name: url.replace(/^\//, '') });
          }
        }
      }
    });
    return { filePath, filename };
  }

  // ZIP بکاپ کامل: db.json (همه‌ی جدول‌ها) + پوشه‌ی uploads
  async buildFullZip(): Promise<{ filePath: string; filename: string }> {
    const { filePath, filename } = await this.buildZipFile('cafe-dastan-full', async (archive: any) => {
      const tables: Record<string, unknown> = {};
      const [
        customer, staffUser, cafeTable, category, product, productCategory,
        order, orderItem, orderStatusLog, discountCode, loyaltyMember, loyaltyHistory,
        voucher, notification, homeSettings, story, storyComment, feedback,
      ] = await Promise.all([
        this.prisma.customer.findMany(),
        this.prisma.staffUser.findMany(),
        this.prisma.cafeTable.findMany(),
        this.prisma.category.findMany(),
        this.prisma.product.findMany(),
        this.prisma.productCategory.findMany(),
        this.prisma.order.findMany(),
        this.prisma.orderItem.findMany(),
        this.prisma.orderStatusLog.findMany(),
        this.prisma.discountCode.findMany(),
        this.prisma.loyaltyMember.findMany(),
        this.prisma.loyaltyHistory.findMany(),
        this.prisma.voucher.findMany(),
        this.prisma.notification.findMany(),
        this.prisma.homeSettings.findMany(),
        this.prisma.story.findMany(),
        this.prisma.storyComment.findMany(),
        this.prisma.feedback.findMany(),
      ]);
      tables.customer = customer;
      tables.staffUser = staffUser;
      tables.cafeTable = cafeTable;
      tables.category = category;
      tables.product = product;
      tables.productCategory = productCategory;
      tables.order = order;
      tables.orderItem = orderItem;
      tables.orderStatusLog = orderStatusLog;
      tables.discountCode = discountCode;
      tables.loyaltyMember = loyaltyMember;
      tables.loyaltyHistory = loyaltyHistory;
      tables.voucher = voucher;
      tables.notification = notification;
      tables.homeSettings = homeSettings;
      tables.story = story;
      tables.storyComment = storyComment;
      tables.feedback = feedback;
      const payload = { app: 'cafe-dastan', type: 'full', exportedAt: new Date().toISOString(), tables };
      archive.append(JSON.stringify(payload), { name: 'db.json' });
      if (existsSync(UPLOADS_ROOT)) {
        this.addDirToArchive(archive, UPLOADS_ROOT, 'uploads');
      }
    });
    return { filePath, filename };
  }

  private addDirToArchive(archive: any, dirPath: string, zipPrefix: string) {
    let entries: string[] = [];
    try { entries = readdirSync(dirPath); } catch { return; }
    for (const entry of entries) {
      const abs = join(dirPath, entry);
      const rel = `${zipPrefix}/${entry}`;
      try {
        const st = statSync(abs);
        if (st.isDirectory()) this.addDirToArchive(archive, abs, rel);
        else archive.file(abs, { name: rel });
      } catch { /* فایل ناپایدار */ }
    }
  }

  async cleanup(filePath: string) {
    await unlink(filePath).catch(() => {});
  }
}
