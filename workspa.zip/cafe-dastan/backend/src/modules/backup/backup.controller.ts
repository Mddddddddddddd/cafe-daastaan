import { Body, Controller, Get, Post, Res, UseGuards } from '@nestjs/common';
import { statSync } from 'fs';
import type { Response } from 'express';
import { BackupService } from './backup.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

@UseGuards(AuthGuardMock, RolesGuardMock)
@RequireRoles(Roles.ADMIN)
@Controller('admin/backup')
export class BackupController {
  constructor(private readonly backupService: BackupService) {}

  private sendZip(res: Response, filePath: string, filename: string) {
    let size = 0;
    try { size = statSync(filePath).size; } catch { /* ignore */ }
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    if (size > 0) res.setHeader('Content-Length', String(size));
    res.sendFile(filePath, (err) => {
      void this.backupService.cleanup(filePath);
      if (err && !res.headersSent) {
        res.status(500).json({ success: false, message: 'ارسال فایل بکاپ ناموفق بود.' });
      }
    });
  }

  // ZIP بکاپ محصولات (products.json + عکس‌ها) — کامل ساخته می‌شود و بعد ارسال می‌گردد
  @Get('products')
  async exportProducts(@Res() res: Response) {
    try {
      const { filePath, filename } = await this.backupService.buildProductsZip();
      this.sendZip(res, filePath, filename);
    } catch (error) {
      if (!res.headersSent) {
        res.status(400).json({ success: false, message: (error as Error).message });
      }
    }
  }

  // بازیابی محصولات از products.json
  @Post('restore-products')
  restoreProducts(@Body() body: any) {
    return this.backupService.restoreProducts(body);
  }

  // ZIP بکاپ کامل (db.json + uploads)
  @Get('full')
  async exportFull(@Res() res: Response) {
    try {
      const { filePath, filename } = await this.backupService.buildFullZip();
      this.sendZip(res, filePath, filename);
    } catch (error) {
      if (!res.headersSent) {
        res.status(400).json({ success: false, message: (error as Error).message });
      }
    }
  }
}
