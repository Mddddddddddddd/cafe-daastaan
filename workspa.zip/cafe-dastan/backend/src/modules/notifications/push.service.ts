import { Injectable, Logger } from '@nestjs/common';
import * as webpush from 'web-push';
import { PrismaService } from '../../prisma/prisma.service';

// سرویس نوتیفیکیشن Push (Web Push) برای پنل‌های پرسنلی
@Injectable()
export class PushService {
  private readonly logger = new Logger(PushService.name);
  private configured = false;

  constructor(private readonly prisma: PrismaService) {
    const publicKey = String(process.env.VAPID_PUBLIC_KEY || '').trim();
    const privateKey = String(process.env.VAPID_PRIVATE_KEY || '').trim();
    const contact = String(process.env.VAPID_CONTACT || 'mailto:admin@cafedaastaan.ir').trim();
    if (publicKey && privateKey) {
      webpush.setVapidDetails(contact, publicKey, privateKey);
      this.configured = true;
    } else {
      this.logger.warn('VAPID keys are not configured; web push is disabled.');
    }
  }

  getPublicKey() {
    return this.configured ? String(process.env.VAPID_PUBLIC_KEY) : '';
  }

  isConfigured() {
    return this.configured;
  }

  async subscribe(subscription: any, staffRole?: string) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const p256dh = String(subscription.keys?.p256dh || '').trim();
      const auth = String(subscription.keys?.auth || '').trim();
      if (!p256dh || !auth) return { success: false, message: 'اطلاعات اشتراک ناقص است (p256dh/auth).' };
      await this.prisma.pushSubscription.upsert({
        where: { endpoint: subscription.endpoint },
        update: { p256dh, auth, staffRole: staffRole || subscription.staffRole || null },
        create: {
          endpoint: subscription.endpoint,
          p256dh,
          auth,
          staffRole: staffRole || subscription.staffRole || null,
          userAgent: String(subscription.userAgent || '').slice(0, 300) || null,
        },
      });
      return { success: true };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'ثبت اشتراک نوتیفیکیشن ناموفق بود.' };
    }
  }

  async unsubscribe(endpoint?: string, staffRole?: string) {
    if (!this.prisma.isAvailable()) return { success: false, message: 'بک‌اند در حالت حافظه است.' };
    try {
      const where: any = {};
      if (endpoint) where.endpoint = endpoint;
      if (staffRole) where.staffRole = staffRole;
      await this.prisma.pushSubscription.deleteMany({ where });
      return { success: true };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: false, message: 'حذف اشتراک ناموفق بود.' };
    }
  }

  // ارسال نوتیفیکیشن به همه‌ی اشتراکات یک نقش (bar/kitchen/waiter)
  async pushToRole(staffRole: string, title: string, body: string, url = '/') {
    if (!this.configured || !this.prisma.isAvailable()) return { sent: 0 };
    let sent = 0;
    try {
      const subs = await this.prisma.pushSubscription.findMany({ where: { staffRole } });
      const icon = `/images/icon-${staffRole}-v2-192.png`;
      const payload = JSON.stringify({ title, body, url, icon });
      await Promise.all(
        subs.map(async (sub) => {
          try {
            await webpush.sendNotification(
              { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
              payload,
              { TTL: 60 },
            );
            sent++;
          } catch (err: any) {
            const status = Number(err?.statusCode || err?.status || 0);
            if ([404, 410].includes(status)) {
              await this.prisma.pushSubscription.delete({ where: { id: sub.id } }).catch(() => {});
            }
          }
        }),
      );
      return { sent };
    } catch (error) {
      this.logger.warn(`pushToRole(${staffRole}) failed: ${(error as Error).message}`);
      return { sent: 0 };
    }
  }
}
