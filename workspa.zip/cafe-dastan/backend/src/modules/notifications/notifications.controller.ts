import { Controller, Get, Post, Body, Delete, Param, Query, Req, UseGuards } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { PushService } from './push.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RequireRoles, Roles } from '../auth/roles';
import { RolesGuardMock } from '../auth/roles.guard';

@Controller('notifications')
@UseGuards(AuthGuardMock)
export class NotificationsController {
  constructor(
    private readonly notificationsService: NotificationsService,
    private readonly pushService: PushService,
  ) {}

  // ===== Web Push (نوتیفیکیشن گوشی پرسنل) =====

  @Get('push/vapid-public-key')
  getVapidPublicKey() {
    return { success: true, data: { publicKey: this.pushService.getPublicKey(), configured: this.pushService.isConfigured() } };
  }

  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN, Roles.BAR, Roles.KITCHEN, Roles.WAITER)
  @Post('push/subscribe')
  subscribe(@Body() body: any, @Req() req: any) {
    return this.pushService.subscribe(body?.subscription || body, String(req.user?.role || '').toLowerCase() || undefined);
  }

  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN, Roles.BAR, Roles.KITCHEN, Roles.WAITER)
  @Delete('push/subscribe')
  unsubscribe(@Query('endpoint') endpoint?: string, @Req() req?: any) {
    return this.pushService.unsubscribe(endpoint, String(req?.user?.role || '').toLowerCase() || undefined);
  }

  @Get()
  getMine(@Req() req: any) {
    return this.notificationsService.getMine(req.user?.id || '');
  }

  @Post('broadcast')
  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  broadcast(@Body() body: { title: string; body: string }) {
    return this.notificationsService.broadcast(body);
  }

  @Post('special')
  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  createSpecial(@Body() body: { title: string; body: string; question?: string; yesLabel?: string; noLabel?: string; durationHours?: number }) {
    return this.notificationsService.createSpecialAction(body);
  }

  @Get('special/report')
  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  getSpecialReport() {
    return this.notificationsService.getSpecialActionReport();
  }

  @Delete('special/:id')
  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  removeSpecial(@Param('id') id: string) {
    return this.notificationsService.removeSpecialAction(id);
  }

  @Post('special/:id/answer')
  answerSpecial(@Param('id') id: string, @Body() body: { answer: 'yes' | 'no' }, @Req() req: any) {
    return this.notificationsService.answerSpecialAction(id, body?.answer === 'yes' ? 'yes' : 'no', req.user);
  }

  @Delete()
  clearAll(@Req() req: any) { return this.notificationsService.clearAll(req.user?.id || ''); }

  @Delete(':id')
  remove(@Param('id') id: string, @Req() req: any) { return this.notificationsService.remove(id, req.user?.id || ''); }
}
