import { Injectable } from '@nestjs/common';
import { store } from '../../store/data.store';
import { PrismaService } from '../../prisma/prisma.service';
import { mapNotification } from '../../prisma/db-mapper';

function isActiveTimedNotification(item: any) {
  if (!item) return false;
  if (item.deletedAt) return false;
  if (!item.expiresAt) return true;
  return new Date(item.expiresAt).getTime() > Date.now();
}

function parseResponsesJson(value: any) {
  if (!value) return {};
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return {}; }
  }
  return value;
}

export function createOrderStatusNotification(orderId: string, status: string, title?: string, body?: string) {
  const exists = store.notifications.some((n: any) => n.orderId === orderId && n.status === status && isActiveTimedNotification(n));
  if (exists) return null;
  const notification = {
    id: `n-order-${orderId}-${status}-${Date.now()}`,
    title: title || 'وضعیت سفارش تغییر کرد',
    body: body || `وضعیت سفارش #${orderId} به‌روزرسانی شد.`,
    createdAt: new Date().toISOString(),
    type: 'order-status',
    orderId,
    status,
  };
  store.notifications.unshift(notification as any);
  return notification;
}

@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  async getMine(customerId?: string) {
    if (!this.prisma.isAvailable()) {
      const data = (store.notifications || []).filter((item: any) => {
        if (!isActiveTimedNotification(item)) return false;
        if (!customerId) return item.type === 'broadcast' || item.type === 'special-action';
        return item.customerId === customerId || item.type === 'broadcast' || item.type === 'special-action';
      });
      return { success: true, data };
    }
    try {
      const notifications = await this.prisma.notification.findMany({
        where: {
          deletedAt: null,
          AND: [
            {
              OR: [
                { expiresAt: null },
                { expiresAt: { gt: new Date() } },
              ],
            },
            customerId
              ? { OR: [{ customerId }, { type: 'broadcast' }, { type: 'special-action' }, { requiresAction: true }] }
              : { OR: [{ type: 'broadcast' }, { type: 'special-action' }, { requiresAction: true }] },
          ],
        },
        orderBy: { createdAt: 'desc' },
      });
      return { success: true, data: notifications.map(mapNotification) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      const data = (store.notifications || []).filter((item: any) => isActiveTimedNotification(item));
      return { success: true, data };
    }
  }

  async remove(id: string, customerId?: string) {
    if (!this.prisma.isAvailable()) {
      const index = store.notifications.findIndex((n: any) => n.id === id);
      if (index === -1) return { success: false, message: 'Notification not found' };
      const removed = store.notifications.splice(index, 1)[0];
      return { success: true, data: removed };
    }
    try {
      const target = await this.prisma.notification.findUnique({ where: { id } });
      if (!target) return { success: false, message: 'Notification not found' };
      if (customerId && target.customerId && target.customerId !== customerId) return { success: false, message: 'اجازه حذف این اعلان را نداری.' };
      const removed = await this.prisma.notification.update({ where: { id }, data: { deletedAt: new Date() } });
      return { success: true, data: mapNotification(removed) };
    } catch {
      return { success: false, message: 'Notification not found' };
    }
  }

  async removeSpecialAction(id: string) {
    if (!this.prisma.isAvailable()) {
      const index = store.notifications.findIndex((n: any) => n.id === id);
      if (index === -1) return { success: false, message: 'اعلان ویژه پیدا نشد.' };
      const target = store.notifications[index] as any;
      if (!target || !(target.type === 'special-action' || target.requiresAction === true)) {
        return { success: false, message: 'اعلان ویژه پیدا نشد.' };
      }
      target.deletedAt = new Date().toISOString();
      return { success: true, data: target };
    }
    try {
      const target = await this.prisma.notification.findUnique({ where: { id } });
      if (!target || !(target.type === 'special-action' || target.requiresAction === true)) return { success: false, message: 'اعلان ویژه پیدا نشد.' };
      const removed = await this.prisma.notification.update({ where: { id }, data: { deletedAt: new Date(), type: 'special-action', requiresAction: true } });
      return { success: true, data: mapNotification(removed) };
    } catch {
      return { success: false, message: 'اعلان ویژه پیدا نشد.' };
    }
  }

  async clearAll(customerId?: string) {
    if (!this.prisma.isAvailable()) {
      if (!customerId) {
        store.notifications.splice(0, store.notifications.length);
      } else {
        const keep = (store.notifications || []).filter((item: any) => item.customerId && item.customerId !== customerId);
        store.notifications.splice(0, store.notifications.length, ...keep);
      }
      return { success: true, data: [] };
    }
    try {
      await this.prisma.notification.updateMany({ where: { deletedAt: null, ...(customerId ? { OR: [{ customerId }, { type: 'broadcast' }, { type: 'special-action' }] } : {}) }, data: { deletedAt: new Date() } });
      return { success: true, data: [] };
    } catch (error) {
      this.prisma.markUnavailable(error);
      store.notifications.splice(0, store.notifications.length);
      return { success: true, data: [] };
    }
  }

  async broadcast(payload: { title: string; body: string }) {
    if (!this.prisma.isAvailable()) {
      const notification = { id: `n-${Date.now()}`, title: payload.title || 'پیام کافه داستان', body: payload.body || '', createdAt: new Date().toISOString(), type: 'broadcast' };
      store.notifications.unshift(notification);
      return { success: true, message: 'Notification broadcast queued', data: notification };
    }
    try {
      const notification = await this.prisma.notification.create({ data: { title: payload.title || 'پیام کافه داستان', body: payload.body || '', type: 'broadcast' } });
      return { success: true, message: 'Notification broadcast queued', data: mapNotification(notification) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.broadcast(payload);
    }
  }

  async createSpecialAction(payload: { title: string; body: string; question?: string; yesLabel?: string; noLabel?: string; durationHours?: number }) {
    const durationHours = Math.max(1, Number(payload.durationHours || 10));
    const expiresAt = new Date(Date.now() + durationHours * 60 * 60 * 1000);

    if (!this.prisma.isAvailable()) {
      const notification = {
        id: `special-${Date.now()}`,
        title: payload.title || 'دعوت ویژه کافه داستان',
        body: payload.body || '',
        createdAt: new Date().toISOString(),
        expiresAt: expiresAt.toISOString(),
        type: 'special-action',
        requiresAction: true,
        actionQuestion: payload.question || payload.title || 'تشریف میارید؟',
        actionYesLabel: payload.yesLabel || 'بله، هستم',
        actionNoLabel: payload.noLabel || 'خیر، نیستم',
        responseYes: 0,
        responseNo: 0,
        responsesJson: {},
      };
      store.notifications.unshift(notification as any);
      return { success: true, data: notification };
    }

    try {
      const notification = await this.prisma.notification.create({
        data: {
          title: payload.title || 'دعوت ویژه کافه داستان',
          body: payload.body || '',
          type: 'special-action',
          expiresAt,
          requiresAction: true,
          actionQuestion: payload.question || payload.title || 'تشریف میارید؟',
          actionYesLabel: payload.yesLabel || 'بله، هستم',
          actionNoLabel: payload.noLabel || 'خیر، نیستم',
          responsesJson: {},
        },
      });
      return { success: true, data: mapNotification(notification) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.createSpecialAction(payload);
    }
  }

  async answerSpecialAction(id: string, answer: 'yes' | 'no', user?: any) {
    const customerId = String(user?.id || '').trim();
    const responseKey = customerId ? `special_action_answer_${id}_${customerId}` : `special_action_answer_${id}_guest`;
    const responder = {
      customerId,
      name: String(user?.username || user?.name || 'مهمان کافه داستان'),
      phone: String(user?.phone || ''),
      answer,
      answeredAt: new Date().toISOString(),
    };

    if (!this.prisma.isAvailable()) {
      const item = (store.notifications || []).find((n: any) => n.id === id && n.type === 'special-action' && isActiveTimedNotification(n));
      if (!item) return { success: false, message: 'اعلان ویژه پیدا نشد یا زمانش تمام شده است.' };
      const responses = parseResponsesJson(item.responsesJson);
      if (responses[responseKey]) return { success: true, data: item, message: 'پاسخ شما قبلاً ثبت شده است.' };
      responses[responseKey] = responder;
      item.responsesJson = responses;
      if (answer === 'yes') item.responseYes = Number(item.responseYes || 0) + 1;
      else item.responseNo = Number(item.responseNo || 0) + 1;
      return { success: true, data: item, message: 'پاسخ شما ثبت شد.' };
    }

    try {
      const notification = await this.prisma.notification.findUnique({ where: { id } });
      if (!notification || notification.type !== 'special-action') return { success: false, message: 'اعلان ویژه پیدا نشد.' };
      if (notification.expiresAt && notification.expiresAt.getTime() <= Date.now()) return { success: false, message: 'زمان پاسخ‌دادن به این اعلان تمام شده است.' };
      const responses = parseResponsesJson((notification as any).responsesJson);
      if (responses[responseKey]) return { success: true, data: mapNotification(notification), message: 'پاسخ شما قبلاً ثبت شده است.' };
      responses[responseKey] = responder;
      const updated = await this.prisma.notification.update({
        where: { id },
        data: {
          responseYes: answer === 'yes' ? { increment: 1 } : undefined,
          responseNo: answer === 'no' ? { increment: 1 } : undefined,
          responsesJson: responses,
        } as any,
      });
      return { success: true, data: mapNotification(updated), message: 'پاسخ شما ثبت شد.' };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return this.answerSpecialAction(id, answer, user);
      return { success: false, message: error?.message || 'خطا در ثبت پاسخ.' };
    }
  }

  async getSpecialActionReport() {
    if (!this.prisma.isAvailable()) {
      const items = (store.notifications || [])
        .filter((n: any) => !n?.deletedAt && (n.type === 'special-action' || n.requiresAction === true))
        .map((n: any) => {
          const responses = Object.values(parseResponsesJson(n.responsesJson || {})) as any[];
          return {
            id: n.id,
            title: n.title,
            body: n.body,
            createdAt: n.createdAt,
            expiresAt: n.expiresAt,
            responseYes: Number(n.responseYes || 0),
            responseNo: Number(n.responseNo || 0),
            yesUsers: responses.filter((r: any) => r.answer === 'yes'),
            noUsers: responses.filter((r: any) => r.answer === 'no'),
          };
        });
      return { success: true, data: items };
    }
    try {
      const items = await this.prisma.notification.findMany({
        where: {
          deletedAt: null,
          OR: [
            { type: 'special-action' },
            { requiresAction: true },
          ],
        },
        orderBy: { createdAt: 'desc' },
      });
      return {
        success: true,
        data: items.map((item: any) => {
          const responses = Object.values(parseResponsesJson(item.responsesJson || {})) as any[];
          return {
            id: item.id,
            title: item.title,
            body: item.body,
            createdAt: item.createdAt.toISOString(),
            expiresAt: item.expiresAt?.toISOString(),
            responseYes: Number(item.responseYes || 0),
            responseNo: Number(item.responseNo || 0),
            yesUsers: responses.filter((r: any) => r.answer === 'yes'),
            noUsers: responses.filter((r: any) => r.answer === 'no'),
          };
        }),
      };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: [] };
    }
  }
}
