import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { store } from '../../store/data.store';
import { awardLoyaltyForFeedback, getTier } from '../loyalty/loyalty.service';
import { PrismaService } from '../../prisma/prisma.service';
import { ensureCustomerOwnsResource } from '../auth/customer-auth';

function mapFeedback(feedback: any) {
  return {
    id: feedback.id,
    orderId: feedback.orderId,
    createdAt: feedback.createdAt instanceof Date ? feedback.createdAt.toISOString() : feedback.createdAt,
    customerName: feedback.customerName,
    staffRating: feedback.staffRating,
    staffComment: feedback.staffComment || '',
    orderRating: feedback.orderRating,
    orderComment: feedback.orderComment || '',
    itemRatings: Array.isArray(feedback.itemRatings) ? feedback.itemRatings : [],
  };
}

@Injectable()
export class FeedbackService {
  constructor(private readonly prisma: PrismaService) {}

  async getAll() {
    if (!this.prisma.isAvailable()) return { success: true, data: store.feedbacks || [] };
    try {
      const feedbacks = await this.prisma.feedback.findMany({ orderBy: { createdAt: 'desc' } });
      return { success: true, data: feedbacks.map(mapFeedback) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.feedbacks || [] };
    }
  }

  async remove(id: string) {
    if (!this.prisma.isAvailable()) {
      const before = (store.feedbacks || []).length;
      store.feedbacks = (store.feedbacks || []).filter((f: any) => f.id !== id);
      return store.feedbacks.length < before ? { success: true } : { success: false, message: 'نظرسنجی پیدا نشد.' };
    }
    try {
      await this.prisma.feedback.delete({ where: { id } });
      return { success: true };
    } catch (error) {
      if ((error as any)?.code === 'P2025') return { success: false, message: 'نظرسنجی پیدا نشد.' };
      this.prisma.markUnavailable(error);
      return { success: false, message: 'حذف ناموفق بود.' };
    }
  }

  async getOrderSurvey(orderId: string, user?: any) {
    if (!this.prisma.isAvailable()) return this.getMemoryOrderSurvey(orderId, user);
    try {
      const order = await this.prisma.order.findUnique({ where: { id: orderId }, include: { items: true, table: true, customer: true } });
      if (!order) throw new NotFoundException('سفارش پیدا نشد.');
      ensureCustomerOwnsResource(user, order.customerId || '');
      const items = (order.items || []).map((item: any) => ({
        productId: item.productId,
        name: item.productNameSnapshot,
        qty: Number(item.qty || 1),
        option: Array.isArray(item.selectedOptions) ? item.selectedOptions.map((o: any) => o?.name || o).filter(Boolean).join('، ') : '',
      }));
      const alreadySubmitted = !!(await this.prisma.feedback.findFirst({ where: { orderId } }));
      return {
        success: true,
        data: {
          orderId,
          table: order.tableName || order.table?.name || 'میز فروغ',
          createdAt: order.createdAt?.toISOString() || new Date().toISOString(),
          items,
          alreadySubmitted,
        },
      };
    } catch (error) {
      if (error instanceof ForbiddenException || error instanceof NotFoundException) throw error;
      this.prisma.markUnavailable(error);
      return this.getMemoryOrderSurvey(orderId, user);
    }
  }

  async create(body: any, user?: any) {
    if (!this.prisma.isAvailable()) return this.createMemoryFeedback(body, user);
    try {
      const orderId = String(body?.orderId || '').trim() || 'بدون سفارش';
      const itemRatings = Array.isArray(body?.itemRatings) ? body.itemRatings.map((item: any) => ({ productId: item.productId, name: item.name, rating: Number(item.rating || 0), comment: item.comment || '' })) : [];
      const order = await this.prisma.order.findUnique({ where: { id: orderId }, include: { customer: true } }).catch(() => null);
      if (!order) throw new NotFoundException('سفارش پیدا نشد.');
      const customer = ensureCustomerOwnsResource(user, order.customerId || '');
      const feedback = await this.prisma.feedback.create({
        data: {
          orderId,
          customerId: customer.id,
          customerName: body?.customerName || customer.name || order.customer?.name || 'مهمان کافه',
          staffRating: Number(body?.staffRating || 0),
          staffComment: body?.staffComment || '',
          orderRating: Number(body?.orderRating || 0),
          orderComment: body?.orderComment || '',
          itemRatings,
        },
      });
      const loyalty = await this.awardFeedbackPointsDb(orderId, customer.id);
      return { success: true, data: { ...mapFeedback(feedback), loyalty } };
    } catch (error) {
      if (error instanceof ForbiddenException || error instanceof NotFoundException) throw error;
      this.prisma.markUnavailable(error);
      return this.createMemoryFeedback(body, user);
    }
  }

  private async awardFeedbackPointsDb(orderId: string, customerId: string) {
    const customer = await this.prisma.customer.findUnique({ where: { id: customerId } });
    if (!customer) throw new NotFoundException('مشتری سفارش پیدا نشد.');
    const member = await this.prisma.loyaltyMember.upsert({
      where: { customerId: customer.id },
      update: { phone: customer.phone || '', name: customer.name || 'مهمان کافه داستان' },
      create: { customerId: customer.id, name: customer.name || 'مهمان کافه داستان', phone: customer.phone || '', points: 0, lifetimePoints: 0, tier: 'راوی تازه‌وارد' },
      include: { history: true, vouchers: true },
    });
    const existing = await this.prisma.loyaltyHistory.findFirst({ where: { memberId: member.id, type: 'feedback', orderId } });
    if (existing) return { awarded: false, points: 0, member: { ...member, tier: getTier(member.lifetimePoints).title } };
    const points = 35;
    const nextLifetime = member.lifetimePoints + points;
    const tier = getTier(nextLifetime).title;
    const updated = await this.prisma.loyaltyMember.update({
      where: { id: member.id },
      data: {
        points: { increment: points },
        lifetimePoints: { increment: points },
        tier,
        history: { create: { type: 'feedback', title: `امتیاز نظرسنجی سفارش #${orderId}`, points, orderId, note: 'امتیاز تشکر بابت ثبت نظر و کمک به بهتر شدن تجربه کافه داستان' } },
      },
      include: { history: { orderBy: { createdAt: 'desc' } }, vouchers: { orderBy: { createdAt: 'desc' } } },
    });
    return { awarded: true, points, member: updated };
  }

  private getMemoryOrderSurvey(orderId: string, user?: any) {
    const order = store.orders.find((o: any) => o.id === orderId);
    if (!order) throw new NotFoundException('سفارش پیدا نشد.');
    const userId = String(user?.id || '');
    const orderCustomerId = String(order.customerId || '');
    if (orderCustomerId && userId && orderCustomerId !== userId) throw new ForbiddenException('شما به این سفارش دسترسی ندارید.');
    const rawItems = order.items || [];
    const items = rawItems.map((item: any) => {
      const product = store.products.find((p) => p.id === item.productId);
      return { productId: item.productId, name: product?.name || item.name || item.productId, qty: Number(item.qty || 1), option: item.customizations?.option || item.option || '' };
    });
    return { success: true, data: { orderId, table: order.table || 'میز فروغ', createdAt: order.createdAt || new Date().toISOString(), items, alreadySubmitted: (store.feedbacks || []).some((f: any) => f.orderId === orderId) } };
  }

  private createMemoryFeedback(body: any, user?: any) {
    const orderId = String(body?.orderId || '').trim();
    const order = store.orders.find((o: any) => o.id === orderId);
    if (order?.customerId && String(order.customerId) !== String(user?.id || '')) throw new ForbiddenException('شما اجازه ثبت نظر برای سفارش شخص دیگر را ندارید.');
    const feedback = { id: `fb-${Date.now()}`, orderId: orderId || 'بدون سفارش', customerId: user?.id || '', createdAt: new Date().toISOString(), customerName: body?.customerName || user?.name || 'مهمان کافه', staffRating: Number(body?.staffRating || 0), staffComment: body?.staffComment || '', orderRating: Number(body?.orderRating || 0), orderComment: body?.orderComment || '', itemRatings: Array.isArray(body?.itemRatings) ? body.itemRatings.map((item: any) => ({ productId: item.productId, name: item.name, rating: Number(item.rating || 0), comment: item.comment || '' })) : [] };
    store.feedbacks.unshift(feedback as any);
    const loyalty = awardLoyaltyForFeedback(orderId || 'بدون سفارش');
    return { success: true, data: { ...feedback, loyalty } };
  }
}
