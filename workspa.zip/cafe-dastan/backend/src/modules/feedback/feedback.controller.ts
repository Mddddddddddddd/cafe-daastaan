import { Body, Controller, Delete, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { FeedbackService } from './feedback.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

@Controller('feedback')
@UseGuards(AuthGuardMock)
export class FeedbackController {
  constructor(private readonly feedbackService: FeedbackService) {}

  @Get()
  getAll() { return this.feedbackService.getAll(); }

  @Get('order/:id')
  getOrderSurvey(@Param('id') id: string, @Req() req: any) { return this.feedbackService.getOrderSurvey(id, req.user); }

  @Post()
  create(@Body() body: any, @Req() req: any) { return this.feedbackService.create(body, req.user); }

  // مدیریت: فقط ادمین می‌تواند نظرسنجی را حذف کند
  @UseGuards(RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  @Delete(':id')
  remove(@Param('id') id: string) { return this.feedbackService.remove(id); }
}
