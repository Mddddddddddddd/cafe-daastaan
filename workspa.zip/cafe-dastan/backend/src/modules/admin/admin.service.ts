import { Injectable } from '@nestjs/common';
import { categories, store } from '../../store/data.store';
import { createDiscountCode } from '../discounts/discounts.service';
import { PrismaService } from '../../prisma/prisma.service';
import { DEFAULT_HOME_SETTINGS, mapDiscount, mapProduct } from '../../prisma/db-mapper';
import { saveBase64Image } from '../../common/file-storage';
import { hashPassword } from '../auth/password.service';

function orderCreatedAt(order: any) {
  const raw = order?.createdAt || order?.date || (String(order?.id || '').match(/^\d{10,}$/) ? Number(order.id) : Date.now());
  const date = new Date(raw);
  return Number.isFinite(date.getTime()) ? date.toISOString() : new Date().toISOString();
}

function getOrderItems(order: any) {
  return (order.items || []).map((item: any) => {
    const product = store.products.find((p) => p.id === item.productId);
    const qty = Number(item.qty || 1);
    const price = Number(item.price ?? product?.price ?? 0);
    return { productId: item.productId, name: item.name || product?.name || item.productId, qty, price, total: qty * price };
  });
}

function getSyntheticOrdersFromQueues() {
  const known = new Set(store.orders.map((o: any) => String(o.id)));
  const ids = new Set<string>();
  [...store.barOrders, ...store.kitchenOrders].forEach((q: any) => q?.orderId ? ids.add(String(q.orderId)) : null);
  store.waiterTables.forEach((t: any) => t?.orderId ? ids.add(String(t.orderId)) : null);

  return [...ids]
    .filter((id) => !known.has(id))
    .filter((id) => id !== '1042')
    .map((id) => {
      const queueItems = [...store.barOrders, ...store.kitchenOrders].filter((q: any) => String(q.orderId) === id);
      const table = store.waiterTables.find((t: any) => String(t.orderId) === id);
      const items = queueItems.flatMap((q: any) => {
        if (Array.isArray(q.items) && q.items.length) return q.items;
        return [{ productId: q.productId, name: q.name, qty: q.qty || 1 }];
      });
      return {
        id,
        createdAt: new Date().toISOString(),
        table: table?.name || queueItems[0]?.tableName || 'میز',
        status: table?.status || queueItems[0]?.status || 'فعال',
        items,
      };
    });
}

export function buildAccountingReport(from?: string, to?: string) {
  const fromTime = from ? new Date(`${from}T00:00:00`).getTime() : 0;
  const toTime = to ? new Date(`${to}T23:59:59`).getTime() : Number.MAX_SAFE_INTEGER;
  const sourceOrders = [...store.orders, ...getSyntheticOrdersFromQueues()];
  const orders = sourceOrders.filter((order: any) => {
    const orderTime = new Date(orderCreatedAt(order)).getTime();
    return orderTime >= fromTime && orderTime <= toTime;
  }).map((order: any) => {
    const items = getOrderItems(order);
    const grossTotal = Number(order.total ?? items.reduce((sum: number, item: any) => sum + item.total, 0));
    const discountAmount = Number(order.discountAmount || 0);
    const total = Number(order.finalTotal ?? Math.max(0, grossTotal - discountAmount));
    const estimatedCost = Math.round(grossTotal * 0.55);
    const profit = total - estimatedCost;
    return {
      id: order.id,
      date: orderCreatedAt(order),
      table: order.table || order.tableName || 'میز',
      status: order.status,
      items,
      grossTotal,
      discountAmount,
      total,
      estimatedCost,
      profit,
    };
  }).sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const totalSales = orders.reduce((sum: number, order: any) => sum + order.total, 0);
  const totalCost = orders.reduce((sum: number, order: any) => sum + order.estimatedCost, 0);
  const totalDiscount = orders.reduce((sum: number, order: any) => sum + order.discountAmount, 0);
  return { success: true, data: { orders, totalSales, totalCost, totalProfit: totalSales - totalCost, totalDiscount, orderCount: orders.length } };
}

function parseResturanYarMenu(content: string) {
  const items: { name: string; price: number; desc?: string; category?: string; image?: string }[] = [];
  const seenNames = new Set<string>();

  try {
    const nextDataMatch = content.match(/<script id="__NEXT_DATA__" [^>]*>([\s\S]*?)<\/script>/i) || content.match(/window\.__INITIAL_STATE__\s*=\s*({[\s\S]*?});/i);
    if (nextDataMatch && nextDataMatch[1]) {
      const json = JSON.parse(nextDataMatch[1]);
      const traverse = (obj: any, currentCategory = 'ویژه کافه') => {
        if (!obj || typeof obj !== 'object') return;
        if (Array.isArray(obj)) {
          obj.forEach((i) => traverse(i, currentCategory));
          return;
        }
        if (obj.categoryName || obj.categoryTitle || obj.groupName) {
          currentCategory = String(obj.categoryName || obj.categoryTitle || obj.groupName).trim();
        }
        if ((obj.title || obj.name || obj.foodName) && (obj.price !== undefined || obj.unitPrice !== undefined || obj.amount !== undefined)) {
          const name = String(obj.title || obj.name || obj.foodName).trim();
          const price = Number(String(obj.price ?? obj.unitPrice ?? obj.amount).replace(/[^0-9]/g, ''));
          if (name && price > 500 && !seenNames.has(name)) {
            seenNames.add(name);
            items.push({
              name,
              price: price < 10000 ? price * 10 : price,
              desc: String(obj.description || obj.desc || '').trim(),
              category: currentCategory,
              image: obj.image || obj.imageUrl || obj.pic || '/images/menu/coffee.svg',
            });
          }
        }
        for (const key of Object.keys(obj)) {
          traverse(obj[key], currentCategory);
        }
      };
      traverse(json);
      if (items.length > 0) return items;
    }
  } catch {}

  const normalizeDigits = (str: string) => str.replace(/[۰-۹]/g, (d) => '0123456789'['۰۱۲۳۴۵۶۷۸۹'.indexOf(d)]).replace(/[٠-٩]/g, (d) => '0123456789'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)]);
  
  let lines = content.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (content.includes('<') && content.includes('>')) {
    const cleanHtml = content
      .replace(/<(?:h1|h2|h3|h4|strong|b)[^>]*>([^<]+)<\/(?:h1|h2|h3|h4|strong|b)>/gi, '\n---CAT---$1\n')
      .replace(/<[^>]+>/g, '\n');
    lines = cleanHtml.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  }

  let currentCat = 'منوی رستوران‌یار';
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith('---CAT---')) {
      currentCat = line.replace('---CAT---', '').trim();
      continue;
    }
    const normLine = normalizeDigits(line);
    const priceMatch = normLine.match(/(\d{1,3}(?:[,\.]\d{3})+)|\b(\d{4,8})\b/);
    const hasCurrency = /(?:تومان|ریال|Toman|Rial|ت)/i.test(line);
    if ((hasCurrency && priceMatch) || (priceMatch && Number(priceMatch[0].replace(/[^0-9]/g, '')) >= 5000 && line.length < 30)) {
      const rawPrice = Number(priceMatch[0].replace(/[^0-9]/g, ''));
      const price = rawPrice < 5000 ? rawPrice * 1000 : rawPrice;
      let name = '';
      let desc = '';
      for (let j = i - 1; j >= Math.max(0, i - 3); j--) {
        const candidate = lines[j];
        if (candidate && !candidate.startsWith('---CAT---') && candidate.length < 50 && !/(?:تومان|ریال|\d{4,})/.test(normalizeDigits(candidate))) {
          if (!name) name = candidate;
          else if (!desc) desc = candidate;
        }
      }
      if (name && !seenNames.has(name) && name.length > 2) {
        seenNames.add(name);
        items.push({ name, price, desc, category: currentCat, image: '/images/menu/coffee.svg' });
      }
    }
  }

  return items;
}

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  async getProducts() {
    if (!this.prisma.isAvailable()) return { success: true, data: store.products, categories, homeSections: store.homeSections, discountCodes: store.discountCodes };
    try {
      const [products, dbCategories, home, discountCodes] = await Promise.all([
        this.prisma.product.findMany({ where: { deletedAt: null }, include: { categories: { include: { category: true } } }, orderBy: { createdAt: 'desc' } }),
        this.prisma.category.findMany({ where: { active: true }, orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }] }),
        this.prisma.homeSettings.findUnique({ where: { id: 'default' } }),
        this.prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } }),
      ]);
      return { success: true, data: products.map(mapProduct), categories: dbCategories.map((c) => c.name), homeSections: home?.data || DEFAULT_HOME_SETTINGS, discountCodes: discountCodes.map(mapDiscount) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.products, categories, homeSections: store.homeSections, discountCodes: store.discountCodes };
    }
  }

  async createDiscount(body: any) {
    if (!this.prisma.isAvailable()) {
      const discount = createDiscountCode({ code: body?.code, title: body?.title || 'کد تخفیف پنل ادمین', type: body?.type || 'percent', value: Number(body?.value || 0), once: body?.once !== false, active: body?.active !== false }, 'admin');
      return { success: true, data: discount, discountCodes: store.discountCodes };
    }
    try {
      const code = String(body?.code || `DASTAN-${Math.random().toString(36).slice(2, 8)}`).toUpperCase().replace(/\s+/g, '');
      const discount = await this.prisma.discountCode.upsert({
        where: { code },
        update: {},
        create: { code, title: body?.title || 'کد تخفیف پنل ادمین', type: body?.type || 'percent', value: Number(body?.value || 0), once: body?.once !== false, active: body?.active !== false, source: 'admin' },
      });
      const discountCodes = await this.prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
      return { success: true, data: mapDiscount(discount), discountCodes: discountCodes.map(mapDiscount) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return this.createDiscount(body);
      return { success: false, message: error?.message || 'خطا در ثبت تخفیف.' };
    }
  }

  async updateDiscount(id: string, body: any) {
    if (!this.prisma.isAvailable()) {
      const discount = store.discountCodes.find((d: any) => d.id === id);
      if (!discount) return { success: false, message: 'Discount not found' };
      Object.assign(discount, { ...body, code: body?.code ? String(body.code).toUpperCase().replace(/\s+/g, '') : discount.code, value: body?.value !== undefined ? Number(body.value || 0) : discount.value, active: body?.active !== undefined ? !!body.active : discount.active, once: body?.once !== undefined ? !!body.once : discount.once });
      return { success: true, data: discount, discountCodes: store.discountCodes };
    }
    try {
      const discount = await this.prisma.discountCode.update({ where: { id }, data: { ...(body?.code ? { code: String(body.code).toUpperCase().replace(/\s+/g, '') } : {}), ...(body?.title !== undefined ? { title: body.title } : {}), ...(body?.type !== undefined ? { type: body.type } : {}), ...(body?.value !== undefined ? { value: Number(body.value || 0) } : {}), ...(body?.active !== undefined ? { active: !!body.active } : {}), ...(body?.once !== undefined ? { once: !!body.once } : {}) } });
      const discountCodes = await this.prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
      return { success: true, data: mapDiscount(discount), discountCodes: discountCodes.map(mapDiscount) };
    } catch (error) {
      return { success: false, message: 'Discount not found' };
    }
  }

  async deleteDiscount(id: string) {
    if (!this.prisma.isAvailable()) {
      const index = store.discountCodes.findIndex((d: any) => d.id === id);
      if (index === -1) return { success: false, message: 'Discount not found' };
      const removed = store.discountCodes.splice(index, 1)[0];
      return { success: true, data: removed, discountCodes: store.discountCodes };
    }
    try {
      const removed = await this.prisma.discountCode.delete({ where: { id } });
      const discountCodes = await this.prisma.discountCode.findMany({ orderBy: { createdAt: 'desc' } });
      return { success: true, data: mapDiscount(removed), discountCodes: discountCodes.map(mapDiscount) };
    } catch {
      return { success: false, message: 'Discount not found' };
    }
  }

  async getAccounting(from?: string, to?: string) {
    if (!this.prisma.isAvailable()) return buildAccountingReport(from, to);
    try {
      const fromDate = from ? new Date(`${from}T00:00:00`) : undefined;
      const toDate = to ? new Date(`${to}T23:59:59`) : undefined;
      const dbOrders = await this.prisma.order.findMany({
        where: { status: 'DELIVERED' as any, paymentStatus: { not: 'PENDING' as any }, createdAt: { ...(fromDate ? { gte: fromDate } : {}), ...(toDate ? { lte: toDate } : {}) } },
        include: { items: true, table: true },
        orderBy: { createdAt: 'desc' },
      });
      const mappedDbOrders = dbOrders.map((order) => {
        const items = order.items.map((item) => ({ productId: item.productId, name: item.productNameSnapshot, qty: item.qty, price: item.unitPrice, total: item.qty * item.unitPrice }));
        const grossTotal = Number(order.subtotal || 0);
        const discountAmount = Number(order.discountAmount || 0);
        const total = Number(order.finalTotal || 0);
        const estimatedCost = Math.round(grossTotal * 0.55);
        return { id: order.id, date: order.createdAt.toISOString(), table: order.tableName || order.table?.name || 'میز', status: order.status, items, grossTotal, discountAmount, total, estimatedCost, profit: total - estimatedCost };
      });
      const memoryReport = buildAccountingReport(from, to).data;
      const mergedMap = new Map();
      for (const order of [...(memoryReport?.orders || []), ...mappedDbOrders]) mergedMap.set(String(order.id), order);
      const orders = [...mergedMap.values()].sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
      const totalSales = orders.reduce((sum, order) => sum + order.total, 0);
      const totalCost = orders.reduce((sum, order) => sum + order.estimatedCost, 0);
      const totalDiscount = orders.reduce((sum, order) => sum + order.discountAmount, 0);
      return { success: true, data: { orders, totalSales, totalCost, totalProfit: totalSales - totalCost, totalDiscount, orderCount: orders.length } };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return buildAccountingReport(from, to);
    }
  }

  async deleteAccountingOrder(id: string) {
    if (!this.prisma.isAvailable()) {
      const index = store.orders.findIndex((o: any) => String(o.id) === String(id));
      if (index === -1) return { success: false, message: 'Order not found' };
      const removed = store.orders.splice(index, 1)[0];
      store.barOrders = store.barOrders.filter((o: any) => String(o.orderId) !== String(id));
      store.kitchenOrders = store.kitchenOrders.filter((o: any) => String(o.orderId) !== String(id));
      store.waiterTables = store.waiterTables.filter((o: any) => String(o.orderId) !== String(id));
      return { success: true, data: removed };
    }
    try {
      await this.prisma.orderStatusLog.deleteMany({ where: { orderId: id } });
      await this.prisma.orderItem.deleteMany({ where: { orderId: id } });
      await this.prisma.notification.deleteMany({ where: { orderId: id } });
      const removed = await this.prisma.order.delete({ where: { id } });
      return { success: true, data: removed };
    } catch {
      return { success: false, message: 'Order not found' };
    }
  }

  async createProduct(body: any) {
    const image = await saveBase64Image(body.image, 'products');
    const station = body.station === 'kitchen' ? 'kitchen' : 'bar';
    if (!this.prisma.isAvailable()) {
      const item = { id: `p${Date.now()}`, name: body.name, categories: body.categories || [], price: Number(body.price || 0), desc: body.desc || '', active: true, image, station, featured: !!body.featured, discounted: !!body.discounted, oldPrice: body.oldPrice ? Number(body.oldPrice) : undefined, customizations: body.customizations || [] };
      store.products.push(item as any);
      return { success: true, data: item };
    }
    try {
      const product = await this.prisma.product.create({ data: { name: body.name, desc: body.desc || '', price: Number(body.price || 0), oldPrice: body.oldPrice ? Number(body.oldPrice) : null, active: body.active !== false, image, station, featured: !!body.featured, discounted: !!body.discounted, customizations: body.customizations || [] } as any });
      await this.syncProductCategories(product.id, body.categories || []);
      return { success: true, data: await this.getMappedProduct(product.id) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      if (!this.prisma.isAvailable()) return this.createProduct({ ...body, image });
      return { success: false, message: error?.message || 'خطا در ثبت محصول.' };
    }
  }

  async updateProduct(id: string, body: any) {
    const image = body.image !== undefined ? await saveBase64Image(body.image, 'products') : undefined;
    if (!this.prisma.isAvailable()) {
      const product = store.products.find((p) => p.id === id);
      if (!product) return { success: false, message: 'Product not found' };
      Object.assign(product, { ...body, ...(image !== undefined ? { image } : {}), categories: body.categories || product.categories, featured: !!body.featured, discounted: !!body.discounted, active: body.active !== undefined ? !!body.active : product.active, price: body.price !== undefined ? Number(body.price) : product.price, oldPrice: body.oldPrice !== undefined && body.oldPrice !== '' ? Number(body.oldPrice) : undefined, ...(body.station !== undefined ? { station: body.station === 'kitchen' ? 'kitchen' : 'bar' } : {}) });
      return { success: true, data: product };
    }
    try {
      await this.prisma.product.update({ where: { id }, data: { ...(body.name !== undefined ? { name: body.name } : {}), ...(body.desc !== undefined ? { desc: body.desc } : {}), ...(body.price !== undefined ? { price: Number(body.price) } : {}), ...(body.oldPrice !== undefined ? { oldPrice: body.oldPrice !== '' ? Number(body.oldPrice) : null } : {}), ...(image !== undefined ? { image } : {}), ...(body.featured !== undefined ? { featured: !!body.featured } : {}), ...(body.discounted !== undefined ? { discounted: !!body.discounted } : {}), ...(body.active !== undefined ? { active: !!body.active } : {}), ...(body.outOfStock !== undefined ? { outOfStock: !!body.outOfStock } : {}), ...(body.station !== undefined ? { station: body.station === 'kitchen' ? 'kitchen' : 'bar' } : {}), ...(body.customizations !== undefined ? { customizations: body.customizations || [] } : {}) } as any });
      if (body.categories) await this.syncProductCategories(id, body.categories);
      return { success: true, data: await this.getMappedProduct(id) };
    } catch {
      return { success: false, message: 'Product not found' };
    }
  }

  async deleteProduct(id: string) {
    if (!this.prisma.isAvailable()) {
      const index = store.products.findIndex((p) => p.id === id);
      if (index === -1) return { success: false, message: 'Product not found' };
      const removed = store.products.splice(index, 1)[0];
      return { success: true, data: removed };
    }
    try {
      const removed = await this.prisma.product.update({ where: { id }, data: { active: false, deletedAt: new Date() }, include: { categories: { include: { category: true } } } });
      return { success: true, data: mapProduct(removed) };
    } catch {
      return { success: false, message: 'Product not found' };
    }
  }

  async createCategory(body: any) {
    const name = String(body?.name || '').trim();
    if (!name) return { success: false, message: 'Category name is required' };
    if (!this.prisma.isAvailable()) {
      if (!categories.includes(name)) categories.push(name);
      return { success: true, data: categories };
    }
    await this.prisma.category.upsert({ where: { name }, update: { active: true }, create: { name, displayOrder: categories.length + 1 } });
    const dbCategories = await this.prisma.category.findMany({ where: { active: true }, orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }] });
    return { success: true, data: dbCategories.map((c) => c.name) };
  }

  async updateCategory(oldName: string, body: any) {
    const nextName = String(body?.name || '').trim();
    if (!nextName) return { success: false, message: 'Category not found' };
    if (!this.prisma.isAvailable()) {
      const index = categories.findIndex((c) => c === oldName);
      if (index === -1) return { success: false, message: 'Category not found' };
      categories[index] = nextName;
      store.products.forEach((p) => { p.categories = (p.categories || []).map((c) => c === oldName ? nextName : c); });
      return { success: true, data: categories };
    }
    try {
      await this.prisma.category.update({ where: { name: oldName }, data: { name: nextName } });
      const dbCategories = await this.prisma.category.findMany({ where: { active: true }, orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }] });
      return { success: true, data: dbCategories.map((c) => c.name) };
    } catch {
      return { success: false, message: 'Category not found' };
    }
  }

  async deleteCategory(name: string) {
    if (!this.prisma.isAvailable()) {
      const index = categories.findIndex((c) => c === name);
      if (index === -1) return { success: false, message: 'Category not found' };
      categories.splice(index, 1);
      store.products.forEach((p) => { p.categories = (p.categories || []).filter((c) => c !== name); });
      return { success: true, data: categories };
    }
    try {
      await this.prisma.category.update({ where: { name }, data: { active: false } });
      const dbCategories = await this.prisma.category.findMany({ where: { active: true }, orderBy: [{ displayOrder: 'asc' }, { name: 'asc' }] });
      return { success: true, data: dbCategories.map((c) => c.name) };
    } catch {
      return { success: false, message: 'Category not found' };
    }
  }

  async updateHomeSections(body: any) {
    if (!this.prisma.isAvailable()) {
      const next = { ...store.homeSections, ...body, promoCards: Array.isArray(body?.promoCards) ? body.promoCards : store.homeSections.promoCards };
      if (Object.prototype.hasOwnProperty.call(body || {}, 'memoryCard')) next.memoryCard = body.memoryCard;
      if (Object.prototype.hasOwnProperty.call(body || {}, 'moodCard')) next.moodCard = body.moodCard;
      store.homeSections = next as any;
      return { success: true, data: store.homeSections };
    }
    const current = await this.prisma.homeSettings.findUnique({ where: { id: 'default' } });
    const currentData: any = current?.data || DEFAULT_HOME_SETTINGS;
    const next = { ...currentData, ...body, promoCards: Array.isArray(body?.promoCards) ? body.promoCards : currentData.promoCards };
    if (Object.prototype.hasOwnProperty.call(body || {}, 'memoryCard')) next.memoryCard = body.memoryCard;
    if (Object.prototype.hasOwnProperty.call(body || {}, 'moodCard')) next.moodCard = body.moodCard;
    await this.prisma.homeSettings.upsert({ where: { id: 'default' }, update: { data: next }, create: { id: 'default', data: next } });
    return { success: true, data: next };
  }

  async getStaff() {
    const defaults = [
      { username: 'admin', role: 'ADMIN', label: 'مدیریت کل (ادمین)' },
      { username: 'bar', role: 'BAR', label: 'کافه و بار' },
      { username: 'kitchen', role: 'KITCHEN', label: 'آشپزخانه' },
      { username: 'waiter', role: 'WAITER', label: 'سالن‌کار (ویتر)' },
    ];
    if (!this.prisma.isAvailable()) return { success: true, data: defaults };
    try {
      const staff = await this.prisma.staffUser.findMany({ select: { id: true, username: true, role: true, isActive: true }, orderBy: { username: 'asc' } });
      return { success: true, data: staff.length ? staff : defaults };
    } catch {
      return { success: true, data: defaults };
    }
  }

  async updateStaffPassword(username: string, newPassword: string) {
    const cleanUser = String(username || '').trim().toLowerCase();
    const cleanPass = String(newPassword || '').trim();
    if (!cleanPass || cleanPass.length < 4) {
      return { success: false, message: 'رمز عبور باید حداقل ۴ کاراکتر باشد.' };
    }
    if (!this.prisma.isAvailable()) {
      return { success: true, message: `رمز عبور اکانت ${cleanUser} تغییر کرد.` };
    }
    try {
      const roleMap: Record<string, string> = { admin: 'ADMIN', bar: 'BAR', kitchen: 'KITCHEN', waiter: 'WAITER' };
      const hashed = hashPassword(cleanPass);
      await this.prisma.staffUser.upsert({
        where: { username: cleanUser },
        update: { passwordHash: hashed, isActive: true },
        create: { username: cleanUser, passwordHash: hashed, role: (roleMap[cleanUser] as any) || 'ADMIN', isActive: true },
      });
      return { success: true, message: `رمز عبور اکانت ${cleanUser} با موفقیت در دیتابیس تغییر کرد.` };
    } catch (error) {
      return { success: false, message: 'خطا در تغییر رمز عبور در دیتابیس.' };
    }
  }

  private async syncProductCategories(productId: string, names: string[]) {
    await this.prisma.productCategory.deleteMany({ where: { productId } });
    for (const name of names || []) {
      const clean = String(name || '').trim();
      if (!clean) continue;
      const category = await this.prisma.category.upsert({ where: { name: clean }, update: { active: true }, create: { name: clean, displayOrder: categories.length + 1 } });
      await this.prisma.productCategory.create({ data: { productId, categoryId: category.id } });
    }
  }

  private async getMappedProduct(id: string) {
    const product = await this.prisma.product.findUnique({ where: { id }, include: { categories: { include: { category: true } } } });
    return product ? mapProduct(product) : null;
  }
}
