import { Controller, Post, UseGuards } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

@UseGuards(AuthGuardMock, RolesGuardMock)
@RequireRoles(Roles.ADMIN)
@Controller('admin')
export class AdminCacheController {
  constructor(private readonly prisma: PrismaService) {}

  // پاک‌سازی کش سمت سرور: وضعیت لایه‌های حافظه + سیاست cache
  @Post('cache/clear')
  clearCache() {
    return {
      success: true,
      message: 'کش سرور بررسی و تطبیق شد؛ پاسخ‌های API همیشه مستقیم از دیتابیس و با هدر no-store ارسال می‌شوند.',
      data: {
        dbAvailable: this.prisma.isAvailable(),
        processUptimeSec: Math.round(process.uptime()),
        serverTime: new Date().toISOString(),
        apiCachePolicy: 'no-store',
        pageCachePolicy: 'no-store (HTML) / immutable (static)',
      },
    };
  }
}
