import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';

@UseGuards(AuthGuardMock, RolesGuardMock)
@RequireRoles(Roles.ADMIN)
@Controller('admin/products')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('accounting/report') getAccounting(@Query('from') from?: string, @Query('to') to?: string) { return this.adminService.getAccounting(from, to); }
  @Delete('accounting/report/:id') deleteAccountingOrder(@Param('id') id: string) { return this.adminService.deleteAccountingOrder(id); }
  @Get('staff') getStaff() { return this.adminService.getStaff(); }
  @Patch('staff/:username/password') updateStaffPassword(@Param('username') username: string, @Body() body: any) { return this.adminService.updateStaffPassword(username, body?.password); }

  @Get() getProducts() { return this.adminService.getProducts(); }
  @Post() createProduct(@Body() body: any) { return this.adminService.createProduct(body); }

  @Post('discounts') createDiscount(@Body() body: any) { return this.adminService.createDiscount(body); }
  @Patch('discounts/:id') updateDiscount(@Param('id') id: string, @Body() body: any) { return this.adminService.updateDiscount(id, body); }
  @Delete('discounts/:id') deleteDiscount(@Param('id') id: string) { return this.adminService.deleteDiscount(id); }

  @Patch('home/sections/update') updateHomeSections(@Body() body: any) { return this.adminService.updateHomeSections(body); }

  @Post('categories') createCategory(@Body() body: any) { return this.adminService.createCategory(body); }
  @Patch('categories/:name') updateCategory(@Param('name') name: string, @Body() body: any) { return this.adminService.updateCategory(decodeURIComponent(name), body); }
  @Delete('categories/:name') deleteCategory(@Param('name') name: string) { return this.adminService.deleteCategory(decodeURIComponent(name)); }

  @Patch(':id') updateProduct(@Param('id') id: string, @Body() body: any) { return this.adminService.updateProduct(id, body); }
  @Delete(':id') deleteProduct(@Param('id') id: string) { return this.adminService.deleteProduct(id); }
}
