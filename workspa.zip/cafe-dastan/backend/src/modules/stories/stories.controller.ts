import { Body, Controller, Delete, Get, Param, Post, Query, Req, UseGuards, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { mkdirSync } from 'fs';
import { join } from 'path';
import { StoriesService } from './stories.service';
import { mediaMaxBytes } from '../../common/file-storage';
import { AuthGuardMock } from '../auth/auth.guard';
import { RolesGuardMock } from '../auth/roles.guard';
import { RequireRoles, Roles } from '../auth/roles';
import { assertCustomerUser } from '../auth/customer-auth';

@Controller('stories')
export class StoriesController {
  constructor(private readonly storiesService: StoriesService) {}

  @Get()
  getStories(@Query('viewerId') viewerId?: string) { return this.storiesService.getStories(viewerId); }

  @UseGuards(AuthGuardMock, RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  @Get('admin/all')
  getAllStoriesForAdmin() { return this.storiesService.getStoriesForAdmin(); }

  @UseGuards(AuthGuardMock)
  @Post()
  createStory(@Body() body: any, @Req() req: any) { const customer = assertCustomerUser(req.user); return this.storiesService.createStory({ ...body, ownerId: customer.id, customerId: customer.id, userName: body?.userName || customer.name || 'مهمان کافه' }); }

  // آپلود مستقیم فایل استوری ادمین (multipart) — برای فایل‌های حجیم (ویدیو تا 500MB پیش‌فرض).
// پاسخ: { success: true, url: '/uploads/stories/xxx.mp4', mediaType: 'video'|'image', sizeBytes }
@UseGuards(AuthGuardMock, RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: (_req, _file, cb) => {
        const dir = join(process.cwd(), 'uploads', 'stories', '.tmp');
        mkdirSync(dir, { recursive: true });
        cb(null, dir);
      },
      filename: (_req, file, cb) => {
        cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
      },
    }),
    limits: { fileSize: mediaMaxBytes(true) },
  }))
  @Post('admin/media')
  uploadAdminStoryMedia(@UploadedFile() file: any) { return this.storiesService.uploadAdminStoryMedia(file); }

  @UseGuards(AuthGuardMock, RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  @Post('admin')
  createAdminStory(@Body() body: any) { return this.storiesService.createStory({ ...body, isAdminStory: true }); }

  @UseGuards(AuthGuardMock)
  @Post(':id/like')
  likeStory(@Param('id') id: string, @Body() body: any, @Req() req: any) { const customer = assertCustomerUser(req.user); return this.storiesService.likeStory(id, { ...body, viewerId: customer.id, customerId: customer.id, userName: body?.userName || customer.name || 'مهمان کافه' }); }

  @UseGuards(AuthGuardMock)
  @Post(':id/comments')
  commentStory(@Param('id') id: string, @Body() body: any, @Req() req: any) { const customer = assertCustomerUser(req.user); return this.storiesService.commentStory(id, { ...body, viewerId: customer.id, customerId: customer.id, userName: body?.userName || customer.name || 'مهمان' }); }

  @UseGuards(AuthGuardMock)
  @Delete(':id')
  deleteOwnStory(@Param('id') id: string, @Req() req: any) { const customer = assertCustomerUser(req.user); return this.storiesService.deleteStory(id, customer.id, false); }

  @UseGuards(AuthGuardMock, RolesGuardMock)
  @RequireRoles(Roles.ADMIN)
  @Delete(':id/admin')
  deleteStoryAsAdmin(@Param('id') id: string) { return this.storiesService.deleteStory(id, '', true); }
}
