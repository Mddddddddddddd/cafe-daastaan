import { Injectable } from '@nestjs/common';
import { store } from '../../store/data.store';
import { PrismaService } from '../../prisma/prisma.service';
import { saveBase64Media, saveIncomingUploadFile } from '../../common/file-storage';

function normalizeOwnerId(value: any) {
  return String(value || '').trim();
}

function normalizeStoryDurationHours(value: any, isAdminStory = false) {
  const hours = Number(value);
  if (!Number.isFinite(hours) || hours <= 0) return 24;
  if (isAdminStory) return Math.min(Math.max(Math.round(hours), 1), 720);
  return 24;
}

function normalizeMediaType(value: any) {
  return String(value || '').toLowerCase() === 'video' ? 'video' : 'image';
}

function mapStory(story: any, viewerId?: string) {
  const ownerId = normalizeOwnerId(story.ownerId || story.customerId);
  const likedBy: string[] = Array.isArray(story.likedBy) ? story.likedBy : [];
  const normalizedViewer = normalizeOwnerId(viewerId);
  const createdAtValue = story.createdAt instanceof Date ? story.createdAt.toISOString() : story.createdAt;
  const expiresAtValue = story.expiresAt instanceof Date ? story.expiresAt.toISOString() : story.expiresAt;
  const created = new Date(createdAtValue || 0).getTime();
  const expires = new Date(expiresAtValue || 0).getTime();
  const remainingMs = Number.isFinite(expires) ? Math.max(0, expires - Date.now()) : 0;

  return {
    id: story.id,
    userName: story.userName,
    caption: story.caption,
    image: story.image,
    mediaType: normalizeMediaType((story as any).mediaType),
    ownerId,
    isAdmin: !!(story as any).isAdmin,
    isHighlight: !!(story as any).isHighlight,
    canDelete: !!normalizedViewer && ownerId === normalizedViewer,
    likedByMe: !!normalizedViewer && likedBy.includes(normalizedViewer),
    createdAt: createdAtValue,
    expiresAt: expiresAtValue,
    remainingMs,
    durationHours: Number.isFinite(created) && Number.isFinite(expires) && expires > created ? Math.max(1, Math.round((expires - created) / (60 * 60 * 1000))) : 24,
    likes: story.likes || likedBy.length || 0,
    comments: (story.comments || []).map((comment: any) => ({
      id: comment.id,
      userName: comment.userName,
      text: comment.text,
      createdAt: comment.createdAt instanceof Date ? comment.createdAt.toISOString() : comment.createdAt,
    })),
  };
}

@Injectable()
export class StoriesService {
  private readonly storyLifeMs = 24 * 60 * 60 * 1000;

  constructor(private readonly prisma: PrismaService) {}

  private removeExpiredStories() {
    const now = Date.now();
    store.stories = store.stories.filter((story: any) => {
      const expiresAt = story?.expiresAt ? new Date(story.expiresAt).getTime() : (new Date(story.createdAt).getTime() + this.storyLifeMs);
      return !Number.isFinite(expiresAt) || now < expiresAt;
    });
  }

  async getStories(viewerId?: string) {
    if (!this.prisma.isAvailable()) {
      this.removeExpiredStories();
      return { success: true, data: store.stories.map((story: any) => mapStory(story, viewerId)) };
    }
    try {
      const now = new Date();
      const stories = await this.prisma.story.findMany({
        where: { OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] },
        include: { comments: { orderBy: { createdAt: 'asc' } } },
        orderBy: [{ isHighlight: 'desc' }, { isAdmin: 'desc' }, { createdAt: 'desc' }],
      });
      return { success: true, data: stories.map((story) => mapStory(story, viewerId)) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      this.removeExpiredStories();
      return { success: true, data: store.stories.map((story: any) => mapStory(story, viewerId)) };
    }
  }

  // مخصوص ادمین: همه استوری‌ها (حتی منقضی‌شده) را برمی‌گرداند تا قابل مدیریت/حذف باشند.
  async getStoriesForAdmin() {
    if (!this.prisma.isAvailable()) {
      return { success: true, data: store.stories.map((story: any) => mapStory(story)) };
    }
    try {
      const stories = await this.prisma.story.findMany({
        include: { comments: { orderBy: { createdAt: 'asc' } } },
        orderBy: [{ isHighlight: 'desc' }, { isAdmin: 'desc' }, { createdAt: 'desc' }],
      });
      return { success: true, data: stories.map((story) => mapStory(story)) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return { success: true, data: store.stories.map((story: any) => mapStory(story)) };
    }
  }

  async createStory(body: any) {
    const media = await saveBase64Media(body.image, 'stories');
    if (!this.prisma.isAvailable()) return this.createMemoryStory({ ...body, image: media });
    try {
      if (!media) return { success: false, message: 'Media is required' };
      const ownerId = normalizeOwnerId(body.ownerId);
      const isAdminStory = !!body.isAdminStory;
      const durationHours = normalizeStoryDurationHours(body.durationHours, isAdminStory);
      const createdAt = new Date();
      const customerId = normalizeOwnerId(body.customerId) || undefined;
      const story = await this.prisma.story.create({
        data: {
          userName: body.userName || 'مهمان کافه',
          caption: body.caption || '',
          image: media,
          mediaType: normalizeMediaType(body.mediaType),
          likes: 0,
          likedBy: [],
          ownerId,
          customerId,
          isAdmin: isAdminStory,
          isHighlight: !!body.isHighlight,
          expiresAt: new Date(createdAt.getTime() + durationHours * 60 * 60 * 1000),
          createdAt,
        },
        include: { comments: true },
      });
      return { success: true, data: mapStory(story, ownerId) };
    } catch (error) {
      this.prisma.markUnavailable(error);
      return this.createMemoryStory({ ...body, image: media });
    }
  }

  // آپلود مستقیم فایل استوری ادمین (از multipart) — فایل روی disk ذخیره می‌شود و URL برمی‌گردد.
  async uploadAdminStoryMedia(file: any) {
    if (!file) return { success: false, message: 'No file received.' };
    try {
      const url = await saveIncomingUploadFile(file, 'stories');
      const isVideo = /\.(mp4|webm|mov)$/i.test(url);
      return { success: true, url, mediaType: isVideo ? 'video' : 'image', sizeBytes: file.size || 0 };
    } catch (error: any) {
      return { success: false, message: error?.message || 'Upload failed.' };
    }
  }

  async likeStory(id: string, body?: any) {
    const viewerId = normalizeOwnerId(body?.viewerId);
    if (!viewerId) return { success: false, message: 'viewerId is required' };
    if (!this.prisma.isAvailable()) return this.likeMemoryStory(id, viewerId);
    try {
      const story = await this.prisma.story.findUnique({ where: { id }, include: { comments: { orderBy: { createdAt: 'asc' } } } });
      if (!story) return { success: false, message: 'Story not found' };
      const likedBy: string[] = Array.isArray((story as any).likedBy) ? (story as any).likedBy : [];
      if (likedBy.includes(viewerId)) return { success: true, data: mapStory(story, viewerId), message: 'قبلاً لایک شده است.' };
      const nextLikedBy = [...likedBy, viewerId];
      const updated = await this.prisma.story.update({ where: { id }, data: { likes: nextLikedBy.length, likedBy: nextLikedBy }, include: { comments: { orderBy: { createdAt: 'asc' } } } });
      return { success: true, data: mapStory(updated, viewerId) };
    } catch {
      return { success: false, message: 'Story not found' };
    }
  }

  async commentStory(id: string, body: any) {
    if (!this.prisma.isAvailable()) return this.commentMemoryStory(id, body);
    try {
      const text = body.text || '';
      if (!text.trim()) return { success: false, message: 'Comment text is required' };
      await this.prisma.storyComment.create({ data: { storyId: id, userName: body.userName || 'مهمان', text } });
      const story = await this.prisma.story.findUnique({ where: { id }, include: { comments: { orderBy: { createdAt: 'asc' } } } });
      if (!story) return { success: false, message: 'Story not found' };
      return { success: true, data: mapStory(story, body?.viewerId) };
    } catch {
      return { success: false, message: 'Story not found' };
    }
  }

  async deleteStory(id: string, ownerId?: string, force = false) {
    const normalizedOwner = normalizeOwnerId(ownerId);
    if (!this.prisma.isAvailable()) {
      const index = store.stories.findIndex((s: any) => s.id === id);
      if (index === -1) return { success: false, message: 'Story not found' };
      const target: any = store.stories[index];
      if (!force && normalizeOwnerId(target.ownerId) !== normalizedOwner) return { success: false, message: 'اجازه حذف این استوری را نداری.' };
      const removed = store.stories.splice(index, 1)[0];
      return { success: true, data: removed };
    }
    try {
      const story = await this.prisma.story.findUnique({ where: { id } });
      if (!story) return { success: false, message: 'Story not found' };
      if (!force && normalizeOwnerId((story as any).ownerId) !== normalizedOwner) return { success: false, message: 'اجازه حذف این استوری را نداری.' };
      await this.prisma.storyComment.deleteMany({ where: { storyId: id } });
      const removed = await this.prisma.story.delete({ where: { id } });
      return { success: true, data: mapStory(removed, normalizedOwner) };
    } catch {
      return { success: false, message: 'Story not found' };
    }
  }

  private createMemoryStory(body: any) {
    const ownerId = normalizeOwnerId(body.ownerId);
    const isAdminStory = !!body.isAdminStory;
    const durationHours = normalizeStoryDurationHours(body.durationHours, isAdminStory);
    const createdAt = new Date();
    const story = {
      id: `s-${Date.now()}`,
      userName: body.userName || 'مهمان کافه',
      caption: body.caption || '',
      image: body.image || '',
      mediaType: normalizeMediaType(body.mediaType),
      isAdmin: isAdminStory,
      isHighlight: !!body.isHighlight,
      createdAt: createdAt.toISOString(),
      expiresAt: new Date(createdAt.getTime() + durationHours * 60 * 60 * 1000).toISOString(),
      likes: 0,
      likedBy: [] as string[],
      ownerId,
      comments: [],
    };
    if (!story.image) return { success: false, message: 'Media is required' };
    store.stories.unshift(story as any);
    return { success: true, data: mapStory(story, ownerId) };
  }

  private likeMemoryStory(id: string, viewerId: string) {
    this.removeExpiredStories();
    const story: any = store.stories.find((s: any) => s.id === id);
    if (!story) return { success: false, message: 'Story not found' };
    story.likedBy = Array.isArray(story.likedBy) ? story.likedBy : [];
    if (!story.likedBy.includes(viewerId)) story.likedBy.push(viewerId);
    story.likes = story.likedBy.length;
    return { success: true, data: mapStory(story, viewerId) };
  }

  private commentMemoryStory(id: string, body: any) {
    this.removeExpiredStories();
    const story: any = store.stories.find((s: any) => s.id === id);
    if (!story) return { success: false, message: 'Story not found' };
    const comment = { id: `c-${Date.now()}`, userName: body.userName || 'مهمان', text: body.text || '', createdAt: new Date().toISOString() };
    if (!comment.text.trim()) return { success: false, message: 'Comment text is required' };
    story.comments.push(comment);
    return { success: true, data: mapStory(story, body?.viewerId) };
  }
}
