import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello() {
    return {
      name: 'Cafe Dastan API',
      status: 'ok',
      message: 'Backend scaffold is ready',
    };
  }
}