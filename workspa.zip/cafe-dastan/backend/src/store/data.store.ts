export type ProductOptionValue = string | { id?: string; name: string; price?: number };
export type ProductOption = { id?: string; name: string; values: ProductOptionValue[] };
export type ProductItem = { id: string; name: string; categories: string[]; price: number; desc?: string; active: boolean; outOfStock?: boolean; image?: string; customizations: ProductOption[]; featured?: boolean; discounted?: boolean; oldPrice?: number; station?: 'bar' | 'kitchen'; };
export type HomePromoCard = { id: string; title: string; text: string; image?: string; visible?: boolean };
export type HomeSections = {
  showHero?: boolean;
  heroTitle: string;
  heroSubtitle: string;
  promoCode?: string;
  heroImage?: string;
  showSuggested?: boolean;
  showDiscounted?: boolean;
  promoCards: HomePromoCard[];
  showMemoryMood?: boolean;
  memoryCard?: HomePromoCard;
  moodCard?: HomePromoCard;
};
export type StaffOrder = { id: string; productId: string; name: string; tableName: string; tableQr: string; time: string; status: 'جدید' | 'درحال آماده‌سازی' | 'آماده تحویل'; station: 'bar' | 'kitchen'; orderId: string; qty?: number; items?: { productId: string; name: string; qty: number }[]; };
export type CafeStory = { id: string; userName: string; caption: string; image: string; mediaType?: 'image' | 'video'; isAdmin?: boolean; isHighlight?: boolean; expiresAt?: string; createdAt: string; likes: number; comments: { id: string; userName: string; text: string; createdAt: string }[]; };
export type CafeFeedback = { id: string; orderId: string; createdAt: string; customerName: string; staffRating: number; staffComment?: string; orderRating: number; orderComment?: string; itemRatings: { productId: string; name: string; rating: number; comment?: string }[]; };
export type LoyaltyMember = { id: string; name: string; phone: string; points: number; lifetimePoints: number; tier: string; vouchers: any[]; history: any[]; };
export type DiscountCode = { id: string; code: string; title: string; type: 'percent' | 'fixed' | 'free_order'; value: number; active: boolean; once?: boolean; used?: boolean; source?: 'admin' | 'loyalty'; rewardId?: string; createdAt: string; };
export const categories = ['نوشیدنی گرم','نوشیدنی سرد','قهوه تخصصی','دمنوش','صبحانه','دسر','کیک','غذای سبک','فصلی','ویژه کافه'];
export const store = {
  products: <ProductItem[]>[
    { id: 'p1', name: 'لاته همینگوی', categories: ['نوشیدنی گرم','قهوه تخصصی'], price: 168000, oldPrice: 198000, discounted: true, featured: true, desc: 'لاته‌ای آرام برای شروع یک فصل نرم با فوم لطیف و شیر بخاردیده.', active: true, image: '/images/menu/coffee.svg', customizations: [{ id: 'c1', name: 'نوع شیر', values: ['شیر معمولی', 'شیر بادام', 'شیر جو', 'بدون لاکتوز'] }, { id: 'c2', name: 'اندازه', values: ['کوچک', 'متوسط', 'بزرگ'] }] },
    { id: 'p4', name: 'اسپرسو سینگل ۱۰۰٪ عربیکا', categories: ['نوشیدنی گرم','قهوه تخصصی'], price: 65000, desc: 'عصاره‌گیری استاندارد از دانه‌های تخصصی عربیکا با کرمای مخملی و طعم‌یاد فندق.', active: true, image: '/images/menu/coffee.svg', customizations: [{ id: 'c6', name: 'نوع دانه', values: ['۱۰۰٪ عربیکا کلمبیا', 'ترکیب ۷۰/۳۰ ویژه'] }] },
    { id: 'p5', name: 'آمریکانو داغ کلاسیک', categories: ['نوشیدنی گرم'], price: 75000, desc: 'دابل اسپرسو همراه با آب داغ تصفیه‌شده، ملایم، شفاف و انرژی‌بخش برای مطالعه.', active: true, image: '/images/menu/coffee.svg', customizations: [] },
    { id: 'p6', name: 'کاپوچینو ونیزی', categories: ['نوشیدنی گرم'], price: 155000, desc: 'اسپرسو، شیر گرم و لایه‌ای ضخیم و مخملی از فوم شیر با گارنیش پودر کاکائو.', active: true, image: '/images/menu/coffee.svg', customizations: [] },
    { id: 'p7', name: 'هات چاکلت بلژیکی', categories: ['نوشیدنی گرم','ویژه کافه'], price: 170000, featured: true, desc: 'نوشیدنی شکلات داغ غلیظ تهیه شده از تکه‌های شکلات تلخ بلژیکی و شیر تازه.', active: true, image: '/images/menu/coffee.svg', customizations: [] },

    { id: 'p2', name: 'آیس موکا باران', categories: ['نوشیدنی سرد','ویژه کافه'], price: 184000, featured: true, desc: 'ترکیب اسپرسو، سیروپ شکلات تلخ، شیر سرد و یخ؛ خنک، سبک و مناسب عصرهای گرم.', active: true, image: '/images/menu/cold.svg', customizations: [{ id: 'c3', name: 'یخ', values: ['کم', 'متوسط', 'زیاد'] }, { id: 'c4', name: 'سیروپ', values: ['وانیل', 'کارامل', 'بدون سیروپ'] }] },
    { id: 'p8', name: 'آیس لاته کاراملی', categories: ['نوشیدنی سرد'], price: 175000, desc: 'اسپرسو دابل عصاره‌گیری شده روی شیر سرد و یخ بلوری همراه با سیروپ کارامل نمکی.', active: true, image: '/images/menu/cold.svg', customizations: [] },
    { id: 'p9', name: 'موخیتا لیمو و نعناع تازه', categories: ['نوشیدنی سرد','فصلی'], price: 150000, desc: 'عصاره لیموترش شیرازی، نعناع ساطوری تازه، سودا و یخ کراش؛ فوق‌العاده طراوت‌بخش.', active: true, image: '/images/menu/cold.svg', customizations: [] },

    { id: 'p10', name: 'V60 دمی کلمبیا', categories: ['قهوه تخصصی'], price: 145000, desc: 'قهوه دمی موج سوم خاستگاه کلمبیا با اسیدیته شفاف و طعم‌یادهای کارامل و هلو.', active: true, image: '/images/menu/specialty.svg', customizations: [] },
    { id: 'p11', name: 'کمیکس اتیوپی', categories: ['قهوه تخصصی'], price: 160000, desc: 'دم‌آوری با فیلتر ضخیم کمیکس، بادی سبک شبیه چای با عطر یاس و مرکبات.', active: true, image: '/images/menu/specialty.svg', customizations: [] },

    { id: 'p12', name: 'دمنوش آرامش شب‌بو', categories: ['دمنوش'], price: 120000, desc: 'ترکیب طبیعی گل گاوزبان، بهارنارنج، اسطوخودوس و هل؛ آرام‌بخش اعصاب و روان.', active: true, image: '/images/menu/tea.svg', customizations: [] },
    { id: 'p13', name: 'چای ماسالا اصیل هندی', categories: ['دمنوش','نوشیدنی گرم'], price: 140000, desc: 'چای سیاه دم‌کشیده با ادویه‌های گرم اصیل هندی (هل، دارچین، زنجبیل، میخک) و شیر.', active: true, image: '/images/menu/tea.svg', customizations: [] },

    { id: 'p14', name: 'بشقاب صبحانه انگلیسی کامل', categories: ['صبحانه','ویژه کافه'], price: 320000, featured: true, desc: 'دو عدد تخم‌مرغ نیمرو، سوسیس شکاری، خوراک لوبیا چیتی، قارچ طعم‌دار، گوجه و تست برشته.', active: true, image: '/images/menu/breakfast.svg', customizations: [] },
    { id: 'p15', name: 'املت اسفناج و پنیر گودا', categories: ['صبحانه'], price: 240000, desc: 'سه عدد تخم‌مرغ تازه همراه با برگ‌های اسفناج تفت‌داده با کره، قارچ و پنیر ذوب‌شده.', active: true, image: '/images/menu/breakfast.svg', customizations: [] },

    { id: 'p16', name: 'پنینی مرغ و پستو دست‌ساز', categories: ['غذای سبک'], price: 285000, desc: 'سینه مرغ گریل‌شده با سس پستو ریحان تازه، پنیر موزارلا و گوجه خشک در نان چیاباتا.', active: true, image: '/images/menu/food.svg', customizations: [] },
    { id: 'p17', name: 'سالاد سزار با مرغ گریل', categories: ['غذای سبک','فصلی'], price: 270000, desc: 'کاهو پیچ ترد، تکه‌های سینه مرغ گریل، کروتان سیر و کره، پنیر پارمزان و سس اصیل سزار.', active: true, image: '/images/menu/food.svg', customizations: [] },

    { id: 'p3', name: 'چیزکیک پایان شیرین سن‌سباستین', categories: ['دسر','کیک'], price: 189000, oldPrice: 219000, discounted: true, desc: 'چیزکیک سوخته اسپانیایی با بافت کرمی فوق‌العاده لطیف، سرو با سس شکلات بلژیکی.', active: true, image: '/images/menu/dessert.svg', customizations: [{ id: 'c5', name: 'تاپینگ', values: ['توت‌فرنگی', 'شکلات', 'بدون تاپینگ'] }] },
    { id: 'p18', name: 'کیک هویج و گردو با کرم چیز', categories: ['کیک','دسر'], price: 135000, desc: 'کیک خانگی تازه پخت پر از گردو و دارچین با لایه‌ای ضخیم از فراستینگ پنیر خامه‌ای.', active: true, image: '/images/menu/cake.svg', customizations: [] },
    { id: 'p19', name: 'تیرامیسو کلاسیک ایتالیایی', categories: ['دسر'], price: 175000, desc: 'لایه‌های بیسکویت لیدی فینگر آغشته به اسپرسو تخصصی و کرم ماسکارپونه لطیف.', active: true, image: '/images/menu/cake.svg', customizations: [] },

    { id: 'p20', name: 'شیک شاتوت و وانیل ویژه داستان', categories: ['فصلی','نوشیدنی سرد'], price: 195000, desc: 'ترکیب بستنی وانیلی پرچرب، پوره شاتوت تازه طبیعی و خامه قنادی؛ غلیظ و بی‌نظیر.', active: true, image: '/images/menu/shake.svg', customizations: [] },
  ],
  homeSections: <HomeSections>{
    showHero: false,
    heroTitle: 'امشب دوست داری چه داستانی را مزه کنی؟',
    heroSubtitle: 'پیشنهادهای شخصی‌سازی‌شده، دسرهای ویژه و تجربه‌ای شبیه منوهای مدرن ولی با حال‌وهوای کافه داستان.',
    promoCode: 'DASTAN20',
    heroImage: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200&auto=format&fit=crop',
    showSuggested: true,
    showDiscounted: true,
    promoCards: [
      { id: 'pr1', title: 'پیشنهاد ما', text: 'لاته همینگوی + چیزکیک پایان شیرین', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
      { id: 'pr2', title: 'سفارش‌های تخفیف‌دار', text: 'دسرهای منتخب با کد DASTAN20', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true },
    ],
    showMemoryMood: false,
    memoryCard: { id: 'memory', title: 'حافظه کافه', text: 'دفعه قبل لاته و چیزکیک سفارش دادی.', image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop', visible: true },
    moodCard: { id: 'mood', title: 'حال و هوای امروز', text: 'آرام، رمانتیک یا ماجراجو؟', image: 'https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200&auto=format&fit=crop', visible: true }
  },
  orders: [] as any[],
  barOrders: <StaffOrder[]>[],
  kitchenOrders: <StaffOrder[]>[],
  waiterTables: [],
  discountCodes: <DiscountCode[]>[
    { id: 'dc-seed-20', code: 'DASTAN20', title: 'تخفیف افتتاحیه داستان', type: 'percent', value: 20, active: true, once: false, used: false, source: 'admin', createdAt: new Date().toISOString() },
  ],
  notifications: [
    { id: 'n1', title: 'فصل تازه در منو', body: 'آیس موکا باران امروز در دسترس است.', createdAt: new Date().toISOString(), type: 'broadcast' },
    { id: 'n2', title: 'سفارش تو در بار است', body: 'لاته همینگوی درحال آماده‌سازی است.', createdAt: new Date().toISOString(), type: 'order-status' },
  ] as any[],
  feedbacks: <CafeFeedback[]>[],
  loyalty: {
    member: <LoyaltyMember>{
      id: 'guest-1',
      name: 'مهمان کافه داستان',
      phone: '',
      points: 0,
      lifetimePoints: 0,
      tier: 'راوی تازه‌وارد',
      vouchers: [],
      history: [],
    },
  },
  stories: <CafeStory[]>[
    { id: 's1', userName: 'ادمین کافه', caption: 'پیشنهاد ویژه امروز کافه داستان.', image: '/images/menu/coffee.svg', mediaType: 'image', isAdmin: true, isHighlight: true, expiresAt: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(), createdAt: new Date().toISOString(), likes: 12, comments: [{ id: 'c-s1', userName: 'کافه داستان', text: 'چه قاب قشنگی!', createdAt: new Date().toISOString() }] },
    { id: 's2', userName: 'راوی میز فروغ', caption: 'گوشه آرام کافه برای نوشتن.', image: '/images/menu/cafe-corner.svg', mediaType: 'image', isAdmin: false, isHighlight: false, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), createdAt: new Date().toISOString(), likes: 8, comments: [] },
  ],
};
