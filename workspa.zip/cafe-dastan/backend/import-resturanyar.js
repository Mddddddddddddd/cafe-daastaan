/**
 * اسکریپت استخراج و وارد کردن منو از رستوران‌یار به دیتابیس کافه داستان
 * اجرای مستقیم در ترمینال سرور:
 * node import-resturanyar.js "https://resturanyar.ir/PublicMenu?token=dfaf59a3339841b1b8c7074d6e17dd2e"
 */

const https = require('https');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const url = process.argv[2] || "https://resturanyar.ir/PublicMenu?token=dfaf59a3339841b1b8c7074d6e17dd2e";

async function fetchUrl(targetUrl) {
  return new Promise((resolve, reject) => {
    https.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
        'Accept': 'text/html,application/json,*/*',
      }
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

async function run() {
  console.log(`📡 درحال دریافت اطلاعات از: ${url}...`);
  try {
    const html = await fetchUrl(url);
    console.log(`📄 محتوای صفحه دریافت شد (${html.length} بایت). درحال استخراج...`);
    
    // استخراج آیتم‌ها از محتوا
    const items = [];
    const seen = new Set();

    // بررسی ساختار JSON در سورس صفحه
    const jsonMatch = html.match(/<script id="__NEXT_DATA__" [^>]*>([\s\S]*?)<\/script>/i) || html.match(/window\.__INITIAL_STATE__\s*=\s*({[\s\S]*?});/i);
    if (jsonMatch && jsonMatch[1]) {
      try {
        const data = JSON.parse(jsonMatch[1]);
        const traverse = (obj, cat = 'ویژه کافه') => {
          if (!obj || typeof obj !== 'object') return;
          if (Array.isArray(obj)) { obj.forEach(i => traverse(i, cat)); return; }
          if (obj.categoryName || obj.categoryTitle) cat = String(obj.categoryName || obj.categoryTitle).trim();
          if ((obj.title || obj.name) && (obj.price !== undefined)) {
            const name = String(obj.title || obj.name).trim();
            const price = Number(String(obj.price).replace(/[^0-9]/g, ''));
            if (name && price > 500 && !seen.has(name)) {
              seen.add(name);
              items.push({ name, price: price < 10000 ? price * 10 : price, desc: String(obj.description || '').trim(), category: cat });
            }
          }
          Object.keys(obj).forEach(k => traverse(obj[k], cat));
        };
        traverse(data);
      } catch (e) {}
    }

    if (items.length === 0) {
      console.log('⚠️ ساختار JSON یافت نشد. درحال جستجو در تگ‌های HTML و متون...');
      const cleanHtml = html.replace(/<(?:h1|h2|h3|h4|strong|b)[^>]*>([^<]+)<\/(?:h1|h2|h3|h4|strong|b)>/gi, '\n---CAT---$1\n').replace(/<[^>]+>/g, '\n');
      const lines = cleanHtml.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      let cat = 'منوی رستوران‌یار';
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith('---CAT---')) { cat = lines[i].replace('---CAT---', '').trim(); continue; }
        if (/(?:تومان|ریال)/.test(lines[i]) || /\b\d{5,8}\b/.test(lines[i])) {
          const price = Number(lines[i].replace(/[^0-9]/g, ''));
          if (price >= 5000) {
            let name = '';
            for (let j = i - 1; j >= Math.max(0, i - 3); j--) {
              if (lines[j] && !lines[j].startsWith('---CAT---') && lines[j].length < 45 && !/\d{4,}/.test(lines[j])) {
                name = lines[j]; break;
              }
            }
            if (name && !seen.has(name)) {
              seen.add(name);
              items.push({ name, price: price < 5000 ? price * 1000 : price, desc: '', category: cat });
            }
          }
        }
      }
    }

    console.log(`✅ تعداد ${items.length} محصول استخراج شد.`);
    if (items.length === 0) {
      console.log('❌ آیتمی یافت نشد.');
      return;
    }

    let added = 0;
    for (const item of items) {
      await prisma.product.create({
        data: {
          name: item.name,
          price: item.price,
          desc: item.desc,
          active: true,
          image: '/images/menu/coffee.svg',
        }
      });
      added++;
    }
    console.log(`🎉 با موفقیت ${added} محصول در دیتابیس ذخیره شد!`);
  } catch (err) {
    console.error('❌ خطا:', err.message);
  } finally {
    await prisma.$disconnect();
  }
}

run();
