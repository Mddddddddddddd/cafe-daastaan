# نسخه آماده دانلود و جایگزینی

من فایل‌های پروژه را داخل workspace اصلاح کردم.

## کار تو
1. کل پوشه `cafe-dastan` را دانلود کن
2. روی نسخه لوکال خودت overwrite کن
3. backend را اجرا کن:
```bash
cd cafe-dastan/backend
npm install
npm run start:dev
```
4. frontend را اجرا کن:
```bash
cd cafe-dastan/frontend
npm install
npm run dev
```

## اگر frontend کش قدیمی داشت
```bash
cd cafe-dastan/frontend
rmdir /s /q .next
npm run dev
```

## اگر backend watch خطا داد
مطمئن شو این فایل‌های جدید جایگزین شده‌اند:
- `backend/src/modules/orders/orders.service.ts`
- `backend/src/modules/staff/staff.service.ts`

## نکته
این نسخه هنوز in-memory است و مرحله بعدی، اتصال به دیتابیس واقعی Prisma/PostgreSQL خواهد بود.


## نهایی‌سازی امنیت و مالکیت مشتری
- خطای backend مربوط به `awardLoyaltyForFeedback` و `rewardDiscountMeta` کامل رفع شد.
- مالکیت سفارش برای `GET /orders/:id` از سمت backend اجباری شد و فقط صاحب همان سفارش با توکن مشتری خودش می‌تواند رهگیری را ببیند.
- مالکیت نظرسنجی برای `GET /feedback/order/:id` و `POST /feedback` از سمت backend اجباری شد.
- امتیاز نظرسنجی دیگر روی `guest-1` ذخیره نمی‌شود و به مشتری واقعی همان سفارش وصل می‌شود.
- مسیرهای customer برای استوری/لایک/کامنت/حذف استوری به توکن مشتری وصل شدند و دیگر به `ownerId` ارسالی از frontend اعتماد نمی‌شود.
- مسیر نوتیفیکیشن‌ها از `customerId` query جدا شد و از توکن مشتری واقعی خوانده می‌شود.
- صفحه‌های `tracking/[id]` و `feedback/[id]` در frontend هم بدون فلش محتوای صفحه، قبل از نمایش بررسی ورود مشتری می‌شوند.

### نکته مهم اجرا روی سیستم شما
چون backend و auth و prisma قبلاً تغییر داشته، بعد از جایگذاری فایل‌ها این‌ها را انجام بده:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\backend
npm install
npm run prisma:generate
npm run prisma:push
npm run build
```

و برای frontend:

```cmd
cd C:\Users\Mohamad\cafe-dastan\cafe-dastan\frontend
npm install
npm run build
```

بعد **هردو سرویس frontend و backend را کامل stop/restart کن**.

### AUTH_ENFORCE
- اگر `AUTH_ENFORCE=false` باشد، dev bypass برای بعضی مسیرهای محافظت‌شده backend فعال می‌ماند.
- اگر `AUTH_ENFORCE=true` باشد، بدون توکن معتبر هیچ route محافظت‌شده‌ای عبور نمی‌کند.
- برای تست واقعی امنیت مالکیت مشتری، بهتر است روی سیستم خودت `AUTH_ENFORCE=true` بگذاری.
