# تغییر ۱۳۲ — جلوگیری از افتادن به حالت دمو + رفع باگ ثبت محصول

## باگ اصلی (دلیل «پاک شدن» محصولات)
وارد کردن مشتری با OTP → `customer.upsert` با `username: user_<4 رقم آخر تلفن>` →
دو مشتری با ۴ رقم پایانی یکسان → **خطای unique (P2002)** →
`markUnavailable` کل بک‌اند را به **حافظه/دمو** می‌برد → همه داده‌ها پنهان می‌شدند.

## اصلاح‌ها
1. **`auth.service.ts`**: username جدید = `user_<شماره کامل تلفن>` (تلفن @unique است → دیگر برخوردی نیست)
2. **`prisma.service.ts`**: `markUnavailable` فقط برای **خطای اتصال واقعی (P1xxx)** fallback می‌کند؛
   خطای سطح داده (P2xxx) لاگ می‌شود و بک‌اند **روی PostgreSQL می‌ماند**
3. **۳ نقطه‌ی retry** (`createDiscount`, `createProduct`, `answerSpecialAction`):
   guard اضافه شد — اگر fallback واقعی نشده باشد، به‌جای ری‌ورشن بی‌نهایت، **خطای واقعی به فرانت برمی‌گردد**

## اثر
- ثبت محصول با خطای واقعی (مثلاً مشکل DB) دیگر کل سایت را دمو نمی‌کند
- پیام خطای دقیق به پنل ادمین می‌رسد

## تست‌ها (لوکال)
- build بک‌اند ✅
- ثبت محصول (حالت حافظه) ✅
- منو ✅
- (مسیر DB روی سرور با تست curl تأیید شد: success:true)

## Deploy
```bash
cd /var/www
unzip -o /مسیر/فایل/cafe-dastan-final-customer-scoped-complete.zip
cd /var/www/cafe-dastan/backend
npm install
npm run build
pm2 restart cafe-dastan-backend
```
- فرانت تغییر نکرده → نیازی به rebuild فرانت نیست
- schema دیتابیس تغییر نکرده → prisma:push لازم نیست

## یادآوری‌های سرور
- `sudo nginx -T | grep client_max_body_size` باید 550m و 30m را نشان دهد (برای عکس حجیم محصول)
  - فایل‌های فعال: `sites-available/api.cafedaastaan.ir` و `sites-available/cafedaastaan.ir` (پسوند .ir!)
- محصول تستی «تست دیباگ» در DB هست؛ از پنل حذفش کن
