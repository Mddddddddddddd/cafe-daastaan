# System Architecture

## Recommended Stack
### Frontend
- Next.js (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion
- Zustand or Redux Toolkit
- TanStack Query
- PWA support

### Backend
- NestJS
- PostgreSQL
- Prisma ORM
- Redis (cache, queues, rate-limit support)
- Socket.IO or WebSocket Gateway for realtime

### Infra / Services
- SMS OTP provider
- Push notifications (Web Push / Firebase Cloud Messaging if needed)
- S3-compatible object storage for images/videos
- Printer bridge for kitchen/bar printers
- POS integration adapter layer

## Why this stack
- Scalable multi-role architecture
- Strong support for realtime workflows
- Clean separation between customer app and operations panels
- Secure auth and RBAC
- Excellent DX for long-term maintainability

## Apps
1. Customer PWA
2. Admin Dashboard
3. Kitchen Display
4. Bar Display
5. Waiter Console
6. Auth Service / API Gateway

## Core backend modules
- Auth Module (OTP, JWT, refresh token, session management)
- Users Module
- Roles & Permissions Module (RBAC)
- Branch Module
- Tables Module
- Menu Module
- Product Module
- Inventory Module
- Orders Module
- Order Item Customization Module
- Kitchen Module
- Bar Module
- Waiter Module
- Payment Module
- Notification Module
- Story Engine Module
- Recommendation Module
- Reporting Module
- Settings Module
- Printer/POS Integration Module

## Realtime events
- order.created
- order.accepted
- order.item.bar.started
- order.item.kitchen.started
- order.item.ready
- order.serving
- order.delivered
- customer.call_waiter
- inventory.low_stock
- admin.broadcast

## Security
- OTP login for customers
- Separate secure login for admin, kitchen, bar
- JWT access token + refresh token
- Role-based access control
- Rate limiting
- Audit logs
- Input validation
- Device/session management

## Data model highlights
### User
- id
- phone
- name
- preferred_language
- story_profile
- favorite_items
- last_visit_at

### Employee
- id
- role
- branch_id
- pin/login credentials
- active status

### Product
- id
- type (food/drink)
- name_fa / name_en / name_ar
- story_text
- ingredients
- allergens
- caffeine_level
- sweetness_level
- bitterness_level
- calories
- prep_time
- inventory_count
- character_name
- brand_color
- emoji
- pairings
- music_link

### Order
- id
- branch_id
- customer_id
- order_type
- table_id
- payment_status
- order_status
- story_badges
- created_at

### OrderItem
- id
- order_id
- product_id
- station (bar/kitchen)
- customizations
- status
- timer_started_at

## Deployment approach
- Monorepo
- apps/customer
- apps/admin
- apps/bar
- apps/kitchen
- apps/waiter
- apps/api
- packages/ui
- packages/config
- packages/types
